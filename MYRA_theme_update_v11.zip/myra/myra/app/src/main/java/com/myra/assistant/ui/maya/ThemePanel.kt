package com.myra.assistant.ui.maya

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.ai.PredictiveEngine
import com.myra.assistant.utils.Constants

/** Prefs read by the home screen / input bar. Same file the rest of the app uses. */
object PredictivePrefs {
    fun enabled(c: Context) = c.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getBoolean("predictive_enabled", true)
    fun typing(c: Context) = c.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getBoolean("predictive_typing", true)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemePanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    var predOn by remember { mutableStateOf(PredictivePrefs.enabled(ctx)) }
    var typeOn by remember { mutableStateOf(PredictivePrefs.typing(ctx)) }
    var habitsTick by remember { mutableStateOf(0) }
    val habits = remember(habitsTick) { PredictiveEngine.peek(ctx, 5) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Theme & Predictive", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(14.dp))

            // live preview: it changes the moment anything below is touched
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(MC.BgTop, MC.LightBg, MC.BgBottom))).padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.AutoAwesome, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Maya", color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Ei hocche tomar notun look", color = MC.Sub, fontSize = 13.sp)
                    }
                    Text("OK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(MC.BlueDeep).padding(horizontal = 14.dp, vertical = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text("Hint text", color = MC.Hint, fontSize = 13.sp)
            }

            Label("Mode")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    Pill(m.bn, ThemeStore.mode == m, Modifier.weight(1f)) { ThemeStore.update(ctx) { mode = m } }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (ThemeStore.mode) {
                    ThemeMode.AUTO -> "Sondhya 7 ta theke bhor 6 ta porjonto dark."
                    ThemeMode.SYSTEM -> "Phone-er dark / light setting onujayi."
                    else -> ""
                }, color = MC.Sub, fontSize = 12.sp
            )

            Label("Rong")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Accents.all.forEach { a ->
                    val sel = ThemeStore.accentKey == a.key
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(a.light, a.deep)))
                            .then(if (sel) Modifier.border(BorderStroke(3.dp, MC.Navy), CircleShape) else Modifier)
                            .clickable { ThemeStore.update(ctx) { accentKey = a.key } },
                        contentAlignment = Alignment.Center
                    ) { if (sel) Icon(Icons.Filled.Check, a.label, tint = Color.White) }
                }
            }

            Label("Aro")
            SwitchRow("AMOLED black", "Dark mode-e pure kalo background (battery bachay)", ThemeStore.amoled) { on ->
                ThemeStore.update(ctx) { amoled = on; if (on && !isDark) mode = ThemeMode.DARK }
            }
            SwitchRow("Background glow", "Pichone halka rongin alo", ThemeStore.glow) { on -> ThemeStore.update(ctx) { glow = on } }
            SliderRow("Maya-r mood-er rong", "${(ThemeStore.moodStrength * 100).toInt()}%", ThemeStore.moodStrength, 0f..1f) { v ->
                ThemeStore.update(ctx) { moodStrength = v }
            }
            SliderRow("Lekhar size", "${(ThemeStore.fontScale * 100).toInt()}%", ThemeStore.fontScale, 0.85f..1.3f) { v ->
                ThemeStore.update(ctx) { fontScale = (Math.round(v * 20f) / 20f) }
            }
            Text("Voice-e bolte paro: \"dark mode on koro\", \"theme pink\", \"auto theme\", \"amoled on\", \"font boro koro\".",
                color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            Text("Reset", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(12.dp)).clickable { ThemeStore.reset(ctx) }.padding(vertical = 6.dp, horizontal = 4.dp))

            Label("Privacy")
            var privacy by remember { mutableStateOf(com.myra.assistant.system.PrivacyMode.active) }
            SwitchRow("Privacy mode", "Maya nijer theke bolbe na, screen / notification porbe na, kichu shikhbe na, chat lukano thakbe. Voice: \"privacy mode on / off\"",
                com.myra.assistant.system.PrivacyMode.active) { privacy = it; com.myra.assistant.system.PrivacyMode.set(ctx, it) }
            Text("Mic chalu thakle tomar kotha ekhono Maya-r kache jay; mic bondho korle ta-o bondho.", color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))

            Label("Predictive")
            SwitchRow("Tomar jonno suggestion", "Home-e ei shomoyer abhyash onujayi card; Maya nijeo jiggesh kore", predOn) {
                predOn = it; prefs.edit().putBoolean("predictive_enabled", it).apply()
            }
            SwitchRow("Likhar shomoy completion", "Age ja likhecho, shuru korle seta dekhay", typeOn) {
                typeOn = it; prefs.edit().putBoolean("predictive_typing", it).apply()
            }
            Text(
                if (habits.isEmpty()) "Ekhono kichu shikhini. Ekoi kaj alada 2-3 din ekoi shomoy korle ekhane dekhabe."
                else "Ei shomoy tumi shadharonoto: " + habits.joinToString(", ") { "${it.title} (${it.days} din)" },
                color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            Text("Shikha data muche felo", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(12.dp)).clickable {
                    PredictiveEngine.clearAll(ctx); habitsTick++
                    Toast.makeText(ctx, "Shob shikha data muche dilam", Toast.LENGTH_SHORT).show()
                }.padding(vertical = 6.dp, horizontal = 4.dp))
            Text("Ei shikha shudhu ei phone-e thake. Maya shudhu jiggesh kore ba card dekhay, nijer theke kono kaj chalay na.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
private fun Pill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(46.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2,
            modifier = Modifier.padding(horizontal = 4.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(sub, color = MC.Sub, fontSize = 13.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun SliderRow(title: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(value, color = MC.Sub, fontSize = 14.sp)
        }
        Slider(v, onChange, valueRange = range)
    }
}
