package com.myra.assistant.ui.maya

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.overlay.EdgeGlowController
import com.myra.assistant.utils.Constants
import com.myra.assistant.voice.PhoneEventMonitor

class MayaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        PersistentMemory.init(this)
        // charger / battery / wifi announcements and the mic edge-light run from the moment the app opens
        PhoneEventMonitor.start(applicationContext)
        EdgeGlowController.start(applicationContext)
        // rooted phone: allow everything in the background (no-op on a normal phone)
        Thread {
            if (com.myra.assistant.utils.RootAccess.request(applicationContext)) com.myra.assistant.system.PermissionGranter.grantAll(applicationContext)
        }.start()
        val prefs = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        setContent {
            var done by remember { mutableStateOf(prefs.getBoolean("onboarded", false)) }
            MayaTheme(forceDarkBars = !done) { if (done) MayaApp() else OnboardingScreen { done = true } }
        }
    }

    override fun onResume() {
        super.onResume()
        // overlay permission may have just been granted: show the floating voice button
        if (com.myra.assistant.services.ForegroundVoiceService.isRunning)
            com.myra.assistant.overlay.MicButtonOverlay.show(applicationContext)
    }
}
