package com.myra.assistant.ui.maya

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.util.Calendar

/** How the app picks light or dark. AUTO = dark in the evening and at night (19:00 - 06:00). */
enum class ThemeMode(val bn: String) { LIGHT("Light"), DARK("Dark"), AUTO("Auto (raat e dark)"), SYSTEM("Phone-er moto") }

class AccentPreset(
    val key: String, val label: String,
    val main: Color, val deep: Color, val light: Color,
    // light-theme surfaces tinted with this accent
    val bgTop: Color, val bg: Color, val bgBottom: Color, val cardTop: Color, val card: Color, val ink: Color,
    // only the original blue keeps hand-picked secondary text colours; the rest are blended from ink
    val sub: Color? = null, val hint: Color? = null
)

object Accents {
    val all = listOf(
        AccentPreset("blue", "Blue", Color(0xFF3B8EEA), Color(0xFF1E6FD9), Color(0xFF5CB0FF),
            Color(0xFFEAF1FC), Color(0xFFD9E3F5), Color(0xFFC3D3F0), Color(0xFFF8FAFF), Color(0xFFF1F5FD), Color(0xFF1B2250),
            sub = Color(0xFF4A5680), hint = Color(0xFF8E9AC0)),
        AccentPreset("pink", "Pink", Color(0xFFE0457B), Color(0xFFC72763), Color(0xFFFF7FA8),
            Color(0xFFFCEEF4), Color(0xFFF5DDE8), Color(0xFFEFC6D8), Color(0xFFFFF8FB), Color(0xFFFDF1F6), Color(0xFF3A1830)),
        AccentPreset("purple", "Purple", Color(0xFF8E6CFF), Color(0xFF6C47E0), Color(0xFFB59CFF),
            Color(0xFFF3EEFC), Color(0xFFE6DDF5), Color(0xFFD5C6EF), Color(0xFFFBF8FF), Color(0xFFF6F1FD), Color(0xFF2A1B50)),
        AccentPreset("green", "Green", Color(0xFF2FB36B), Color(0xFF1B9453), Color(0xFF5CD491),
            Color(0xFFE9F7EF), Color(0xFFD7EDE0), Color(0xFFBFE0CD), Color(0xFFF8FFFA), Color(0xFFEFFAF3), Color(0xFF143327)),
        AccentPreset("orange", "Orange", Color(0xFFF08A24), Color(0xFFD96F0B), Color(0xFFFFB066),
            Color(0xFFFCF1E6), Color(0xFFF5E4D2), Color(0xFFEFD2B3), Color(0xFFFFFAF5), Color(0xFFFDF4EB), Color(0xFF40240F)),
        AccentPreset("teal", "Teal", Color(0xFF18A9B5), Color(0xFF0C8A96), Color(0xFF5CD3DE),
            Color(0xFFE6F6F7), Color(0xFFD3EBEC), Color(0xFFB9DEE0), Color(0xFFF7FEFF), Color(0xFFEDF9FA), Color(0xFF12343A))
    )
    fun byKey(k: String) = all.firstOrNull { it.key == k } ?: all[0]
}

/** One resolved set of colours (light or dark, with the chosen accent). */
class Palette(
    val dark: Boolean,
    val bgTop: Color, val bg: Color, val bgBottom: Color,
    val cardTop: Color, val card: Color,
    val ink: Color, val sub: Color, val hint: Color,
    val accent: Color, val accentDeep: Color, val accentLight: Color,
    val bubble: Color, val shadowAmbient: Color, val shadowSpot: Color
)

private fun buildPalette(dark: Boolean, a: AccentPreset, amoled: Boolean): Palette =
    if (!dark) Palette(
        false, a.bgTop, a.bg, a.bgBottom, a.cardTop, a.card, a.ink,
        a.sub ?: lerp(a.ink, a.bg, 0.35f), a.hint ?: lerp(a.ink, a.bg, 0.60f),
        a.main, a.deep, a.light, Color.White, Color.White, Color(0x663B5A9A)
    ) else {
        // dark surfaces carry a faint hint of the accent so the theme still feels like "yours"
        fun tint(c: Long) = lerp(Color(c), a.main, 0.06f)
        Palette(
            true,
            if (amoled) Color(0xFF000000) else tint(0xFF151C31),
            if (amoled) Color(0xFF000000) else tint(0xFF0E1424),
            if (amoled) Color(0xFF000000) else tint(0xFF0A0F1C),
            if (amoled) Color(0xFF1A1B22) else tint(0xFF232D49),
            if (amoled) Color(0xFF121218) else tint(0xFF1A2238),
            Color(0xFFF2F5FF), Color(0xFFA9B4D0), Color(0xFF7A85A8),
            a.main, a.deep, a.light,
            if (amoled) Color(0xFF1A1B22) else tint(0xFF1F2842), Color(0x00000000), Color(0xCC000000)
        )
    }

/**
 * All theme settings. They are Compose state, so changing any of them (from the Theme panel, or by voice with
 * `THEME dark`) repaints the whole app straight away, and they are saved in SharedPreferences.
 */
object ThemeStore {
    private const val PREFS = "myra_prefs"
    private var inited = false

    var mode by mutableStateOf(ThemeMode.LIGHT)          // default keeps the original look
    var accentKey by mutableStateOf("blue")
    var amoled by mutableStateOf(false)
    var moodStrength by mutableStateOf(1f)               // 0..1: how much her feeling colours the screen
    var glow by mutableStateOf(true)                     // soft colour glows in the background
    var fontScale by mutableStateOf(1f)                  // 0.85..1.3
    var systemDark by mutableStateOf(false)
    var hour by mutableStateOf(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))

    val isDark: Boolean get() = when (mode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.AUTO -> hour >= 19 || hour < 6
    }

    private val pal: Palette by derivedStateOf { buildPalette(isDark, Accents.byKey(accentKey), amoled) }
    fun palette(): Palette = pal

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        inited = true
        val app = ctx.applicationContext
        systemDark = (app.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        mode = runCatching { ThemeMode.valueOf(p.getString("theme_mode", "LIGHT") ?: "LIGHT") }.getOrDefault(ThemeMode.LIGHT)
        accentKey = Accents.byKey(p.getString("theme_accent", "blue") ?: "blue").key
        amoled = p.getBoolean("theme_amoled", false)
        moodStrength = p.getFloat("theme_mood", 1f).coerceIn(0f, 1f)
        glow = p.getBoolean("theme_glow", true)
        fontScale = p.getFloat("theme_font", 1f).coerceIn(0.85f, 1.3f)
    }

    /** Re-read the saved values (after a sync restore). */
    fun reload(ctx: Context) { inited = false; init(ctx) }

    private fun save(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("theme_mode", mode.name).putString("theme_accent", accentKey).putBoolean("theme_amoled", amoled)
            .putFloat("theme_mood", moodStrength).putBoolean("theme_glow", glow).putFloat("theme_font", fontScale).apply()
    }

    fun update(ctx: Context, change: ThemeStore.() -> Unit) { init(ctx); change(); save(ctx) }

    fun reset(ctx: Context) = update(ctx) {
        mode = ThemeMode.LIGHT; accentKey = "blue"; amoled = false; moodStrength = 1f; glow = true; fontScale = 1f
    }

    // ---- voice / typed control: THEME <words> ----

    private val ACCENT_WORDS = mapOf(
        "blue" to "blue", "নীল" to "blue", "neel" to "blue", "nil" to "blue",
        "pink" to "pink", "গোলাপি" to "pink", "golapi" to "pink", "গোলাপী" to "pink",
        "purple" to "purple", "বেগুনি" to "purple", "beguni" to "purple", "violet" to "purple",
        "green" to "green", "সবুজ" to "green", "sobuj" to "green",
        "orange" to "orange", "কমলা" to "orange", "komola" to "orange",
        "teal" to "teal", "cyan" to "teal", "ফিরোজা" to "teal"
    )
    private val DARK_W = setOf("dark", "ডার্ক", "night", "রাত", "black")
    private val LIGHT_W = setOf("light", "লাইট", "day", "দিন", "white")
    private val AUTO_W = setOf("auto", "অটো", "automatic")
    private val SYSTEM_W = setOf("system", "সিস্টেম", "phone")
    private val OFF_W = setOf("off", "band", "bondho", "বন্ধ", "অফ", "false", "no")
    private val BIGGER_W = setOf("bigger", "big", "larger", "boro", "bora", "বড়", "বড়", "increase", "badhao", "বাড়াও")
    private val SMALLER_W = setOf("smaller", "small", "choto", "ছোট", "decrease", "komao", "কমাও")

    /** Runs a THEME command and returns a short confirmation in Banglish for Maya to say. */
    fun apply(ctx: Context, raw: String): String {
        init(ctx)
        val t = raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()
        val w = t.split(' ').filter { it.isNotEmpty() }
        if (w.isEmpty()) return "Kon theme? dark, light, auto, ba rong (blue, pink, purple, green, orange, teal) bolo."
        // predictive controls: "predictive off", "typing suggestion off", "predictive data muche felo"
        if (w.any { it in setOf("predictive", "prediction", "suggestion", "suggestions", "সাজেশন", "autocomplete") }) {
            val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (w.any { it in setOf("forget", "clear", "muche", "মুছে", "delete", "bhule") }) {
                com.myra.assistant.ai.PredictiveEngine.clearAll(ctx.applicationContext)
                return "Shob shikha data muche dilam."
            }
            val on = w.none { it in OFF_W }
            return if (w.any { it in setOf("typing", "autocomplete", "likhar", "লেখার") }) {
                sp.edit().putBoolean("predictive_typing", on).apply()
                if (on) "Likhar completion chalu korlam." else "Likhar completion bondho korlam."
            } else {
                sp.edit().putBoolean("predictive_enabled", on).apply()
                if (on) "Predictive suggestion chalu korlam." else "Predictive suggestion bondho korlam."
            }
        }
        if (w.any { it == "reset" || it == "default" || it == "ডিফল্ট" }) { reset(ctx); return "Theme ager moto kore dilam." }

        val done = ArrayList<String>()
        val off = w.any { it in OFF_W }
        update(ctx) {
            if (w.any { it == "amoled" || it == "oled" }) {
                amoled = !off
                if (amoled) { mode = ThemeMode.DARK; done += "AMOLED black dark theme" } else done += "AMOLED off"
            }
            if (w.any { it == "mood" || it == "মুড" }) {
                val n = w.firstNotNullOfOrNull { it.toIntOrNull() }
                moodStrength = when { n != null -> (n / 100f).coerceIn(0f, 1f); off -> 0f; else -> 1f }
                done += "mood-er rong ${(moodStrength * 100).toInt()}%"
            }
            if (w.any { it == "glow" || it == "glo" }) { glow = !off; done += if (glow) "glow on" else "glow off" }
            if (w.any { it in setOf("font", "text", "size", "ফন্ট", "লেখা", "সাইজ") }) {
                when {
                    w.any { it in BIGGER_W } -> fontScale = (fontScale + 0.1f).coerceAtMost(1.3f)
                    w.any { it in SMALLER_W } -> fontScale = (fontScale - 0.1f).coerceAtLeast(0.85f)
                    else -> fontScale = 1f
                }
                done += "lekhar size ${(fontScale * 100).toInt()}%"
            }
            val acc = w.firstNotNullOfOrNull { ACCENT_WORDS[it] }
            if (acc != null) { accentKey = acc; done += "${Accents.byKey(acc).label} rong" }
            val newMode = when {
                w.any { it in AUTO_W } -> ThemeMode.AUTO
                w.any { it in SYSTEM_W } -> ThemeMode.SYSTEM
                w.any { it in DARK_W } -> if (off) ThemeMode.LIGHT else ThemeMode.DARK
                w.any { it in LIGHT_W } -> if (off) ThemeMode.DARK else ThemeMode.LIGHT
                else -> null
            }
            if (newMode != null && !w.any { it == "amoled" || it == "oled" }) {
                mode = newMode
                done += when (newMode) {
                    ThemeMode.DARK -> "dark mode"
                    ThemeMode.LIGHT -> "light mode"
                    ThemeMode.AUTO -> "auto mode (raat e dark)"
                    ThemeMode.SYSTEM -> "phone-er theme"
                }
            }
        }
        return if (done.isEmpty()) "Eta bujhini. Dark, light, auto, ba rong (blue, pink, purple, green, orange, teal) bolo."
        else "Ho gaya: " + done.joinToString(", ") + "."
    }
}

/** The old names stay, so every existing `MC.Navy` / `MC.Card` now follows the chosen theme automatically. */
object MC {
    // Light group: follows light / dark and the accent
    val LightBg get() = ThemeStore.palette().bg
    val BgTop get() = ThemeStore.palette().bgTop
    val BgBottom get() = ThemeStore.palette().bgBottom
    val Card get() = ThemeStore.palette().card
    val CardTop get() = ThemeStore.palette().cardTop
    val Bubble get() = ThemeStore.palette().bubble
    val Navy get() = ThemeStore.palette().ink
    val Sub get() = ThemeStore.palette().sub
    val Hint get() = ThemeStore.palette().hint
    val Blue get() = ThemeStore.palette().accent
    val BlueDeep get() = ThemeStore.palette().accentDeep
    val AccentLight get() = ThemeStore.palette().accentLight
    val ShadowAmbient get() = ThemeStore.palette().shadowAmbient
    val ShadowSpot get() = ThemeStore.palette().shadowSpot
    val IsDark get() = ThemeStore.palette().dark
    val Dot = Color(0xFFD62F6E)
    // Dark (onboarding): always dark, not part of the theme
    val DarkBg = Color(0xFF0B1120)
    val DarkCard = Color(0xFF182036)
    val DarkBorder = Color(0xFF2A3350)
    val DarkText = Color(0xFFFFFFFF)
    val DarkSub = Color(0xFF9AA4BD)
    val Accent = Color(0xFF4A7BFF)
    val PendingFg = Color(0xFFFF9800)
    val PendingBg = Color(0xFF3A2A22)
    val DoneFg = Color(0xFF3DDC84)
    val DoneBg = Color(0xFF173226)
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/**
 * Wraps the app: loads the saved theme, keeps system / time-of-day mode current, applies the text-size setting,
 * sets Material colours (dialogs, switches, sliders) and the status bar icon colour.
 * [forceDarkBars] is for screens that are always dark (onboarding).
 */
@Composable
fun MayaTheme(forceDarkBars: Boolean = false, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    remember { ThemeStore.init(ctx); true }
    val sysDark = isSystemInDarkTheme()
    SideEffect { ThemeStore.systemDark = sysDark }
    LaunchedEffect(Unit) {
        while (true) { ThemeStore.hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); delay(60_000) }
    }
    val p = ThemeStore.palette()
    val view = LocalView.current
    val darkBars = forceDarkBars || p.dark
    if (!view.isInEditMode) SideEffect {
        val window = ctx.findActivity()?.window
        if (window != null) WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !darkBars
            isAppearanceLightNavigationBars = !darkBars
        }
    }
    val scheme = if (p.dark) darkColorScheme(
        primary = p.accent, onPrimary = Color.White, surface = p.card, onSurface = p.ink,
        background = p.bg, onBackground = p.ink, surfaceVariant = p.cardTop, onSurfaceVariant = p.sub,
        surfaceContainerHigh = p.card, surfaceContainer = p.card
    ) else lightColorScheme(
        primary = p.accentDeep, onPrimary = Color.White, surface = p.card, onSurface = p.ink,
        background = p.bg, onBackground = p.ink, surfaceVariant = p.cardTop, onSurfaceVariant = p.sub,
        surfaceContainerHigh = p.card, surfaceContainer = p.card
    )
    val base = LocalDensity.current
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * ThemeStore.fontScale)) {
            content()
        }
    }
}
