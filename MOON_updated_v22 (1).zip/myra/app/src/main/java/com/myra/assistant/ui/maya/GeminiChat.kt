package com.myra.assistant.ui.maya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Text / vision chat against Gemini REST. Key is sent in a header, never in the URL. */
object GeminiChat {
    const val MODEL = com.myra.assistant.utils.Constants.GEMINI_CHAT_MODEL
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()

    suspend fun testKey(key: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("$BASE/models?pageSize=1")
                .header("x-goog-api-key", key.trim()).build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    suspend fun ask(
        key: String,
        history: List<Pair<Boolean, String>>, // (fromUser, text)
        userText: String,
        imageB64: String? = null,
        mime: String = "image/jpeg",
        system: String = "You are Moon, a warm, helpful assistant. Reply in the language the user speaks: Bangla (Bengali script or Banglish) or English. Keep replies short and friendly. Remember the user's custom memory facts."
    ): String = withContext(Dispatchers.IO) {
        try {
            val contents = JSONArray()
            history.takeLast(20).forEach { (u, t) ->
                contents.put(JSONObject().put("role", if (u) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            val parts = JSONArray().put(JSONObject().put("text", userText))
            if (imageB64 != null) parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", mime).put("data", imageB64)))
            contents.put(JSONObject().put("role", "user").put("parts", parts))
            val body = JSONObject().put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", system))))
            val req = Request.Builder().url("$BASE/models/$MODEL:generateContent")
                .header("x-goog-api-key", key.trim())
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@withContext "Error ${r.code}: " +
                    (runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("request failed"))
                JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
        } catch (e: Exception) { "Network error: ${e.message}" }
    }

    /** Pulls short, durable facts about the user out of text / a document (resume etc.). */
    suspend fun extractFacts(key: String, text: String, b64: String? = null, mime: String = "application/pdf"): List<String> {
        val r = ask(key, emptyList(),
            "Extract up to 12 short durable facts about the user from the content below (name, work, skills, preferences, family, goals). " +
                "Return ONLY one fact per line, no numbering, no extra words. If there is nothing useful, return nothing.\n\n$text",
            b64, mime, "You extract user facts. Output plain lines only.")
        if (r.startsWith("Error") || r.startsWith("Network")) return emptyList()
        return r.lines().map { it.trim().trimStart('-', '•', '*', ' ') }.filter { it.length in 4..200 }.take(12)
    }

    // ------------------------------------------------------------------------------------------
    // Typed chat that can actually DO things: phone actions + live Google search.
    // ------------------------------------------------------------------------------------------
    private const val FALLBACK_MODEL = "gemini-3.8-flash"

    private fun fn(name: String, desc: String, prop: String, propDesc: String) = JSONObject().apply {
        put("name", name); put("description", desc)
        put("parameters", JSONObject().apply {
            put("type", "OBJECT")
            put("properties", JSONObject().put(prop, JSONObject().put("type", "STRING").put("description", propDesc)))
            put("required", JSONArray().put(prop))
        })
    }

    private val TOOLS: JSONArray by lazy {
        JSONArray().put(JSONObject().put("functionDeclarations", JSONArray()
            .put(fn("phone_action",
                "Perform an action on the phone. Call it whenever the user asks to open an app, call or message someone, " +
                    "play something, torch, volume, wifi/bluetooth/etc, go home/back, or look at the screen.",
                "command",
                "Exactly one of: OPEN_APP <n> | CALL <n> | WHATSAPP_CALL <n> | WHATSAPP_MSG <n> <message> | YOUTUBE_PLAY <query> | " +
                    "SPOTIFY_PLAY <query> | FLASHLIGHT_ON | FLASHLIGHT_OFF | VOLUME_UP | VOLUME_DOWN | HOME | BACK | RECENTS | " +
                    "NOTIFICATIONS | READ_NOTIFICATIONS | SMS <n> | <message> | REPLY_NOTIFICATION <message> | READ_SCREEN | " +
                    "SYSTEM <wifi|bluetooth|mobile_data|airplane|dnd|lock> <on|off> | BRIGHTNESS <0-100> | ROOT <status|wifi|data|bluetooth|airplane|dnd|gps|hotspot|nfc|autosync|autorotate|ringer|battery_saver|brightness|volume|lock|screenshot|stop|clearcache|grant|install|uninstall|reboot> [args]"))
            .put(fn("web_search",
                "Search Google live. Use for news, prices, scores, weather, facts about people/places/products, " +
                    "or anything that may have changed recently.",
                "query", "What to search for."))))
    }

    private fun post(key: String, model: String, body: JSONObject): Pair<Int, String> {
        val req = Request.Builder().url("$BASE/models/$model:generateContent")
            .header("x-goog-api-key", key.trim())
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        return client.newCall(req).execute().use { r -> r.code to r.body?.string().orEmpty() }
    }

    private fun errMsg(code: Int, txt: String) = "Error $code: " +
        runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("request failed")

    /** Blocking Google-grounded search for other classes (call it off the main thread). */
    fun groundedSearch(key: String, query: String): String = grounded(key, query)

    /** One grounded Google search, answered in plain text. */
    private fun grounded(key: String, query: String): String {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", query)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        for (m in listOf(MODEL, FALLBACK_MODEL)) {
            val (code, txt) = post(key, m, body)
            if (code in 200..299) {
                val parts = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                return (0 until parts.length()).mapNotNull { parts.getJSONObject(it).optString("text").takeIf { t -> t.isNotEmpty() } }
                    .joinToString("").take(4000)
            }
            if (code !in listOf(404, 400, 503, 429, 500)) return errMsg(code, txt)
        }
        return "search failed"
    }

    suspend fun askAgent(
        key: String,
        history: List<Pair<Boolean, String>>,
        userText: String,
        imageB64: String? = null,
        mime: String = "image/jpeg",
        system: String,
        runPhone: suspend (String) -> String
    ): String = withContext(Dispatchers.IO) {
        try {
            val contents = JSONArray()
            history.takeLast(20).forEach { (u, t) ->
                contents.put(JSONObject().put("role", if (u) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            val parts = JSONArray().put(JSONObject().put("text", userText))
            if (imageB64 != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", imageB64)))
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            val sys = system + "\nYou can act on the phone with phone_action and search the internet with web_search. " +
                "When the user asks you to do something on the phone, call phone_action instead of just talking about it. " +
                "For anything recent or factual, call web_search first. After a tool returns, answer in one or two short sentences."
            var model = MODEL
            var last = ""
            repeat(6) {
                val body = JSONObject().put("contents", contents).put("tools", TOOLS)
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                var (code, txt) = post(key, model, body)
                if ((code == 404 || code == 400 || code == 503 || code == 429 || code == 500) && model != FALLBACK_MODEL) {   // model name not available for this key
                    model = FALLBACK_MODEL
                    val r = post(key, model, body); code = r.first; txt = r.second
                }
                if (code !in 200..299) return@withContext errMsg(code, txt)

                val cand = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)
                    ?: return@withContext "Kono uttor ashe nai (safety block hote pare). Abar chesta koro."
                val content = cand.optJSONObject("content") ?: return@withContext last.ifBlank { "Kono uttor ashe nai." }
                val ps = content.optJSONArray("parts") ?: JSONArray()
                val calls = (0 until ps.length()).map { ps.getJSONObject(it) }.filter { it.has("functionCall") }
                val text = (0 until ps.length()).mapNotNull { ps.getJSONObject(it).optString("text").takeIf { t -> t.isNotEmpty() } }.joinToString("")
                if (text.isNotBlank()) last = text
                if (calls.isEmpty()) return@withContext text.ifBlank { last.ifBlank { "Hoye geche." } }

                contents.put(JSONObject().put("role", "model").put("parts", ps))
                val resp = JSONArray()
                for (c in calls) {
                    val f = c.getJSONObject("functionCall")
                    val name = f.optString("name")
                    val args = f.optJSONObject("args") ?: JSONObject()
                    val result = try {
                        when (name) {
                            "phone_action" -> runPhone(args.optString("command")).ifBlank { "done" }
                            "web_search" -> grounded(key, args.optString("query"))
                            else -> "unknown function"
                        }
                    } catch (e: Exception) { "failed: ${e.message}" }
                    resp.put(JSONObject().put("functionResponse",
                        JSONObject().put("name", name).put("response", JSONObject().put("result", result))))
                }
                contents.put(JSONObject().put("role", "user").put("parts", resp))
            }
            last.ifBlank { "Kaj ses korte parlam na." }
        } catch (e: Exception) { "Network error: ${e.message}" }
    }
}
