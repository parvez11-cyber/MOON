# MOON source repair notes

Base archive: `MOON_home_brain_full_v4 (1).zip`

## Changes
1. Restored `app/src/main/assets/models/riya.vrm` from the supplied v2 archive because it was absent from v4.
2. Updated `Anime3DAssistantView.kt` so the native loading fallback is released after the main HTML document finishes loading, even if the JavaScript bridge callback is unavailable on a particular WebView build.
3. Added a subtle navy/blue radial CSS background to the animation page so the Home animation surface does not degrade to a flat black rectangle if canvas rendering is unavailable.
4. Kept the existing launcher, Compose UI, permissions, services, and feature code otherwise unchanged.

## Verification
The archive and source files were inspected. A Gradle build was attempted, but the build environment could not resolve `services.gradle.org` (network/DNS unavailable). Therefore this ZIP is source-repaired but not build-verified. Run `./gradlew assembleDebug` in GitHub Actions or Android Studio to confirm compilation on your build environment.
