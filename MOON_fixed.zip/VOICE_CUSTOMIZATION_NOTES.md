# MOON Voice Customization

Settings now includes a Gemini Live voice selector and an ElevenLabs API key + voice ID field. Gemini voice selection is saved to `myra_prefs` (`gemini_voice_name`) and used when the Live session is initialized. ElevenLabs fields are configuration only in this update; ElevenLabs synthesis is not yet wired into speech playback.

Available Gemini preset selector: Aoede, Kore, Leda, Zephyr, Puck, Charon, Fenrir, Orus, Autonoe, Callirrhoe, Enceladus, Iapetus, Umbriel, Algieba, Despina, Erinome, Gacrux, Laomedeia, Schedar, Achernar.
