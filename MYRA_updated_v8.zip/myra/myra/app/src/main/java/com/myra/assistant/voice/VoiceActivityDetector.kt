package com.myra.assistant.voice

import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Logger

class VoiceActivityDetector(
    private val onSpeechStart: () -> Unit,
    private val onSpeechEnd: () -> Unit
) {
    private var noiseFloor = 0.004f
    private val speechThreshold: Float get() = (noiseFloor * 3f).coerceIn(0.012f, 0.04f)
    private val silenceFrames = 18       // ~360 ms with current 20 ms-ish processing
    private val speechFrames = 2
    private var silenceCount = 0
    private var speechCount = 0
    @Volatile private var speechActive = false

    fun processChunk(pcm: ByteArray) {
        val rms = AudioUtils.calculateRms(pcm)
        VoiceStateManager.updateAmplitude(rms)
        if (!speechActive && rms < speechThreshold * 1.5f) noiseFloor = noiseFloor * 0.98f + rms * 0.02f
        if (rms > speechThreshold) {
            silenceCount = 0
            speechCount++
            if (!speechActive && speechCount >= speechFrames) {
                speechActive = true
                Logger.d("VAD", "Speech start rms=$rms")
                onSpeechStart()
            }
        } else {
            speechCount = 0
            if (speechActive) {
                silenceCount++
                if (silenceCount >= silenceFrames) {
                    speechActive = false
                    silenceCount = 0
                    Logger.d("VAD", "Speech end")
                    onSpeechEnd()
                }
            }
        }
    }

    fun isSpeechActive(): Boolean = speechActive

    fun reset() {
        silenceCount = 0
        speechCount = 0
        speechActive = false
    }
}
