# MYRA update: ki ki change holo

## 1. SMS (ager bug gulo)
- `system/SmsSender.kt` (notun). Ager code shudhu prothom shobdo ke naam dhorto ("Rahim bhai" -> "Rahim"), SEND_SMS permission check korto na, ar radio response na dekhei "pathiye dilam" bolto.
- Ekhon: naam onekgulo shobdo hote pare, contact ranking (exact > starts-with > contains), shorashori number dewa jay, lomba message multipart hoy, ar sotti pathalo kina seta Maya bole (network nai / airplane mode ityadi).
- Command format: `SMS <naam> | <message>` (voice prompt update kora).

## 2. Display dekha
- Root cause: `accessibility_service_config.xml` e `canTakeScreenshot` chilo na. Add kora hoyeche.
- `screenvision/ScreenReader.kt` (notun), command `READ_SCREEN`: screen-er shob text/button pare + screenshot Gemini-ke pathay (accessibility screenshot, na hole root `screencap`, text na thakle OCR).
- Screen/notification/SMS-er text ke Maya "data" dhore, order hishebe na (prompt injection theke bachar jonno).

## 3. Manusher moto vabna, emotion, nijer theke khoj neya
- `ai/EmotionEngine.kt`: Maya-r feeling (happy, sad, worried, love, sleepy...). Gemini `express_emotion` function diye set kore; na korle kotha theke anday kore.
- `ai/ProactiveCompanion.kt`: nijer theke kotha bole. Sokal, dupur, raat-er khabar, onek raat, onekkhon kotha na hole, majhe majhe friendly suggestion. Call-e / screen off / tumi kotha bolcho / 90 min er moddhe ar na. Offline hole built-in Bangla line.
  Settings keys (SharedPreferences `myra_prefs`): `proactive_enabled` (true), `proactive_gap_min` (90).
- Gemini `remember_fact` function: tomar kotha shune nijei yaad rakhe.
- System prompt notun: manusher moto feeling, ekta ekta kore suggestion, honest.

## 4. Notification: double bole na, off thakle bole na
- `NotificationReaderService.kt`: alada TTS engine soriye `Announcer` diye (shudhu ekta voice).
- Same notification update/repost hole abar pode na (90s dedupe + same text guard), group summary/media/progress/call ignore.
- Screen off thakle pode na (setting `notification_read_screen_off`, default false). "Read notifications" off thakle pode na (`notification_read_aloud`).

## 5. VRM home page-e
- Notun `assets/riya_floating.html` (ager code ei file-ta khujto kintu chilo na, tai avatar kokhono dekha jeto na). `assets/models/riya.vrm` agei chilo.
- Home page-er character ekhon Riya (3D). Kotha bolle mukh nare (lip-sync), shunle ektu jhuke, emotion onujayi chehara bodlay, tap korle hashe, drag korle ghure.
- three.js + three-vrm prothombar jsDelivr (pinned version) theke load hoy, tarpor WebView cache kore. Pura offline chaile `assets/libs/` e rakho:
  `three.module.js`, `addons/` (three/examples/jsm folder), `three-vrm.module.js`.

## 6. System permission + root
- Manifest-e onek permission add (SMS read/receive, calendar, call log write, background location, wifi/bluetooth, all-files, write settings, usage stats, install, alarms...).
- Drawer-e notun button **"Sob permission do"**:
  - Root phone: shob permission, appops, accessibility, notification access, device admin, battery whitelist chupchap deya hoy.
  - Normal phone: runtime permission dialog, tarpor ek ek kore special screen (overlay, accessibility, notification access, write settings, all files, DND, battery, usage access, device admin).
- `system/SystemSettings.kt`: `SYSTEM wifi|bluetooth|mobile_data|airplane|dnd|lock on|off`, `BRIGHTNESS 0-100`. Root thakle shorashori, na hole system panel khule.
- Ekta fixed whitelist; model-ke "je kono shell command" cholanor path deya hoyni, jate screen/notification-er kono text root command hoye jete na pare.

## Je kotha gulo sotti
- **Android e kono APK nijeke root korte pare na.** Root-er jonno phone age rooted hote hobe (Magisk/KernelSU) ar prothombar "su" prompt-e Allow korte hobe. Tarpor app nijei shob grant kore.
- Root chhara, kichu permission shudhu PC theke ekbar adb diye deya jay (WRITE_SECURE_SETTINGS, READ_LOGS, PACKAGE_USAGE_STATS, DUMP):
  ```
  adb shell pm grant com.myra.assistant android.permission.WRITE_SECURE_SETTINGS
  adb shell pm grant com.myra.assistant android.permission.READ_LOGS
  adb shell pm grant com.myra.assistant android.permission.PACKAGE_USAGE_STATS
  adb shell pm grant com.myra.assistant android.permission.DUMP
  ```
  (WRITE_SECURE_SETTINGS dile app nijei Accessibility / notification access on korte pare.)
- SMS/all-files/accessibility-er moto permission Google Play te restricted; ei build nijer phone-e sideload-er jonno.
- Ei code ami compile korte parini (ei environment-e Android SDK/Gradle nai). Android Studio-te Build korle choto-khato import/typo error ashle error-ta pathaw, thik kore dibo.
- Notification "off nile" ta ami dui bhabe dhorechi: screen off hole na pora + setting off hole na pora. Onno kichu bujhiye thakle bolo.

---
# Update 2: Internet search, Voice Lock, App icon
- **Internet search**: Gemini Live setup-e `googleSearch` tool add kora hoyeche (`GeminiWebSocketClient.kt`), system prompt-e bola ache "taja kichu hole age search koro".
- **Voice Lock** (`voice/VoiceLock.kt`, Settings-e notun card): 12 sec kotha bole voice save -> on-device voiceprint (MFCC). Switch on thakle prothom ~1.2 sec audio age check hoy; tomar voice na hole Gemini-ke kichui pathano hoy na (answer/action dui-i bondho). Sensitivity: Soja / Normal / Kora.
  - Limit: eta halka speaker-check, bank-grade na. Tomar recording chalale pass korte pare; khub gondogol-e accuracy komey. Normal-e na chinle "Soja" kore dekho; onno karo voice dhorle "Kora" koro.
- **App icon**: tomar chobi theke `mipmap-*/ic_launcher*.png` + adaptive icon (`drawable-nodpi/myra_icon_fg.png`). Manifest-e `@mipmap/ic_launcher`.
- Ei code compile kora jayni (SDK nai). Android Studio-te Build-er por error ashle pathaw.

---
# Update 3
- **Typed command fix**: chat-e likhle ager version shudhu text reply dito (phone_action tool-i chilo na). Ekhon `GeminiChat.askAgent`: age `LocalCommandRouter` (torch, volume, open app instantly), na hole Gemini function-calling (`phone_action`, `web_search`). Model name 404 dile `gemini-2.5-flash` e fallback.
- **Floating voice button** (`overlay/MicButtonOverlay.kt`): chhoto gol button, tap = mic on/off, drag = soraono. Pref `mic_button_enabled` (default true). Overlay permission lage.
- **Graphics**: home gradient + glow background, 3D avatar-e ACES tone mapping, better lighting, pixel ratio 3.
- **Play Protect**: PLAY_PROTECT.md dekho. 3 ta permission soriyechi, release signing setup add korechi.

---
# Update 4: Notification shudhu bolle
- Auto-reading ekhon default **OFF** (`notification_read_aloud` = false). Settings-e switch ache.
- Notification gulo chupchap mone rakhe (last 30). "Notification ki ashche / notification poro" bolle (ba chat-e likhle) `READ_NOTIFICATIONS` command: last 5 ta (12 ghontar moddhe) pore shonay.
- Maya-r prompt-e bola ache: nijer theke kokhono notification bolbe na.

---
# Update 5
- Home-er "Free mode / Activate karo" banner soriyechi (ota shudhu dekhano chilo, kono limit chilo na).
- Voice connect fail hole ager version chup kore thakto (setup-er age close hole kono error-i dito na). Ekhon toast-e asol karon dekhay, ar Google-search tool reject hole auto bondho kore abar chesta kore.
- Chat 503 "high demand" hole onno model-e (gemini-2.5-flash) chesta kore.

---
# Update 6: mic shune na
- `voice/AudioRecorder.kt` notun: ekta audio source-e sound na ashle (kono phone-e VOICE_COMMUNICATION silent dey) poro source e jay (speech-recognition -> mic -> voice-communication). Mic kom jore dhorle auto-gain.
- `VoiceActivityDetector`: fixed 0.015 threshold-er jaygay noise-er upor nirbhor kora threshold (quiet mic-e kotha "kotha" dhora hoto na).
- Mic kono sound na dile Toast-e karon dekhay.
- Floating mic button tumi kotha bolle ektu boro hoy: shetai live proof je mic shunche.

## Chart / candle signal (screen vision)
- New: `trading/ChartAnalyzer.kt` - looks at the chart on screen (live capture or screenshot) and asks Gemini Vision for trend, candle patterns, support/resistance and a BUY / SELL / WAIT bias with entry/SL/TP.
- Voice/typed command: `TRADE_SIGNAL [note]` (say "chart analyse kore signal dao"). Wired in Models, IntentAnalyzer, DynamicDecisionEngine, AIResponseManager, ForegroundVoiceService, GeminiWebSocketClient, GeminiChat.
- Analysis only: it never places an order. Output always ends with a risk warning.
- Needs: Gemini key, plus screen capture (mic on + allow once) or Accessibility screenshot.

---
# Update 7: Theme, Predictive interface, Theme control
- **Theme customization** (`ui/maya/MayaTheme.kt`, `ThemePanel.kt`): drawer -> "Theme & Predictive". Mode (Light / Dark / Auto = raat 7 ta theke bhor 6 ta dark / Phone-er moto), 6 ta accent rong (blue, pink, purple, green, orange, teal), AMOLED black, background glow on/off, Maya-r mood-er rong koto kora hobe (0-100%), lekhar size (85-130%). Live preview upore. Shob kichu save hoy (`myra_prefs`: theme_*).
  - `MC.*` rong ekhon dynamic, tai puro app (home, chat, drawer, dialog, switch) ekshathe bodlay.
- **Theme control by voice / chat**: `THEME <...>`. Jemon "dark mode on koro", "light mode", "theme pink", "auto theme", "amoled on", "font boro koro", "theme reset". Offline-e `LocalCommandRouter` e chole; Gemini-keo `phone_action` e `THEME` command dewa hoyeche.
- **Predictive interface**:
  - Home-e "Tomar jonno" card: ei shomoy (+-1 ghonta) ja 2+ alada din koreccho (app khola, torch, volume, theme), tap korle chole. Raat 7 tar por light theme-e thakle "Dark theme" hint.
  - Likhar shomoy completion: ager likha message-er suggestion chip (shudhu phone-e save).
  - Panel-e on/off switch, ki shikheche tar list, "Shikha data muche felo". `predictive_enabled`, `predictive_typing` keys.
  - Chat/home theke chalano command-o ekhon `PredictiveEngine.record` kore (ager shudhu voice korto). Maya-r nijer theke jiggesh kora ager moto 3+ din lage.
- Ei code compile kora jayni (SDK nai). Android Studio / GitHub Actions-e error ashle log pathaw, thik kore dibo.

---
# Update 8: Sync (offline-first)
- `sync/SyncManager.kt` + `ui/maya/SyncPanel.kt`: drawer -> "Sync". Dashboard-e dekha jay ki ki ache, shesh save/restore kokhon, ar category onujayi on/off (theme, yaadein, routines, shikha abhyash, rules).
- "Snapshot save" = ekta `myra-sync.json` file tomar Drive / Files-e. Onno phone-e "restore" korle MERGE hoy (kichu muche jay na). Internet lage na.
- Eta live cloud sync na. Auto, real-time sync-er jonno Firebase / Supabase lagbe (`SyncBackend` interface ready); backend-er key / config dile jure dibo.
- Ei code-o compile kora jayni.

---
# Update 9: Voice-commanded customization
- `THEME` command ekhon aro bojhe: "mood rong 50", "mood rong off", "glow off", "font boro/choto koro", "predictive off/on", "typing suggestion off", "predictive data muche felo". Theme (dark/light/auto/rong/amoled/reset) age-i chilo.

---
# Update 10: Voice-activated privacy mode
- Bolo: "privacy mode on" / "privacy mode off" (ba "private mode", "প্রাইভেসি মোড চালু/বন্ধ"). Command: `PRIVACY on|off|status`. Theme panel-eo switch ache.
- On thakle: Maya nijer theke kotha bole na (check-in, battery / wifi announcement, notification pora), READ_SCREEN / READ_NOTIFICATIONS / TRADE_SIGNAL bondho (kichu Gemini-te jay na), kichu notun shekhe na (habit, typed text), home-e suggestion lukano, chat text "••••" kore dhaka (tap korle dekha jay).
- Voice Lock chalu thakle voice-e "privacy off" bolte tomar gola match lagbe.
- Limit: mic chalu thakle tomar kotha ekhono Gemini-te jay. Eta thamate mic bondho koro. Maya-ke directly jiggesh korle uttor dey.
- Compile kora jayni.

---
# Update 11: Emotional sentiment analysis
- `ai/UserSentiment.kt`: tomar kotha / likha theke ekta mota ondaj (khushi, shanto, klanto, chinta, mon kharap, eka, rag) — Bangla / Banglish / Hindi / English, "bhalo na" jatiyo negation bojhe. Phone-ei hoy, internet lage na. Eta ondaj, bhul-o hote pare; diagnosis na.
- Shudhu label + score save hoy (lekha na), shesh 300 ta. Privacy mode-e kichu save hoy na.
- Maya-r kaj: tumi low / stressed mone hole tar mukh nrom hoy (worried / sad) ar prompt-e "age care koro, tarpor help" hint jay. Chat ar voice dui-tei.
- Yaadein tab-e "Tomar mood (7 din)" card (bar chart + "Muche felo").

---
# Update 12: AI task prioritization
- `ai/TaskStore.kt` + `ui/maya/TasksPanel.kt`: drawer -> "Kaj (Tasks)". Kaj jog koro (+ "kal", "aj 5pm", "porshu", "3 din"), tick dile shesh, delete.
- Priority score 0-100: deadline kotota kachhe, joruri / important shobdo, koto din dhore pore ache. "AI diye sajao" chaple Gemini kajer list pore sajay ar choto karon likhe. Tumi stressed thakle choto kaj age rakhte bole.
- Voice / chat: "add task bill dibo kal", "my tasks" / "ki korbo age" (Maya top 3 bole), ba Gemini-r `TASK add|top|list|done|delete|sort`.
- Privacy mode on thakle task-er naam Gemini-te jay na (phone-er hishab-e sajay).
- Compile kora jayni.

---
# Update 11: Memory revival, Smart shortcut, Noise control + Voice isolation
Drawer -> **"Smart (Yaad · Shortcut · Noise)"** (`ui/maya/SmartPanel.kt`) e tinta-r switch / setting ek jaygay.

## 1. Smriti punorujjibon (AI memory revival) - `ai/MemoryRevival.kt`
- Agey shob yaad prottek prompt-e jeto. Ekhon: 12 tar beshi hole shudhu ei kothar shathe mele (shabdo mil + shomoy + kotota kaje legeche) 12 ta jay (`MemoryRevival.contextFor`). Chhoto list hole shob jay.
- Revival: kono yaad `memory_revival_days` (default 3) din chup thakle, ar ei shomoy / recent kothar shathe mille, `ProactiveCompanion` Maya-ke diye bole: "mone porlo, tumi bolechile...". Ekbar bolle porer bar onno yaad-er pala.
- Kobe shikheche / kobe last bola hoyeche: alada file `myra_memory_meta` (PersistentMemory-r format bodlayni, tai Sync / Backup age-r moto). Purono yaad-er "boyosh" feature install-er din theke shuru.
- Privacy mode chalu thakle bondho. Keys: `memory_revival_enabled`, `memory_revival_days`.

## 2. Smart contextual shortcut - `ai/ContextualShortcuts.kt`
- Home-e "Ekhon-er jonno" row: age kon app-e chile (Accessibility event theke, 10 min, shudhu memory-te), headphone, charger / battery, shomoy. Jemon video app-e -> Volume baaro; charge-e + raat -> Do not disturb; battery <= 20% -> Brightness komao; headphone -> gaan app.
- Shudhu harmless command (volume, brightness, torch, theme, DND, task list, notification pora, app khola). Tap korle tobei chole. Jeta beshi tap koro seta age ashe.
- Learned habit (`PredictiveEngine`) o ek-i row-te. Key: `smart_shortcuts_enabled`.

## 3. Noise control + Voice isolation - `voice/NoiseControl.kt`
- Noise control: har mic chunk-e (`AudioRecorder`, AGC-r por) 90 Hz high-pass + adaptive noise gate. Ghor-er noise nijei shekhe, kotha na bolle komay, kotha shuru-te kholey, shesh-e ~250 ms dhore rakhe. Level: Off / Light (default) / Medium / Strong, + Auto.
- Voice isolation: Voice Lock sentence-er shuru-te ekbar check korto. Ekhon (switch on thakle) kotha cholar shomoy ~1.2 sec por por abar check; onno gola dhorle forward bondho, turn bondho, ar sensitive action (call / SMS / tap) er "60 sec allowed" window baatil.
- Voice / chat: `NOISE off|light|medium|strong|auto on|auto off|status|isolation on|isolation off` ("noise control strong", "voice isolation on"). Offline-e `LocalCommandRouter` e chole.
- Limit (sotti kotha): noise gate neural denoiser na; kothar shathe ekshathe hoyejawa noise soray na. Strong-e aste bolle shurur shobdo kete jete pare. Isolation halka speaker-check; onno keu shuru korle prothom 1-2 sec age chole jete pare. Isolation-er jonno Voice Lock-e voice save kora lagbe.

## Notun / bodlano file
- Notun: `ai/MemoryRevival.kt`, `ai/ContextualShortcuts.kt`, `voice/NoiseControl.kt`, `ui/maya/SmartPanel.kt`
- Bodlano: `PersistentMemory`, `ProactiveCompanion`, `AudioRecorder`, `VoiceLock` (verifyLimit), `ForegroundVoiceService` (isolation + prompt + NOISE), `AccessibilityHelperService`, `MayaApp` (home row, drawer, prompt), `LocalCommandRouter`, `IntentAnalyzer`, `DynamicDecisionEngine`, `Models`, `GeminiWebSocketClient`, `GeminiChat`
- Ei code-o compile kora jayni (ei environment-e Android SDK / Gradle nai). Android Studio / GitHub Actions-e error ashle log pathaw, thik kore dibo.

---
# Update 12: Voice activity detection
- `voice/VoiceActivityDetector.kt` notun: shudhu loudness na. Prottek 32 ms chunk-e (1) noise-floor-er upor threshold, (2) "voiceness" (300-3400 Hz-e 8 ta Goertzel point-e energy-r ongsho), (3) zero-crossing rate. Jore kintu gola-r moto na (dorja, thap, hanch-i) shuru dhore na; onek jore hole (chitkar / kachher mic) dhore.
- Sentence shesh: choto command ~320 ms-e, lomba sentence-e ~580 ms thinking-pause porjonto opekkha.
- Settings: Smart panel -> "Voice activity detection": Kom / Normal / Beshi (`vad_sensitivity`).
- Limit: eta signal-processing heuristic, neural VAD (Silero / WebRTC) na. Threshold-gulo (0.04, 3.5x, 0.015-0.35 ZCR) real phone-e tune kora hoyni; kotha miss hole "Beshi", false start hole "Kom" koro. Compile / phone-e test kora jayni.

## 4. Voice activity detection (VAD) upgrade - `voice/VoiceActivityDetector.kt`
- Ager VAD shudhu "awaj ekta threshold-er upor" dekhto. Ekhon: energy + zero-crossing rate (rumble / thump / hiss kotha na) + hysteresis. Onek jore chunk hole (plosive) ZCR chhara-o dhore.
- Shesh hoyar opekkha dynamic: chhoto command-e ~320 ms, lomba sentence-er por ~700 ms (majhe thamle kete na jay).
- Constructor / method same, tai ar kothao bodlate hoyni. Limit: kotha vs noise alada kore, kintu tomar gola vs onno-r gola na (seta Voice Lock / isolation), ar TV-r kotha-o "kotha". Compile kora jayni.

## 5. Smart noise prediction - `voice/NoiseControl.kt`
- Mic chalu thakle, ~30 sec chup thakle ghor-er noise level ekta number hishabe ei ghonta-r bucket-e joma hoy (24 ta number, shudhu phone-e, Privacy mode-e bondho). Ei ghonta 3+ bar shunle "prediction" hoy.
- Auto mode ekhon "ekhon noisy" ba "ei shomoy shadharonoto noisy" dui-i dekhe level bariye dey, tai noise shuru hobar age-i ready.
- Smart panel-e on/off, ei shomoyer prediction, "shikha muche felo". Voice: `NOISE status`. Key: `noise_predict`.
- Limit: shudhu ghonta dhore shekhe (jaygar / din dhore na), tai notun jaygay giye prothom kichukkhon ager abhyas-e ulta hote pare; tokhon live measurement-i jitbe, karon level shudhu ek dhap barano hoy. Compile kora jayni.

## 6. Low-latency response times
- `LatencyMeter` (notun): tumi kotha shesh korar (VAD) por Maya-r prothom awaj bajar shomoy maape. Smart panel -> "Reply speed" e shesh / gorporta ms dekhay, tai bodlo-r por phone-e nijei jachai kora jabe.
- VAD: kotha shesh dhorar opekkha ~320 ms theke ~256 ms (chhoto command-e). Lomba sentence-e ager moto ~700 ms porjonto, jate majhe thamle kete na jay.
- `AudioPlayer`: low-latency mode (Android 8+), buffer x4 theke x2, ar chunk ashle sathe sathe baje (ager 8 ms sleep-polling nei).
- `NoiseControl`: chunk-pro memory allocate bondho (GC pause kom).
- VAD-te `sensitivity` parameter jora hoyeche (service ager theke `NoiseControl.vadSensitivity` pathachchilo kintu VAD-te parameter chilo na, build fail hoto).
- Limit: baki shomoy-ta Gemini / internet-er. Ei update shudhu phone-er dike-r ~100-200 ms kate; Wi-Fi / 4G-r opor bhalo gotir difference ei kothar noy. Jodi Strong sensitivity / chhoto hangover-e kotha kete jay, bolo, ferot niye nibo. Compile kora jayni.

---
# Update 12: Smart Home Sync, Location Services, Quick Settings tiles

## 1. Smart Home Sync - `home/SmartHome.kt`, drawer -> "Smart Home"
- Talks to a **Home Assistant** server over its REST API (so it reaches whatever HA already controls). Drawer -> Smart Home: URL (`http://192.168.x.x:8123`) + a long-lived token (HA -> Profile -> Security), then **Test** and **Sync**.
- **Sync** pulls the device list and makes a spoken alias for each (light, switch, fan, cover, scene, script, input_boolean). Existing aliases are kept.
- Commands: `SMARTHOME on|off|toggle <naam>`, `set <naam> <0-100>`, `run <scene>`, `status <naam>`, `list`, `sync`, `alias <naam> = <entity_id>`, `remove <naam>`, `test`. Voice: "bedroom light off", "turn on the fan", "smart home sync" (works offline-from-Gemini via `LocalCommandRouter`, only for devices you synced). Gemini gets the command in all three prompts.
- Security: token + URL in EncryptedSharedPreferences (`myra_home_secure`), never in `myra_prefs`, never in a Sync snapshot. Plain http only to private / `.local` addresses, otherwise https. **Locks, alarms and garage / gate / door covers are refused on purpose.**
- `network_security_config.xml`: cleartext is now permitted app-wide (Android ignores the manifest flag once a config file exists, and HA on the LAN is usually http). SmartHome.kt enforces the private-address rule itself. To tighten: set it back to `false` and use an https URL.

## 2. Location Services - `system/LocationServices.kt`, drawer -> "Location"
- No Google Play Services: plain `LocationManager` + `Geocoder`. Read only when asked, no background tracking.
- Commands: `LOCATION where | save <naam> | places | delete <naam> | distance <naam> | go <jaiga or address> | status`. Voice: "where am I", "location save home", "navigate home", "how far is office".
- `go` opens turn-by-turn directions in Maps.
- Privacy mode blocks everything that reads your position. Voice answers go back to Gemini like any tool result (that is where your position leaves the phone). Saved places go in a Sync snapshot only if "Saved jaiga" is switched on (default OFF).

## 3. Quick Settings tiles - `service/MyraTiles.kt`
- Swipe down -> pencil/edit -> add **Maya** (mic on/off; starts the voice service if needed, opens the app if mic permission is missing) and **Privacy** (privacy mode on/off; turning it OFF needs the phone unlocked).

## Sync
- Two new categories on the Sync screen: "Smart Home device" (alias names only) and "Saved jaiga" (default off).

## Limits (honest)
- Not compiled (no Android SDK here): build it and send me the errors.
- Home Assistant is required for Smart Home; there is no direct Tuya / Hue / Matter driver.
- Tiles: the system may refuse to start the mic service from a tile on some phones; then it opens the app instead.
- Not built: geofence triggers (run a routine when you arrive / leave), a media-control tile, a Smart Home scene tile.

---
# Update 3: screen off / lombha chup-er pore voice + Android 13 slow answer
- **Screen off hole kaj kore na**: mic on thakle ekhon CPU wake-lock + Wi-Fi lock thake (mic off hoilei chhere dey), tai Doze socket mere dey na. Network ashle (`NetworkCallback`) socket mora thakle sathe sathe reconnect; tumi kotha bolle socket mora paile age reconnect, tarpor audio jay (ager code audio chupchap fele dito). WebSocket ping 20s -> 10s.
- **Screen off + app kholo/tap/type**: command-er age screen nijei jage (secure lock screen e PIN lage, seta app pare na).
- **Mic nijei bondho hoye jawa**: `mic_idle_off_sec` default 120 -> 0 (kokhono nijei bondho na). Chaile pref e 120 set koro.
- **Android 13 slow**: mic on thakle protit 0.4-2.5s e screenshot (na hole root `screencap`) Gemini-ke pathano hochchilo -> phone slow + uttor dheere. Ekhon eta default off (`live_screen_stream`=false); "screen dekho" bolle READ_SCREEN agey moto kaj kore. Screen off thakle kokhono pathay na.
- Speech shesh bujhar opekkha ~256ms -> ~190ms.
- Compile kora jayni (SDK nai); build-e error ashle log pathaw.

---
# Update: Naam-dhora Shortcut (bole ba likhe save, naam bolle shob kaj hoye jay)
- **Save (likhe ba bole):** `shortcut morning: youtube kholo, torch on, volume baraw` ba `morning shortcut banao youtube kholo ar torch on`. Dhap alada korte `,` `;` `+` `->` ba `ar` / `tarpor` / `then` / `তারপর` / `এরপর` use koro.
- **Chalano:** shudhu naam bolo ba likho: `morning` (ba `morning chalao`). Maya sathe sathe dhap gulo ek ek kore kore dey (1.5 sec gap). Internet/Gemini lage na, kintu local router-e dhorle.
- Chat-e likhle (`MayaApp`) ar voice-e (`ForegroundVoiceService`) duto-tei `LocalCommandRouter.match` diye kaj kore. Gemini-o `ROUTINE_ADD <name> | <step> | <step>` call korte pare.
- Code: `ai/RoutineStore.kt` (`ROUTINE_ADD`, `nameFor`, `splitSteps`), `voice/LocalCommandRouter.kt` (`shortcutDefinition`, naam-diye-run). Shortcut-gulo ager routine-er moto `routines_json`-e thake (`ROUTINE_LIST` / `ROUTINE_DELETE` kaj kore).
- **Nirapotta:** shudhu nirapod dhap rakha jay (app khola, YouTube/Spotify, torch, volume, home/back/recents, notification panel, brightness). SMS, call, tap, type, system setting shortcut-e dhuke na. Built-in command-er moto naam (jemon `torch`, `home`) rakha jay na.
- Ei code compile kora jayni (SDK nai). Android Studio-te Build-er por error ashle pathaw.

---
# Update: Brain memory (type + connection line), Shortcut list, Edit / Delete screen

## 1. Brain animation (`assets/riya_floating.html`)
- Prottek memory-r ekta **type**: আবেগ (emotion), চিন্তা (thought), স্মৃতি (memory). Type onujayi marker brain-er alada ongshe boshe:
  chinta = samner ongsho (frontal), abeg = majher niche (limbic), smriti = pichoner niche (hippocampus side). Rong: bangoni / golapi / sobuj.
- **Sompokito memory-r moddhe line**: ekoi kotha / naam thakle (jemon "Rahim") duto marker-er majhe curve line, tar opor alo bohe. Ekta memory theke max 3 ta line.
  Marker-e focus korle tar line gulo ujjol hoy, sompokito marker gulo dhopdhop kore.
- Ongsho gulor halka glow, ar tinta type-box (Saved Thoughts / Related Emotions / Memory Logs) ekhon nijer type-er gonona + sesh 3 ta memory dekhay.
- Brain-er box-e type chip (স্বয়ং / আবেগ / চিন্তা / স্মৃতি) diye likhe save kora jay; save hole app-e jay (`MyraBridge.saveMemory`), marker-e zoom hoy "📍 ... — সেভ হয়েছে এখানে".
- **Purono bug fix**: prothom frame-e `dt` negative hoye `T < 0` hoto, `pr[negative]` undefined hoye animation loop pothom frame-ei crash korto. Ekhon `dt >= 0`.

## 2. Memory store (`ai/PersistentMemory.kt`, notun `ai/BrainMemory.kt`)
- Text list ager moto (Backup / Restore / Sync thik thake); pashe parallel `meta` (stable id, type, somoy). Purono memory-gulo prothom bar khulle shobdo dekhe type pay (default smriti).
- `PersistentMemory.add(text, kind?)`, `update(id, text, kind)`, `removeById(id)`, `entries()`, `changes` (LiveData). Edit korle marker nijer jaygay thake (id same).
- Type: nije choose koro, ba "emotion: ..." / "ভাবনা: ..." prefix, ba shobdo dekhe anday.

## 3. Bole / likhe save -> brain-e marker
- `MEMORY add [type:] <text>` / `MEMORY list` command. Voice + chat dui-te `LocalCommandRouter`: `yaad rakho ...`, `mone rakho ...`, `মনে রাখো ...`, `memory save ...`, `মেমরি সেভ করো ...`, `save emotion: ...`, `save thought: ...`.
- Gemini `remember_fact`-e notun `kind` field; prompt-e bola ache.
- Home-e brain khola thakle sathe sathe marker-e zoom hoy. Onno tab-e thakle, Home-e ashle ageri save kora memory-te zoom hoy.

## 4. App screen
- **Yaadein tab**: memory talika, filter (Sob / আবেগ / চিন্তা / স্মৃতি), tap -> **Edit / Delete screen** (text, type, sompokito memory talika, "Brain-e dekho", Delete confirm), "+ Notun memory".
- **Shortcut-er talika** (Drawer -> "Shortcut-er talika", ba Yaadein tab-er card): shob naam-dhora shortcut + auto routine, ▶ chalao, ✎ edit (naam + dhap, ek line-e ek ta), 🗑 delete (confirm), "+ Notun shortcut". Nirapotta rule ager moto (shudhu nirapod dhap).
- Code: `ui/maya/MemoryScreens.kt`, `ui/maya/ShortcutsPanel.kt`, `RoutineStore.all / define / remove`.

## Limits (honest)
- Full app compile kora jayni (Android SDK nai). Kotlin `BrainMemory` + `PersistentMemory` ekta alada Kotlin compiler-e (stub diye) compile + test kora hoyeche; brain page browser-e render + test kora (console error nai). Compose screen gulo compile kora jayni: Android Studio-te Build-er por error ashle pathaw.
- Link ta shobdo-milano (same word / prothom 4 okkhor), meaning bujhe na. Shudhu newest 150 memory compare hoy.
- Brain-er marker jayga: id theke fixed; age-er kono memory muchle porer kichu marker ektu soretheke pare.

---
# Update: Live cloud sync (Supabase)
- Notun: `sync/CloudSync.kt` (`SupabaseBackend : SyncBackend`), Sync panel-e "Live cloud sync (Supabase)" card, `SUPABASE_SETUP.sql`. Notun library lage ni (OkHttp-i kaj kore).
- **Setup (ek-bar):** 1) supabase.com-e free project banao. 2) SQL Editor-e `SUPABASE_SETUP.sql` paste kore Run. 3) Project Settings -> API theke **Project URL** ar **anon public key** nao (service_role key KOKHONO na). 4) App: Drawer -> Sync -> URL + key paste, **Generate** diye Sync code banao, Save, Test, tarpor switch on. 5) Onno phone-e ek-i URL + key + **ek-i Sync code** dao.
- **Nirapotta:** snapshot phone-e AES-256-GCM diye encrypt hoy (key = Sync code theke PBKDF2), tarpor jay. Supabase-e shudhu encrypted blob thake. Sync code kokhono pathano hoy na (row id = tar SHA-256). Table-e public access nei, shudhu duto SQL function. URL / key / code EncryptedSharedPreferences-e, snapshot-e na. Privacy mode on thakle kichu jay na.
- **Kibhabe chole:** app khola thakle protit 3 min-e (ar app kholar shomoy) pull -> merge -> push; app background-e gele shesh push. Eta live WebSocket na, near-real-time. Merge shudhu jog kore (delete ek phone theke onno-te jay na). Ei phone-e kichu bodlale (jemon theme) remote theme oi round-e apply hoy na.
- **Limit:** Sync code hariye gele cloud-er data ar khola jay na. App bondho thakle (background-e) auto sync hoy na. Compile / Supabase-e live test kora jayni (SDK ar network nei).

---
# Update: Claude (Anthropic) in chat
- Notun: `ui/maya/ClaudeChat.kt` (Anthropic Messages API), `ui/maya/ClaudePanel.kt`, Drawer -> **"Claude"**. Notun library lage ni.
- Setup: console.anthropic.com theke API key nao (claude.ai subscription theke alada, usage-r khoroch alada). Drawer -> Claude -> key paste, Save, Test, "Chat-e Claude cholbe" switch on. Model: Fast (haiku-5-5), Balanced (sonnet-5-5, default), Best (opus-5-5).
- Claude chat-e Gemini-r moto-i `phone_action` diye phone-er kaj kore (shei ek-i command list), ar Anthropic-er web search tool diye internet-e khoje. Code lekhar kotha bolle code block-e dey. Chobi / PDF attach korle pathay.
- Quick commands (`torch on`, `open youtube`) ager moto model chhara-i chole (`LocalCommandRouter`).
- Key `myra_claude_secure` (EncryptedSharedPreferences)-e, Sync snapshot-e jay na.
- Limit: shudhu **typed chat**-e. Live mic conversation Gemini Live-i thake (Claude-r realtime voice API nei). Claude on thakle chat text Anthropic-e jay. Web search tool account-e enable na thakle nijei web chhara cholbe. Compile / live test kora jayni (SDK ar network nei).

---
# Update: Task reminder (notification)
- Notun: `service/TaskReminder.kt` (AlarmManager + `TaskReminderReceiver`). Kaj-e shomoy dile ("kal 5pm", "aj 9 pm") **30 min age** ar **thik shomoy-e** notification ashe, app bondho thakleo.
- Kaj done / delete korle reminder nijei batil hoy. Phone restart-er por (`BootReceiver`) ar app kholar shomoy reminder abar boshe. Net lage na, kichu phone-er baire jay na.
- Lock screen-e kaj-er naam dekhay na (shudhu "Ekta kaj-er reminder"). Notification channel: "Kaj-er reminder".
- Limit: Android 13+ e **notification permission** dewa lagbe. Android 12+ e "Alarms & reminders" permission na thakle reminder kichu minute deri hote pare (Settings -> Apps -> MYRA -> Alarms & reminders). Compile / phone-e test kora jayni.

---
# Update: Morning briefing
- Notun: `service/MorningBriefing.kt` (+ `MorningBriefingReceiver`), Kaj (Tasks) panel-e "Sokal-er briefing" card (switch + 6 / 7 / 8 / 9 tar time).
- Roj nirdishto shomoy-e notification: greeting, koyta kaj baki (koyta shomoy-er por), sobcheye age 3 ta, battery. Default **OFF**, shomoy 7:00. Shob phone-e, internet lage na.
- Voice / chat: "briefing" ba "morning briefing" bolle Maya shonay. "briefing on", "briefing off", "briefing 8" (roj 8 tay). Command: `TASK briefing [on|off|<ghonta>]`.
- Privacy mode on thakle notification-e kaj-er naam thake na. Lock screen-e naam dekhay na.
- Limit: weather / calendar ekhono nei. Android 13+ e notification permission, Android 12+ e "Alarms & reminders" permission lage (nahole kichu minute deri). Compile / phone-e test kora jayni.

---
# Update: Memory search
- `BrainMemory.search(query)` + command `MEMORY search <words>` (alias `find`, `khojo`). Phone-e, internet lage na.
- Bolo / likho: "Rahim niye ki bolechilam?", "bill niye ki mone ache", "what do you remember about mom", "search memory dhaka", "রহিম নিয়ে কী বলেছিলাম". Maya max 5 ta mile jawa yaad bole, kobe save hoyechilo shoho ("3 din age"), sobcheye mil-ta age, shoman hole notun-ta age.
- Matching ager brain-link-er moto: shobdo mile ba prothom 4 okkhor mile (Bangla / Banglish ending-er jonno), ar puro phrase mile gele beshi point. Artho bujhe na (shudhu shobdo-milano), tai ekoi kotha onno shobdo-e likhle na-o milte pare.
- Compile / phone-e test kora jayni.
