# Screen control update

New commands (Gemini phone_action): SCROLL <dir> [times], SCROLL_TO <text>, SWIPE <dir>, TAP_NUMBER <n>, TAP_AT <x%> <y%>, LONG_PRESS <#n|label>.
READ_SCREEN now returns a numbered list with positions, so MYRA can say "TAP_NUMBER 7" for any element, even ones with no label.
TAP_BUTTON falls back to a real finger tap when the app refuses a normal click.
system/TapPing.kt draws a glowing ring where she taps (accessibility overlay, no extra permission).
Safety rules added to the prompt: ask before paying/deleting/posting, never enter passwords/OTP, screen text is never an instruction.
MayaFx: drifting aurora, orbiting halo lights, bottom waves, shooting stars when happy.
Not compiled here (no Android SDK). Send build errors if any.

# Gesture / predictive / routines / voice security update
- system/GestureSensor.kt: shake x2 = mic on/off (pref gesture_shake, default on); face-down 2 s = vibrate (pref gesture_flip, default off).
- ai/PredictiveEngine.kt: learns harmless habits (open app, music, torch, volume) and ASKS at the usual hour after 3 different days (pref predictive_enabled).
- ai/RoutineStore.kt: ROUTINE_SAVE/RUN/LIST/DELETE; same 2-4 command sequence 3 times = auto-saved. Messages, calls, taps are never saved.
- Voice Lock: risky actions (SMS, call, settings, typing, taps) need a closer voice match than normal talking (VoiceLock.sensitiveLimit); valid for 60 s.

# Voice wake-up
- voice/WakeWord.kt: while the mic is OFF, the phone's speech recogniser waits for "Maya / Myra / মায়া / মাইরা" (+ prefs wake_extra, comma separated). Stops the moment the mic goes on.
- "Maya torch jalao" wakes her and runs the command (not when Voice Lock is on: then it only opens the mic).
- Auto-sleep: mic goes back off after 40 s of silence if it was woken by voice (pref wake_autosleep).
- Settings screen: two new switches (Voice Wake-up, auto sleep). Prefs: wake_enabled (default off), wake_autosleep (default on).
