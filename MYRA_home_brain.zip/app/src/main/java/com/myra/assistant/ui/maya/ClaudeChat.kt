package com.myra.assistant.ui.maya

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Claude (Anthropic Messages API) as the typed-chat brain. Same abilities as the Gemini chat: it can run phone
 * commands through the `phone_action` tool, and it can search the web (Anthropic's server-side web search).
 * It is especially good for writing / fixing code. Voice (the live mic conversation) stays on Gemini Live:
 * Claude has no realtime audio API.
 *
 * The API key lives in EncryptedSharedPreferences (never in myra_prefs, never in a Sync snapshot).
 * Chat text (and any image / PDF you attach) goes to Anthropic when this is switched on, and privacy mode does not
 * change that for things you type to Maya directly, same as the Gemini chat.
 */
object ClaudeChat {
    private const val SECURE_FILE = "myra_claude_secure"
    private const val K_KEY = "claude_api_key"
    private const val BASE = "https://api.anthropic.com/v1"
    private const val VERSION = "2023-06-01"

    /** label -> model id */
    val MODELS = listOf("Fast" to "claude-haiku-5-5", "Balanced" to "claude-sonnet-5-5", "Best" to "claude-opus-5-5")
    private const val DEFAULT_MODEL = "claude-sonnet-5-5"
    private const val FALLBACK_MODEL = "claude-haiku-5-5"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    @Volatile private var securePrefs: SharedPreferences? = null
    private fun secure(c: Context): SharedPreferences? {
        securePrefs?.let { return it }
        return try {
            val mk = MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(c.applicationContext, SECURE_FILE, mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM).also { securePrefs = it }
        } catch (_: Exception) { null }
    }
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun hasKey(c: Context) = !secure(c)?.getString(K_KEY, "").isNullOrBlank()
    private fun key(c: Context) = secure(c)?.getString(K_KEY, "").orEmpty()
    fun saveKey(c: Context, k: String): Boolean = secure(c)?.edit()?.putString(K_KEY, k.trim())?.commit() ?: false
    fun clearKey(c: Context) { secure(c)?.edit()?.clear()?.apply(); p(c).edit().putString("ai_provider", "gemini").apply() }
    fun model(c: Context) = p(c).getString("claude_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun setModel(c: Context, id: String) { p(c).edit().putString("claude_model", id).apply() }
    fun setActive(c: Context, on: Boolean) { p(c).edit().putString("ai_provider", if (on) "claude" else "gemini").apply() }
    /** Typed chat uses Claude only when it is switched on AND a key is saved. */
    fun isActive(c: Context) = p(c).getString("ai_provider", "gemini") == "claude" && hasKey(c)

    private fun errMsg(code: Int, txt: String) = "Error $code: " +
        runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("request failed")

    private fun post(key: String, path: String, body: JSONObject?): Pair<Int, String> {
        val b = Request.Builder().url("$BASE$path").header("x-api-key", key).header("anthropic-version", VERSION)
        val req = if (body == null) b.get().build() else b.post(body.toString().toRequestBody(JSON)).build()
        return client.newCall(req).execute().use { r -> r.code to r.body?.string().orEmpty() }
    }

    suspend fun test(c: Context): String = withContext(Dispatchers.IO) {
        val k = key(c)
        if (k.isBlank()) return@withContext "Age Claude API key save koro."
        try {
            val (code, txt) = post(k, "/models?limit=1", null)
            if (code == 200) "Claude connected." else if (code == 401) "Key thik na (401)." else errMsg(code, txt)
        } catch (e: Exception) { "Network error: ${e.message}" }
    }

    /** phone_action tool: same command list as the Gemini chat, so both brains can do the same things. */
    private val PHONE_TOOL: JSONObject by lazy {
        val d = GeminiChat.TOOLS.getJSONObject(0).getJSONArray("functionDeclarations").getJSONObject(0)
        JSONObject().put("name", "phone_action").put("description", d.getString("description"))
            .put("input_schema", JSONObject().put("type", "object")
                .put("properties", JSONObject().put("command", JSONObject().put("type", "string")
                    .put("description", d.getJSONObject("parameters").getJSONObject("properties").getJSONObject("command").getString("description"))))
                .put("required", JSONArray().put("command")))
    }
    private val WEB_TOOL: JSONObject by lazy {
        JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)
    }

    /** The API wants strictly alternating user / assistant turns that start with a user turn. */
    private fun cleanHistory(h: List<Pair<Boolean, String>>): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        for ((u, t) in h.takeLast(20)) {
            if (t.isBlank()) continue
            if (out.isEmpty() && !u) continue
            if (out.isNotEmpty() && out.last().first == u) out[out.size - 1] = u to (out.last().second + "\n" + t)
            else out.add(u to t)
        }
        // the new user message follows, so the history must end on an assistant turn
        if (out.isNotEmpty() && out.last().first) out.removeAt(out.size - 1)
        return out
    }

    suspend fun askAgent(
        c: Context,
        history: List<Pair<Boolean, String>>,
        userText: String,
        imageB64: String? = null,
        mime: String = "image/jpeg",
        system: String,
        runPhone: suspend (String) -> String
    ): String = withContext(Dispatchers.IO) {
        val k = key(c)
        if (k.isBlank()) return@withContext "Age Claude API key save koro (Drawer -> Claude)."
        try {
            val msgs = JSONArray()
            cleanHistory(history).forEach { (u, t) ->
                msgs.put(JSONObject().put("role", if (u) "user" else "assistant").put("content", t))
            }
            val first = JSONArray()
            if (imageB64 != null) {
                val isPdf = mime == "application/pdf"
                val media = if (isPdf || mime in setOf("image/jpeg", "image/png", "image/gif", "image/webp")) mime else "image/jpeg"
                first.put(JSONObject().put("type", if (isPdf) "document" else "image").put("source",
                    JSONObject().put("type", "base64").put("media_type", media).put("data", imageB64)))
            }
            first.put(JSONObject().put("type", "text").put("text", userText))
            msgs.put(JSONObject().put("role", "user").put("content", first))

            val sys = system + "\nYou can act on the phone with the phone_action tool and search the internet with web_search. " +
                "When the user asks you to do something on the phone, call phone_action instead of only talking about it. " +
                "For anything recent or factual, search first. If the user asks for code, write correct, complete code in a code block, " +
                "then explain it in one or two short sentences in the user's language. Otherwise answer in one or two short sentences."
            var model = model(c)
            var useWeb = true
            var last = ""
            repeat(8) {
                val tools = JSONArray().put(PHONE_TOOL).apply { if (useWeb) put(WEB_TOOL) }
                val body = JSONObject().put("model", model).put("max_tokens", 2048).put("system", sys).put("tools", tools).put("messages", msgs)
                var (code, txt) = post(k, "/messages", body)
                // web search not enabled for this account / model name not available: retry once in a simpler way
                if (code == 400 && useWeb && txt.contains("web_search", ignoreCase = true)) {
                    useWeb = false
                    body.put("tools", JSONArray().put(PHONE_TOOL))
                    val r = post(k, "/messages", body); code = r.first; txt = r.second
                }
                if ((code == 404 || code == 529 || code == 503) && model != FALLBACK_MODEL) {
                    model = FALLBACK_MODEL
                    body.put("model", model)
                    val r = post(k, "/messages", body); code = r.first; txt = r.second
                }
                if (code !in 200..299) return@withContext errMsg(code, txt)

                val resp = JSONObject(txt)
                val content = resp.optJSONArray("content") ?: JSONArray()
                val blocks = (0 until content.length()).map { content.getJSONObject(it) }
                val text = blocks.filter { it.optString("type") == "text" }.joinToString("") { it.optString("text") }
                if (text.isNotBlank()) last = text
                val uses = blocks.filter { it.optString("type") == "tool_use" }
                val stop = resp.optString("stop_reason")
                if (stop == "refusal") return@withContext last.ifBlank { "Eta niye ami help korte parbo na." }
                if (uses.isEmpty() && stop != "pause_turn") return@withContext text.ifBlank { last.ifBlank { "Hoye geche." } }

                msgs.put(JSONObject().put("role", "assistant").put("content", content))   // exactly as received
                if (uses.isEmpty()) return@repeat                                          // pause_turn: just continue
                val results = JSONArray()
                for (u in uses) {
                    val res = try {
                        if (u.optString("name") == "phone_action")
                            runPhone(u.optJSONObject("input")?.optString("command").orEmpty()).ifBlank { "done" }
                        else "unknown tool"
                    } catch (e: Exception) { "failed: ${e.message}" }
                    results.put(JSONObject().put("type", "tool_result").put("tool_use_id", u.optString("id")).put("content", res.take(4000)))
                }
                msgs.put(JSONObject().put("role", "user").put("content", results))
            }
            last.ifBlank { "Kaj ses korte parlam na." }
        } catch (e: Exception) { "Network error: ${e.message}" }
    }
}
