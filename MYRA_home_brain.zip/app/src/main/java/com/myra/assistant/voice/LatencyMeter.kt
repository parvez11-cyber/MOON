package com.myra.assistant.voice

import android.os.SystemClock

/**
 * Measures how long Maya takes to answer: from the moment the speech detector decides you stopped talking until the
 * first sound of her reply starts playing. Shown in the Smart panel so a change can be checked on the real phone.
 * Only two timestamps are kept; nothing is stored on disk.
 */
object LatencyMeter {
    @Volatile private var endAt = 0L
    @Volatile var lastMs = 0L
        private set
    @Volatile var avgMs = 0L
        private set
    @Volatile var count = 0
        private set

    fun speechEnd() { endAt = SystemClock.elapsedRealtime() }

    /** Call when reply audio starts. Ignored if there was no matching speech end (proactive talk) or it is stale (> 20 s). */
    fun firstAudio() {
        val s = endAt
        if (s == 0L) return
        endAt = 0L
        val d = SystemClock.elapsedRealtime() - s
        if (d !in 1..20_000) return
        lastMs = d
        avgMs = if (count == 0) d else (avgMs * 4 + d) / 5          // recent replies count more
        count++
    }

    fun reset() { endAt = 0L; lastMs = 0L; avgMs = 0L; count = 0 }
}
