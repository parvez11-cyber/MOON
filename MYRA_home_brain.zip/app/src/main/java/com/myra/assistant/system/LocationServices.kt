package com.myra.assistant.system

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Location Services (no Google Play Services needed: plain LocationManager + Geocoder).
 *
 * Command: LOCATION where | save <name> | places | delete <name> | distance <name> | go <name or address> | status
 *
 * - Saved places (home, office...) stay on the phone in myra_prefs ("saved_places"); they are only put in a Sync
 *   snapshot if the "Places" category is switched on (it is OFF by default).
 * - Privacy mode blocks everything that reads where you are. When Maya answers by voice, the answer text goes to
 *   Gemini like any other tool result, so that is the one place your position leaves the phone.
 * - Location is only read when you ask. There is no background tracking.
 */
object LocationServices {
    private const val KEY_PLACES = "saved_places"      // {name: {lat, lng}}
    private const val FIX_TIMEOUT_MS = 12_000L
    private const val STALE_MS = 2 * 60_000L

    // ---------- permission / provider ----------
    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    fun hasPermission(c: Context) = granted(c, Manifest.permission.ACCESS_FINE_LOCATION) || granted(c, Manifest.permission.ACCESS_COARSE_LOCATION)
    private fun lm(c: Context) = c.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    fun isLocationOn(c: Context): Boolean = try { LocationManagerCompat.isLocationEnabled(lm(c)) } catch (_: Exception) { false }

    private fun providers(c: Context): List<String> {
        val m = lm(c); val fine = granted(c, Manifest.permission.ACCESS_FINE_LOCATION)
        val out = ArrayList<String>()
        try {
            if (fine && m.isProviderEnabled(LocationManager.GPS_PROVIDER)) out += LocationManager.GPS_PROVIDER
            if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) out += LocationManager.NETWORK_PROVIDER
            if (Build.VERSION.SDK_INT >= 31 && m.isProviderEnabled(LocationManager.FUSED_PROVIDER)) out += LocationManager.FUSED_PROVIDER
        } catch (_: SecurityException) {}
        return out
    }

    // ---------- fix ----------
    @SuppressLint("MissingPermission")
    private fun lastKnown(c: Context): Location? = try {
        lm(c).getProviders(true).mapNotNull { runCatching { lm(c).getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
    } catch (_: Exception) { null }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private suspend fun fresh(c: Context, provider: String): Location? = withTimeoutOrNull(FIX_TIMEOUT_MS) {
        suspendCancellableCoroutine<Location?> { cont ->
            val m = lm(c)
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val cancel = CancellationSignal()
                    cont.invokeOnCancellation { cancel.cancel() }
                    m.getCurrentLocation(provider, cancel, ContextCompat.getMainExecutor(c)) { loc -> if (cont.isActive) cont.resume(loc) }
                } else {
                    val l = object : LocationListener {
                        override fun onLocationChanged(loc: Location) { if (cont.isActive) cont.resume(loc) }
                        override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) { if (cont.isActive) cont.resume(null) }
                    }
                    cont.invokeOnCancellation { m.removeUpdates(l) }
                    m.requestSingleUpdate(provider, l, Looper.getMainLooper())
                }
            } catch (_: Exception) { if (cont.isActive) cont.resume(null) }
        }
    }

    /** Best available position: a recent cached one, else a fresh fix (GPS first, then network), else any cached one. */
    suspend fun current(c: Context): Location? {
        val cached = lastKnown(c)
        if (cached != null && System.currentTimeMillis() - cached.time < STALE_MS) return cached
        for (p in providers(c)) fresh(c, p)?.let { return it }
        return cached
    }

    @Suppress("DEPRECATION")
    private suspend fun address(c: Context, loc: Location): String? {
        if (!Geocoder.isPresent()) return null
        val g = Geocoder(c.applicationContext, Locale.getDefault())
        val list: List<Address>? = if (Build.VERSION.SDK_INT >= 33) withTimeoutOrNull(6_000L) { geocode33(g, loc) }
        else withContext(Dispatchers.IO) { try { g.getFromLocation(loc.latitude, loc.longitude, 1) } catch (_: Exception) { null } }
        val a = list?.firstOrNull() ?: return null
        val line = a.getAddressLine(0)
        return if (!line.isNullOrBlank()) line else listOfNotNull(a.thoroughfare, a.subLocality, a.locality).joinToString(", ").ifBlank { null }
    }

    @RequiresApi(33)
    private suspend fun geocode33(g: Geocoder, loc: Location): List<Address>? = suspendCancellableCoroutine { cont ->
        try {
            g.getFromLocation(loc.latitude, loc.longitude, 1, object : Geocoder.GeocodeListener {
                override fun onGeocode(addresses: MutableList<Address>) { if (cont.isActive) cont.resume(addresses) }
                override fun onError(errorMessage: String?) { if (cont.isActive) cont.resume(null) }
            })
        } catch (_: Exception) { if (cont.isActive) cont.resume(null) }
    }

    // ---------- saved places ----------
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    data class Place(val name: String, val lat: Double, val lng: Double)

    fun places(c: Context): List<Place> {
        val o = try { JSONObject(prefs(c).getString(KEY_PLACES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        return o.keys().asSequence().mapNotNull { k ->
            o.optJSONObject(k)?.let { Place(k, it.optDouble("lat", Double.NaN), it.optDouble("lng", Double.NaN)) }
        }.filter { !it.lat.isNaN() && !it.lng.isNaN() }.sortedBy { it.name }.toList()
    }

    fun placeCount(c: Context) = places(c).size

    fun addPlace(c: Context, name: String, lat: Double, lng: Double) {
        val o = try { JSONObject(prefs(c).getString(KEY_PLACES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        o.put(norm(name), JSONObject().put("lat", lat).put("lng", lng))
        prefs(c).edit().putString(KEY_PLACES, o.toString()).apply()
    }

    fun deletePlace(c: Context, name: String): Boolean {
        val o = try { JSONObject(prefs(c).getString(KEY_PLACES, "{}") ?: "{}") } catch (_: Exception) { return false }
        val had = o.remove(norm(name)) != null
        prefs(c).edit().putString(KEY_PLACES, o.toString()).apply()
        return had
    }

    private fun findPlace(c: Context, name: String): Place? {
        val n = norm(name); if (n.isEmpty()) return null
        val all = places(c)
        return all.firstOrNull { it.name == n } ?: all.filter { it.name.startsWith(n) || it.name.contains(n) }.singleOrNull()
    }

    fun distanceText(meters: Float): String =
        if (meters < 950f) "${(Math.round(meters / 10f) * 10).coerceAtLeast(10)} meter" else String.format(Locale.US, "%.1f km", meters / 1000f)

    // ---------- command entry ----------
    suspend fun apply(c: Context, argRaw: String): String {
        val arg = argRaw.trim()
        val head = arg.substringBefore(' ').lowercase()
        val rest = arg.substringAfter(' ', "").trim()
        if (com.myra.assistant.system.PrivacyMode.isOn(c) && head != "places" && head != "delete")
            return "Privacy mode chalu, tai location dekhchi na."
        return when (head) {
            "", "where", "here", "now" -> where(c)
            "status" -> status(c)
            "places", "list" -> placesList(c)
            "save", "mark" -> save(c, rest)
            "delete", "remove" -> if (deletePlace(c, rest)) "$rest muchhe dilam." else "\"$rest\" naam-er kono jaiga nei."
            "distance", "dur", "doori" -> distance(c, rest)
            "go", "navigate", "nav", "route" -> navigate(c, rest)
            else -> "LOCATION where | save <naam> | places | delete <naam> | distance <naam> | go <jaiga> bolo."
        }
    }

    private fun needsSetup(c: Context): String? = when {
        !hasPermission(c) -> "Location permission nei. Drawer -> \"Sob permission do\" e location allow koro."
        !isLocationOn(c) -> "Phone-er Location off ache. Quick settings theke Location on koro."
        else -> null
    }

    private fun status(c: Context): String {
        val perm = if (hasPermission(c)) "permission ache" else "permission nei"
        val on = if (isLocationOn(c)) "Location on" else "Location off"
        return "$on, $perm, ${placeCount(c)} ta saved jaiga."
    }

    private suspend fun where(c: Context): String {
        needsSetup(c)?.let { return it }
        val loc = current(c) ?: return "Ekhon location pelam na. Khola jaygay giye abar chesta koro."
        val addr = address(c, loc)
        val acc = if (loc.hasAccuracy()) ", ~${loc.accuracy.toInt()}m er moddhe" else ""
        val coords = String.format(Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude)
        val near = places(c).minByOrNull { distTo(loc, it) }?.takeIf { distTo(loc, it) < 150f }
        return buildString {
            append(if (addr != null) "Tumi ekhon: $addr ($coords$acc)." else "Tumi ekhon $coords$acc.")
            if (near != null) append(" Eta tomar \"${near.name}\"-er kachhei.")
        }
    }

    private fun distTo(loc: Location, p: Place): Float {
        val r = FloatArray(1); Location.distanceBetween(loc.latitude, loc.longitude, p.lat, p.lng, r); return r[0]
    }

    private suspend fun save(c: Context, name: String): String {
        if (norm(name).isEmpty()) return "Ki naam-e save korbo? Jemon: LOCATION save home"
        needsSetup(c)?.let { return it }
        val loc = current(c) ?: return "Ekhon location pelam na, save kora gelo na."
        addPlace(c, name, loc.latitude, loc.longitude)
        return "\"${norm(name)}\" hishebe ei jaiga save korlam."
    }

    private fun placesList(c: Context): String {
        val p = places(c)
        return if (p.isEmpty()) "Kono jaiga save kora nei. \"save home\" bolo." else "${p.size} ta jaiga: " + p.joinToString(", ") { it.name }
    }

    private suspend fun distance(c: Context, name: String): String {
        val p = findPlace(c, name) ?: return "\"$name\" naam-er jaiga save kora nei."
        needsSetup(c)?.let { return it }
        val loc = current(c) ?: return "Ekhon location pelam na."
        return "${p.name} ekhan theke prai ${distanceText(distTo(loc, p))} dure."
    }

    /** Opens turn-by-turn navigation in the maps app, for a saved place or any address / name. */
    private fun navigate(c: Context, target: String): String {
        if (target.isBlank()) return "Kothay jabo? Jemon: LOCATION go home"
        val p = findPlace(c, target)
        val uri = if (p != null) Uri.parse("google.navigation:q=${p.lat},${p.lng}")
                  else Uri.parse("google.navigation:q=" + Uri.encode(target))
        return try {
            val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(c.packageManager) == null) {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(target))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else c.startActivity(i)
            "${p?.name ?: target}-er directions khulchi."
        } catch (_: Exception) { "Maps app khola gelo na." }
    }
}
