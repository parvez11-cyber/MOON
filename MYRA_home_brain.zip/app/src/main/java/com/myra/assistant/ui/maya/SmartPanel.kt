package com.myra.assistant.ui.maya

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.ai.ContextualShortcuts
import com.myra.assistant.ai.MemoryRevival
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.voice.NoiseControl
import com.myra.assistant.voice.VoiceLock
import kotlinx.coroutines.delay

/**
 * Drawer -> "Smart". One place for the three smart features:
 *  1. Memory revival      (ai/MemoryRevival.kt)
 *  2. Contextual shortcuts (ai/ContextualShortcuts.kt)
 *  3. Noise control + voice isolation (voice/NoiseControl.kt)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var revOn by remember { mutableStateOf(MemoryRevival.enabled(ctx)) }
    var days by remember { mutableStateOf(MemoryRevival.dormantDays(ctx)) }
    var scOn by remember { mutableStateOf(ContextualShortcuts.enabled(ctx)) }
    var level by remember { mutableStateOf(NoiseControl.level(ctx)) }
    var auto by remember { mutableStateOf(NoiseControl.auto(ctx)) }
    var vad by remember { mutableStateOf(NoiseControl.vadSensitivity(ctx)) }
    var pred by remember { mutableStateOf(NoiseControl.predict(ctx)) }
    var iso by remember { mutableStateOf(NoiseControl.isolation(ctx)) }
    var tick by remember { mutableStateOf(0) }
    var room by remember { mutableStateOf(NoiseControl.roomLabel()) }
    val dormant = remember(tick, days) { MemoryRevival.dormantSummary(ctx) }
    val total = remember(tick) { PersistentMemory.all().size }
    val shortcuts = remember(tick, scOn) { ContextualShortcuts.describe(ctx) }
    val locked = remember(tick) { VoiceLock.active(ctx) }

    // the room level is live while the microphone is on
    LaunchedEffect(Unit) { while (true) { room = NoiseControl.roomLabel(); delay(1000) } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Smart features", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)

            // ---------------------------------------------------------- 1. memory revival
            SLabel("Smriti punorujjibon (Memory revival)")
            SSwitchRow("Purono kotha mone pore", "Onekdin chup thaka kono yaad, ei shomoy ba ei kothar shathe mile gele Maya nijei mone koriye dey. Shudhu kajer yaad-gulo prompt-e jay, shob na.", revOn) {
                revOn = it; MemoryRevival.setEnabled(ctx, it)
            }
            SSliderRow("Koto din chup thakle mone korabe", "$days din", days.toFloat(), 1f..14f) { v ->
                days = Math.round(v); MemoryRevival.setDormantDays(ctx, days)
            }
            Text(
                if (total == 0) "Ekhono kono yaad nei. Maya-ke tomar kotha bolo, ba Yaadein tab-e resume dao."
                else "Mot $total ta yaad, tar moddhe ${dormant.first} ta ${days}+ din dhore chup." +
                    (dormant.second?.let { "\nSobcheye purono: \"${it.take(80)}\"" } ?: ""),
                color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            SLink("Revival-er hishab muche felo") {
                MemoryRevival.clearAll(ctx); tick++
                Toast.makeText(ctx, "Revival hishab muche dilam (yaad-gulo ache)", Toast.LENGTH_SHORT).show()
            }
            Text("Privacy mode chalu thakle revival bondho. Yaad-gulo ei phone-e thake; Gemini shudhu ei shomoyer jonno bachhai kora koyekta paay.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))

            // ---------------------------------------------------------- 2. contextual shortcuts
            SLabel("Smart shortcut")
            SSwitchRow("Ekhon-er jonno shortcut", "Kon app-e chile, headphone, charger, battery, shomoy dekhe home-e ek-tap shortcut", scOn) {
                scOn = it; ContextualShortcuts.setEnabled(ctx, it)
            }
            Text(if (scOn) "Ekhon: $shortcuts" else "Bondho.", color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Text("Kon app-e chile seta jante Accessibility chalu thakte hobe. Shudhu harmless kaj (volume, brightness, torch, theme, app khola); tap korle tobei chole.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            SLink("Kon shortcut-e tap korechi seta bhule jao") {
                ContextualShortcuts.clearAll(ctx); tick++
                Toast.makeText(ctx, "Shortcut-er hishab muche dilam", Toast.LENGTH_SHORT).show()
            }

            // ---------------------------------------------------------- 3. noise control + voice isolation
            SLabel("Noise control")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(NoiseControl.OFF, NoiseControl.LIGHT, NoiseControl.MEDIUM, NoiseControl.STRONG).forEach { l ->
                    SPill(NoiseControl.name(l), level == l, Modifier.weight(1f)) { level = l; NoiseControl.setLevel(ctx, l) }
                }
            }
            Text(
                when (level) {
                    NoiseControl.OFF -> "Kono filter nei."
                    NoiseControl.LIGHT -> "Halka: rumble ar shanto ghorer hum kome. Roj-er jonno bhalo."
                    NoiseControl.MEDIUM -> "Medium: fan, AC, rastar noise bhalo kome."
                    else -> "Strong: bhir / onek noise-e. Aste bolle shuru-r shobdo kete jete pare."
                }, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            SSwitchRow("Auto", "Ghor onek noisy hole nijei ek dhap bariye dey", auto) { auto = it; NoiseControl.setAuto(ctx, it) }
            Text("Ghor ekhon: $room (mic chalu thakle live dekhay)", color = MC.Sub, fontSize = 13.sp)
            SSwitchRow("Smart noise prediction", "Kon shomoy ghor kotota noisy thake shikhe, noise shuru hobar age-i level bariye rakhe", pred) { pred = it; NoiseControl.setPredict(ctx, it); tick++ }
            Text("Ei shomoy shadharonoto: " + remember(tick, pred) { NoiseControl.predictionLabel(ctx) }, color = MC.Sub, fontSize = 13.sp)
            SLink("Noise-er shikha muche felo") { NoiseControl.clearPrediction(ctx); tick++; Toast.makeText(ctx, "Noise prediction muche dilam", Toast.LENGTH_SHORT).show() }
            Text("Eta noise gate: kotha-r majhe majhe jey noise thake seta kome, kintu tomar kotha-r shathe ekshathe hoye jawa noise (jemon kono-ke bolche) soray na. Seta Voice isolation-er kaj.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))

            SLabel("Voice activity detection (kotha shuru / shesh bojha)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Kom (noisy jaygay)", "Normal", "Beshi (aste bolle)").forEachIndexed { i, l ->
                    SPill(l, vad == i, Modifier.weight(1f)) { vad = i; NoiseControl.setVadSensitivity(ctx, i) }
                }
            }
            Text("Ekhon shudhu jore shobdo na, gola-r moto shobdo (voice-er frequency, zero-crossing) holei kotha dhore; dorja-r shobdo, thap, hanch-ite sentence shuru hoy na. Choto command taratari, lomba sentence-e majhe thamle-o shesh hoy na.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))

            SLabel("Reply speed")
            var lat by remember { mutableStateOf("") }
            LaunchedEffect(Unit) {
                while (true) {
                    val m = com.myra.assistant.voice.LatencyMeter
                    lat = if (m.count == 0) "Ekhono maap hoyni. Maya-r shathe ekta kotha bolo." else "Shesh uttor: ${m.lastMs} ms · gorporta: ${m.avgMs} ms (${m.count} bar)"
                    delay(1000)
                }
            }
            Text(lat, color = MC.Sub, fontSize = 13.sp)
            Text("Tumi kotha shesh korar por Maya-r prothom awaj shonar shomoy. Internet / Gemini-r gotir upor-o nirbhor kore.", color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))

            SLabel("Voice isolation")
            SSwitchRow("Shudhu amar gola", "Sentence-er majheo ~1.2 sec por por voice mila-e dekhe. Onno keu kotha bolle Maya shunna bondho kore, ar call / message-er moto kaj-e notun kore voice match lage.", iso && locked) {
                if (it && !locked) Toast.makeText(ctx, "Age Settings > Voice Lock-e tomar voice save kore chalu koro", Toast.LENGTH_LONG).show()
                else { iso = it; NoiseControl.setIsolation(ctx, it); tick++ }
            }
            if (!locked) Text("Voice Lock chalu / voice save kora nei, tai eta ekhon kaj korbe na.", color = MC.BlueDeep, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            Text("Halka speaker-check, bank-grade na. Onno keu shuru korle prothom 1-2 sec ager-ta Maya-r kache chole jete pare.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))
            Text("Voice-e bolte paro: \"noise control strong\", \"noise off\", \"voice isolation on\".",
                color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 28.dp))
        }
    }
}

@Composable
private fun SLabel(text: String) {
    Text(text, color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
private fun SLink(text: String, onClick: () -> Unit) {
    Text(text, color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp,
        modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp, horizontal = 4.dp))
}

@Composable
private fun SPill(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(46.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp), textAlign = TextAlign.Center)
    }
}

@Composable
private fun SSwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(sub, color = MC.Sub, fontSize = 13.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun SSliderRow(title: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(value, color = MC.Sub, fontSize = 14.sp)
        }
        Slider(v, onChange, valueRange = range)
    }
}
