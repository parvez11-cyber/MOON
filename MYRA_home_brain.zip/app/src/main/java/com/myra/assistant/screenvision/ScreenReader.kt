package com.myra.assistant.screenvision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Lets Maya actually see the display.
 *
 * 1. Reads every visible text / button from the accessibility tree (fast, exact).
 * 2. Takes a screenshot (accessibility API, or root `screencap` as a fallback) and streams it to Gemini
 *    as an image, so she can also understand pictures, games, maps and apps with no readable text.
 * 3. If the tree is empty, runs on-device OCR on the screenshot.
 *
 * Everything returned here is DATA from the screen. The system prompt tells the model never to obey
 * instructions that appear inside it.
 */
object ScreenReader {
    private const val TAG = "SCREEN_READER"
    private const val MAX_CHARS = 3500

    suspend fun describe(context: Context): String {
        val service = AccessibilityHelperService.instance
        if (service == null && !RootAccess.isRootAvailable) {
            return "Screen dekha jabe na: Accessibility service off. Settings > Accessibility te Maya on korte hobe."
        }

        val sb = StringBuilder()
        val root = AccessibilityHelperService.getFreshRoot()
        if (root != null) {
            sb.append("App: ").append(appLabel(context, root.packageName?.toString())).append('\n')
            val dm = context.resources.displayMetrics
            sb.append("(Numbered items: use TAP_NUMBER <n>; @(x%,y%) is the position on screen for TAP_AT)\n")
            com.myra.assistant.system.ScreenControl.buildMap(root, dm.widthPixels, dm.heightPixels)
                .forEach { if (sb.length < MAX_CHARS) sb.append(it).append('\n') }
        }

        val shot = screenshot()
        if (shot != null) {
            if (sb.length < 80) {
                val ocr = ocr(shot)
                if (ocr.isNotBlank()) sb.append("(OCR) ").append(ocr.take(MAX_CHARS))
            }
            val jpeg = toJpeg(shot)
            ForegroundVoiceService.instance?.sendVideoFrame(jpeg)
            sb.append("\n[A screenshot of the screen was also sent to you as an image. Describe what you see.]")
        }

        return if (sb.isBlank()) "Screen e kichu pawa jayni (screen lock ba secure app hote pare)." else sb.toString().take(MAX_CHARS + 200)
    }

    private fun appLabel(context: Context, pkg: String?): String {
        pkg ?: return "unknown"
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        node ?: return
        if (depth > 40 || out.size > 220) return
        try {
            if (node.isVisibleToUser) {
                val text = (node.text ?: node.contentDescription ?: node.hintText)?.toString()?.trim().orEmpty()
                if (text.isNotEmpty()) {
                    val kind = when {
                        node.isEditable -> "[input] "
                        node.isClickable || node.isCheckable -> "[button] "
                        else -> ""
                    }
                    val r = Rect(); node.getBoundsInScreen(r)
                    out.add("$kind${text.take(200)}")
                }
            }
            for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
        } catch (e: Exception) {
            Logger.e(TAG, "collect: ${e.message}")
        }
    }

    private suspend fun screenshot(): Bitmap? {
        val viaService = withTimeoutOrNull(3000) {
            suspendCancellableCoroutine<Bitmap?> { cont ->
                AccessibilityHelperService.takeScreenScreenshot { if (cont.isActive) cont.resume(it) }
            }
        }
        if (viaService != null) return viaService
        return RootAccess.screencap()
    }

    /** Just a screenshot of whatever is on screen right now, as a small JPEG. Null if none could be taken. */
    suspend fun screenshotJpeg(): ByteArray? = screenshot()?.let { toJpeg(it) }

    private suspend fun ocr(bitmap: Bitmap): String = withTimeoutOrNull(4000) {
        suspendCancellableCoroutine<String> { cont ->
            OCRProcessor.extractText(bitmap) { if (cont.isActive) cont.resume(it) }
        }
    }.orEmpty()

    private fun toJpeg(src: Bitmap): ByteArray {
        val w = 768
        val scaled = if (src.width > w) Bitmap.createScaledBitmap(src, w, (src.height * w.toFloat() / src.width).toInt(), true) else src
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return out.toByteArray()
    }
}
