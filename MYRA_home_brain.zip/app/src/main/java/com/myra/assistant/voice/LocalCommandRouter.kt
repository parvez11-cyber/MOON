package com.myra.assistant.voice

import android.content.Context
import com.myra.assistant.apps.InstalledAppsManager

/**
 * Understands the everyday phone commands on the device itself (Bangla, Banglish, Hindi, English),
 * so they run instantly: no network round trip, and they also work offline.
 *
 * Deliberately strict: only short, clear commands match. Anything else returns null and is left to
 * Gemini. Returns the same structured command string the rest of the app already understands.
 */
object LocalCommandRouter {

    private val FILLER = setOf(
        "maya", "myra", "মায়া", "মাইরা", "please", "plz", "pls", "প্লিজ", "ভাই", "bhai", "ek", "ekta", "একটু", "একটা",
        "zara", "jara", "ji", "জি", "na", "না", "to", "তো", "hey", "hi", "ok", "okay", "দাও", "dao", "do", "de", "দে", "দিন", "dijiye"
    )
    private val DOERS = setOf("koro", "karo", "kar", "kro", "করো", "কর", "করুন", "করে", "kijiye", "kijie")

    private val TORCH = listOf("torch", "flashlight", "flash light", "tarch", "টর্চ", "ফ্ল্যাশলাইট", "ফ্ল্যাশ লাইট", "टॉर्च")
    private val ON = listOf(" on", "chalu", "jalao", "jalaw", "jalo", "jala", "চালু", "জ্বালাও", "জ্বালিয়ে", "জ্বেলে", "জ্বাল", "অন", "চালাও", "चालू", "जलाओ")
    private val OFF = listOf(" off", "band", "bondho", "bondo", "nibhao", "nivao", "বন্ধ", "নিভাও", "নিভিয়ে", "অফ", "बंद", "बन्द")
    private val VOL = listOf("volume", "ভলিউম", "আওয়াজ", "awaj", "awaz", "sound", "শব্দ", "আওয়াজ", "वॉल्यूम", "आवाज")
    private val UP = listOf(" up", "badhao", "barao", "baro", "বাড়াও", "বাড়িয়ে", "বেশি", "zyada", "jyada", "increase", "louder", "tez", "बढ़ाओ", "बढ़ा")
    private val DOWN = listOf(" down", "kam", "komao", "কমাও", "কমিয়ে", "কম", "decrease", "lower", "dhire", "ধীরে", "कम")

    private val TASK_LIST_PHRASES = setOf("task list", "tasks", "my tasks", "todo list", "top task", "task priority", "what should i do first",
        "ki korbo age", "aj ki kaj", "আজকের কাজ", "কাজের তালিকা", "ki kaj baki")

    private val BRIEFING_PHRASES = setOf("briefing", "morning briefing", "daily briefing", "my briefing", "aj-er shar", "aj er shar", "sokaler briefing", "সকালের ব্রিফিং", "ব্রিফিং")

    private val PRIVACY_WORDS = listOf("privacy mode", "private mode", "privacy on", "privacy off", "প্রাইভেসি মোড", "প্রাইভেট মোড")

    private val NOISE_WORDS = listOf("noise control", "noise cancel", "noise reduction", "noise", "নয়েজ", "voice isolation", "isolation", "আইসোলেশন")

    private val THEME_WORDS = listOf(
        "theme", "থিম", "dark mode", "ডার্ক মোড", "light mode", "লাইট মোড", "night mode", "নাইট মোড", "amoled", "dark theme", "light theme",
        "predictive", "suggestion", "সাজেশন", "autocomplete", "glow", "mood rong", "mood color", "font size", "ফন্ট"
    )

    private val SMARTHOME_SYNC = setOf("smart home sync", "sync smart home", "sync home devices", "home sync", "স্মার্ট হোম সিঙ্ক")
    private val LOCATION_PHRASES = mapOf(
        "where am i" to "LOCATION where", "my location" to "LOCATION where", "current location" to "LOCATION where",
        "ami kothay" to "LOCATION where", "ami kothay achi" to "LOCATION where", "আমি কোথায়" to "LOCATION where", "আমি কোথায় আছি" to "LOCATION where",
        "saved places" to "LOCATION places", "my places" to "LOCATION places"
    )

    private val HOME = setOf("home", "go home", "home jao", "home chalo", "হোম", "হোমে যাও", "হোমে চলো", "হোমে নাও", "होम", "घर जाओ")
    private val BACK = setOf("back", "go back", "back jao", "peeche jao", "pichhe jao", "ব্যাক", "পিছনে যাও", "পেছনে যাও", "ফিরে যাও", "वापस जाओ", "पीछे जाओ")
    private val RECENTS = setOf("recent", "recents", "recent apps", "recent app", "রিসেন্ট", "রিসেন্ট অ্যাপ", "রিসেন্ট অ্যাপস", "सेंट")

    private val OPEN_PREFIX = listOf("open ", "launch ", "start ", "খোলো ", "ওপেন ")
    private val OPEN_SUFFIX = listOf(
        " kholo", " khulo", " khol", " kholiye", " open", " chalao", " chalu", " chalu karo", " launch",
        " খোলো", " খুলো", " খুলুন", " খুলে", " ওপেন", " চালাও", " চালু", " খোল", " खोलो", " खोल", " चलाओ"
    )

    private val ALIAS = mapOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটসঅ্যাপে" to "whatsapp", "ইউটিউব" to "youtube", "ফেসবুক" to "facebook",
        "মেসেঞ্জার" to "messenger", "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "গ্যালারী" to "gallery",
        "সেটিংস" to "settings", "সেটিং" to "settings", "ক্রোম" to "chrome", "গুগল" to "google", "জিমেইল" to "gmail",
        "টেলিগ্রাম" to "telegram", "ইনস্টাগ্রাম" to "instagram", "টিকটক" to "tiktok", "স্পটিফাই" to "spotify",
        "ম্যাপস" to "maps", "ম্যাপ" to "maps", "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock", "ফোন" to "phone",
        "মেসেজ" to "messages", "বিকাশ" to "bkash", "নগদ" to "nagad", "व्हाट्सएप" to "whatsapp"
    )

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Strips Maya's name, politeness words and "karo" so "maya torch on karo please" becomes "torch on". */
    private fun clean(s: String): String =
        norm(s).split(' ').filter { it.isNotEmpty() && it !in FILLER && it !in DOERS }.joinToString(" ")

    fun match(context: Context, raw: String, allowShortcuts: Boolean = true): String? {
        val t0 = clean(raw)
        if (t0.isEmpty()) return null
        if (allowShortcuts) {
            // save a shortcut by typing or voice, and run it later by just saying / typing its name
            shortcutDefinition(raw)?.let { return it }
            com.myra.assistant.ai.RoutineStore.nameFor(context, t0)?.let { return "ROUTINE_RUN $it" }
        }
        // "memory save kal ami khushi chilam" / "yaad rakho: ..." / "মনে রাখো ..." / "save emotion: ..." -> saved + shown in the brain
        memoryCommand(raw)?.let { return it }
        memorySearch(raw)?.let { return it }
        // "add task bill dibo kal" (any length: the title is the user's own words, kept as typed)
        Regex("(?i)^\\s*(?:maya\\s+|myra\\s+)?(?:add task|task add|add todo|todo add)\\s+(.+)$").find(raw)?.let { return "TASK add " + it.groupValues[1].trim() }
        val t = " $t0"
        if (t0.split(' ').size > 6) return null

        // smart home: "smart home sync", and "bedroom light off" (only when that device was synced from Home Assistant)
        if (t0 in SMARTHOME_SYNC) return "SMARTHOME sync"
        if (!t.contains("torch") && !t.contains("flash")) com.myra.assistant.home.SmartHome.matchSpoken(context, t0)?.let { return it }
        // location: "where am i", "location save home", "take me home" style commands
        LOCATION_PHRASES[t0]?.let { return it }
        Regex("^(?:location save|save location|save this place as|save place)\\s+(.+)$").find(t0)?.let { return "LOCATION save " + it.groupValues[1] }
        Regex("^(?:navigate|directions|take me|route)(?: to)?\\s+(.+)$").find(t0)?.let { return "LOCATION go " + it.groupValues[1] }
        Regex("^(?:distance(?: to)?|how far is)\\s+(.+)$").find(t0)?.let { return "LOCATION distance " + it.groupValues[1] }

        // tasks: "my tasks" / "ki korbo age"
        if (t0 in TASK_LIST_PHRASES) return "TASK top"
        if (t0 in BRIEFING_PHRASES) return "TASK briefing"
        Regex("^(?:morning |daily )?briefing (on|off|\\d{1,2})$").find(t0)?.let { return "TASK briefing " + it.groupValues[1] }
        // privacy mode: "privacy mode on", "private mode off", "প্রাইভেসি মোড চালু"
        if (PRIVACY_WORDS.any { t.contains(it) }) {
            val off = OFF.any { t.contains(it) } || t.contains(" stop") || t.contains(" exit") || t.contains(" disable")
            val on = ON.any { t.contains(it) } || t.contains(" enable") || t.contains(" start")
            if (off) return "PRIVACY off"
            if (on || t0.split(' ').size <= 3) return "PRIVACY on"
            return null
        }
        // noise control / voice isolation: "noise control strong", "noise off", "voice isolation on", "নয়েজ কন্ট্রোল চালু"
        if (NOISE_WORDS.any { t.contains(it) } && t0.split(' ').size <= 4) return "NOISE $t0"
        // theme: "dark mode on", "light mode", "theme pink", "amoled on" (a question like "dark mode kya hota hai" is left to Gemini)
        if (THEME_WORDS.any { t.contains(it) }) {
            val short = t0.split(' ').size <= 3
            if (short || ON.any { t.contains(it) } || OFF.any { t.contains(it) }) {
                if (t0.split(' ').size >= 2 || t0.contains("amoled")) return "THEME $t0"
            }
            return null
        }
        // torch
        if (TORCH.any { t.contains(it) }) {
            return when {
                OFF.any { t.contains(it) } -> "FLASHLIGHT_OFF"
                ON.any { t.contains(it) } -> "FLASHLIGHT_ON"
                else -> null
            }
        }
        // volume
        if (VOL.any { t.contains(it) }) {
            return when {
                UP.any { t.contains(it) } -> "VOLUME_UP"
                DOWN.any { t.contains(it) } -> "VOLUME_DOWN"
                else -> null
            }
        }
        // navigation: only when that is the whole sentence
        if (t0 in HOME) return "HOME"
        if (t0 in BACK) return "BACK"
        if (t0 in RECENTS) return "RECENTS"

        // open <app> / <app> kholo
        var app: String? = null
        for (p in OPEN_PREFIX) if (t0.startsWith(p)) { app = t0.removePrefix(p); break }
        if (app == null) for (sfx in OPEN_SUFFIX) {
            val s = sfx.trim()
            if (t0.endsWith(" $s")) { app = t0.removeSuffix(" $s"); break }
        }
        if (app != null) {
            val name = app.trim().split(' ').joinToString(" ") { ALIAS[it] ?: it }.trim()
            if (name.isEmpty() || name.split(' ').size > 3) return null
            // only claim it if the app really exists on this phone, otherwise let Gemini sort it out
            val found = InstalledAppsManager.findApp(context, name) ?: return null
            if (!(found.name.contains(name) || name.contains(found.name))) return null
            return "OPEN_APP $name"
        }
        return null
    }

    /** "Rahim niye ki bolechilam?", "what do you remember about mom", "search memory bill" -> MEMORY search <words> */
    private fun memorySearch(raw: String): String? {
        val s = raw.trim()
        val pats = listOf(
            """(?is)^\s*(?:maya\s+|myra\s+)?(?:search|find|khojo|khuje\s+dekho)\s+(?:my\s+)?(?:memory|memories|yaad|মেমরি|স্মৃতি)\s*(?:for|about|e|te|:)?\s*(.{2,60})$""",
            """(?is)^\s*(?:maya\s+|myra\s+)?(?:what do you remember about|what did i (?:say|tell you) about|do you remember|remember anything about)\s+(.{2,60}?)\s*\??\s*$""",
            """(?is)^\s*(?:maya\s+|myra\s+)?(.{2,40}?)\s+(?:niye|sombondhe|somporke|shomporke|bepare)\s+(?:ami\s+)?(?:ki|kii|kichu)\s+(?:bolechilam|bolechhilam|bolechi|rekhechi|save korechi|mone ache|yaad ache)\s*\??\s*$""",
            """(?is)^\s*(.{2,40}?)\s+(?:নিয়ে|সম্পর্কে|সম্বন্ধে)\s+(?:আমি\s+)?(?:কী|কি)\s+(?:বলেছিলাম|বলেছি|রেখেছি|মনে আছে)\s*\??\s*$"""
        )
        for (p in pats) Regex(p).find(s)?.let { return "MEMORY search " + it.groupValues[1].trim() }
        return null
    }

    private val MEMORY_LIST = setOf("memory list", "memories", "my memories", "yaad list", "মেমরি লিস্ট", "মেমোরি লিস্ট", "স্মৃতি লিস্ট")

    /**
     * "memory save <text>", "remember <text>", "yaad rakho <text>", "mone rakho <text>", "মনে রাখো <text>", "মেমরি সেভ <text>",
     * and with a type: "save emotion: <text>" / "save thought: <text>" / "save memory: <text>". -> MEMORY add [type:] <text>
     */
    private fun memoryCommand(raw: String): String? {
        val s = raw.trim()
        if (norm(s) in MEMORY_LIST) return "MEMORY list"
        val lead = "(?:maya\\s+|myra\\s+)?(?:memory\\s+save|save\\s+memory|save(?=\\s+(?:emotion|feeling|thought|idea|memory|আবেগ|ভাবনা|স্মৃতি)(?=[\\s:：\\-]))|remember(?:\\s+this)?|yaad\\s+rakho|yad\\s+rakho|mone\\s+rakho|mone\\s+rekho|মনে\\s+রাখো|মনে\\s+রেখো|মনে\\s+রাখ|মেমরি\\s+সেভ(?:\\s+করো)?|মেমোরি\\s+সেভ(?:\\s+করো)?|সেভ\\s+করো)"
        val m = Regex("(?is)^\\s*$lead\\s*[:,\\-]?\\s+(.{2,})$").find(s) ?: return null
        val body = m.groupValues[1].trim()
        // a plain "save <word>" must not swallow other commands like "save location home"
        if (Regex("(?i)^(?:location|place|shortcut|routine|task)\\b").containsMatchIn(body)) return null
        return "MEMORY add $body"
    }

    /** "shortcut morning: youtube kholo, torch on"  /  "morning shortcut banao youtube kholo ar torch on" -> ROUTINE_ADD morning | ... */
    private fun shortcutDefinition(raw: String): String? {
        val s = raw.trim()
        val kw = "(?:shortcut|short cut|routine|macro|শর্টকাট|রুটিন)"
        val verb = "(?:save|add|set|new|create|banao|banaw|বানাও|সেভ|সেট|নতুন)"
        val m = Regex("(?i)^\\s*(?:maya\\s+|myra\\s+)?$kw\\s+(?:$verb\\s+)?([^:=]+?)\\s*(?::|=|->|\\bbolle\\b|\\bjate\\b|বললে|যাতে)\\s*(.+)$").find(s)
            ?: Regex("(?i)^\\s*(?:maya\\s+|myra\\s+)?([^:=]+?)\\s+$kw\\s+$verb(?:\\s+koro|\\s+kor|\\s+করো)?\\s*(?::|=|,|\\bbolle\\b|\\bjate\\b|বললে|যাতে)?\\s*(.+)$").find(s)
            ?: return null
        val name = m.groupValues[1].trim()
        val steps = com.myra.assistant.ai.RoutineStore.splitSteps(m.groupValues[2])
        if (name.isEmpty() || steps.isEmpty()) return null
        return "ROUTINE_ADD $name | " + steps.joinToString(" | ")
    }

    /** Same action = same key, so a command that ran locally is not run again when Gemini sends it too. */
    fun keyOf(command: String): String {
        val c = command.trim()
        val head = c.substringBefore(' ').uppercase()
        // commands that carry their own content (a message, a target) are keyed by that content,
        // so two different SMS in one go are both sent, while the same one is never sent twice
        val withArgs = setOf("OPEN_APP", "SMS", "TYPE_TEXT", "TAP_BUTTON", "WHATSAPP_MSG", "REPLY_NOTIFICATION", "REPLY_NOTIFICATION_TO", "SYSTEM", "BRIGHTNESS", "THEME", "PRIVACY", "NOISE", "TASK", "CALL", "WHATSAPP_CALL", "SCROLL", "SCROLL_TO", "SWIPE", "TAP_AT", "TAP_NUMBER", "LONG_PRESS", "ROUTINE_SAVE", "ROUTINE_ADD", "ROUTINE_RUN", "ROUTINE_DELETE", "SMARTHOME", "LOCATION", "MEMORY")
        return if (head in withArgs) head + " " + c.substringAfter(' ', "").lowercase().trim() else head
    }
}
