package com.myra.assistant.ui.maya

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.myra.assistant.services.ForegroundVoiceService
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

private val HudBg = Color(0xFF050508)
private val HudBlue = Color(0xFF2F74D0)
private val HudBlueText = Color(0xFF3F7BD0)
private val HudDim = Color(0xFF4C5E86)
private val HudGreen = Color(0xFF3DDC84)

/** ImageProxy -> JPEG, rotated upright and scaled so frames stay small and fast. */
private fun ImageProxy.toJpeg(maxSide: Int, quality: Int): ByteArray {
    var bmp = toBitmap()
    val m = Matrix()
    val scale = maxSide.toFloat() / max(bmp.width, bmp.height)
    if (scale < 1f) m.postScale(scale, scale)
    if (imageInfo.rotationDegrees != 0) m.postRotate(imageInfo.rotationDegrees.toFloat())
    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    val o = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.JPEG, quality, o)
    return o.toByteArray()
}

/**
 * MAYA VISION. Live camera with the HUD:
 *  - shutter: take one photo and send it to Maya to explain
 *  - REC: start a vision session. A frame goes to Maya's live voice session about once a second,
 *    so she can see what you point at while you talk to her
 *  - FLIP: front / back camera
 */
@Composable
fun ScanTab(onResult: (String) -> Unit, onStartVoice: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var hasCam by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    var front by remember { mutableStateOf(false) }
    var live by remember { mutableStateOf(false) }
    var frm by remember { mutableIntStateOf(4181) }
    var sig by remember { mutableIntStateOf(65) }
    var connected by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    val executor = remember { Executors.newSingleThreadExecutor() }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val analysis = remember { ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build() }
    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    // camera on while this tab is open
    DisposableEffect(hasCam, front) {
        var provider: ProcessCameraProvider? = null
        if (hasCam) {
            val fut = ProcessCameraProvider.getInstance(ctx)
            fut.addListener({
                try {
                    val p = fut.get()
                    provider = p
                    val preview = Preview.Builder().build()
                    preview.setSurfaceProvider(previewView.surfaceProvider)
                    p.unbindAll()
                    p.bindToLifecycle(
                        owner,
                        if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                        preview, imageCapture, analysis
                    )
                } catch (_: Exception) { note = "CAMERA START NAHI HUA" }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { provider?.unbindAll() } catch (_: Exception) {} }
    }

    // vision session: send a frame to Maya about once a second
    DisposableEffect(live) {
        if (live) {
            var last = 0L
            analysis.setAnalyzer(executor) { proxy ->
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now - last >= 900) {
                        last = now
                        val svc = ForegroundVoiceService.instance
                        if (svc != null && svc.isGeminiConnected()) svc.sendVideoFrame(proxy.toJpeg(512, 55))
                    }
                } catch (_: Exception) {
                } finally { proxy.close() }
            }
        }
        onDispose { try { analysis.clearAnalyzer() } catch (_: Exception) {} }
    }

    // HUD numbers and connection status
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            kotlinx.coroutines.delay(100)
            frm += 3
            tick++
            connected = ForegroundVoiceService.instance?.isGeminiConnected() == true
            val base = if (live && connected) 90 else 62
            if (tick % 4 == 0) sig = base + ((tick / 4) * 5) % 7
        }
    }

    val t = rememberInfiniteTransition(label = "hud")
    val spin1 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "s1")
    val spin2 by t.animateFloat(0f, -360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "s2")
    val pulse by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "p")

    Box(Modifier.fillMaxSize().background(HudBg)) {
        // camera feed: dim in standby, full while the vision session is live
        if (hasCam) AndroidView({ previewView }, Modifier.fillMaxSize().alpha(if (live) 1f else 0.3f))

        Canvas(Modifier.fillMaxSize()) {
            val grid = Color(0x14295AA8)
            val step = 40.dp.toPx()
            var x = 0f
            while (x < size.width) { drawLine(grid, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
            var y = 0f
            while (y < size.height) { drawLine(grid, Offset(0f, y), Offset(size.width, y), 1f); y += step }
            val axis = Color(0x30295AA8)
            drawLine(axis, Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), 1.5f)
            drawLine(axis, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.5f)

            val c = Offset(size.width / 2, size.height / 2)
            // dashed outer ring
            rotate(spin1, c) {
                drawCircle(HudBlue.copy(alpha = 0.8f), 107.dp.toPx(), c,
                    style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 14f))))
            }
            // four sweeping arcs
            val ar = 88.dp.toPx()
            rotate(spin2, c) {
                for (i in 0 until 4) {
                    drawArc(HudBlue, 20f + i * 90f, 62f, false, Offset(c.x - ar, c.y - ar), Size(ar * 2, ar * 2),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            // cross-hair ticks
            val a = 73.dp.toPx(); val b = 82.dp.toPx(); val tw = 1.5.dp.toPx()
            drawLine(HudBlue, Offset(c.x - b, c.y), Offset(c.x - a, c.y), tw)
            drawLine(HudBlue, Offset(c.x + a, c.y), Offset(c.x + b, c.y), tw)
            drawLine(HudBlue, Offset(c.x, c.y - b), Offset(c.x, c.y - a), tw)
            drawLine(HudBlue, Offset(c.x, c.y + a), Offset(c.x, c.y + b), tw)
            drawCircle(Color(0xFF3B8EEA).copy(alpha = pulse), 5.dp.toPx(), c)

            // corner brackets (outer + a thinner inner one)
            fun bracket(cx: Float, cy: Float, sx: Float, sy: Float, len: Float, w: Float, col: Color) {
                drawLine(col, Offset(cx, cy), Offset(cx + sx * len, cy), w)
                drawLine(col, Offset(cx, cy), Offset(cx, cy + sy * len), w)
            }
            val m = 26.dp.toPx(); val l1 = 40.dp.toPx(); val l2 = 28.dp.toPx(); val g = 7.dp.toPx()
            val outer = Color(0xFF2B5FA8); val inner = Color(0x992B5FA8)
            val w1 = 2.5.dp.toPx(); val w2 = 1.5.dp.toPx()
            bracket(m, m, 1f, 1f, l1, w1, outer); bracket(m + g, m + g, 1f, 1f, l2, w2, inner)
            bracket(size.width - m, m, -1f, 1f, l1, w1, outer); bracket(size.width - m - g, m + g, -1f, 1f, l2, w2, inner)
            bracket(m, size.height - m, 1f, -1f, l1, w1, outer); bracket(m + g, size.height - m - g, 1f, -1f, l2, w2, inner)
            bracket(size.width - m, size.height - m, -1f, -1f, l1, w1, outer); bracket(size.width - m - g, size.height - m - g, -1f, -1f, l2, w2, inner)
        }

        // top: title, camera name, status line
        Row(Modifier.fillMaxWidth().padding(start = 15.dp, end = 15.dp, top = 12.dp), verticalAlignment = Alignment.Top) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (live) HudGreen else Color(0xFF8A94B8)))
                Spacer(Modifier.width(10.dp))
                Text("MAYA VISION", color = HudBlueText, fontSize = 17.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Medium)
            }
            Text(if (front) "FRONT CAM" else "BACK CAM", color = Color(0xFF5D6C94), fontSize = 13.sp, letterSpacing = 1.sp)
        }
        Text(
            note?.let { "> $it" } ?: when {
                !hasCam -> "> CAMERA BAND HAI — yahan tap karke permission do"
                live -> "> LIVE — Maya dekh rahi hai, ab bolo 🎤"
                else -> "> STANDBY — session shuru karo, Maya ko aankhein do 🎤"
            },
            color = HudDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(start = 15.dp, top = 40.dp).clickable(enabled = !hasCam) { permLauncher.launch(Manifest.permission.CAMERA) }
        )

        // bottom: counters + controls
        Column(Modifier.align(Alignment.BottomStart).padding(start = 15.dp, bottom = 112.dp)) {
            Text("FRM ${"%06d".format(frm)}  SIG $sig", color = HudBlueText, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(3.dp))
            Text(if (live && connected) "AI-FEED LIVE" else "AI-FEED OFFLINE",
                color = if (live && connected) HudGreen else Color(0xFF42557F), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }

        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 26.dp), horizontalArrangement = Arrangement.spacedBy(34.dp), verticalAlignment = Alignment.Bottom) {
            HudButton("🔄", "FLIP", false) { front = !front }

            Box(
                Modifier.size(78.dp).clickable {
                    if (!hasCam) { permLauncher.launch(Manifest.permission.CAMERA); return@clickable }
                    imageCapture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val bytes = try { image.toJpeg(1280, 85) } catch (_: Exception) { null } finally { image.close() }
                            if (bytes != null) ContextCompat.getMainExecutor(ctx).execute { onResult(Base64.encodeToString(bytes, Base64.NO_WRAP)) }
                        }
                        override fun onError(exception: ImageCaptureException) {}
                    })
                },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(78.dp).background(
                    Brush.radialGradient(listOf(Color.White, Color.White, Color(0x99BFD8FF), Color(0x00BFD8FF))), CircleShape))
            }

            HudButton("🎥", if (live) "STOP" else "REC", live) {
                if (!hasCam) { permLauncher.launch(Manifest.permission.CAMERA); return@HudButton }
                live = !live
                note = null
                /* scanning never switches the mic on by itself; only the mic button does */
            }
        }
    }
}

@Composable
private fun HudButton(icon: String, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(42.dp).clip(CircleShape)
                .background(if (active) Color(0xFF3A1822) else Color(0xFF15171F))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Text(icon, fontSize = 18.sp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (active) Color(0xFFE0457B) else HudBlueText, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}
