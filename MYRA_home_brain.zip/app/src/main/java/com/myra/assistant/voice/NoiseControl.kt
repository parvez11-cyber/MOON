package com.myra.assistant.voice

import android.content.Context
import com.myra.assistant.utils.Constants
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Noise control and voice isolation (নয়েজ কন্ট্রোল এবং ভয়েস আইসোলেশন).
 *
 * Two separate things, both on the phone, no network, no extra library:
 *
 *  NOISE CONTROL  ([Processor], runs on every microphone chunk before the speech detector and Gemini)
 *   - a 90 Hz high-pass filter removes rumble (traffic, handling noise, wind thumps),
 *   - an adaptive noise gate learns how loud the room is when nobody talks and turns that steady background
 *     (fan, AC, street hum, crowd murmur) down while you are silent. It opens in a few ms when you speak and holds
 *     ~250 ms after, so word endings are not cut,
 *   - levels: 0 Off, 1 Light, 2 Medium, 3 Strong. "Auto" lifts the level by one when the room is really loud.
 *   Limit: it is a gate, not a neural denoiser. It removes noise BETWEEN words, it cannot remove noise that happens at
 *   the same moment as speech (the phone's own noise suppressor, attached in [EchoCancellationManager], helps there).
 *   Strong can clip very soft word starts, so Light is the default.
 *
 *  VOICE ISOLATION  (setting only; the check itself runs in ForegroundVoiceService, using [VoiceLock])
 *   Voice Lock already checks WHO is talking at the start of a sentence. Isolation keeps checking every ~1.2 s while
 *   you talk, so if another person starts talking over / after you inside the same sentence, Maya stops forwarding
 *   audio and sensitive actions need a fresh voice match. It needs a saved voice (Voice Lock).
 *   Limit: same lightweight speaker check as Voice Lock; the 1-2 s that were forwarded before the switch was noticed
 *   cannot be taken back.
 *
 * Smart prediction: every ~30 s of quiet the room level is averaged into a per-hour table (24 numbers, on the phone, off in
 * privacy mode). Auto then steps the level up when the room is loud now OR usually loud at this hour.
 * Pref keys (myra_prefs): noise_level (1), noise_auto (true), voice_isolation (false), noise_predict (true).
 */
object NoiseControl {
    const val OFF = 0
    const val LIGHT = 1
    const val MEDIUM = 2
    const val STRONG = 3

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun level(c: Context) = p(c).getInt("noise_level", LIGHT).coerceIn(OFF, STRONG)
    fun setLevel(c: Context, l: Int) = p(c).edit().putInt("noise_level", l.coerceIn(OFF, STRONG)).apply()
    fun auto(c: Context) = p(c).getBoolean("noise_auto", true)
    fun setAuto(c: Context, on: Boolean) = p(c).edit().putBoolean("noise_auto", on).apply()
    /** Speech detector sensitivity: 0 low (noisy place), 1 normal, 2 high (quiet room / soft voice). */
    fun vadSensitivity(c: Context) = p(c).getInt("vad_sensitivity", 1).coerceIn(0, 2)
    fun setVadSensitivity(c: Context, s: Int) = p(c).edit().putInt("vad_sensitivity", s.coerceIn(0, 2)).apply()
    fun isolation(c: Context) = p(c).getBoolean("voice_isolation", false)
    fun setIsolation(c: Context, on: Boolean) = p(c).edit().putBoolean("voice_isolation", on).apply()

    // ---- smart noise prediction: how noisy is the room usually at this hour? (learned on the phone, one number per hour)
    private const val K_PRED = "noise_pred"           // { "21": [avgFloor, samples] }
    fun predict(c: Context) = p(c).getBoolean("noise_predict", true)
    fun setPredict(c: Context, on: Boolean) = p(c).edit().putBoolean("noise_predict", on).apply()

    private fun hourNow() = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)

    /** Called by the filter about every 30 s of quiet; slowly averages the room level for this hour. */
    internal fun learn(c: Context, floor: Float) {
        if (!predict(c) || com.myra.assistant.system.PrivacyMode.isOn(c)) return
        try {
            val o = org.json.JSONObject(p(c).getString(K_PRED, "{}") ?: "{}")
            val h = hourNow().toString()
            val a = o.optJSONArray(h)
            val n = a?.optInt(1, 0) ?: 0
            val avg = a?.optDouble(0, floor.toDouble()) ?: floor.toDouble()
            val w = if (n < 20) 1.0 / (n + 1) else 0.05          // new hours learn fast, old ones change slowly
            o.put(h, org.json.JSONArray().put(avg + (floor - avg) * w).put(n + 1))
            p(c).edit().putString(K_PRED, o.toString()).apply()
        } catch (_: Exception) {}
    }

    /** Expected room noise (0..1 RMS) around now, or null until this hour was heard 3+ times. Uses the hour before/after as a fallback. */
    fun predictedFloor(c: Context): Float? {
        if (!predict(c)) return null
        return try {
            val o = org.json.JSONObject(p(c).getString(K_PRED, "{}") ?: "{}")
            val a = o.optJSONArray(hourNow().toString()) ?: return null
            if (a.optInt(1, 0) < 3) null else a.optDouble(0).toFloat()
        } catch (_: Exception) { null }
    }

    fun clearPrediction(c: Context) = p(c).edit().remove(K_PRED).apply()

    fun predictionLabel(c: Context): String {
        val f = predictedFloor(c) ?: return "Ekhono shikhchi (ei ghonta-r jonno kom-pokkho 3 bar shunte hobe)"
        return when { f < 0.008f -> "shanto"; f < 0.02f -> "halka noise"; f < 0.05f -> "noise beshi"; else -> "onek noise" }
    }

    fun name(level: Int) = when (level) { OFF -> "Off"; LIGHT -> "Light"; MEDIUM -> "Medium"; else -> "Strong" }

    /** Room noise measured by the running microphone (0..1 RMS). 0 when the mic is off. Shown in the Smart panel. */
    @Volatile var liveFloor = 0f
        internal set

    fun roomLabel(): String = when {
        liveFloor <= 0f -> "mic bondho"
        liveFloor < 0.008f -> "shanto"
        liveFloor < 0.02f -> "halka noise"
        liveFloor < 0.05f -> "noise beshi"
        else -> "onek noise"
    }

    /** NOISE off|light|medium|strong|auto on|auto off|status  (voice / typed command), also ISOLATION on|off. */
    fun apply(c: Context, arg: String): String {
        val w = arg.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }
        fun has(vararg s: String) = w.any { it in s }
        if (has("isolation", "isolate", "আইসোলেশন")) {
            if (has("off", "band", "bondho", "বন্ধ", "অফ", "disable")) { setIsolation(c, false); return "Voice isolation bondho korlam." }
            if (!VoiceLock.active(c)) return "Voice isolation-er jonno age Voice Lock-e tomar voice save kore chalu koro."
            setIsolation(c, true); return "Voice isolation chalu. Shudhu tomar gola shunbo, sentence-er majheo check korbo."
        }
        if (has("auto")) {
            val off = has("off", "band", "bondho", "বন্ধ", "অফ")
            setAuto(c, !off); return if (off) "Auto noise control bondho." else "Auto noise control chalu."
        }
        return when {
            has("status") -> "Noise control ${name(level(c))}${if (auto(c)) " (auto)" else ""}, ghor ekhon ${roomLabel()}. Ei shomoy shadharonoto: ${predictionLabel(c)}. Voice isolation ${if (isolation(c)) "chalu" else "bondho"}."
            has("off", "band", "bondho", "বন্ধ", "অফ") -> { setLevel(c, OFF); "Noise control bondho korlam." }
            has("strong", "high", "max", "beshi", "বেশি", "zyada") -> { setLevel(c, STRONG); "Noise control Strong. Onek noise-e bhalo, kintu normal-e halka kore bolle shuru-r shobdo kete jete pare." }
            has("medium", "mid", "normal") -> { setLevel(c, MEDIUM); "Noise control Medium kore dilam." }
            has("light", "low", "kom", "কম", "on", "chalu", "চালু") -> { setLevel(c, LIGHT); "Noise control Light chalu." }
            else -> "NOISE off | light | medium | strong | auto on/off | status bolo."
        }
    }

    /**
     * Per-recording filter. Create one per microphone session and call [process] on every chunk (16-bit little-endian
     * mono PCM at 16 kHz). It changes the bytes in place. Cheap: a few operations per sample.
     */
    class Processor(private val context: Context) {
        // 2nd-order Butterworth high-pass at 90 Hz (fs 16 kHz)
        private val b0: Float; private val b1: Float; private val b2: Float; private val a1: Float; private val a2: Float
        private var x1 = 0f; private var x2 = 0f; private var y1 = 0f; private var y2 = 0f

        private var floor = 0f
        private var calibrating = 12                 // first ~0.4 s: start from the quietest chunk seen
        private var hold = 0
        private var gain = 1f

        private var level = LIGHT
        private var auto = true
        private var cfgAt = 0L
        private var scratch = FloatArray(1024)       // reused, so no memory is allocated per 32 ms chunk
        private var predicted: Float? = null
        private var quietChunks = 0

        init {
            val w0 = 2.0 * PI * 90.0 / 16000.0
            val alpha = sin(w0) / (2.0 * 0.7071)
            val cw = cos(w0)
            val a0 = 1.0 + alpha
            b0 = (((1.0 + cw) / 2.0) / a0).toFloat()
            b1 = ((-(1.0 + cw)) / a0).toFloat()
            b2 = b0
            a1 = ((-2.0 * cw) / a0).toFloat()
            a2 = ((1.0 - alpha) / a0).toFloat()
        }

        private fun refreshConfig() {
            val now = System.currentTimeMillis()
            if (now - cfgAt < 1000) return
            cfgAt = now
            level = NoiseControl.level(context)
            auto = NoiseControl.auto(context)
            predicted = NoiseControl.predictedFloor(context)
        }

        fun process(buf: ByteArray, len: Int) {
            refreshConfig()
            val n = len / 2
            if (n <= 0) return
            if (scratch.size < n) scratch = FloatArray(n)
            val x = scratch
            var i = 0
            while (i < n) {
                x[i] = (((buf[2 * i].toInt() and 0xFF) or (buf[2 * i + 1].toInt() shl 8)).toShort().toInt()) / 32768f
                i++
            }
            if (level == OFF) { liveFloor = 0f; return }          // untouched, not even the high-pass

            // high-pass + energy
            var sum = 0.0
            i = 0
            while (i < n) {
                val xi = x[i]
                val y = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
                x2 = x1; x1 = xi; y2 = y1; y1 = y
                x[i] = y
                sum += y.toDouble() * y
                i++
            }
            val rms = sqrt(sum / n).toFloat()

            // learn the room: follows quiet down fast, rises very slowly (a fan switched on is learned in ~15 s)
            if (calibrating > 0) {
                floor = if (floor == 0f) rms else minOf(floor, rms)
                calibrating--
            } else if (rms < floor) floor = floor * 0.9f + rms * 0.1f
            else floor += (rms - floor) * 0.0015f
            floor = floor.coerceAtLeast(0.0008f)
            liveFloor = floor

            var lv = level
            // Auto steps up when the room is loud now, or is usually loud at this hour (so it is ready before the noise starts)
            val expected = maxOf(floor, (predicted ?: 0f) * 0.8f)
            if (auto && expected > 0.02f && lv < STRONG) lv++
            val ratio = when (lv) { LIGHT -> 2.5f; MEDIUM -> 3.0f; else -> 3.8f }
            val atten = when (lv) { LIGHT -> 0.35f; MEDIUM -> 0.15f; else -> 0.04f }

            val speech = calibrating > 0 || (rms > floor * ratio && rms > 0.006f)
            val target = when {
                speech -> { hold = 8; 1f }                         // ~250 ms hang time
                hold > 0 -> { hold--; 1f }
                else -> atten
            }
            // open fast (a few ms), close slowly: speech starts are not clipped, noise does not "pump"
            val newGain = if (target > gain) target else gain + (target - gain) * 0.18f
            val rampLen = if (newGain > gain) minOf(n, 96) else n
            val start = gain
            i = 0
            while (i < n) {
                val g = if (i < rampLen) start + (newGain - start) * (i + 1) / rampLen else newGain
                val v = (x[i] * g * 32768f).toInt().coerceIn(-32768, 32767)
                buf[2 * i] = (v and 0xFF).toByte()
                buf[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
                i++
            }
            gain = newGain

            // quiet for ~30 s in a row -> one more sample of "how noisy is this hour"
            if (!speech && hold == 0 && calibrating == 0) {
                if (++quietChunks >= 940) { quietChunks = 0; NoiseControl.learn(context, floor) }
            } else quietChunks = 0
        }
    }
}
