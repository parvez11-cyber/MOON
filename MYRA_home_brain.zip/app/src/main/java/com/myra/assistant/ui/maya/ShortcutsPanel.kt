package com.myra.assistant.ui.maya

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.ai.RoutineStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A saved step, written the way a person would say it ("OPEN_APP youtube" -> "youtube kholo"). Only for showing in the list. */
private fun prettyStep(cmd: String): String {
    val head = cmd.trim().substringBefore(' ').uppercase()
    val arg = cmd.trim().substringAfter(' ', "").trim()
    return when (head) {
        "OPEN_APP" -> "$arg kholo"
        "FLASHLIGHT_ON" -> "torch on"
        "FLASHLIGHT_OFF" -> "torch off"
        "VOLUME_UP" -> "volume baraw"
        "VOLUME_DOWN" -> "volume komao"
        "YOUTUBE_PLAY" -> "youtube-e $arg"
        "SPOTIFY_PLAY" -> "spotify-te $arg"
        "HOME" -> "home"
        "BACK" -> "back"
        "RECENTS" -> "recents"
        "NOTIFICATIONS" -> "notification panel"
        "BRIGHTNESS" -> "brightness $arg"
        else -> cmd
    }
}

@Composable
private fun ScButton(label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).clip(RoundedCornerShape(16.dp))
            .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/**
 * Named shortcuts (and routines Maya saved by herself): see the list, run one, edit its name / steps, delete it, add a new one.
 * Saying or typing just the name runs it. Only harmless steps are allowed (app open, torch, volume, home / back, brightness...).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortcutsPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf<String?>(null) }      // null = the list, "" = a new one, otherwise the name being edited
    var name by remember { mutableStateOf("") }
    var stepsText by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<String?>(null) }
    val list = remember(tick) { RoutineStore.all(ctx) }

    fun openEditor(n: String?, steps: List<String>) {
        editing = n ?: ""
        name = n ?: ""
        stepsText = steps.joinToString("\n")
        err = ""
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            if (editing == null) {
                Text("Shortcut-er talika", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("Shudhu naam bolle ba likhle sob dhap ek ek kore hoye jay.", color = MC.Sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(14.dp))
                if (list.isEmpty()) {
                    Text(
                        "Ekhono kono shortcut nei. Niche Notun dabao, ba bolo: \"morning shortcut banao youtube kholo, torch on\".",
                        color = MC.Sub, fontSize = 15.sp, lineHeight = 21.sp
                    )
                }
                list.forEach { (n, steps) ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                            .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(n, color = MC.Navy, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(steps.joinToString("  →  ") { prettyStep(it) }, color = MC.Sub, fontSize = 13.sp, lineHeight = 18.sp)
                        }
                        Icon(Icons.Filled.PlayArrow, "run", tint = MC.BlueDeep, modifier = Modifier.size(40.dp).clickable {
                            status = "Chalachhi: $n"
                            scope.launch {
                                status = try {
                                    withContext(Dispatchers.IO) { RoutineStore.handle(ctx.applicationContext, "ROUTINE_RUN $n") }
                                } catch (e: Exception) { "Parlam na: ${e.message}" }
                            }
                        }.padding(8.dp))
                        Icon(Icons.Filled.Edit, "edit", tint = MC.Hint, modifier = Modifier.size(40.dp).clickable { openEditor(n, steps) }.padding(8.dp))
                        Icon(Icons.Filled.Delete, "delete", tint = MC.Hint, modifier = Modifier.size(40.dp).clickable { toDelete = n }.padding(8.dp))
                    }
                }
                if (status.isNotBlank()) Text(status, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(12.dp))
                ScButton("+ Notun shortcut", true, Modifier.fillMaxWidth()) { openEditor(null, emptyList()) }
                Text(
                    "Nirapotta: shudhu nirapod dhap rakha jay. Message, call, tap, type, system setting shortcut-e dhuke na.",
                    color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp)
                )
            } else {
                val old = editing.orEmpty()
                val isNew = old.isEmpty()
                Text(if (isNew) "Notun shortcut" else "Shortcut edit", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(name, { name = it; err = "" }, label = { Text("Naam (maximum 3 shobdo)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    stepsText, { stepsText = it; err = "" }, label = { Text("Dhap (ek line-e ek ta)") }, minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Jemon: youtube kholo / torch on / volume barao. Ager save kora dhap (OPEN_APP youtube) o thik thake. Maximum 8 ta.",
                    color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
                if (err.isNotEmpty()) Text(err, color = MC.Dot, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ScButton("Save", true, Modifier.weight(1f)) {
                        val e = RoutineStore.define(ctx, if (isNew) null else old, name, stepsText.lines())
                        if (e == null) { editing = null; status = ""; tick++ } else err = e
                    }
                    ScButton("Bad dao", false, Modifier.weight(1f)) { editing = null }
                }
                Spacer(Modifier.height(28.dp))
            }
        }
    }

    toDelete?.let { n ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Muche felbo?") },
            text = { Text("'$n' shortcut muche jabe.") },
            confirmButton = { TextButton({ RoutineStore.remove(ctx, n); toDelete = null; tick++ }) { Text("Muche felo") } },
            dismissButton = { TextButton({ toDelete = null }) { Text("Thak") } }
        )
    }
}
