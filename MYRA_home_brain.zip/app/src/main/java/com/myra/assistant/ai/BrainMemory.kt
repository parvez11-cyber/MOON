package com.myra.assistant.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * The "brain" view of Maya's memories (ব্রেন মেমোরি).
 *
 *  - Every memory has a TYPE: EMOTION (আবেগ), THOUGHT (চিন্তা) or MEMORY (স্মৃতি). The type decides which part of the
 *    brain animation (assets/riya_floating.html) the marker sits in: thoughts in the front (frontal lobe), emotions in the
 *    middle-low part (limbic / temporal), memories in the back-low part (hippocampus side).
 *  - Memories that talk about the same thing are RELATED (shared words, same simple matching as [MemoryRevival]).
 *    The brain draws a line between related memories; the edit screen lists them.
 *  - Type is chosen by the user, or by a prefix ("emotion: ...", "ভাবনা: ..."), or guessed from the words.
 *
 * Storage stays in [PersistentMemory] (the plain text list is unchanged, so Backup / Sync keep working); this object only
 * adds the type + a stable id next to each text and the maths for links. Everything runs on the phone.
 */
object BrainMemory {
    enum class Kind(val key: String, val bn: String) {
        EMOTION("emotion", "আবেগ"), THOUGHT("thought", "চিন্তা"), MEMORY("memory", "স্মৃতি");

        companion object {
            fun of(s: String?): Kind? = values().firstOrNull { it.key.equals(s?.trim(), true) }
        }
    }

    /** Stored next to each text: stable id (the marker keeps its place when the text is edited), type, created time. */
    data class Meta(val id: Int, val kind: Kind, val at: Long)

    data class Entry(val id: Int, val text: String, val kind: Kind, val at: Long)

    // ------------------------------------------------------------------ type

    private val EMOTION_WORDS = listOf(
        "feel", "feeling", "happy", "sad", "angry", "anger", "love", "miss ", "missing", "afraid", "scared", "fear", "worried", "anxious",
        "lonely", "excited", "upset", "cry", "joy", "stress", "tension", "proud", "jealous", "hurt", "nervous", "mood",
        "khushi", "khusi", "kharap lag", "mon kharap", "bhalo lag", "bhoy", "voy", "rag ", "dukkho", "dukhho", "kosto", "kosht", "bhalobash", "ekla", "chintito",
        "ভালো লাগ", "খুশি", "মন খারাপ", "ভয়", "রাগ", "দুঃখ", "কষ্ট", "ভালোবাস", "মিস", "একা", "চিন্তিত", "আনন্দ", "দুশ্চিন্তা", "অনুভূতি", "আবেগ", "ঘৃণা"
    )
    private val THOUGHT_WORDS = listOf(
        "idea", "think", "thought", "plan", "goal", "maybe", "should ", "wish", "dream", "someday", "wonder", "what if", "decide",
        "bhabchi", "vabchi", "bhabi", "bhabna", "vabna", "chinta", "icche", "iccha", "korbo", "jodi ",
        "ভাবছি", "ভাবি", "ভাবনা", "আইডিয়া", "পরিকল্পনা", "চিন্তা", "ইচ্ছা", "করব", "করবো", "যদি ", "স্বপ্ন", "সিদ্ধান্ত"
    )

    /** Guess the type from the words. Facts, names, dates and events (the default) are MEMORY. */
    fun classify(text: String): Kind {
        val t = " " + text.lowercase() + " "
        val e = EMOTION_WORDS.count { t.contains(it) }
        val h = THOUGHT_WORDS.count { t.contains(it) }
        return when {
            e > 0 && e >= h -> Kind.EMOTION
            h > 0 -> Kind.THOUGHT
            else -> Kind.MEMORY
        }
    }

    private val PREFIX = Regex(
        "^\\s*(emotion|feeling|mood|আবেগ|অনুভূতি|thought|idea|ভাবনা|আইডিয়া|চিন্তা|memory|memories|স্মৃতি|মেমরি|মেমোরি)\\s*[:：\\-–—]\\s*(.+)$",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    /** "emotion: kal khub khushi chilam" -> (EMOTION, "kal khub khushi chilam"). No prefix -> (null, the text). */
    fun parse(raw: String): Pair<Kind?, String> {
        val m = PREFIX.find(raw.trim()) ?: return null to raw.trim()
        val kind = when (m.groupValues[1].lowercase()) {
            "emotion", "feeling", "mood", "আবেগ", "অনুভূতি" -> Kind.EMOTION
            "thought", "idea", "ভাবনা", "আইডিয়া", "চিন্তা" -> Kind.THOUGHT
            else -> Kind.MEMORY
        }
        return kind to m.groupValues[2].trim()
    }

    // ------------------------------------------------------------------ links

    private val STOP = setOf(
        "the", "a", "an", "is", "are", "was", "to", "of", "and", "in", "on", "for", "my", "me", "i", "you", "it", "that", "this", "with", "has", "have",
        "ami", "tumi", "amar", "tomar", "ache", "achhe", "ki", "ke", "ta", "te", "er", "o", "na", "ar", "je", "jar", "hobe", "kore", "koro", "hoy", "chilo", "kal", "aj",
        "আমি", "তুমি", "আমার", "তোমার", "আছে", "কি", "কী", "কে", "এর", "ও", "না", "আর", "যে", "হবে", "করে", "করো", "একটা", "এই", "সেই", "হয়", "ছিল", "আজ", "কাল"
    )

    private fun words(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.length >= 3 && it !in STOP }.toSet()

    /** Bangla / Banglish words carry endings, so two words match when equal or when their first 4 letters agree. */
    private fun overlap(a: Set<String>, b: Set<String>): Int {
        var n = 0
        for (x in a) for (y in b) {
            if (x == y || (x.length >= 4 && y.length >= 4 && x.take(4) == y.take(4))) { n++; break }
        }
        return n
    }

    private const val MAX_LINKED = 150      // only the newest N memories are compared (keeps it instant)
    private const val PER_NODE = 3          // at most 3 lines leave one memory, so the brain stays readable
    private const val MAX_LINKS = 80

    /** Pairs of related memory ids, strongest first. */
    fun links(all: List<Entry>): List<Pair<Int, Int>> {
        val list = all.takeLast(MAX_LINKED)
        val ws = list.map { words(it.text) }
        data class C(val a: Int, val b: Int, val s: Int)
        val cand = ArrayList<C>()
        for (i in list.indices) for (j in i + 1 until list.size) {
            val s = overlap(ws[i], ws[j])
            if (s > 0) cand.add(C(i, j, s))
        }
        val deg = IntArray(list.size)
        val out = ArrayList<Pair<Int, Int>>()
        for (c in cand.sortedByDescending { it.s }) {
            if (deg[c.a] >= PER_NODE || deg[c.b] >= PER_NODE) continue
            deg[c.a]++; deg[c.b]++
            out.add(list[c.a].id to list[c.b].id)
            if (out.size >= MAX_LINKS) break
        }
        return out
    }

    /** Memories related to one memory (for the edit screen). */
    fun relatedTo(all: List<Entry>, id: Int): List<Entry> {
        val byId = all.associateBy { it.id }
        return links(all).mapNotNull { (a, b) -> if (a == id) byId[b] else if (b == id) byId[a] else null }
    }

    // ------------------------------------------------------------------ bridge to the brain animation

    /** JSON for assets/riya_floating.html: { items: [{id,t,k,at}], links: [[idA,idB], ...] } */
    fun toJson(all: List<Entry>): String {
        val items = JSONArray()
        all.forEach { items.put(JSONObject().put("id", it.id).put("t", it.text).put("k", it.kind.key).put("at", it.at)) }
        val ls = JSONArray()
        links(all).forEach { ls.put(JSONArray().put(it.first).put(it.second)) }
        return JSONObject().put("items", items).put("links", ls).toString()
    }

    // ------------------------------------------------------------------ search ("Rahim niye ki bolechilam?")

    /** Memories that match [query], best first (same word matching as the brain links, plus an exact-phrase bonus; newer wins a tie). */
    fun search(query: String, limit: Int = 5): List<Entry> {
        val q = words(query)
        val ql = query.trim().lowercase()
        if (q.isEmpty() && ql.length < 2) return emptyList()
        return PersistentMemory.entries()
            .map { e ->
                var score = overlap(q, words(e.text)) * 10
                if (ql.length >= 3 && e.text.lowercase().contains(ql)) score += 15
                e to score
            }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Entry, Int>> { it.second }.thenByDescending { it.first.at })
            .take(limit).map { it.first }
    }

    private fun ago(at: Long): String {
        val d = ((System.currentTimeMillis() - at) / 86_400_000L).toInt()
        return when { at <= 0L -> ""; d <= 0 -> "ajke"; d == 1 -> "gotokal"; d < 30 -> "$d din age"; d < 365 -> "${d / 30} mash age"; else -> "${d / 365} bochor age" }
    }

    // ------------------------------------------------------------------ voice / chat command:  MEMORY add [type:] <text>  |  MEMORY list  |  MEMORY search <words>

    fun handle(c: Context, arg: String): String {
        val verb = arg.trim().substringBefore(' ').lowercase()
        val rest = arg.trim().substringAfter(' ', "").trim()
        return when (verb) {
            "add", "save" -> {
                val (kind, text) = parse(rest)
                if (text.length < 2) return "Ki save korbo? Kichu bolo."
                if (text.length > 300) return "Onek lomba, 300 okkhor-er moddhe bolo."
                val id = PersistentMemory.add(text, kind)
                val k = PersistentMemory.entries().firstOrNull { e -> e.id == id }?.kind ?: kind ?: classify(text)
                "Save korlam (${k.bn}). Brain-e ${k.bn}-er jaygay marker dekhabe."
            }
            "search", "find", "khojo" -> {
                if (rest.isBlank()) return "Ki niye khujbo? Bolo."
                val hits = search(rest)
                if (hits.isEmpty()) "'$rest' niye kichu mone nei."
                else "${hits.size} ta pailam: " + hits.mapIndexed { i, e -> "${i + 1}) ${e.text}" + ago(e.at).let { a -> if (a.isNotEmpty()) " ($a)" else "" } }.joinToString("; ")
            }
            "list" -> {
                val all = PersistentMemory.entries()
                if (all.isEmpty()) "Ekhono kichu save kora nei."
                else all.takeLast(8).reversed().joinToString("; ") { "${it.kind.bn}: ${it.text}" }
            }
            else -> "Memory command bujhini."
        }
    }
}
