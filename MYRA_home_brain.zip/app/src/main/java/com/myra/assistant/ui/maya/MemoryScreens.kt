package com.myra.assistant.ui.maya

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Observer
import com.myra.assistant.ai.BrainMemory
import com.myra.assistant.ai.PersistentMemory

/** Colour of each memory type; the same colours are used for the markers in the brain animation. */
private fun kindColor(k: BrainMemory.Kind): Color = when (k) {
    BrainMemory.Kind.THOUGHT -> Color(0xFFBA68FF)
    BrainMemory.Kind.EMOTION -> Color(0xFFFF6F91)
    BrainMemory.Kind.MEMORY -> Color(0xFF2FBF86)
}

private fun agoText(at: Long): String {
    val m = (System.currentTimeMillis() - at) / 60_000L
    return when {
        m < 1 -> "ekhon"
        m < 60 -> "$m min age"
        m < 60 * 24 -> "${m / 60} ghonta age"
        else -> "${m / (60 * 24)} din age"
    }
}

@Composable
private fun MemChip(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) color else color.copy(alpha = 0.16f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.White else MC.Navy, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MemButton(label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).clip(RoundedCornerShape(16.dp))
            .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/**
 * The list of everything Maya remembers, grouped by type (আবেগ / চিন্তা / স্মৃতি). Tap a memory to edit or delete it,
 * "Notun" to add one. Every change is also shown in the brain animation on the home screen.
 */
@Composable
fun BrainMemorySection(onShowInBrain: () -> Unit = {}) {
    val ctx = LocalContext.current
    PersistentMemory.init(ctx)
    var version by remember { mutableStateOf(0) }
    DisposableEffect(Unit) {
        val o = Observer<Long> { version++ }
        PersistentMemory.changes.observeForever(o)
        onDispose { PersistentMemory.changes.removeObserver(o) }
    }
    val asc = remember(version) { PersistentMemory.entries() }                 // oldest first
    val entries = remember(asc) { asc.reversed() }                              // newest first, for the list
    val relCount = remember(asc) {
        val m = HashMap<Int, Int>()
        BrainMemory.links(asc).forEach { (a, b) -> m[a] = (m[a] ?: 0) + 1; m[b] = (m[b] ?: 0) + 1 }
        m
    }
    var filter by remember { mutableStateOf<BrainMemory.Kind?>(null) }
    var editing by remember { mutableStateOf<BrainMemory.Entry?>(null) }
    val shown = entries.filter { filter == null || it.kind == filter }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MemChip("Sob ${entries.size}", filter == null, MC.BlueDeep) { filter = null }
            BrainMemory.Kind.values().forEach { k ->
                MemChip("${k.bn} ${entries.count { it.kind == k }}", filter == k, kindColor(k)) { filter = k }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (shown.isEmpty()) {
            Text(
                if (entries.isEmpty()) "Abhi khaali hai. \"yaad rakho ...\" bolo ba likho, ba niche Notun dabao. Save hole brain-e marker dekhabe."
                else "Ei type-e kichu nei.",
                color = MC.Sub, fontSize = 16.sp, lineHeight = 22.sp
            )
        }
        shown.forEach { e ->
            val rel = relCount[e.id] ?: 0
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
                    .clickable { editing = e }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(kindColor(e.kind)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.text, color = MC.Navy, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        listOf(e.kind.bn, agoText(e.at), if (rel > 0) "$rel ta sompokito" else "").filter { it.isNotEmpty() }.joinToString(" · "),
                        color = MC.Sub, fontSize = 12.sp
                    )
                }
                Icon(Icons.Filled.Edit, "edit", tint = MC.Hint, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        MemButton("+ Notun memory", true, Modifier.fillMaxWidth()) {
            editing = BrainMemory.Entry(-1, "", filter ?: BrainMemory.Kind.MEMORY, System.currentTimeMillis())
        }
    }

    editing?.let { e ->
        MemoryEditSheet(e, asc, onShowInBrain = { editing = null; onShowInBrain() }) { editing = null }
    }
}

/** Edit / delete screen for one memory (id < 0 means a new one). Changes the type too, which moves the marker's part of the brain. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MemoryEditSheet(entry: BrainMemory.Entry, all: List<BrainMemory.Entry>, onShowInBrain: () -> Unit, onDismiss: () -> Unit) {
    val isNew = entry.id < 0
    var text by remember { mutableStateOf(entry.text) }
    var kind by remember { mutableStateOf<BrainMemory.Kind?>(if (isNew) null else entry.kind) }   // null = decide from the words
    var err by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    val related = remember(entry.id, all) { if (isNew) emptyList() else BrainMemory.relatedTo(all, entry.id) }

    ModalBottomSheet(
        onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text(if (isNew) "Notun memory" else "Memory edit", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                text, { text = it; err = "" }, label = { Text("Ki mone rakhbo?") }, minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Text("Brain-er kon ongshe thakbe", color = MC.Sub, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isNew) MemChip("Auto", kind == null, MC.BlueDeep) { kind = null }
                BrainMemory.Kind.values().forEach { k -> MemChip(k.bn, kind == k, kindColor(k)) { kind = k } }
            }
            Text(
                "চিন্তা = সামনের অংশ · আবেগ = মাঝের নিচের অংশ · স্মৃতি = পিছনের নিচের অংশ",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
            if (related.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text("Sompokito (brain-e line ache)", color = MC.Sub, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                related.forEach { r ->
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(kindColor(r.kind)))
                        Spacer(Modifier.width(8.dp))
                        Text("${r.kind.bn}: ${r.text}", color = MC.Navy, fontSize = 14.sp)
                    }
                }
            }
            if (err.isNotEmpty()) Text(err, color = MC.Dot, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MemButton("Save", true, Modifier.weight(1f)) {
                    val t = text.trim()
                    when {
                        t.length < 2 -> err = "Kichu likho."
                        t.length > 300 -> err = "300 okkhor-er moddhe likho."
                        isNew -> { PersistentMemory.add(t, kind); onDismiss() }
                        PersistentMemory.update(entry.id, t, kind ?: entry.kind) -> onDismiss()
                        else -> err = "Eki kotha ager ekta memory-te ache."
                    }
                }
                if (!isNew) MemButton("Delete", false, Modifier.weight(1f)) { confirmDelete = true }
            }
            if (!isNew) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
                        .clickable { PersistentMemory.requestFocus(entry.id); onShowInBrain() }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Psychology, null, tint = MC.BlueDeep); Spacer(Modifier.width(10.dp))
                    Text("Brain-e dekho", color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Muche felbo?") },
        text = { Text("\"${entry.text.take(80)}\" memory ar brain-er marker dui-i muche jabe.") },
        confirmButton = { TextButton({ confirmDelete = false; PersistentMemory.removeById(entry.id); onDismiss() }) { Text("Muche felo") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Thak") } }
    )
}
