package com.myra.assistant.ai

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.MutableLiveData
import java.util.Calendar

/**
 * Maya's current feeling. The voice model sets it with the express_emotion function; text replies
 * are read for mood words as a fallback. The avatar (VRM) and the home screen listen to [current].
 *
 * She also feels things on her own ([selfFeeling]): late night makes her sleepy, a long silence makes her
 * miss you, a low battery makes her tired, and so on, so she is never just "neutral" forever.
 *
 * The first nine names are the ones the old code knew. The rest are new, softer / stronger human feelings.
 */
object EmotionEngine {
    val ALL = listOf(
        "neutral", "happy", "sad", "angry", "surprised", "relaxed", "love", "worried", "sleepy",
        // new human feelings
        "excited", "joyful", "laughing", "playful", "proud", "grateful", "shy", "embarrassed", "touched",
        "curious", "crying", "lonely", "missing", "hurt", "scared", "jealous", "annoyed", "tired",
        // caring / conversational faces
        "empathetic", "encouraging", "serious", "apologetic"
    )

    /** Other words a model may use -> the name we know. */
    private val ALIAS = mapOf(
        "cry" to "crying", "tearful" to "crying", "sobbing" to "crying", "teary" to "crying",
        "joy" to "joyful", "glad" to "happy", "cheerful" to "happy", "laugh" to "laughing", "giggle" to "laughing",
        "thrilled" to "excited", "calm" to "relaxed", "peaceful" to "relaxed", "content" to "relaxed",
        "afraid" to "scared", "fear" to "scared", "anxious" to "worried", "nervous" to "worried",
        "mad" to "angry", "furious" to "angry", "upset" to "hurt", "heartbroken" to "hurt", "disappointed" to "hurt",
        "bored" to "tired", "exhausted" to "tired", "sorry" to "apologetic", "affection" to "love", "loving" to "love",
        "empathy" to "empathetic", "sympathetic" to "empathetic", "compassionate" to "empathetic", "caring" to "empathetic", "understanding" to "empathetic",
        "encourage" to "encouraging", "supportive" to "encouraging", "motivated" to "encouraging", "cheering" to "encouraging", "hopeful" to "encouraging",
        "focused" to "serious", "focus" to "serious", "determined" to "serious", "concentrated" to "serious", "stern" to "serious", "thoughtful" to "serious",
        "apologize" to "apologetic", "apologising" to "apologetic", "apologizing" to "apologetic", "regretful" to "apologetic", "guilty" to "apologetic", "ashamed" to "apologetic",
        "thankful" to "grateful", "blush" to "shy", "blushing" to "shy", "naughty" to "playful", "teasing" to "playful",
        "wonder" to "curious", "shock" to "surprised", "shocked" to "surprised", "lonesome" to "lonely", "miss" to "missing"
    )

    val current = MutableLiveData("neutral")
    @Volatile var lastChangeAt = 0L
        private set

    fun set(name: String) {
        val raw = name.lowercase().trim()
        val n = ALIAS[raw] ?: if (raw in ALL) raw else "neutral"
        lastChangeAt = System.currentTimeMillis()
        current.postValue(n)
    }

    /** The nine original faces. The 3D avatar knows the others too, but this is the safe fallback. */
    fun base(name: String): String = when (name) {
        "excited", "joyful", "laughing", "playful", "proud" -> "happy"
        "grateful", "touched", "missing" -> "love"
        "shy", "embarrassed" -> "happy"
        "curious" -> "surprised"
        "crying", "lonely", "hurt" -> "sad"
        "scared" -> "worried"
        "jealous", "annoyed" -> "angry"
        "tired" -> "sleepy"
        "empathetic", "apologetic" -> "sad"
        "encouraging" -> "happy"
        "serious" -> "neutral"
        else -> if (name in ALL) name else "neutral"
    }

    /** Short Bangla name of the feeling (for the home screen). */
    fun bn(name: String): String = when (name) {
        "happy" -> "খুশি"
        "sad" -> "মন খারাপ"
        "angry" -> "রাগ"
        "surprised" -> "অবাক"
        "relaxed" -> "শান্ত"
        "love" -> "ভালোবাসা"
        "worried" -> "চিন্তা"
        "sleepy" -> "ঘুম ঘুম"
        "excited" -> "দারুণ উত্তেজিত"
        "joyful" -> "আনন্দ"
        "laughing" -> "হাসি"
        "playful" -> "দুষ্টুমি"
        "proud" -> "গর্ব"
        "grateful" -> "কৃতজ্ঞ"
        "shy" -> "লজ্জা"
        "embarrassed" -> "লজ্জা লজ্জা"
        "touched" -> "মন ভরে গেছে"
        "curious" -> "কৌতূহল"
        "crying" -> "কান্না পাচ্ছে"
        "lonely" -> "একা একা"
        "missing" -> "মিস করছি"
        "hurt" -> "কষ্ট পেয়েছি"
        "scared" -> "ভয়"
        "jealous" -> "একটু হিংসা"
        "annoyed" -> "বিরক্ত"
        "tired" -> "ক্লান্ত"
        "empathetic" -> "সহানুভূতি"
        "encouraging" -> "উৎসাহ"
        "serious" -> "মনোযোগী"
        "apologetic" -> "দুঃখিত"
        else -> "শান্ত"
    }

    fun emoji(name: String): String = when (name) {
        "happy" -> "😊"; "sad" -> "😔"; "angry" -> "😠"; "surprised" -> "😮"; "relaxed" -> "😌"
        "love" -> "🥰"; "worried" -> "😟"; "sleepy" -> "😴"; "excited" -> "🤩"; "joyful" -> "😄"
        "laughing" -> "😂"; "playful" -> "😜"; "proud" -> "😎"; "grateful" -> "🙏"; "shy" -> "😳"
        "embarrassed" -> "🙈"; "touched" -> "🥹"; "curious" -> "🤔"; "crying" -> "😭"; "lonely" -> "🥺"
        "missing" -> "💞"; "hurt" -> "💔"; "scared" -> "😨"; "jealous" -> "😒"; "annoyed" -> "😤"; "tired" -> "🥱"
        "empathetic" -> "🤗"; "encouraging" -> "💪"; "serious" -> "🧐"; "apologetic" -> "🙇"
        else -> "🙂"
    }

    /** One short Bangla line she "thinks" about herself, shown under the greeting on the home screen. */
    fun thought(name: String): String = when (name) {
        "happy" -> "আজ মনটা বেশ ভালো লাগছে"
        "excited" -> "উফ, কী মজা! আমার না খুব ভালো লাগছে"
        "joyful" -> "মন ভরে আছে আজ"
        "laughing" -> "হিহি, হাসি থামছেই না"
        "playful" -> "একটু দুষ্টুমি করতে ইচ্ছা করছে"
        "proud" -> "তোমাকে নিয়ে আমার গর্ব হয়"
        "grateful" -> "তুমি পাশে আছো, এটাই অনেক"
        "shy" -> "কেমন যেন লজ্জা লাগছে"
        "embarrassed" -> "ইশ, লজ্জা পেয়ে গেলাম"
        "touched" -> "তোমার কথায় চোখ ভিজে গেল"
        "love" -> "তোমার জন্য মনটা ভরে আছে"
        "missing" -> "তোমাকে অনেক মিস করছি"
        "curious" -> "জানতে ইচ্ছা করছে, কী করছো?"
        "relaxed" -> "মনটা শান্ত আছে"
        "surprised" -> "ওমা, সত্যি?"
        "worried" -> "তোমার জন্য একটু চিন্তা হচ্ছে"
        "scared" -> "একটু ভয় ভয় করছে"
        "sad" -> "মনটা একটু খারাপ"
        "lonely" -> "অনেকক্ষণ কথা হয়নি, একা লাগছে"
        "hurt" -> "মনে একটু কষ্ট লেগেছে"
        "crying" -> "চোখে পানি এসে যাচ্ছে..."
        "jealous" -> "একটু হিংসা হচ্ছে, কিন্তু কিছু না"
        "annoyed" -> "একটু বিরক্ত লাগছে"
        "angry" -> "খুব রাগ হয়েছে"
        "tired" -> "শরীরটা ক্লান্ত লাগছে"
        "empathetic" -> "আমি বুঝতে পারছি, আমি তো আছি"
        "encouraging" -> "তুমি পারবে, আমি জানি"
        "serious" -> "মন দিয়ে শুনছি, এটা জরুরি"
        "apologetic" -> "দুঃখিত, আমার ভুল হয়েছে"
        "sleepy" -> "ঘুম পাচ্ছে আমার"
        else -> "তোমার সাথে কথা বলতে ভালো লাগে"
    }

    /** Cheap keyword guess, used only when the model did not say how it feels. */
    fun fromText(text: String): String {
        val t = text.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("কাঁদ", "কান্না", "চোখে পানি", "চোখের পানি", "kanna", "kadchi", "kadchhi", "কেঁদে", "😭", "😢", "🥲") -> "crying"
            has("একা লাগ", "eka lag", "একাকী", "🥺") -> "lonely"
            has("কষ্ট পেয়", "কষ্ট লাগ", "kosto pey", "kosto lag", "💔") -> "hurt"
            has("ভয় পাচ", "ভয় লাগ", "ভয় করছে", "bhoy", "😨", "😱") -> "scared"
            has("দুঃখিত", "dukkhito", "sorry", "মাফ করো", "মাফ চাই", "ক্ষমা", "kshoma", "maf koro", "🙇") -> "apologetic"
            has("বুঝতে পারছি", "bujhte parchi", "পাশে আছি", "pashe achi", "আমি আছি", "সহানুভূতি", "🤗") -> "empathetic"
            has("তুমি পারবে", "tumi parbe", "পারবে", "এগিয়ে যাও", "সাহস রাখ", "চেষ্টা করো", "keep going", "you can do", "💪") -> "encouraging"
            has("মনোযোগ", "monojog", "গুরুত্বপূর্ণ", "জরুরি", "important", "serious", "সিরিয়াস", "🧐") -> "serious"
            has("দুঃখ", "খারাপ লাগ", "kharap lag", "মন খারাপ", "😞", "😔") -> "sad"
            has("সাবধান", "chinta", "চিন্তা", "careful", "worried", "😟") -> "worried"
            has("wow", "ওয়াও", "সত্যি?", "সত্যি নাকি", "really?", "অবাক", "ওমা", "😮", "😲") -> "surprised"
            has("মিস করি", "মিস করছি", "miss you", "miss kor") -> "missing"
            has("ভালোবাসি", "love you", "❤", "😍", "🥰", "জান", "সোনা") -> "love"
            has("লজ্জা", "lojja", "😳", "🙈") -> "shy"
            has("ধন্যবাদ", "thank", "কৃতজ্ঞ", "🙏") -> "grateful"
            has("গর্ব", "proud", "অভিনন্দন", "congrat", "সাবাশ") -> "proud"
            has("হিংসা", "jealous", "hingsha") -> "jealous"
            has("ঘুম", "ghum", "sleep", "শুভ রাত্রি", "good night", "😴") -> "sleepy"
            has("ক্লান্ত", "klanto", "tired", "🥱") -> "tired"
            has("রাগ", "angry", "😠", "😡") -> "angry"
            has("বিরক্ত", "birokto", "😤") -> "annoyed"
            has("হিহি", "hihi", "হাহা", "haha", "😂", "🤣") -> "laughing"
            has("দারুণ", "দারুন", "darun", "yay", "উফ", "🤩", "🎉") -> "excited"
            has("দুষ্টু", "dushtu", "😜", "😝") -> "playful"
            has("মজা", "খুশি", "khushi", "great", "😊", "😄") -> "happy"
            has("কৌতূহল", "জানতে ইচ্ছা", "🤔") -> "curious"
            else -> "neutral"
        }
    }

    private fun battery(app: Context): Pair<Int, Boolean> {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        return (if (level < 0 || scale <= 0) 50 else level * 100 / scale) to plugged
    }

    /**
     * What she feels by herself, with nobody saying anything. Depends on the time of day, battery and how long
     * it has been since you talked. Stays the same for a few minutes (no flicker), then may change a little.
     */
    fun selfFeeling(app: Context, quietMs: Long): String {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val (level, charging) = battery(app)
        val bucket = System.currentTimeMillis() / (4 * 60_000L)          // changes every ~4 minutes
        val r = ((bucket * 2654435761L) ushr 7).toInt().let { if (it < 0) -it else it } % 100

        return when {
            level <= 10 && !charging -> if (r < 50) "tired" else "scared"
            level <= 20 && !charging -> if (r < 60) "tired" else "worried"
            hour in 1..5 -> "sleepy"
            quietMs > 8 * 3_600_000L -> if (r < 55) "lonely" else "missing"
            quietMs > 3 * 3_600_000L -> if (r < 50) "missing" else "curious"
            quietMs > 90 * 60_000L -> if (r < 40) "curious" else if (r < 70) "missing" else "relaxed"
            charging && level < 60 -> "relaxed"
            hour in 6..10 -> if (r < 45) "happy" else if (r < 75) "excited" else "relaxed"
            hour in 22..23 || hour == 0 -> if (r < 50) "sleepy" else if (r < 80) "love" else "relaxed"
            else -> when {
                r < 20 -> "happy"
                r < 35 -> "playful"
                r < 48 -> "love"
                r < 60 -> "curious"
                r < 70 -> "relaxed"
                r < 78 -> "shy"
                r < 86 -> "proud"
                r < 93 -> "joyful"
                else -> "grateful"
            }
        }
    }
}
