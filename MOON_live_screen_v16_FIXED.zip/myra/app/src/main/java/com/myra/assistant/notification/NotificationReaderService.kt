package com.myra.assistant.notification

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.PowerManager
import android.os.SystemClock
import com.myra.assistant.voice.Announcer
import com.myra.assistant.voice.Say
import com.myra.assistant.utils.prefs
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Reads user notifications and uses notification RemoteInput when a reply action exists.
 *
 * Spoken through [Announcer], so there is only ever ONE voice (never Maya + a second TTS engine), and:
 *  - the same notification is never read twice (updates, re-posts, group summaries are ignored),
 *  - nothing is read while the screen is off (unless the user turned that on),
 *  - nothing is read when the user switched "read notifications" off.
 */
class NotificationReaderService : NotificationListenerService() {

    /** pkg|title|text -> time it was last read */
    private val recent = ConcurrentHashMap<String, Long>()
    /** sbn.key -> hash of the last text read for it (a progress/update post of the same message is silent) */
    private val lastTextForKey = ConcurrentHashMap<String, Int>()

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.isOngoing) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, Notification.CATEGORY_ALARM,
            Notification.CATEGORY_CALL -> return
        }
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        if (title.contains("MOON", true)) return

        // reply target is always remembered, even when we stay silent
        val actions = n.actions
        if (actions != null) for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            val reply = ReplyTarget(sbn.key, title, text, action.actionIntent, remoteInputs)
            targets[sbn.key] = reply
            latest = reply
            break
        }

        remember(sbn, title, text)

        if (!shouldSpeak()) return

        // ---- duplicate guard ----
        val body = "$title|$text"
        val h = body.hashCode()
        if (lastTextForKey[sbn.key] == h) return                 // same notification updated, nothing new
        lastTextForKey[sbn.key] = h
        val now = SystemClock.elapsedRealtime()
        val sig = "${sbn.packageName}|$body"
        val prev = recent[sig]
        if (prev != null && now - prev < 90_000) return          // same message re-posted by another path
        recent[sig] = now
        if (recent.size > 200) recent.entries.removeIf { now - it.value > 120_000 }
        if (lastTextForKey.size > 300) lastTextForKey.clear()

        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { "" }
        val spoken = buildString {
            if (app.isNotBlank()) append(app).append(": ")
            if (title.isNotBlank()) append(title)
            if (title.isNotBlank() && text.isNotBlank()) append(". ")
            append(text)
        }.take(220)
        if (spoken.isBlank()) return
        Announcer.announce(this, "notif:$h", Say(spoken, spoken, "New notification from $spoken"), dedupeMs = 90_000)
    }

    private fun shouldSpeak(): Boolean {
        val p = prefs()
        if (!p.getBoolean("notification_read_aloud", false)) return false
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive && !p.getBoolean("notification_read_screen_off", false)) return false
        return true
    }

    private fun remember(sbn: StatusBarNotification, title: String, text: String) {
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        synchronized(seen) {
            seen.removeAll { it.key == sbn.key }
            seen.addFirst(Seen(sbn.key, app, title, text, System.currentTimeMillis()))
            while (seen.size > 30) seen.removeLast()
        }
    }

    /** What the user hears when THEY ask for their notifications (never read out on its own). */
    fun recentSummary(max: Int = 5): String {
        val cutoff = System.currentTimeMillis() - 12 * 3600_000L
        val list = synchronized(seen) { seen.filter { it.time >= cutoff }.take(max) }
        if (list.isEmpty()) return "Notun kono notification nei."
        return "Notification (" + list.size + " ta): " + list.joinToString(" | ") { n ->
            buildString {
                append(n.app)
                if (n.title.isNotBlank()) append(": ").append(n.title)
                if (n.text.isNotBlank()) append(" - ").append(n.text.take(120))
            }
        }
    }

    fun replyToLatest(message: String): Boolean = latest?.let { sendReply(it, message) } ?: false

    fun replyTo(titleOrApp: String?, message: String): Boolean {
        val query = titleOrApp?.trim()?.lowercase(Locale.getDefault()).orEmpty()
        val target = if (query.isBlank()) latest else targets.values.firstOrNull {
            it.title.lowercase(Locale.getDefault()).contains(query)
        }
        return target?.let { sendReply(it, message) } ?: false
    }

    private fun sendReply(target: ReplyTarget, message: String): Boolean {
        return try {
            val fillIn = Intent()
            val results = Bundle()
            target.remoteInputs.forEach { input -> results.putCharSequence(input.resultKey, message) }
            android.app.RemoteInput.addResultsToIntent(target.remoteInputs, fillIn, results)
            target.actionIntent.send(this, 0, fillIn)
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onListenerDisconnected() {
        latest = null
    }

    override fun onDestroy() {
        latest = null
        targets.clear()
        instance = null
        super.onDestroy()
    }

    data class Seen(val key: String, val app: String, val title: String, val text: String, val time: Long)

    data class ReplyTarget(
        val key: String,
        val title: String,
        val text: String,
        val actionIntent: PendingIntent,
        val remoteInputs: Array<android.app.RemoteInput>
    )

    companion object {
        @Volatile var instance: NotificationReaderService? = null
        @Volatile private var latest: ReplyTarget? = null
        private val targets = ConcurrentHashMap<String, ReplyTarget>()
        private val seen = java.util.ArrayDeque<Seen>()
    }
}
