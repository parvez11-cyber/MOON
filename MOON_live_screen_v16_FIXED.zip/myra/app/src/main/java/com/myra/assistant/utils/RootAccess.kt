package com.myra.assistant.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.TimeUnit

/**
 * Root bridge that never throws. Every call has a timeout so a hung su prompt cannot freeze the app,
 * and every failure (no su, denied, killed, bad output) becomes a plain false/null.
 */
object RootAccess {
    private const val TIMEOUT_SEC = 8L
    private const val CHECK_TTL_MS = 60_000L

    @Volatile var isRootAvailable: Boolean = false
        private set

    @Volatile private var checkedAt = 0L
    private val lock = Any()

    /** Asks for su once (cached 60s). Safe to call from any thread. Returns true only if uid=0 is confirmed. */
    fun request(@Suppress("UNUSED_PARAMETER") context: Context? = null): Boolean = synchronized(lock) {
        val now = System.currentTimeMillis()
        if (checkedAt != 0L && now - checkedAt < CHECK_TTL_MS) return isRootAvailable
        isRootAvailable = runCatching {
            val out = runSu("id")
            out != null && out.contains("uid=0")
        }.getOrDefault(false)
        checkedAt = now
        Logger.d("ROOT", "root=$isRootAvailable")
        isRootAvailable
    }

    /** Runs one command as root. Returns output, or null on any failure. Never throws. */
    fun exec(command: String): String? {
        if (!isRootAvailable) return null
        return runCatching { runSu(command) }.getOrNull()
    }

    /** Several commands in one su session. Returns true only if the session exited 0. */
    fun execAllOk(commands: List<String>): Boolean {
        if (!isRootAvailable || commands.isEmpty()) return false
        return runCatching {
            val p = ProcessBuilder("su", "-c", commands.joinToString(" && ")).redirectErrorStream(true).start()
            val finished = p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
            if (!finished) { p.destroy(); false } else p.exitValue() == 0
        }.getOrDefault(false)
    }

    fun execAll(commands: List<String>): String? = exec(commands.joinToString("\n"))

    /** Screenshot through root. Returns null on failure. */
    fun screencap(): Bitmap? {
        if (!isRootAvailable) return null
        return runCatching {
            val p = ProcessBuilder("su", "-c", "screencap -p").start()
            val bytes = p.inputStream.use { it.readBytes() }
            if (!p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)) { p.destroy(); return null }
            if (bytes.isEmpty()) null else BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }

    private fun runSu(command: String): String? {
        val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        if (!p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)) { p.destroy(); return null }
        return out.trim()
    }
}
