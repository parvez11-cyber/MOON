package com.myra.assistant.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Shared "name or number -> phone number" lookup, used by calling and SMS. */
object ContactResolver {
    data class Contact(val name: String, val number: String)

    fun isNumber(s: String) = s.replace(Regex("[\\s\\-()]"), "").matches(Regex("\\+?\\d{6,15}"))

    fun granted(c: Context, p: String = Manifest.permission.READ_CONTACTS) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    /** Best match for a spoken name, or the cleaned number if [query] already looks like one. Null if not found. */
    fun resolve(context: Context, query: String): Contact? {
        val q = query.trim()
        if (isNumber(q)) return Contact(q, q.replace(Regex("[\\s\\-()]"), ""))
        if (!granted(context)) return null
        val norm = q.lowercase().replace(Regex("\\s+"), " ").trim()
        return lookup(context, q).minByOrNull {
            val n = it.name.lowercase().replace(Regex("\\s+"), " ").trim()
            when { n == norm -> 0; n.startsWith(norm) -> 1; else -> 2 }
        }
    }

    fun lookup(context: Context, name: String): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${name.trim()}%"), null
            )?.use { c ->
                while (c.moveToNext() && out.size < 20) {
                    val num = c.getString(1)?.replace(Regex("[\\s\\-()]"), "").orEmpty()
                    if (num.isNotEmpty()) out.add(Contact(c.getString(0).orEmpty(), num))
                }
            }
        } catch (_: Exception) { }
        return out
    }
}
