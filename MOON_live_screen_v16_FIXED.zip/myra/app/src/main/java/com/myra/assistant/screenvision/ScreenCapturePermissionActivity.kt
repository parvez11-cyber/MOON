package com.myra.assistant.screenvision

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import com.myra.assistant.services.ForegroundVoiceService

/**
 * Invisible one-tap activity: shows Android's own "Start recording or casting?" system dialog
 * once, then hands the grant straight to the voice service so it can capture the real, live
 * screen (continuous frames) instead of one-off screenshots. Finishes itself either way.
 */
class ScreenCapturePermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            ForegroundVoiceService.instance?.startLiveScreen(resultCode, data)
        }
        finish()
    }

    companion object {
        private const val REQ = 9021
        fun launch(ctx: android.content.Context) {
            ctx.startActivity(Intent(ctx, ScreenCapturePermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
