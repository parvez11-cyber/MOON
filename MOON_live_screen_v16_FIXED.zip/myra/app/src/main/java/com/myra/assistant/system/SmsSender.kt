package com.myra.assistant.system

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

/**
 * Sends a real SMS and reports whether it actually left the phone.
 *
 * Old code problems fixed here:
 *  - "SMS Rahim Bhai hello" used to take only "Rahim" as the name. Now the name can be several words.
 *  - SEND_SMS permission was never checked (silent failure).
 *  - Contact lookup was a plain LIKE; now it ranks exact > starts-with > contains and also accepts a raw number.
 *  - It said "sent" without waiting for the radio. Now it waits for the sent callback.
 */
object SmsSender {
    private const val TAG = "SMS"
    private const val ACTION_SENT = "com.myra.assistant.SMS_SENT"

    data class Result(val ok: Boolean, val message: String)
    private data class Contact(val name: String, val number: String)

    // words that are only "send an sms to ..." wording, never a person's name or part of the message start
    private val LEAD_STOP = setOf(
        "sms", "text", "texts", "message", "msg", "send", "to", "ke", "ko", "koro", "kor", "dao", "bhejo", "bhejao",
        "pathao", "pathan", "likho", "এসএমএস", "মেসেজ", "কে", "কো", "পাঠাও", "পাঠান", "লিখো", "দাও"
    )
    // after the name, "to" / "do" can be genuine message words, so they stay
    private val MSG_LEAD_STOP = LEAD_STOP - setOf("to")

    private fun stripLead(words: List<String>, stop: Set<String>): List<String> {
        var i = 0
        while (i < words.size - 1 && words[i].lowercase().trim(',', ':', '.') in stop) i++
        return words.drop(i)
    }

    private fun words(s: String) = s.trim().split(Regex("\\s+")).filter { it.isNotBlank() }

    /** [rest] is whatever follows the word SMS. Supports "name | message", "name :: message" or "name message words". */
    suspend fun sendFromCommand(context: Context, rest: String): Result {
        val text = rest.trim()
        if (text.isEmpty()) return Result(false, "SMS er jonno kar naam ar ki likhbo seta bolo.")
        val (target, body) = split(context, text)
        if (target.isBlank() || body.isBlank()) return Result(false, "Naam ba message bujhte parini.")
        return send(context, target, body)
    }

    suspend fun send(context: Context, nameOrNumber: String, message: String): Result {
        val app = context.applicationContext
        if (!granted(app, Manifest.permission.SEND_SMS)) {
            // with root we can grant it ourselves
            if (RootAccess.isRootAvailable) RootAccess.exec("pm grant ${app.packageName} ${Manifest.permission.SEND_SMS}")
            if (!granted(app, Manifest.permission.SEND_SMS)) {
                return Result(false, "SMS permission deya nai. Settings theke SMS permission on korte hobe.")
            }
        }
        if (!isNumber(nameOrNumber) && !granted(app, Manifest.permission.READ_CONTACTS)) {
            return Result(false, "Contacts permission deya nai, tai naam diye khujte parchi na. Permission on koro, ba number bolo.")
        }
        // Never guess: if the name is not clearly ONE person, do not send. Ask instead.
        val target = when (val p = pick(app, nameOrNumber)) {
            is Pick.One -> p
            is Pick.Many -> return Result(false,
                "SMS pathai ni. '${nameOrNumber}' naam e ekadhik contact ache: ${p.names.joinToString(", ")}. Kon-ta ke pathabo? Puro naam bolo.")
            is Pick.Near -> return Result(false,
                "SMS pathai ni. '${nameOrNumber}' naam e hubohu paini, kintu ${p.names.joinToString(" ba ")} ache. Kake pathabo, puro naam bolo.")
            Pick.None -> return Result(false, "'$nameOrNumber' naam e kono contact paini. SMS pathai ni.")
        }
        val tail = target.number.filter { it.isDigit() }.takeLast(4)
        return when (val r = dispatch(app, target.number, message)) {
            null -> Result(true, "SMS pathano hoyeche ${target.name} (...$tail) ke.")
            else -> Result(false, "SMS jayni (${target.name} ...$tail): $r")
        }
    }

    // ---------------------------------------------------------------- parsing & contacts

    private fun split(context: Context, text: String): Pair<String, String> {
        for (sep in listOf("|", "::")) {
            val i = text.indexOf(sep)
            if (i > 0) {
                val name = stripLead(words(text.substring(0, i)), LEAD_STOP).joinToString(" ")
                return name to text.substring(i + sep.length).trim()
            }
        }
        val w = stripLead(words(text), LEAD_STOP)
        if (w.size < 2) return w.joinToString(" ") to ""
        // longest leading run of words that is really a contact name wins
        if (granted(context, Manifest.permission.READ_CONTACTS)) {
            for (n in minOf(4, w.size - 1) downTo 1) {
                val name = w.take(n).joinToString(" ")
                if (isNumber(name) || candidates(context, name).isNotEmpty()) {
                    return name to stripLead(w.drop(n), MSG_LEAD_STOP).joinToString(" ")
                }
            }
        }
        return w[0] to stripLead(w.drop(1), MSG_LEAD_STOP).joinToString(" ")
    }

    private fun isNumber(s: String) = s.replace(Regex("[\\s\\-()]"), "").matches(Regex("\\+?\\d{6,15}"))

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()

    private data class Entry(val name: String, val number: String, val type: Int)

    private sealed class Pick {
        data class One(val name: String, val number: String) : Pick()
        data class Many(val names: List<String>) : Pick()
        data class Near(val names: List<String>) : Pick()
        object None : Pick()
    }

    /** 0 = exact name, 1 = every spoken word is a whole word of the name, 2 = every spoken word starts a word of the name. */
    private fun rank(contactName: String, q: List<String>): Int? {
        val n = norm(contactName)
        if (n == q.joinToString(" ")) return 0
        val nw = n.split(' ')
        if (q.all { it in nw }) return 1
        if (q.all { it.length >= 3 && nw.any { w -> w.startsWith(it) } }) return 2
        return null
    }

    private fun fetch(context: Context, like: String): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${like.trim()}%"),
                null
            )?.use { c ->
                while (c.moveToNext() && out.size < 200) {
                    val num = c.getString(1)?.replace(Regex("[\\s\\-()]"), "").orEmpty()
                    if (num.isNotEmpty()) out.add(Entry(c.getString(0).orEmpty(), num, c.getInt(2)))
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "contact lookup: ${e.message}")
        }
        return out
    }

    /** Only the best-matching tier of contacts (whole-word / prefix matches), never loose "contains" hits. */
    private fun candidates(context: Context, query: String): List<Entry> {
        val q = norm(query).split(' ').filter { it.isNotEmpty() }
        if (q.isEmpty() || norm(query).length < 2) return emptyList()
        val scored = fetch(context, q.maxByOrNull { it.length }!!).mapNotNull { e -> rank(e.name, q)?.let { it to e } }
        val best = scored.minOfOrNull { it.first } ?: return emptyList()
        return scored.filter { it.first == best }.map { it.second }
    }

    private fun pick(context: Context, query: String): Pick {
        if (isNumber(query)) return Pick.One(query.trim(), query.replace(Regex("[\\s\\-()]"), ""))
        val tier = candidates(context, query)
        if (tier.isEmpty()) {
            // only loose matches exist: show them, but do not send to them
            val near = fetch(context, query.trim()).map { it.name }.distinctBy { norm(it) }.take(3)
            return if (near.isEmpty() || query.trim().length < 2) Pick.None else Pick.Near(near)
        }
        val people = tier.groupBy { norm(it.name) }
        if (people.size > 1) return Pick.Many(people.values.map { it.first().name }.take(4))
        val entries = people.values.first()
        // same person with several numbers: prefer a mobile number, then the first one
        val best = entries.firstOrNull { it.type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE } ?: entries.first()
        return Pick.One(best.name, best.number)
    }

    // ---------------------------------------------------------------- sending

    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    private fun smsManager(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()

    /** Returns null on success, otherwise a short reason. */
    private suspend fun dispatch(app: Context, number: String, message: String): String? {
        return try {
            val sms = smsManager(app)
            val parts = sms.divideMessage(message)
            val total = parts.size
            val okCount = AtomicInteger(0)
            val failReason = arrayOfNulls<String>(1)

            val outcome = withTimeoutOrNull(15_000) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val action = "$ACTION_SENT.${System.nanoTime()}"
                    val done = AtomicInteger(0)
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(c: Context, i: Intent) {
                            if (resultCode == Activity.RESULT_OK) okCount.incrementAndGet()
                            else failReason[0] = reason(resultCode)
                            if (done.incrementAndGet() >= total && cont.isActive) cont.resume(okCount.get() == total)
                        }
                    }
                    ContextCompat.registerReceiver(app, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                    cont.invokeOnCancellation { runCatching { app.unregisterReceiver(receiver) } }
                    try {
                        val flags = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                        val sent = ArrayList<PendingIntent>()
                        for (i in 0 until total) {
                            sent.add(PendingIntent.getBroadcast(app, i, Intent(action).setPackage(app.packageName), flags))
                        }
                        if (total == 1) sms.sendTextMessage(number, null, message, sent[0], null)
                        else sms.sendMultipartTextMessage(number, null, parts, sent, null)
                    } catch (e: Exception) {
                        failReason[0] = e.message ?: "error"
                        runCatching { app.unregisterReceiver(receiver) }
                        if (cont.isActive) cont.resume(false)
                    }
                }
            }
            when (outcome) {
                true -> null
                false -> failReason[0] ?: "unknown error"
                null -> "radio response dei nai (network/SIM check korun)"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "send error: ${e.message}")
            e.message ?: "error"
        }
    }

    private fun reason(code: Int) = when (code) {
        SmsManager.RESULT_ERROR_NO_SERVICE -> "network nai"
        SmsManager.RESULT_ERROR_RADIO_OFF -> "airplane mode/radio off"
        SmsManager.RESULT_ERROR_NULL_PDU -> "message khali"
        else -> "generic failure ($code)"
    }

    /** Last resort when SEND_SMS is not allowed: open the composer prefilled so one tap sends it. */
    fun openComposer(context: Context, number: String, message: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
                    .putExtra("sms_body", message).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }
}
