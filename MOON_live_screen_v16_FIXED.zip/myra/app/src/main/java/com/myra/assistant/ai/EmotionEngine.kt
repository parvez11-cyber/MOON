package com.myra.assistant.ai

import androidx.lifecycle.MutableLiveData

/**
 * Maya's current feeling. The voice model sets it with the express_emotion function; text replies
 * are read for mood words as a fallback. The avatar (VRM) listens to [current] and changes its face.
 *
 * Names used everywhere: neutral, happy, sad, angry, surprised, relaxed, love, worried, sleepy
 */
object EmotionEngine {
    val ALL = listOf("neutral", "happy", "sad", "angry", "surprised", "relaxed", "love", "worried", "sleepy")

    /** Richer words the model may use, mapped to the nearest face the avatar can show. */
    private val ALIASES = mapOf(
        "excited" to "surprised", "playful" to "happy", "joy" to "happy", "joyful" to "happy", "cheerful" to "happy",
        "proud" to "happy", "amused" to "happy", "laughing" to "happy", "delighted" to "happy",
        "caring" to "relaxed", "calm" to "relaxed", "gentle" to "relaxed", "content" to "relaxed",
        "affectionate" to "love", "loving" to "love", "warm" to "love",
        "sympathetic" to "worried", "concerned" to "worried", "anxious" to "worried", "empathetic" to "worried",
        "upset" to "sad", "disappointed" to "sad", "tired" to "sleepy",
        "annoyed" to "angry", "curious" to "surprised", "shocked" to "surprised"
    )

    val current = MutableLiveData("neutral")
    @Volatile var lastChangeAt = 0L
        private set

    fun set(name: String) {
        val raw = name.lowercase().trim()
        val n = when {
            raw in ALL -> raw
            raw in ALIASES -> ALIASES.getValue(raw)
            else -> "neutral"
        }
        lastChangeAt = System.currentTimeMillis()
        current.postValue(n)
    }

    /** Cheap keyword guess, used only when the model did not say how it feels. */
    fun fromText(text: String): String {
        val t = text.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("sorry", "dukkhito", "দুঃখ", "আহা রে", "ইশ", "উফ", "খারাপ লাগ", "kharap lag", "মন খারাপ", "😢", "😞") -> "sad"
            has("সাবধান", "chinta", "চিন্তা", "careful", "worried", "ভয়") -> "worried"
            has("wow", "ওয়াও", "সত্যি?", "really?", "অবাক", "😮", "😲") -> "surprised"
            has("ভালোবাসি", "love you", "miss", "মিস করি", "❤", "😍") -> "love"
            has("ঘুম", "ghum", "sleep", "শুভ রাত্রি", "good night", "😴") -> "sleepy"
            has("রাগ", "angry", "বিরক্ত", "😠") -> "angry"
            has("haha", "হাহা", "মজা", "খুশি", "khushi", "great", "দারুণ", "😊", "😄", "😂", "yay", "wah", "বাহ", "ওয়াও", "হিহি", "আনন্দ", "bhalo lagche", "ভালো লাগছে", "congrat", "অভিনন্দন", "🥳", "😁") -> "happy"
            else -> "neutral"
        }
    }
}
