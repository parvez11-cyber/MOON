package com.myra.assistant.automation

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.ContactResolver
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess

object CallAutomation {
    private const val TAG = "MYRA_CALL"

    data class Result(val ok: Boolean, val message: String)

    /** Resolves [nameOrNumber] to a contact and places a real call, with root-permission and dialer fallback. */
    fun callByName(context: Context, nameOrNumber: String): Result {
        val query = nameOrNumber.trim()
        if (query.isEmpty()) return Result(false, "Kake call korbo bolo.")
        val contact = ContactResolver.resolve(context, query)
            ?: return Result(false, "'$query' naam e kono contact paini.")
        return makeCall(context, contact.number, contact.name)
    }

    fun makeCall(context: Context, number: String, label: String = number): Result {
        val cleanNumber = number.replace(Regex("[\\s\\-()]"), "")
        if (cleanNumber.isEmpty()) return Result(false, "Number ta bujhte parini.")

        if (!hasCallPermission(context) && RootAccess.isRootAvailable) {
            RootAccess.exec("pm grant ${context.packageName} ${Manifest.permission.CALL_PHONE}")
        }
        if (hasCallPermission(context)) {
            return try {
                val intent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$cleanNumber")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                Logger.d(TAG, "calling -> $cleanNumber")
                Result(true, "$label ke call korchi.")
            } catch (e: Exception) {
                Logger.d(TAG, "call failed: ${e.message}")
                openDialer(context, cleanNumber)
                Result(false, "Call korte parlam na, dialer khule dilam.")
            }
        }
        // no CALL_PHONE permission and no root to grant it silently -> open the dialer pre-filled, user taps call
        openDialer(context, cleanNumber)
        return Result(false, "Call korar permission nai, dialer khule dilam $label-er number diye.")
    }

    fun openDialer(context: Context, number: String): Boolean = try {
        context.startActivity(Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$number")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        true
    } catch (_: Exception) { false }

    private fun hasCallPermission(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
}
