package com.myra.assistant.screenvision

import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * MOON's "eyes": while the mic toggle is ON, this streams the phone's own screen to Gemini as a
 * live sequence of frames, so she sees whatever is on screen as you talk. The instant the mic
 * goes OFF, this stops -- nothing is captured again until mic is ON.
 *
 * Two sources, tried in this order each tick:
 *  1. Live capture (MediaProjection via ForegroundVoiceService.liveScreenFrame()) -- real continuous
 *     frames, no per-frame screenshot overhead, this is the "live" path. Granted once with a normal
 *     system dialog (ScreenCapturePermissionActivity); after that it just works until the service dies.
 *  2. Fallback: one screenshot per tick (accessibility API or root), used only until live capture has
 *     been granted, or if it stops producing frames for any reason.
 */
object ScreenWatcher {
    private const val TAG = "SCREEN_WATCH"
    private const val LIVE_INTERVAL_MS = 400L   // live frames: fast, no subprocess spawn, feels real-time
    private const val FALLBACK_INTERVAL_MS = 2500L

    // kept so LiveScreen / the voice service still compile: with this old-style watcher, "live" is simply "mic is on"
    @Volatile private var live = false
    fun setLive(on: Boolean, untilMicOff: Boolean = false) { live = on }
    fun isLive(): Boolean = live

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (true) {
                var sentLive = false
                try {
                    val svc = ForegroundVoiceService.instance
                    if (svc != null && svc.isMicEnabled() && svc.isGeminiConnected()) {
                        val liveFrame = if (svc.hasLiveScreen()) svc.liveScreenFrame() else null
                        if (liveFrame != null) {
                            svc.sendVideoFrame(toJpeg(liveFrame))
                            sentLive = true
                        } else {
                            val jpeg = ScreenReader.screenshotJpeg()
                            if (jpeg != null) svc.sendVideoFrame(jpeg)
                        }
                    }
                } catch (e: Exception) {
                    Logger.e(TAG, "frame failed: ${e.message}")
                }
                delay(if (sentLive) LIVE_INTERVAL_MS else FALLBACK_INTERVAL_MS)
            }
        }
        Logger.d(TAG, "started")
    }

    fun stop() {
        job?.cancel()
        job = null
        Logger.d(TAG, "stopped")
    }

    private fun toJpeg(bmp: android.graphics.Bitmap): ByteArray {
        val w = 768
        val scaled = if (bmp.width > w)
            android.graphics.Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true)
        else bmp
        val out = java.io.ByteArrayOutputStream()
        scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, out)
        return out.toByteArray()
    }
}
