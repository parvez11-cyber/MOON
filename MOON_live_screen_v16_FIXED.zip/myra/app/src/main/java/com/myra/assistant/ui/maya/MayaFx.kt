package com.myra.assistant.ui.maya

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Observer
import com.myra.assistant.ai.EmotionEngine
import com.myra.assistant.utils.Constants
import com.myra.assistant.voice.VoiceStateManager
import kotlin.math.PI
import kotlin.math.sin

/** How each feeling looks: two colours, what floats around, and the little label shown on the home screen. */
private const val P_DOT = 0
private const val P_HEART = 1
private const val P_SPARKLE = 2
private const val P_RAIN = 3
private const val P_BUBBLE = 4
private const val P_EMBER = 5

private data class Feeling(val a: Color, val b: Color, val kind: Int, val label: String, val emoji: String)

private fun feelingOf(e: String): Feeling = when (e) {
    "happy" -> Feeling(Color(0xFFFFB84D), Color(0xFFFF7BAC), P_SPARKLE, "Khush hoon", "😊")
    "sad" -> Feeling(Color(0xFF6C8CD5), Color(0xFFA9BDF0), P_RAIN, "Thodi udaas", "🥺")
    "angry" -> Feeling(Color(0xFFE5484D), Color(0xFFFF9A62), P_EMBER, "Naraz", "😤")
    "surprised" -> Feeling(Color(0xFF38C7E8), Color(0xFFB38BFF), P_SPARKLE, "Hairan", "😲")
    "relaxed" -> Feeling(Color(0xFF52C9A0), Color(0xFF8FD9F0), P_BUBBLE, "Sukoon me", "😌")
    "love" -> Feeling(Color(0xFFFF6FA5), Color(0xFFFFB3D1), P_HEART, "Pyaar aa raha hai", "🥰")
    "worried" -> Feeling(Color(0xFF9B7FE6), Color(0xFF7FB2E6), P_BUBBLE, "Tumhari fikar hai", "😟")
    "sleepy" -> Feeling(Color(0xFF7A84B8), Color(0xFFB5B9E8), P_BUBBLE, "Neend aa rahi", "😴")
    else -> Feeling(Color(0xFF3B8EEA), Color(0xFF8E7BFF), P_DOT, "Tumhare saath", "💙")
}

@Composable
private fun rememberEmotion(): String {
    var emotion by remember { mutableStateOf("neutral") }
    DisposableEffect(Unit) {
        val e = Observer<String> { emotion = it ?: "neutral" }
        EmotionEngine.current.observeForever(e)
        onDispose { EmotionEngine.current.removeObserver(e) }
    }
    return emotion
}

/** A small glass pill showing how Maya feels right now (changes smoothly with her mood). */
@Composable
fun MayaFeelingChip(modifier: Modifier = Modifier) {
    val emotion = rememberEmotion()
    val f = feelingOf(emotion)
    val border by animateColorAsState(f.a.copy(alpha = 0.55f), tween(700), label = "chipBorder")
    val bob by rememberInfiniteTransition(label = "chip").animateFloat(
        0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Reverse), label = "bob"
    )
    Row(
        modifier.clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.62f))
            .border(BorderStroke(1.2.dp, border), RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Crossfade(targetState = f.emoji, animationSpec = tween(450), label = "emoji") { em ->
            Text(em, fontSize = (17f + 2f * bob).sp)
        }
        Spacer(Modifier.width(8.dp))
        Crossfade(targetState = f.label, animationSpec = tween(450), label = "label") { l ->
            Text(l, color = MC.Navy, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/**
 * Living background for the home screen. Everything follows Maya's feeling:
 *  - a two-colour wash and slow drifting glows (colours blend smoothly when her mood changes),
 *  - a breathing aura behind her, with rings that pulse out while she listens / speaks,
 *  - feeling-specific things floating around: hearts for love, sparkles for joy, soft rain for sadness,
 *    calm bubbles for relaxed / worried / sleepy, warm embers for anger.
 * One infinite transition drives everything, so it stays smooth and cheap.
 */
@Composable
fun MayaAmbientFx(modifier: Modifier = Modifier.fillMaxSize()) {
    val emotion = rememberEmotion()
    var voice by remember { mutableStateOf(Constants.STATE_IDLE) }
    DisposableEffect(Unit) {
        val v = Observer<String> { voice = it ?: Constants.STATE_IDLE }
        VoiceStateManager.state.observeForever(v)
        onDispose { VoiceStateManager.state.removeObserver(v) }
    }

    val f = feelingOf(emotion)
    val a by animateColorAsState(f.a, tween(1100), label = "colA")
    val b by animateColorAsState(f.b, tween(1100), label = "colB")
    val kind = f.kind
    val active = voice == Constants.STATE_LISTENING || voice == Constants.STATE_SPEAKING
    val speaking = voice == Constants.STATE_SPEAKING
    val lively = emotion == "love" || emotion == "happy" || emotion == "surprised"

    val t by rememberInfiniteTransition(label = "fx").animateFloat(
        0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0f, 1f, infiniteRepeatable(tween(if (speaking) 1100 else 1900, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
    val twoPi = 2f * PI.toFloat()

    Canvas(modifier) {
        val w = size.width; val h = size.height
        val centre = Offset(w / 2f, h * 0.36f)

        // soft two-colour wash over the whole screen
        drawRect(Brush.verticalGradient(listOf(a.copy(alpha = 0.16f), Color.Transparent, b.copy(alpha = 0.16f))))

        // two slowly drifting colour glows, like a gentle aurora
        val g1 = Offset(w * (0.25f + 0.10f * sin(t * twoPi)), h * (0.20f + 0.05f * sin(t * twoPi * 2f)))
        val g2 = Offset(w * (0.78f + 0.08f * sin(t * twoPi + 2f)), h * (0.62f + 0.06f * sin(t * twoPi + 1f)))
        drawCircle(Brush.radialGradient(listOf(b.copy(alpha = 0.30f), Color.Transparent), g1, w * 0.7f), w * 0.7f, g1)
        drawCircle(Brush.radialGradient(listOf(a.copy(alpha = 0.26f), Color.Transparent), g2, w * 0.75f), w * 0.75f, g2)

        // breathing aura behind Maya; it "beats" a little faster when she is full of joy or love
        val beat = if (lively) 5f else 3f
        val breathe = 0.5f + 0.5f * sin(t * twoPi * beat)
        val r = w * (0.62f + 0.07f * breathe)
        drawCircle(Brush.radialGradient(listOf(a.copy(alpha = 0.32f + 0.12f * breathe), b.copy(alpha = 0.10f), Color.Transparent), centre, r), r, centre)

        // pulse rings while she listens / speaks
        if (active) {
            for (k in 0..2) {
                val p = (pulse + k / 3f) % 1f
                val rr = w * (0.22f + 0.40f * p)
                drawCircle((if (k == 1) b else a).copy(alpha = (1f - p) * 0.38f), rr, centre, style = Stroke(width = 3f + 5f * (1f - p)))
            }
        }

        // feeling-specific floating things (fixed seeds, no state allocated per frame)
        val count = when (kind) { P_HEART -> 14; P_RAIN -> 30; P_SPARKLE -> 20; else -> 22 }
        for (i in 0 until count) {
            val seed = (i * 0.6180339f) % 1f
            val phase = (t * (1 + i % 3) + seed) % 1f
            val sway = sin(phase * twoPi + i) * w * 0.03f
            val x = w * ((seed * 7.3f) % 1f) + sway
            val fade = sin(phase * PI.toFloat()).coerceIn(0f, 1f)
            val col = if (i % 2 == 0) a else b
            when (kind) {
                P_HEART -> {
                    val y = h * (1.05f - phase * 1.15f)
                    heart(Offset(x, y), 7f + (i % 4) * 3.5f, col.copy(alpha = fade * 0.55f))
                }
                P_SPARKLE -> {
                    val y = h * (1.0f - phase * 1.05f)
                    val tw = 0.6f + 0.4f * sin(phase * twoPi * 3f + i)
                    sparkle(Offset(x, y), (6f + (i % 4) * 3f) * tw, col.copy(alpha = fade * 0.75f))
                }
                P_RAIN -> {
                    val y = h * (phase * 1.1f - 0.05f)
                    val len = 14f + (i % 3) * 8f
                    drawLine(col.copy(alpha = fade * 0.45f), Offset(x, y), Offset(x - 3f, y + len), strokeWidth = 2.4f)
                }
                P_EMBER -> {
                    val y = h * (1.05f - phase * 1.1f)
                    val s = 2.5f + (i % 3) * 1.6f
                    drawCircle(col.copy(alpha = fade * 0.5f), s, Offset(x, y))
                    drawCircle(col.copy(alpha = fade * 0.15f), s * 3.2f, Offset(x, y))
                }
                P_BUBBLE -> {
                    val y = h * (1.05f - phase * 1.1f)
                    val s = 5f + (i % 4) * 4f
                    drawCircle(col.copy(alpha = fade * 0.16f), s, Offset(x, y))
                    drawCircle(col.copy(alpha = fade * 0.38f), s, Offset(x, y), style = Stroke(width = 1.6f))
                }
                else -> {
                    val y = h * (1.05f - phase * 1.15f)
                    val s = 2.5f + (i % 4) * 1.8f
                    drawCircle(col.copy(alpha = fade * 0.45f), s, Offset(x, y))
                    drawCircle(col.copy(alpha = fade * 0.12f), s * 3f, Offset(x, y))
                }
            }
        }
    }
}

private fun DrawScope.heart(c: Offset, s: Float, color: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y + s * 0.9f)
        cubicTo(c.x - s * 1.6f, c.y - s * 0.2f, c.x - s * 0.7f, c.y - s * 1.3f, c.x, c.y - s * 0.4f)
        cubicTo(c.x + s * 0.7f, c.y - s * 1.3f, c.x + s * 1.6f, c.y - s * 0.2f, c.x, c.y + s * 0.9f)
        close()
    }
    drawPath(p, color)
}

private fun DrawScope.sparkle(c: Offset, s: Float, color: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y - s)
        quadraticBezierTo(c.x, c.y, c.x + s, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y + s)
        quadraticBezierTo(c.x, c.y, c.x - s, c.y)
        quadraticBezierTo(c.x, c.y, c.x, c.y - s)
        close()
    }
    drawPath(p, color)
}
