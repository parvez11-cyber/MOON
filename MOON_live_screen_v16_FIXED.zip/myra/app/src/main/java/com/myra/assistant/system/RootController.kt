package com.myra.assistant.system

import android.content.Context
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Every root operation lives here. Nothing else in the app runs su directly.
 *
 * Voice / model grammar (all start with ROOT):
 *   ROOT status
 *   ROOT wifi on|off            ROOT data on|off          ROOT bluetooth on|off
 *   ROOT airplane on|off        ROOT dnd on|off           ROOT brightness 0-100
 *   ROOT gps on|off             ROOT hotspot on|off       ROOT nfc on|off
 *   ROOT autosync on|off        ROOT autorotate on|off    ROOT ringer silent|vibrate|normal
 *   ROOT lock                   ROOT screenshot
 *   ROOT stop <pkg>             ROOT clearcache <pkg>      ROOT grant <pkg> <permission>
 *   ROOT install <path.apk>     ROOT uninstall <pkg> yes
 *   ROOT battery_saver on|off   ROOT volume <0-100>
 *   ROOT reboot yes             ROOT status
 *
 * Irreversible actions (uninstall, reboot) need the trailing "yes". Without it nothing runs.
 * There is no free-form shell path. Inputs are validated with strict patterns.
 */
object RootController {

    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    private val PERM = Regex("^android\\.permission\\.[A-Z_]+$|^[a-z]+(\\.[A-Za-z0-9_]+)+$")
    private val APK_PATH = Regex("^/sdcard/(Download|Downloads|Pictures|DCIM|MOON)/[A-Za-z0-9_ .\\-]+\\.apk$")

    fun run(context: Context, raw: String): String = try {
        execute(context, raw.trim())
    } catch (e: Throwable) {
        Logger.d("ROOT", "failed: ${e.message}")
        "Root kaj ekhon korte parlam na."
    }

    private fun execute(context: Context, raw: String): String {
        val parts = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val action = parts.getOrNull(0)?.lowercase() ?: return "Ki root kaj korbo?"
        val arg1 = parts.getOrNull(1).orEmpty()
        val arg2 = parts.getOrNull(2).orEmpty()

        if (action == "status") {
            val ok = RootAccess.request(context)
            return if (ok) "Root ache. Sob kaj chalbe." else "Root nai. Settings panel khola hobe."
        }
        if (!RootAccess.request(context)) return "Root nai. Ei kaj korte root lagbe."

        return when (action) {
            "wifi" -> toggle(arg1, "svc wifi enable", "svc wifi disable", "WiFi")
            "data" -> toggle(arg1, "svc data enable", "svc data disable", "Mobile data")
            "bluetooth" -> toggle(arg1, "svc bluetooth enable", "svc bluetooth disable", "Bluetooth")
            "airplane" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf(
                    "cmd connectivity airplane-mode ${if (on) "enable" else "disable"}",
                    "settings put global airplane_mode_on ${if (on) 1 else 0}",
                    "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $on"
                )), "Airplane mode ${onOff(on)}")
            }
            "dnd" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf(
                    "cmd notification set_dnd ${if (on) "priority" else "off"}"
                )), "Do not disturb ${onOff(on)}")
            }
            "gps" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf(
                    "settings put secure location_mode ${if (on) 3 else 0}",
                    "cmd location set-location-enabled $on"
                )), "GPS ${onOff(on)}")
            }
            "hotspot" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf(
                    if (on) "svc wifi tether" else "svc wifi untether",
                    "cmd connectivity airplane-mode disable"
                )), "Hotspot ${onOff(on)} (device-bhede alada hote pare)")
            }
            "nfc" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf("svc nfc ${if (on) "enable" else "disable"}")), "NFC ${onOff(on)}")
            }
            "autosync" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf("content call --uri content://settings --method set_sync_automatically --arg $on")),
                    "Auto-sync ${onOff(on)}")
            }
            "autorotate" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf("settings put system accelerometer_rotation ${if (on) 1 else 0}")),
                    "Auto-rotate ${onOff(on)}")
            }
            "ringer" -> {
                val mode = when (arg1.lowercase()) { "silent" -> 0; "vibrate" -> 1; "normal" -> 2; else -> return "silent, vibrate na normal bolo." }
                ok(RootAccess.execAllOk(listOf("cmd audio set-ringer-mode ${listOf("silent","vibrate","normal")[mode]}")),
                    "Ringer ${arg1.lowercase()} kore dilam")
            }
            "battery_saver" -> {
                val on = isOn(arg1) ?: return "on na off?"
                ok(RootAccess.execAllOk(listOf("cmd power set-mode ${if (on) 1 else 0}")), "Battery saver ${onOff(on)}")
            }
            "brightness" -> {
                val p = (arg1.toIntOrNull() ?: return "Koto percent?").coerceIn(0, 100)
                ok(RootAccess.execAllOk(listOf(
                    "settings put system screen_brightness_mode 0",
                    "settings put system screen_brightness ${(p * 255) / 100}"
                )), "Brightness $p%")
            }
            "volume" -> {
                val p = (arg1.toIntOrNull() ?: return "Koto percent?").coerceIn(0, 100)
                ok(RootAccess.execAllOk(listOf("cmd media_session volume --stream 3 --set ${(p * 15) / 100}")),
                    "Volume $p%")
            }
            "lock" -> ok(RootAccess.execAllOk(listOf("input keyevent 26")), "Screen lock kore dilam")
            "screenshot" -> screenshot()
            "stop" -> {
                if (!PKG.matches(arg1)) return "Package name thik na."
                ok(RootAccess.execAllOk(listOf("am force-stop $arg1")), "$arg1 bondho kore dilam")
            }
            "clearcache" -> {
                if (!PKG.matches(arg1)) return "Package name thik na."
                ok(RootAccess.execAllOk(listOf("pm clear --cache-only $arg1")), "$arg1-er cache mucche dilam")
            }
            "grant" -> {
                if (!PKG.matches(arg1) || !PERM.matches(arg2)) return "Package ba permission name thik na."
                ok(RootAccess.execAllOk(listOf("pm grant $arg1 $arg2")), "Permission diye dilam")
            }
            "install" -> {
                if (!APK_PATH.matches(arg1)) return "APK path thik na ba allowed folder-e nai."
                ok(RootAccess.execAllOk(listOf("pm install -r $arg1")), "APK install kore dilam")
            }
            "uninstall" -> {
                if (!PKG.matches(arg1)) return "Package name thik na."
                if (arg2 != "yes") return "Nischit hole bolun 'yes', tarpor uninstall korbo."
                ok(RootAccess.execAllOk(listOf("pm uninstall $arg1")), "$arg1 uninstall kore dilam")
            }
            "reboot" -> {
                if (arg1 != "yes") return "Phone restart korte 'yes' bolun."
                RootAccess.execAllOk(listOf("reboot"))
                "Restart shuru hocche."
            }
            else -> "Ei root kaj ami jani na: $action"
        }
    }

    private fun toggle(arg: String, onCmd: String, offCmd: String, label: String): String {
        val on = isOn(arg) ?: return "on na off?"
        return ok(RootAccess.execAllOk(listOf(if (on) onCmd else offCmd)), "$label ${onOff(on)}")
    }

    private fun screenshot(): String {
        val bmp = RootAccess.screencap() ?: return "Screenshot neya gelo na."
        val dir = File("/sdcard/Pictures/MOON").apply { mkdirs() }
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val file = File(dir, name)
        return try {
            file.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            "Screenshot save hoyeche: ${file.path}"
        } catch (e: Exception) {
            "Screenshot save korte parlam na."
        }
    }

    private fun isOn(s: String): Boolean? = when (s.lowercase()) {
        "on", "chalu", "start", "true", "1" -> true
        "off", "bondho", "stop", "false", "0" -> false
        else -> null
    }

    private fun onOff(on: Boolean) = if (on) "on" else "off"

    private fun ok(success: Boolean, msg: String): String =
        if (success) "$msg kore dilam." else "Ei kaj root diye holo na."
}
