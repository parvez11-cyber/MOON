package com.myra.assistant.ui.maya

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Observer
import com.myra.assistant.utils.Constants
import com.myra.assistant.voice.VoiceStateManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A real-time 3D animation for the home screen, drawn with plain Compose Canvas maths (rotation + perspective),
 * so it needs no internet, no WebView and no WebGL. It reacts to Maya's state:
 *   idle      -> slow, calm blue globe
 *   listening -> cyan, pulses with your voice, ripples go out
 *   thinking  -> violet, fast spin
 *   speaking  -> pink, strong pulse and ripples
 * [avatarReady] dims it into a halo once the VRM character is on screen.
 */
@Composable
fun Maya3DOrb(modifier: Modifier = Modifier, avatarReady: Boolean = false) {
    var stateName by remember { mutableStateOf(Constants.STATE_IDLE) }
    var rawAmp by remember { mutableFloatStateOf(0f) }

    DisposableEffect(Unit) {
        val so = Observer<String> { stateName = it ?: Constants.STATE_IDLE }
        val ao = Observer<Float> { rawAmp = it ?: 0f }
        VoiceStateManager.state.observeForever(so)
        VoiceStateManager.amplitude.observeForever(ao)
        onDispose {
            VoiceStateManager.state.removeObserver(so)
            VoiceStateManager.amplitude.removeObserver(ao)
        }
    }

    // animated values, advanced once per frame
    var time by remember { mutableFloatStateOf(0f) }
    var rotY by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(0.25f) }
    var pulse by remember { mutableFloatStateOf(0f) }
    var ripple by remember { mutableFloatStateOf(0f) }
    var col by remember { mutableStateOf(Color(0xFF3B8EEA)) }

    val dim by animateFloatAsState(if (avatarReady) 0.55f else 1f, tween(700), label = "orbDim")

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                    time += dt
                    val st = stateName
                    val speedTarget = when (st) {
                        Constants.STATE_LISTENING -> 0.6f
                        Constants.STATE_THINKING -> 1.9f
                        Constants.STATE_SPEAKING -> 0.95f
                        else -> 0.25f
                    }
                    speed += (speedTarget - speed) * min(1f, dt * 3f)
                    rotY += speed * dt

                    val colorTarget = when (st) {
                        Constants.STATE_LISTENING -> Color(0xFF22D3EE)
                        Constants.STATE_THINKING -> Color(0xFF8B5CF6)
                        Constants.STATE_SPEAKING -> Color(0xFFF472B6)
                        else -> Color(0xFF3B8EEA)
                    }
                    col = lerp(col, colorTarget, min(1f, dt * 4f))

                    val t = time
                    val pulseTarget = when (st) {
                        Constants.STATE_LISTENING -> (rawAmp * 8f).coerceIn(0f, 1f) * 0.8f
                        // while she talks the mic is paused, so the pulse is synthetic (looks like speech rhythm)
                        Constants.STATE_SPEAKING ->
                            (0.5f + 0.5f * sin(t * 9f)) * (0.5f + 0.5f * sin(t * 3.7f + 1f))
                        Constants.STATE_THINKING -> 0.15f + 0.1f * sin(t * 5f)
                        else -> 0.05f + 0.04f * sin(t * 1.4f)
                    }
                    pulse += (pulseTarget - pulse) * min(1f, dt * 12f)

                    val rippleTarget = if (st == Constants.STATE_LISTENING || st == Constants.STATE_SPEAKING) 1f else 0f
                    ripple += (rippleTarget - ripple) * min(1f, dt * 4f)
                }
                last = now
            }
        }
    }

    // unit points on a sphere (Fibonacci spiral), computed once
    val sphere = remember {
        val n = 320
        val out = FloatArray(n * 3)
        val golden = PI.toFloat() * (3f - sqrt(5f))
        for (i in 0 until n) {
            val y = 1f - (i / (n - 1f)) * 2f
            val r = sqrt(1f - y * y)
            val th = golden * i
            out[i * 3] = cos(th) * r
            out[i * 3 + 1] = y
            out[i * 3 + 2] = sin(th) * r
        }
        out
    }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w / 2f, h * 0.46f)
        val dp = 1.dp.toPx()
        val base = min(w, h) * 0.38f
        val r = base * (1f + pulse * 0.16f)
        val a = dim
        val color = col

        // soft glow behind everything
        drawCircle(
            Brush.radialGradient(
                listOf(color.copy(alpha = 0.34f * a), color.copy(alpha = 0.10f * a), Color.Transparent),
                center = c, radius = r * 1.7f
            ),
            radius = r * 1.7f, center = c
        )

        // ripples going out
        if (ripple > 0.02f) {
            for (k in 0 until 3) {
                val ph = ((time * 0.55f + k / 3f) % 1f)
                drawCircle(
                    color.copy(alpha = (1f - ph) * 0.32f * ripple * a),
                    radius = r * (1.05f + ph * 0.75f), center = c,
                    style = Stroke(width = 2f * dp)
                )
            }
        }

        val cosY = cos(rotY); val sinY = sin(rotY)
        val tilt = 0.38f
        val cosX = cos(tilt); val sinX = sin(tilt)

        // 1) the dotted globe
        for (i in 0 until sphere.size / 3) {
            val x = sphere[i * 3]; val y = sphere[i * 3 + 1]; val z = sphere[i * 3 + 2]
            val x1 = x * cosY + z * sinY
            val z1 = -x * sinY + z * cosY
            val y2 = y * cosX - z1 * sinX
            val z2 = y * sinX + z1 * cosX
            val persp = 1f / (1f - z2 * 0.28f)
            val d = (z2 + 1f) / 2f
            drawCircle(
                color.copy(alpha = (0.12f + 0.88f * d) * a),
                radius = (0.8f + 2.3f * d) * dp * persp,
                center = Offset(c.x + x1 * r * persp, c.y + y2 * r * persp)
            )
        }

        // 2) three tilted orbit rings, each with a bright moon
        val ringTilt = floatArrayOf(1.15f, -0.55f, 0.1f)
        val ringDir = floatArrayOf(1f, -1.3f, 0.8f)
        for (k in 0 until 3) {
            val rr = r * (1.22f + k * 0.09f)
            val cT = cos(ringTilt[k]); val sT = sin(ringTilt[k])
            val spin = rotY * ringDir[k] * 1.6f
            val cs = cos(spin); val ss = sin(spin)
            val steps = 90
            for (s in 0 until steps) {
                val th = s / steps.toFloat() * 2f * PI.toFloat()
                // circle in the XZ plane, tilted about X, then spun about Y
                val px = cos(th); val pz = sin(th)
                val py0 = -pz * sT; val pz0 = pz * cT
                val x1 = px * cs + pz0 * ss
                val z1 = -px * ss + pz0 * cs
                val persp = 1f / (1f - z1 * 0.28f)
                val d = (z1 + 1f) / 2f
                drawCircle(
                    color.copy(alpha = (0.05f + 0.35f * d) * a),
                    radius = (0.6f + 0.9f * d) * dp * persp,
                    center = Offset(c.x + x1 * rr * persp, c.y + py0 * rr * persp)
                )
            }
            // the moon
            val th = time * (1.1f + k * 0.45f) * (if (k == 1) -1f else 1f) + k * 2.1f
            val px = cos(th); val pz = sin(th)
            val py0 = -pz * sT; val pz0 = pz * cT
            val x1 = px * cs + pz0 * ss
            val z1 = -px * ss + pz0 * cs
            val persp = 1f / (1f - z1 * 0.28f)
            val d = (z1 + 1f) / 2f
            val mc = Offset(c.x + x1 * rr * persp, c.y + py0 * rr * persp)
            val mr = (3.5f + 3.5f * d) * dp * persp
            drawCircle(color.copy(alpha = 0.25f * a), radius = mr * 2.6f, center = mc)
            drawCircle(Color.White.copy(alpha = (0.55f + 0.45f * d) * a), radius = mr, center = mc)
        }

        // 3) bright core
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.85f * a), color.copy(alpha = 0.45f * a), Color.Transparent),
                center = c, radius = r * 0.42f
            ),
            radius = r * 0.42f, center = c
        )
    }
}
