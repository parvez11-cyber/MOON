package com.myra.assistant.overlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.myra.assistant.services.ForegroundVoiceService

/**
 * Tiny pill at the top of the screen that is visible exactly while the mic toggle is ON and
 * invisible exactly while it is OFF -- unlike EdgeGlowController this does not flicker with
 * listening/thinking/speaking, it is a plain on/off indicator of "MOON is listening right now".
 * Needs "display over other apps" (auto-granted by root at start-up; otherwise the user grants it once).
 */
object MicStatusOverlay {
    private var view: TextView? = null
    private var wm: WindowManager? = null
    private var receiver: BroadcastReceiver? = null

    fun start(context: Context) {
        val app = context.applicationContext
        if (receiver != null) return
        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val on = i?.getBooleanExtra("enabled", false) ?: (ForegroundVoiceService.instance?.isMicEnabled() == true)
                setVisible(app, on)
            }
        }
        val f = IntentFilter("MYRA_MIC_STATE")
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else app.registerReceiver(receiver, f)
        // match whatever the mic state already is right now (service may have turned it on before this started)
        setVisible(app, ForegroundVoiceService.instance?.isMicEnabled() == true)
    }

    fun stop(context: Context) {
        try { receiver?.let { context.applicationContext.unregisterReceiver(it) } } catch (_: Exception) {}
        receiver = null
        removeView()
    }

    private fun setVisible(app: Context, on: Boolean) {
        if (on) addView(app) else removeView()
    }

    private fun addView(app: Context) {
        if (view != null) return
        if (!Settings.canDrawOverlays(app)) return
        val dp = app.resources.displayMetrics.density
        val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val tv = TextView(app).apply {
            text = "🎙 MOON shunche..."
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding((14 * dp).toInt(), (6 * dp).toInt(), (14 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 40 * dp
                setColor(0xCC1B8F5A.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (36 * dp).toInt()
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        try { manager.addView(tv, lp); view = tv; wm = manager } catch (_: Exception) {}
    }

    private fun removeView() {
        val v = view ?: return
        view = null
        try { wm?.removeViewImmediate(v) } catch (_: Exception) {}
    }
}
