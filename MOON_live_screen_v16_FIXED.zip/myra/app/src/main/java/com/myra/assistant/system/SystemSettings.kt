package com.myra.assistant.system

import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraDeviceAdminReceiver
import com.myra.assistant.utils.RootAccess

/**
 * Whitelisted system switches. The model can only pick from this fixed list, there is deliberately no
 * "run any shell command" path, so text on the screen or in a notification can never turn into a root command.
 *
 *   SYSTEM wifi|bluetooth|mobile_data|airplane|dnd|lock on|off
 *   BRIGHTNESS 0-100
 *
 * Root is used when present. Without root Android only allows the parts it exposes to normal apps;
 * for the rest the matching system panel is opened instead.
 */
object SystemSettings {

    fun apply(context: Context, command: String): String = try {
        applyUnsafe(context, command)
    } catch (e: Throwable) {
        "Ei kaj ekhon hocche na: ${e.javaClass.simpleName}"
    }

    private fun applyUnsafe(context: Context, command: String): String {
        if (command.trim().startsWith("ROOT", true)) {
            return RootController.run(context, command.trim().drop(4).trim())
        }
        val parts = command.trim().split(Regex("\\s+"))
        return when (parts.firstOrNull()?.uppercase()) {
            "BRIGHTNESS" -> brightness(context, parts.getOrNull(1)?.toIntOrNull())
            "SYSTEM" -> {
                val what = parts.getOrNull(1)?.lowercase().orEmpty()
                val on = parts.getOrNull(2)?.lowercase() !in setOf("off", "false", "0")
                when (what) {
                    "wifi" -> wifi(context, on)
                    "bluetooth" -> bluetooth(context, on)
                    "mobile_data", "data" -> mobileData(context, on)
                    "airplane" -> airplane(context, on)
                    "dnd" -> dnd(context, on)
                    "lock" -> lock(context)
                    else -> "Eta ami korte pari na: $what"
                }
            }
            else -> "Bujhte parini."
        }
    }

    private fun root(vararg cmds: String): Boolean = RootAccess.execAllOk(cmds.toList())

    private fun panel(context: Context, action: String): Boolean = try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }

    private fun wifi(c: Context, on: Boolean): String {
        if (root(if (on) "svc wifi enable" else "svc wifi disable")) return "WiFi ${if (on) "on" else "off"} kore dilam."
        panel(c, Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        return "Root nai, tai WiFi panel khule dilam, ota theke ${if (on) "on" else "off"} korun."
    }

    private fun bluetooth(c: Context, on: Boolean): String {
        if (root(if (on) "svc bluetooth enable" else "svc bluetooth disable")) return "Bluetooth ${if (on) "on" else "off"} kore dilam."
        panel(c, Settings.ACTION_BLUETOOTH_SETTINGS)
        return "Root nai, tai Bluetooth settings khule dilam."
    }

    private fun mobileData(c: Context, on: Boolean): String {
        if (root(if (on) "svc data enable" else "svc data disable")) return "Mobile data ${if (on) "on" else "off"} kore dilam."
        panel(c, Settings.ACTION_DATA_ROAMING_SETTINGS)
        return "Root nai, tai data settings khule dilam."
    }

    private fun airplane(c: Context, on: Boolean): String {
        val v = if (on) 1 else 0
        if (root("cmd connectivity airplane-mode ${if (on) "enable" else "disable"}",
                "settings put global airplane_mode_on $v")) return "Airplane mode ${if (on) "on" else "off"} kore dilam."
        panel(c, Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        return "Root nai, tai airplane settings khule dilam."
    }

    private fun dnd(c: Context, on: Boolean): String {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
            return "Do not disturb ${if (on) "on" else "off"} kore dilam."
        }
        if (root("cmd notification set_dnd ${if (on) "priority" else "off"}")) return "Do not disturb ${if (on) "on" else "off"} kore dilam."
        panel(c, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        return "DND access dite hobe, settings khule dilam."
    }

    private fun lock(c: Context): String {
        if (AccessibilityHelperService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) == true)
            return "Screen lock kore dilam."
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(ComponentName(c, MyraDeviceAdminReceiver::class.java))) { dpm.lockNow(); return "Screen lock kore dilam." }
        if (root("input keyevent 26")) return "Screen lock kore dilam."
        return "Lock korte Accessibility ba Device admin on korte hobe."
    }

    private fun brightness(c: Context, percent: Int?): String {
        val p = (percent ?: return "Koto percent brightness?").coerceIn(0, 100)
        val v = (p * 255) / 100
        if (Settings.System.canWrite(c)) {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
            return "Brightness $p% kore dilam."
        }
        if (root("settings put system screen_brightness_mode 0", "settings put system screen_brightness $v")) return "Brightness $p% kore dilam."
        panel(c, Settings.ACTION_MANAGE_WRITE_SETTINGS)
        return "Write settings permission dite hobe, settings khule dilam."
    }
}
