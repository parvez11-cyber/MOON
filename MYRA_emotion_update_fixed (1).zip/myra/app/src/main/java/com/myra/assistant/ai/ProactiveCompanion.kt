package com.myra.assistant.ai

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.BatteryManager
import android.os.PowerManager
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.Announcer
import com.myra.assistant.voice.Say
import com.myra.assistant.voice.VoiceStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Maya talks first. She notices the situation (time of day, battery, how long since you last spoke,
 * what she remembers about you) and, once in a while, checks on you or suggests something good for you.
 *
 * Rules so she is caring and not annoying:
 *  - never while you are in a call, while she is speaking, or while the screen is off
 *  - at least [gapMin] minutes between two check-ins (default 90, setting "proactive_gap_min")
 *  - never in the middle of a conversation (waits until you were quiet for a while)
 *  - each special moment (morning, lunch, dinner, late night) happens at most once a day
 *  - off switch: setting "proactive_enabled"
 *
 * With the internet she says it in her own words (Gemini, with feeling). Offline she uses a warm built-in line.
 */
object ProactiveCompanion {
    private const val TAG = "PROACTIVE"
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var lastInteraction = System.currentTimeMillis()

    /** Call whenever the user talks or types, so she does not interrupt a live conversation. */
    fun touch() { lastInteraction = System.currentTimeMillis() }

    fun start(context: Context) {
        if (job?.isActive == true) return
        val app = context.applicationContext
        job = scope.launch {
            delay(60_000)                       // let the app settle first
            while (isActive) {
                try { tick(app) } catch (e: Exception) { Logger.e(TAG, "tick: ${e.message}") }
                delay(60_000)
            }
        }
    }

    fun stop() { job?.cancel(); job = null }

    private enum class Moment(val perDay: Boolean) { MORNING(true), LUNCH(true), DINNER(true), LATE_NIGHT(true), LONG_QUIET(false), FRIENDLY(false) }

    private fun tick(app: Context) {
        val p = app.prefs()

        // feelings fade back to calm on their own
        // she feels things by herself: after a minute without a mood change, her own situation (time, battery,
        // how long it has been since you talked) decides how she feels, instead of going flat "neutral"
        val sinceFeel = System.currentTimeMillis() - EmotionEngine.lastChangeAt
        if (sinceFeel > 60_000 && !VoiceStateManager.isAiSpeaking()) {
            val own = EmotionEngine.selfFeeling(app, System.currentTimeMillis() - lastInteraction)
            if (own != EmotionEngine.current.value) EmotionEngine.set(own)
        }

        if (!p.getBoolean("proactive_enabled", true)) return
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.mode != AudioManager.MODE_NORMAL) return                       // call / ringing
        if (VoiceStateManager.isAiSpeaking()) return

        val now = System.currentTimeMillis()
        val gapMs = p.getInt("proactive_gap_min", 90).coerceIn(15, 720) * 60_000L
        if (now - p.getLong("proactive_last", 0L) < gapMs) return
        val quietMs = now - lastInteraction
        if (quietMs < 20 * 60_000L) return                                    // you are chatting, do not cut in

        val cal = Calendar.getInstance()
        val minutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val dayKey = "proactive_done_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val done = p.getString(dayKey, "").orEmpty().split(',').toSet()

        fun fresh(m: Moment) = m.name !in done
        val moment: Moment? = when {
            minutes in (23 * 60 + 30)..(24 * 60 - 1) && fresh(Moment.LATE_NIGHT) -> Moment.LATE_NIGHT
            minutes in 0..90 && fresh(Moment.LATE_NIGHT) -> Moment.LATE_NIGHT
            minutes in (6 * 60 + 30)..(9 * 60 + 30) && fresh(Moment.MORNING) -> Moment.MORNING
            minutes in (13 * 60)..(14 * 60 + 30) && fresh(Moment.LUNCH) -> Moment.LUNCH
            minutes in (20 * 60)..(21 * 60 + 30) && fresh(Moment.DINNER) -> Moment.DINNER
            minutes in 91..(6 * 60 + 29) -> null                                  // deep night: let the user sleep
            quietMs > 4 * 3_600_000L -> Moment.LONG_QUIET
            quietMs > 60 * 60_000L && Math.random() < 0.35 -> Moment.FRIENDLY
            else -> null
        }
        if (moment == null) return

        val battery = batteryInfo(app)
        val facts = PersistentMemory.contextForAI()
        val recent = ConversationMemory.getContextSummary()
        val purpose = when (moment) {
            Moment.MORNING -> "It is morning. Greet the user warmly, wish a good day, and suggest one good thing (water, a light breakfast, a small plan for today)."
            Moment.LUNCH -> "It is lunch time. Gently ask if they ate, and care for them."
            Moment.DINNER -> "It is dinner time. Ask softly if they had dinner, maybe suggest something light or a short walk later."
            Moment.LATE_NIGHT -> "It is very late and the user is still awake. Care for them like a close friend: ask why they are awake, suggest rest, and offer calming music or to set an alarm."
            Moment.LONG_QUIET -> "You have not talked for hours. Miss them a little, ask how their day is going, and offer one helpful idea."
            Moment.FRIENDLY -> "Start a small friendly moment: a light question about their day, a joke, or one useful suggestion based on what you remember about them."
        }
        val prompt = buildString {
            append("[CHECK-IN] You decided to talk first. Do not call phone_action. ")
            append("Situation: local time ${SimpleDateFormat("EEEE hh:mm a", Locale.ENGLISH).format(Date())}; ")
            append("battery ${battery.first}%${if (battery.second) " (charging)" else ""}; ")
            append("last talked ${quietMs / 60_000} minutes ago. ")
            if (facts.isNotBlank()) append("What you remember about the user: ${facts.replace('\n', ' ').take(600)} ")
            if (recent.isNotBlank()) append("Recent conversation: ${recent.replace('\n', ' ').take(400)} ")
            append("Purpose: $purpose ")
            append("Speak in simple, warm, everyday spoken Bangla (tumi), like a close friend, one or two short sentences, let the feeling show in your voice, call express_emotion with the feeling you really have, and ask at most one question.")
        }

        val line = fallbackLine(moment)
        p.edit().putLong("proactive_last", now)
            .putString(dayKey, (done + moment.name).filter { it.isNotBlank() }.joinToString(","))
            .apply()
        EmotionEngine.set(when (moment) { Moment.LATE_NIGHT -> "worried"; Moment.LONG_QUIET -> "missing"; Moment.MORNING -> "excited"; Moment.FRIENDLY -> "playful"; else -> "happy" })
        Logger.d(TAG, "check-in: $moment")
        Announcer.announce(app, "checkin", line, dedupeMs = 10_000, modelPrompt = prompt, respectEventsSwitch = false)
    }

    private fun batteryInfo(app: Context): Pair<Int, Boolean> {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        return (if (level < 0 || scale <= 0) 0 else level * 100 / scale) to plugged
    }

    /** Offline / no-Gemini wording. Kept warm and a little different each time. */
    private fun fallbackLine(m: Moment): Say = when (m) {
        Moment.MORNING -> pick(
            Say("সুপ্রভাত! আজকের দিনটা দারুণ কাটুক। আগে এক গ্লাস পানি খেয়ে নাও।", "Shuprobhat! Aajker dinta darun katuk. Age ek glass pani kheye nao.", "Good morning! Have a glass of water first."),
            Say("সকাল হয়ে গেছে! ঘুম কেমন হলো?", "Shokal hoye gechhe! Ghum kemon holo?", "It's morning! How did you sleep?")
        )
        Moment.LUNCH -> Say("দুপুর হয়ে গেছে, খেয়েছ তো? না খেয়ে থেকো না।", "Dupur hoye gechhe, kheyecho to? Na kheye theko na.", "It's lunch time, did you eat?")
        Moment.DINNER -> Say("রাতের খাবার খেয়েছ? হালকা কিছু হলেই ভালো।", "Raater khabar kheyecho? Halka kichu holei bhalo.", "Did you have dinner?")
        Moment.LATE_NIGHT -> Say("এত রাত হয়ে গেল, এখনো জেগে? একটু ঘুমিয়ে নাও, আমি চিন্তা করছি।", "Eto raat hoye gelo, ekhono jege? Ektu ghumiye nao, ami chinta korchhi.", "It's so late, still awake? Please rest a little.")
        Moment.LONG_QUIET -> Say("অনেকক্ষণ কথা হয়নি, তোমার দিন কেমন যাচ্ছে?", "Onekkhon kotha hoyni, tomar din kemon jachhe?", "We haven't talked in a while, how is your day going?")
        Moment.FRIENDLY -> Say("কী করছ? চাইলে একটা ভালো গান বাজিয়ে দিই?", "Ki korcho? Chaile ekta bhalo gaan bajiye dii?", "What are you up to? Want me to play a nice song?")
    }

    private fun pick(vararg s: Say): Say = s[(Math.random() * s.size).toInt()]
}
