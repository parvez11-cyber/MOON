package com.myra.assistant.overlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.myra.assistant.R
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import kotlin.math.abs

/**
 * A small round voice on/off button that floats over every screen.
 * Tap = microphone on/off. Drag = move it. It follows the real mic state.
 * Turn it off with the pref "mic_button_enabled" (default on). Needs the "display over other apps" permission.
 */
object MicButtonOverlay {
    private var view: ImageView? = null
    private var wm: WindowManager? = null
    private var receiver: BroadcastReceiver? = null

    fun show(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        if (view != null || !prefs.getBoolean("mic_button_enabled", true) || !Settings.canDrawOverlays(app)) return

        val dp = app.resources.displayMetrics.density
        val size = (46 * dp).toInt()
        val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val iv = ImageView(app).apply {
            setPadding((11 * dp).toInt(), (11 * dp).toInt(), (11 * dp).toInt(), (11 * dp).toInt())
            elevation = 8 * dp
            alpha = 0.92f
            contentDescription = "Voice on/off"
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (10 * dp).toInt()
            y = prefs.getInt("mic_button_y", (140 * dp).toInt())
        }

        var downX = 0f; var downY = 0f; var startY = 0; var startX = 0; var moved = false
        val slop = android.view.ViewConfiguration.get(app).scaledTouchSlop
        iv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX - dx.toInt()      // gravity END: x grows towards the left
                        lp.y = startY + dy.toInt()
                        try { manager.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt("mic_button_y", lp.y).apply()
                    else toggle(app)
                }
            }
            true
        }

        try { manager.addView(iv, lp) } catch (_: Exception) { return }
        view = iv; wm = manager
        refresh(app)

        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refresh(app) }
        }
        val f = IntentFilter("MYRA_MIC_STATE")
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else app.registerReceiver(receiver, f)
    }

    private fun toggle(app: Context) {
        val svc = ForegroundVoiceService.instance
        if (svc == null) {
            try {
                val i = Intent(app, ForegroundVoiceService::class.java)
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i)
            } catch (_: Exception) {}
            return
        }
        svc.setMicEnabled(!svc.isMicEnabled())
        refresh(app)
    }

    fun refresh(app: Context) {
        val iv = view ?: return
        val on = ForegroundVoiceService.instance?.isMicEnabled() == true
        iv.setImageResource(if (on) R.drawable.ic_mic_on else R.drawable.ic_mic_off)
        iv.setColorFilter(Color.WHITE)
        iv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) 0xFF22B573.toInt() else 0xFF5A5F73.toInt())
            setStroke((2 * app.resources.displayMetrics.density).toInt(), 0x55FFFFFF)
        }
    }

    fun hide(context: Context) {
        try { receiver?.let { context.applicationContext.unregisterReceiver(it) } } catch (_: Exception) {}
        receiver = null
        try { view?.let { wm?.removeView(it) } } catch (_: Exception) {}
        view = null
    }
}
