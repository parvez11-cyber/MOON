# MYRA update: ki ki change holo

## 1. SMS (ager bug gulo)
- `system/SmsSender.kt` (notun). Ager code shudhu prothom shobdo ke naam dhorto ("Rahim bhai" -> "Rahim"), SEND_SMS permission check korto na, ar radio response na dekhei "pathiye dilam" bolto.
- Ekhon: naam onekgulo shobdo hote pare, contact ranking (exact > starts-with > contains), shorashori number dewa jay, lomba message multipart hoy, ar sotti pathalo kina seta Maya bole (network nai / airplane mode ityadi).
- Command format: `SMS <naam> | <message>` (voice prompt update kora).

## 2. Display dekha
- Root cause: `accessibility_service_config.xml` e `canTakeScreenshot` chilo na. Add kora hoyeche.
- `screenvision/ScreenReader.kt` (notun), command `READ_SCREEN`: screen-er shob text/button pare + screenshot Gemini-ke pathay (accessibility screenshot, na hole root `screencap`, text na thakle OCR).
- Screen/notification/SMS-er text ke Maya "data" dhore, order hishebe na (prompt injection theke bachar jonno).

## 3. Manusher moto vabna, emotion, nijer theke khoj neya
- `ai/EmotionEngine.kt`: Maya-r feeling (happy, sad, worried, love, sleepy...). Gemini `express_emotion` function diye set kore; na korle kotha theke anday kore.
- `ai/ProactiveCompanion.kt`: nijer theke kotha bole. Sokal, dupur, raat-er khabar, onek raat, onekkhon kotha na hole, majhe majhe friendly suggestion. Call-e / screen off / tumi kotha bolcho / 90 min er moddhe ar na. Offline hole built-in Bangla line.
  Settings keys (SharedPreferences `myra_prefs`): `proactive_enabled` (true), `proactive_gap_min` (90).
- Gemini `remember_fact` function: tomar kotha shune nijei yaad rakhe.
- System prompt notun: manusher moto feeling, ekta ekta kore suggestion, honest.

## 4. Notification: double bole na, off thakle bole na
- `NotificationReaderService.kt`: alada TTS engine soriye `Announcer` diye (shudhu ekta voice).
- Same notification update/repost hole abar pode na (90s dedupe + same text guard), group summary/media/progress/call ignore.
- Screen off thakle pode na (setting `notification_read_screen_off`, default false). "Read notifications" off thakle pode na (`notification_read_aloud`).

## 5. VRM home page-e
- Notun `assets/riya_floating.html` (ager code ei file-ta khujto kintu chilo na, tai avatar kokhono dekha jeto na). `assets/models/riya.vrm` agei chilo.
- Home page-er character ekhon Riya (3D). Kotha bolle mukh nare (lip-sync), shunle ektu jhuke, emotion onujayi chehara bodlay, tap korle hashe, drag korle ghure.
- three.js + three-vrm prothombar jsDelivr (pinned version) theke load hoy, tarpor WebView cache kore. Pura offline chaile `assets/libs/` e rakho:
  `three.module.js`, `addons/` (three/examples/jsm folder), `three-vrm.module.js`.

## 6. System permission + root
- Manifest-e onek permission add (SMS read/receive, calendar, call log write, background location, wifi/bluetooth, all-files, write settings, usage stats, install, alarms...).
- Drawer-e notun button **"Sob permission do"**:
  - Root phone: shob permission, appops, accessibility, notification access, device admin, battery whitelist chupchap deya hoy.
  - Normal phone: runtime permission dialog, tarpor ek ek kore special screen (overlay, accessibility, notification access, write settings, all files, DND, battery, usage access, device admin).
- `system/SystemSettings.kt`: `SYSTEM wifi|bluetooth|mobile_data|airplane|dnd|lock on|off`, `BRIGHTNESS 0-100`. Root thakle shorashori, na hole system panel khule.
- Ekta fixed whitelist; model-ke "je kono shell command" cholanor path deya hoyni, jate screen/notification-er kono text root command hoye jete na pare.

## Je kotha gulo sotti
- **Android e kono APK nijeke root korte pare na.** Root-er jonno phone age rooted hote hobe (Magisk/KernelSU) ar prothombar "su" prompt-e Allow korte hobe. Tarpor app nijei shob grant kore.
- Root chhara, kichu permission shudhu PC theke ekbar adb diye deya jay (WRITE_SECURE_SETTINGS, READ_LOGS, PACKAGE_USAGE_STATS, DUMP):
  ```
  adb shell pm grant com.myra.assistant android.permission.WRITE_SECURE_SETTINGS
  adb shell pm grant com.myra.assistant android.permission.READ_LOGS
  adb shell pm grant com.myra.assistant android.permission.PACKAGE_USAGE_STATS
  adb shell pm grant com.myra.assistant android.permission.DUMP
  ```
  (WRITE_SECURE_SETTINGS dile app nijei Accessibility / notification access on korte pare.)
- SMS/all-files/accessibility-er moto permission Google Play te restricted; ei build nijer phone-e sideload-er jonno.
- Ei code ami compile korte parini (ei environment-e Android SDK/Gradle nai). Android Studio-te Build korle choto-khato import/typo error ashle error-ta pathaw, thik kore dibo.
- Notification "off nile" ta ami dui bhabe dhorechi: screen off hole na pora + setting off hole na pora. Onno kichu bujhiye thakle bolo.

---
# Update 2: Internet search, Voice Lock, App icon
- **Internet search**: Gemini Live setup-e `googleSearch` tool add kora hoyeche (`GeminiWebSocketClient.kt`), system prompt-e bola ache "taja kichu hole age search koro".
- **Voice Lock** (`voice/VoiceLock.kt`, Settings-e notun card): 12 sec kotha bole voice save -> on-device voiceprint (MFCC). Switch on thakle prothom ~1.2 sec audio age check hoy; tomar voice na hole Gemini-ke kichui pathano hoy na (answer/action dui-i bondho). Sensitivity: Soja / Normal / Kora.
  - Limit: eta halka speaker-check, bank-grade na. Tomar recording chalale pass korte pare; khub gondogol-e accuracy komey. Normal-e na chinle "Soja" kore dekho; onno karo voice dhorle "Kora" koro.
- **App icon**: tomar chobi theke `mipmap-*/ic_launcher*.png` + adaptive icon (`drawable-nodpi/myra_icon_fg.png`). Manifest-e `@mipmap/ic_launcher`.
- Ei code compile kora jayni (SDK nai). Android Studio-te Build-er por error ashle pathaw.

---
# Update 3
- **Typed command fix**: chat-e likhle ager version shudhu text reply dito (phone_action tool-i chilo na). Ekhon `GeminiChat.askAgent`: age `LocalCommandRouter` (torch, volume, open app instantly), na hole Gemini function-calling (`phone_action`, `web_search`). Model name 404 dile `gemini-2.5-flash` e fallback.
- **Floating voice button** (`overlay/MicButtonOverlay.kt`): chhoto gol button, tap = mic on/off, drag = soraono. Pref `mic_button_enabled` (default true). Overlay permission lage.
- **Graphics**: home gradient + glow background, 3D avatar-e ACES tone mapping, better lighting, pixel ratio 3.
- **Play Protect**: PLAY_PROTECT.md dekho. 3 ta permission soriyechi, release signing setup add korechi.

---
# Update 4: Notification shudhu bolle
- Auto-reading ekhon default **OFF** (`notification_read_aloud` = false). Settings-e switch ache.
- Notification gulo chupchap mone rakhe (last 30). "Notification ki ashche / notification poro" bolle (ba chat-e likhle) `READ_NOTIFICATIONS` command: last 5 ta (12 ghontar moddhe) pore shonay.
- Maya-r prompt-e bola ache: nijer theke kokhono notification bolbe na.
