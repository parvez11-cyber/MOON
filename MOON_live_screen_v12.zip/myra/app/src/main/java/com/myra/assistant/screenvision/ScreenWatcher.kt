package com.myra.assistant.screenvision

import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.voice.VoiceStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * MOON's "eyes": while the mic toggle is ON, this streams the phone's own screen to Gemini as a
 * live sequence of frames, so she sees whatever is on screen as you talk. The instant the mic
 * goes OFF, this stops -- nothing is captured again until mic is ON.
 *
 * Two sources, tried in this order each tick:
 *  1. Live capture (MediaProjection via ForegroundVoiceService.liveScreenFrame()) -- real continuous
 *     frames, no per-frame screenshot overhead, this is the "live" path. Granted once with a normal
 *     system dialog (ScreenCapturePermissionActivity); after that it just works until the service dies.
 *  2. Fallback: one screenshot per tick (accessibility API or root), used only until live capture has
 *     been granted, or if it stops producing frames for any reason.
 */
object ScreenWatcher {
    private const val TAG = "SCREEN_WATCH"
    // Frames are only a glance at the screen, not a video call: sending them too often slowed every spoken answer.
    private const val LIVE_INTERVAL_MS = 1500L
    private const val FALLBACK_INTERVAL_MS = 3000L
    private const val LIVE_MODE_INTERVAL_MS = 1000L       // 1 frame/second = what Gemini Live actually reads
    private const val LIVE_MODE_MAX_MS = 15 * 60 * 1000L  // switches itself off, to save battery and data
    @Volatile private var lastSig = 0L
    @Volatile private var live = false
    @Volatile private var liveSince = 0L

    @Volatile private var untilMicOff = false   // live mode tied to the mic: no 15 min timeout, stops when the mic stops

    fun setLive(on: Boolean, untilMicOff: Boolean = false) {
        live = on
        this.untilMicOff = on && untilMicOff
        if (on) { liveSince = android.os.SystemClock.elapsedRealtime(); lastSig = 0L }
    }
    fun isLive(): Boolean = live

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (true) {
                var sentLive = false
                try {
                    val svc = ForegroundVoiceService.instance
                    // while she is thinking or speaking, extra frames only delay the answer, so wait
                    if (live && !untilMicOff && android.os.SystemClock.elapsedRealtime() - liveSince > LIVE_MODE_MAX_MS) {
                        live = false
                        Logger.d(TAG, "live mode timed out")
                    }
                    // in live mode she keeps watching even while talking; otherwise extra frames only slow the answer
                    val st = VoiceStateManager.state.value
                    val busy = !live && (st == Constants.STATE_THINKING || st == Constants.STATE_SPEAKING)
                    if (svc != null && svc.isMicEnabled() && svc.isGeminiConnected() && !busy) {
                        val liveFrame = if (svc.hasLiveScreen()) svc.liveScreenFrame() else null
                        if (liveFrame != null) {
                            val sig = signature(liveFrame)
                            if (sig != lastSig) {   // unchanged screen: nothing new to send
                                lastSig = sig
                                svc.sendVideoFrame(toJpeg(liveFrame))
                            }
                            sentLive = true
                        } else {
                            val jpeg = ScreenReader.screenshotJpeg()
                            if (jpeg != null) svc.sendVideoFrame(jpeg)
                        }
                    }
                } catch (e: Exception) {
                    Logger.e(TAG, "frame failed: ${e.message}")
                }
                delay(if (live) LIVE_MODE_INTERVAL_MS else if (sentLive) LIVE_INTERVAL_MS else FALLBACK_INTERVAL_MS)
            }
        }
        Logger.d(TAG, "started")
    }

    fun stop() {
        job?.cancel()
        job = null
        Logger.d(TAG, "stopped")
    }

    /** Cheap fingerprint of the screen (48 sample points), so identical frames are not sent again. */
    private fun signature(b: android.graphics.Bitmap): Long {
        var h = 1125899906842597L
        for (gy in 1..8) for (gx in 1..6) {
            val p = b.getPixel(b.width * gx / 7, b.height * gy / 9)
            h = 31 * h + (((p shr 20) and 0xF) * 256 + ((p shr 12) and 0xF) * 16 + ((p shr 4) and 0xF))
        }
        return h
    }

    private fun toJpeg(bmp: android.graphics.Bitmap): ByteArray {
        val w = if (live) 768 else 640
        val scaled = if (bmp.width > w)
            android.graphics.Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true)
        else bmp
        val out = java.io.ByteArrayOutputStream()
        scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 60, out)
        return out.toByteArray()
    }
}
