package com.myra.assistant.ui.maya

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.lifecycle.Observer
import com.myra.assistant.ai.EmotionEngine
import com.myra.assistant.utils.Constants
import com.myra.assistant.voice.VoiceStateManager
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/** Colour of each feeling. Used by the home screen background, the aura and the mood chip. */
fun emotionTint(e: String): Color = when (e) {
    "happy" -> Color(0xFFFFB84D)
    "excited" -> Color(0xFFFF8A3D)
    "joyful" -> Color(0xFFFFC83D)
    "laughing" -> Color(0xFFFFD54A)
    "playful" -> Color(0xFFFF8FD0)
    "proud" -> Color(0xFFE8B04A)
    "grateful" -> Color(0xFF7FD6A8)
    "shy" -> Color(0xFFFF9DB8)
    "embarrassed" -> Color(0xFFFF8FA3)
    "touched" -> Color(0xFFFF8FB8)
    "love" -> Color(0xFFFF6FA5)
    "missing" -> Color(0xFFE37BC0)
    "curious" -> Color(0xFF4FC3F7)
    "relaxed" -> Color(0xFF52C9A0)
    "surprised" -> Color(0xFF38C7E8)
    "worried" -> Color(0xFF9B7FE6)
    "scared" -> Color(0xFF7B6FD0)
    "sad" -> Color(0xFF6C8CD5)
    "lonely" -> Color(0xFF5E7DBA)
    "hurt" -> Color(0xFF8A6FB8)
    "crying" -> Color(0xFF4A78C8)
    "jealous" -> Color(0xFF7CB342)
    "annoyed" -> Color(0xFFE8833A)
    "angry" -> Color(0xFFE5484D)
    "tired" -> Color(0xFF8A94B8)
    "sleepy" -> Color(0xFF7A84B8)
    else -> Color(0xFF3B8EEA)
}

/** The feeling Maya has right now, as Compose state. */
@Composable
fun rememberEmotion(): State<String> {
    val st = remember { mutableStateOf(EmotionEngine.current.value ?: "neutral") }
    DisposableEffect(Unit) {
        val o = Observer<String> { st.value = it ?: "neutral" }
        EmotionEngine.current.observeForever(o)
        onDispose { EmotionEngine.current.removeObserver(o) }
    }
    return st
}

/** Her feeling's colour, fading smoothly from one to the next. */
@Composable
fun rememberMoodTint(): State<Color> {
    val e by rememberEmotion()
    return animateColorAsState(emotionTint(e), tween(1400), label = "moodTint")
}

private enum class FxStyle { CALM, HEARTS, TEARS, SPARKLE, SLEEPY, ANGRY, SHAKY }

private fun styleOf(e: String) = when (e) {
    "love", "missing", "touched", "grateful", "shy", "embarrassed" -> FxStyle.HEARTS
    "crying", "sad", "lonely", "hurt" -> FxStyle.TEARS
    "happy", "excited", "joyful", "laughing", "playful", "proud" -> FxStyle.SPARKLE
    "sleepy", "tired" -> FxStyle.SLEEPY
    "angry", "jealous", "annoyed" -> FxStyle.ANGRY
    "scared", "worried", "surprised" -> FxStyle.SHAKY
    else -> FxStyle.CALM
}

private fun DrawScope.heart(c: Offset, s: Float, color: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y + s * 0.9f)
        cubicTo(c.x - s * 1.6f, c.y - s * 0.2f, c.x - s * 0.7f, c.y - s * 1.3f, c.x, c.y - s * 0.4f)
        cubicTo(c.x + s * 0.7f, c.y - s * 1.3f, c.x + s * 1.6f, c.y - s * 0.2f, c.x, c.y + s * 0.9f)
        close()
    }
    drawPath(p, color)
}

private fun DrawScope.sparkle(c: Offset, s: Float, color: Color) {
    drawLine(color, Offset(c.x - s, c.y), Offset(c.x + s, c.y), 2.5f)
    drawLine(color, Offset(c.x, c.y - s), Offset(c.x, c.y + s), 2.5f)
    drawLine(color, Offset(c.x - s * 0.6f, c.y - s * 0.6f), Offset(c.x + s * 0.6f, c.y + s * 0.6f), 1.5f)
    drawLine(color, Offset(c.x - s * 0.6f, c.y + s * 0.6f), Offset(c.x + s * 0.6f, c.y - s * 0.6f), 1.5f)
    drawCircle(color.copy(alpha = color.alpha * 0.35f), s * 1.4f, c)
}

/**
 * Living background for the home screen. Its colour, its glow and the little things floating around all follow her
 * feeling: hearts when she loves or misses you, tears when she cries, sparkles when she is happy, slow dreamy bubbles
 * when she is sleepy, a red glow when she is angry, trembling dots when she is scared.
 * One infinite transition drives everything, so it stays smooth and cheap.
 */
@Composable
fun MayaAmbientFx(modifier: Modifier = Modifier.fillMaxSize()) {
    val emotion by rememberEmotion()
    var voice by remember { mutableStateOf(Constants.STATE_IDLE) }
    DisposableEffect(Unit) {
        val v = Observer<String> { voice = it ?: Constants.STATE_IDLE }
        VoiceStateManager.state.observeForever(v)
        onDispose { VoiceStateManager.state.removeObserver(v) }
    }

    val tintState = rememberMoodTint()
    val style = styleOf(emotion)
    val active = voice == Constants.STATE_LISTENING || voice == Constants.STATE_SPEAKING
    val speaking = voice == Constants.STATE_SPEAKING

    val t by rememberInfiniteTransition(label = "fx").animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0f, 1f, infiniteRepeatable(tween(if (speaking) 1100 else 1900, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
    // faster loop for things that fall / shake
    val fast by rememberInfiniteTransition(label = "fast").animateFloat(
        0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), label = "f"
    )

    Canvas(modifier) {
        val tint = tintState.value
        val w = size.width; val h = size.height
        val centre = Offset(w / 2f, h * 0.36f)
        val twoPi = 2f * PI.toFloat()

        // soft colour wash over the whole screen in her feeling's colour
        val wash = when (style) { FxStyle.SLEEPY -> 0.20f; FxStyle.TEARS -> 0.22f; else -> 0.16f }
        drawRect(Brush.verticalGradient(listOf(tint.copy(alpha = wash), Color.Transparent, tint.copy(alpha = wash * 0.8f))))
        if (style == FxStyle.SLEEPY) drawRect(Color(0x22101030))

        // breathing aura
        val breathe = 0.5f + 0.5f * sin(t * twoPi * 3f)
        val r = w * (0.62f + 0.06f * breathe)
        val auraA = if (style == FxStyle.TEARS) 0.22f else 0.30f
        drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = auraA + 0.10f * breathe), Color.Transparent), centre, r), r, centre)

        // angry / jealous / annoyed: pulsing glow from the edges
        if (style == FxStyle.ANGRY) {
            val a = 0.18f + 0.16f * (0.5f + 0.5f * sin(fast * twoPi * 2f))
            val rr = max(w, h) * 0.8f
            drawRect(Brush.radialGradient(listOf(Color.Transparent, tint.copy(alpha = a)), Offset(w / 2f, h / 2f), rr))
        }

        // pulse rings while she listens / speaks
        if (active) {
            for (k in 0..2) {
                val p = (pulse + k / 3f) % 1f
                val rr = w * (0.22f + 0.40f * p)
                drawCircle(tint.copy(alpha = (1f - p) * 0.35f), rr, centre, style = Stroke(width = 3f + 5f * (1f - p)))
            }
        }

        when (style) {
            FxStyle.HEARTS -> for (i in 0 until 14) {
                val seed = i * 0.6180339f
                val phase = (t * 2f + seed) % 1f
                val x = w * ((seed * 5.1f) % 1f) + sin(phase * twoPi + i) * w * 0.04f
                val y = h * (1.05f - phase * 1.15f)
                val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.55f
                heart(Offset(x, y), 7f + (i % 4) * 4f, tint.copy(alpha = a))
            }
            FxStyle.TEARS -> {
                val crying = emotion == "crying"
                val count = if (crying) 26 else 16
                for (i in 0 until count) {
                    val seed = i * 0.6180339f
                    val phase = (fast * (if (crying) 1.6f else 1f) + seed) % 1f
                    val x = w * ((seed * 9.7f) % 1f)
                    val y = h * (-0.05f + phase * 1.1f)
                    val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.55f
                    drawLine(tint.copy(alpha = a * 0.6f), Offset(x, y - 26f), Offset(x, y), 3f)
                    drawCircle(tint.copy(alpha = a), 5f + (i % 3) * 1.5f, Offset(x, y))
                }
                if (crying) {
                    // two slow tear streams from where her eyes are
                    for (side in listOf(-1f, 1f)) {
                        val ex = w / 2f + side * w * 0.07f
                        for (k in 0..2) {
                            val p = (fast + k / 3f) % 1f
                            val ty = h * (0.16f + p * 0.16f)
                            drawCircle(Color(0xFFBFE3FF).copy(alpha = (1f - p) * 0.8f), 5f + 3f * p, Offset(ex, ty))
                        }
                    }
                }
            }
            FxStyle.SPARKLE -> {
                val palette = listOf(Color(0xFFFFD54A), Color(0xFFFF8FD0), Color(0xFF7DE3FF), Color(0xFFFFFFFF), Color(0xFFFFA45C))
                for (i in 0 until 20) {
                    val seed = i * 0.6180339f
                    val tw = abs(sin((t * 6f + seed * 5f) * PI.toFloat()))
                    val x = w * ((seed * 7.3f) % 1f)
                    val y = h * (0.08f + ((seed * 3.7f) % 1f) * 0.8f)
                    sparkle(Offset(x, y), 5f + (i % 3) * 3f, palette[i % palette.size].copy(alpha = 0.15f + 0.6f * tw))
                }
            }
            FxStyle.SLEEPY -> for (i in 0 until 9) {
                val seed = i * 0.6180339f
                val phase = (t + seed) % 1f
                val x = w * ((seed * 6.1f) % 1f) + sin(phase * twoPi) * w * 0.02f
                val y = h * (1.05f - phase * 1.1f)
                val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.25f
                drawCircle(tint.copy(alpha = a), 16f + (i % 3) * 10f, Offset(x, y), style = Stroke(2.5f))
            }
            FxStyle.ANGRY -> for (i in 0 until 14) {
                val seed = i * 0.6180339f
                val phase = (fast * 1.5f + seed) % 1f
                val x = w * ((seed * 8.3f) % 1f) + sin(phase * twoPi * 3f) * 6f
                val y = h * (1.0f - phase * 1.0f)
                drawCircle(tint.copy(alpha = (1f - phase) * 0.6f), 3f + (i % 3), Offset(x, y))
            }
            FxStyle.SHAKY -> for (i in 0 until 18) {
                val seed = i * 0.6180339f
                val phase = (t + seed) % 1f
                val x = w * ((seed * 7.3f) % 1f) + sin(fast * twoPi * 6f + i) * 4f
                val y = h * (1.05f - phase * 1.15f)
                val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.45f
                drawCircle(tint.copy(alpha = a), 2.5f + (i % 4) * 1.5f, Offset(x, y))
            }
            FxStyle.CALM -> Unit
        }

        // the gentle floating light particles that were always there
        if (style == FxStyle.CALM || style == FxStyle.SPARKLE || style == FxStyle.HEARTS) {
            for (i in 0 until 22) {
                val seed = i * 0.6180339f
                val phase = (t + seed) % 1f
                val x = w * ((seed * 7.3f) % 1f) + sin((phase * twoPi) + i) * w * 0.03f
                val y = h * (1.05f - phase * 1.15f)
                val size = 2.5f + (i % 4) * 1.8f
                val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.45f
                drawCircle(tint.copy(alpha = a), size, Offset(x, y))
                drawCircle(tint.copy(alpha = a * 0.25f), size * 3f, Offset(x, y))
            }
        }
    }
}
