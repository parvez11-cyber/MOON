package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.system.PrivacyMode
import com.myra.assistant.utils.Constants
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Reads how the USER seems to feel from what they say or type (Bangla, Banglish, Hindi, English), on the phone, with a
 * small keyword + negation + intensity model. It is a rough guess, not a diagnosis, and it can be wrong.
 *  - Only the label and a score are saved (never the text), the last 300 readings, and nothing while Privacy mode is on.
 *  - Maya uses it to care first when you seem low or stressed (a hint in her prompt and a softer mood on her face).
 */
object UserSentiment {
    enum class Mood(val bn: String, val emoji: String, val valence: Float) {
        HAPPY("khushi", "😊", 1f), CALM("shanto", "🙂", 0.3f), NEUTRAL("normal", "😐", 0f),
        TIRED("klanto", "😴", -0.4f), STRESSED("chinta / chap", "😟", -0.7f), SAD("mon kharap", "😔", -0.8f),
        LONELY("eka", "🥺", -0.8f), ANGRY("rag", "😠", -0.9f)
    }

    data class Reading(val mood: Mood, val score: Float, val strength: Float)

    private val WORDS: Map<Mood, List<String>> = mapOf(
        Mood.HAPPY to listOf("happy", "khushi", "khushi", "mojar", "moja", "darun", "awesome", "great", "love it", "excited", "yay", "haha", "hehe", "😊", "😄", "🥳",
            "খুশি", "আনন্দ", "দারুণ", "মজা", "ভালো লাগছে", "valo lagche", "bhalo lagche", "bhalo lagche", "बहुत अच्छा", "खुश"),
        Mood.CALM to listOf("calm", "relaxed", "peaceful", "shanto", "শান্ত", "নিশ্চিন্ত", "thik ache", "ঠিক আছে", "sob thik"),
        Mood.SAD to listOf("sad", "cry", "crying", "depressed", "mon kharap", "mone kharap", "kharap lagche", "kosto", "koshto", "hurt", "heartbroken", "😢", "😭", "💔",
            "মন খারাপ", "কষ্ট", "কান্না", "দুঃখ", "ভালো লাগছে না", "उदास", "दुख"),
        Mood.STRESSED to listOf("stress", "stressed", "tension", "tensed", "anxious", "anxiety", "worried", "panic", "overwhelmed", "chinta", "deadline", "pressure", "😰", "😟",
            "টেনশন", "চিন্তা", "দুশ্চিন্তা", "ভয় পাচ্ছি", "চাপ", "ghabrahat", "tanaav"),
        Mood.ANGRY to listOf("angry", "furious", "hate", "annoyed", "irritated", "pissed", "rag lagche", "raag", "বিরক্ত", "রাগ", "রেগে", "😠", "😡", "gussa", "ghussa"),
        Mood.TIRED to listOf("tired", "exhausted", "sleepy", "burnt out", "burnout", "klanto", "ghum pacche", "ghum pache", "ক্লান্ত", "ঘুম পাচ্ছে", "थक", "😴"),
        Mood.LONELY to listOf("lonely", "alone", "nobody", "no one cares", "eka lagche", "ekla", "একা", "একাকী", "কেউ নেই", "akela", "😔")
    )
    private val BOOST = listOf("very", "so ", "really", "extremely", "khub", "onek", "ekdom", "bohut", "অনেক", "খুব", "এত", "!!", "😭")
    private val NEG = setOf("not", "no", "na", "nai", "nei", "never", "না", "নাই", "নেই", "নয়", "nahi", "नहीं")
    private val POS_WORDS = listOf("good", "fine", "ok", "okay", "happy", "bhalo", "valo", "ভালো", "khushi", "খুশি", "thik", "ঠিক")

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()

    /** One reading for a piece of text, or null when no emotion is visible in it. */
    fun analyze(text: String): Reading? {
        val t = norm(text)
        if (t.length < 3) return null
        val hits = HashMap<Mood, Float>()
        for ((m, words) in WORDS) {
            var n = 0f
            for (w in words) if (t.contains(w)) n += 1f
            if (n > 0) hits[m] = n
        }
        // "bhalo na", "not good", "valo nai": a positive word followed by a negation means the opposite
        val tokens = t.split(' ')
        for (i in tokens.indices) {
            if (POS_WORDS.any { tokens[i].startsWith(it) }) {
                val next = tokens.drop(i + 1).take(2)
                if (next.any { it in NEG }) {
                    hits.remove(Mood.HAPPY); hits.remove(Mood.CALM)
                    hits[Mood.SAD] = (hits[Mood.SAD] ?: 0f) + 1.5f
                }
            }
        }
        // "not sad" / "sad na": a negated negative word is dropped
        for (i in tokens.indices) {
            val next = tokens.getOrNull(i + 1)
            if (next != null && next in NEG && i > 0 && WORDS[Mood.SAD]!!.any { tokens[i] == it }) hits.remove(Mood.SAD)
        }
        if (hits.isEmpty()) return null
        val best = hits.maxByOrNull { it.value }!!.key
        val boost = if (BOOST.any { t.contains(it) }) 1.35f else 1f
        val strength = (0.5f + 0.2f * (hits.values.sum()) ).coerceAtMost(1f) * boost
        val total = hits.values.sum()
        val score = (hits.entries.sumOf { (it.key.valence * it.value).toDouble() } / total).toFloat() * boost.coerceAtMost(1.2f)
        return Reading(best, score.coerceIn(-1f, 1f), strength.coerceAtMost(1f))
    }

    private const val K = "sentiment_log"          // [ {t, m, s} ]
    @Volatile private var lastText = ""
    @Volatile private var lastAt = 0L

    /** Analyse and keep the reading (label + score only). Returns it so the caller can react. */
    fun record(c: Context, text: String): Reading? {
        if (PrivacyMode.isOn(c)) return null
        val now = System.currentTimeMillis()
        val norm = norm(text)
        if (norm == lastText && now - lastAt < 60_000) return null      // the same sentence heard twice
        lastText = norm; lastAt = now
        val r = analyze(text) ?: return null
        try {
            val p = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            val a = JSONArray(p.getString(K, "[]") ?: "[]")
            a.put(JSONObject().put("t", now).put("m", r.mood.name).put("s", r.score.toDouble()))
            val keep = JSONArray()
            for (i in maxOf(0, a.length() - 300) until a.length()) keep.put(a.get(i))
            p.edit().putString(K, keep.toString()).apply()
        } catch (_: Exception) {}
        return r
    }

    private fun log(c: Context): List<Triple<Long, Mood, Float>> = try {
        val a = JSONArray(c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getString(K, "[]") ?: "[]")
        (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            val m = runCatching { Mood.valueOf(o.getString("m")) }.getOrNull() ?: return@mapNotNull null
            Triple(o.getLong("t"), m, o.getDouble("s").toFloat())
        }
    } catch (_: Exception) { emptyList() }

    /** Average score for each of the last [days] days (null = nothing read that day), oldest first. */
    fun trend(c: Context, days: Int = 7): List<Pair<String, Float?>> {
        val fmtDay = SimpleDateFormat("yyyyMMdd", Locale.US)
        val fmtName = SimpleDateFormat("EEE", Locale.ENGLISH)
        val all = log(c).groupBy { fmtDay.format(Date(it.first)) }
        return (days - 1 downTo 0).map { back ->
            val d = Date(System.currentTimeMillis() - back * 86_400_000L)
            val rows = all[fmtDay.format(d)]
            fmtName.format(d) to rows?.map { it.third }?.average()?.toFloat()
        }
    }

    /** The most common mood over the last [hours] hours with how many readings it rests on, or null. */
    fun recentMood(c: Context, hours: Int = 6): Pair<Mood, Int>? {
        val from = System.currentTimeMillis() - hours * 3_600_000L
        val rows = log(c).filter { it.first >= from }
        if (rows.isEmpty()) return null
        val top = rows.groupBy { it.second }.maxByOrNull { it.value.size } ?: return null
        return top.key to rows.size
    }

    /** A line for Maya's prompt when the user has seemed low or stressed lately. Empty otherwise. */
    fun hint(c: Context): String {
        if (PrivacyMode.isOn(c)) return ""
        val rows = log(c).filter { it.first >= System.currentTimeMillis() - 6 * 3_600_000L }
        if (rows.size < 2) return ""
        val avg = rows.map { it.third }.average()
        if (avg > -0.35) return ""
        val mood = rows.groupBy { it.second }.maxByOrNull { it.value.size }!!.key
        return "\n[Note: over the last hours the user has seemed ${mood.bn} (a rough guess from their words, it may be wrong). " +
            "Gently check in, care before helping, do not diagnose, and do not mention that you analysed their words.]"
    }

    fun clear(c: Context) { c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).edit().remove(K).apply() }

    /** Which Maya feeling to show when the user just sounded low. Null = leave her feeling alone. */
    fun reactionFor(r: Reading?): String? = when (r?.mood) {
        Mood.SAD, Mood.LONELY -> "sad"
        Mood.STRESSED -> "worried"
        Mood.ANGRY -> "worried"
        Mood.TIRED -> "sleepy"
        Mood.HAPPY -> "happy"
        else -> null
    }
}
