package com.myra.assistant.voice

import com.myra.assistant.utils.Logger
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Voice activity detection. Same constructor and methods as before, so nothing that uses it changes.
 *
 * Old version: one rule, "louder than a threshold". A door slam, a fan gust or a hum could start a turn.
 * Now each 32 ms chunk is judged on three things:
 *  1. energy above a noise-adaptive threshold (as before; the room level is learned while nobody talks),
 *  2. zero-crossing rate in the speech range. Low rumble / thumps (almost no crossings) and hiss / clicks
 *     (very many) are not speech. A very loud chunk is accepted anyway so plosives are not lost,
 *  3. hysteresis: starting needs [speechFrames] speech-like chunks in a row, ending waits for a hangover that
 *     is longer after a long sentence (people pause mid-sentence) and shorter after a short command.
 * Limit: it separates speech-like sound from non-speech noise, not your voice from someone else's
 * (that is Voice Lock / Voice isolation) and not speech from other speech (TV, a crowd).
 */
class VoiceActivityDetector(
    private val onSpeechStart: () -> Unit,
    private val onSpeechEnd: () -> Unit,
    /** 0 = low (noisy place), 1 = normal, 2 = high (quiet room / soft voice). Read on every chunk, so a change applies at once. */
    private val sensitivity: () -> Int = { 1 }
) {
    private var noiseFloor = 0.004f
    private val speechThreshold: Float get() {
        val scale = when (sensitivity()) { 0 -> 1.4f; 2 -> 0.75f; else -> 1f }
        return (noiseFloor * 3f).coerceIn(0.012f, 0.04f) * scale
    }
    private val minSilenceFrames = 8         // ~256 ms: short command (this is the delay before she starts to answer)
    private val maxSilenceFrames = 22        // ~700 ms: after a long sentence, allow thinking pauses
    private val speechFrames = 2
    private var silenceCount = 0
    private var speechCount = 0
    private var activeFrames = 0
    @Volatile private var speechActive = false

    private fun zeroCrossingRate(pcm: ByteArray): Float {
        var n = 0; var z = 0; var prev = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
            if (abs(s) > 40) {                       // ignore the dither around zero
                val sign = if (s > 0) 1 else -1
                if (prev != 0 && sign != prev) z++
                prev = sign; n++
            }
            i += 2
        }
        return if (n < 20) 0f else z.toFloat() / n
    }

    private fun rms(pcm: ByteArray): Float {
        var sum = 0.0; var n = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
            sum += s.toDouble() * s; n++; i += 2
        }
        return if (n == 0) 0f else sqrt(sum / n).toFloat() / 32768f
    }

    fun processChunk(pcm: ByteArray) {
        val rms = rms(pcm)
        VoiceStateManager.updateAmplitude(rms)
        if (!speechActive && rms < speechThreshold * 1.5f) noiseFloor = noiseFloor * 0.98f + rms * 0.02f

        val zcr = zeroCrossingRate(pcm)
        val speechLike = zcr in 0.02f..0.38f
        val loud = rms > speechThreshold * 3f
        val voiced = rms > speechThreshold && (speechLike || loud)

        if (voiced) {
            silenceCount = 0
            speechCount++
            if (speechActive) activeFrames++
            if (!speechActive && speechCount >= speechFrames) {
                speechActive = true
                activeFrames = speechCount
                Logger.d("VAD", "Speech start rms=$rms zcr=$zcr")
                onSpeechStart()
            }
        } else {
            speechCount = 0
            if (speechActive) {
                silenceCount++
                // 1 s of speech or less -> short hangover; 3 s or more -> long one
                val t = ((activeFrames - 30) / 60f).coerceIn(0f, 1f)
                val limit = (minSilenceFrames + (maxSilenceFrames - minSilenceFrames) * t).toInt()
                if (silenceCount >= limit) {
                    speechActive = false
                    silenceCount = 0
                    activeFrames = 0
                    Logger.d("VAD", "Speech end")
                    onSpeechEnd()
                }
            }
        }
    }

    fun isSpeechActive(): Boolean = speechActive

    fun reset() {
        silenceCount = 0
        speechCount = 0
        activeFrames = 0
        speechActive = false
    }
}
