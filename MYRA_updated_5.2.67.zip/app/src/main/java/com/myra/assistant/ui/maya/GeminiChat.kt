package com.myra.assistant.ui.maya

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Text / vision chat against Gemini REST. Key is sent in a header, never in the URL. */
object GeminiChat {
    const val MODEL = com.myra.assistant.utils.Constants.GEMINI_CHAT_MODEL
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()

    suspend fun testKey(key: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("$BASE/models?pageSize=1")
                .header("x-goog-api-key", key.trim()).build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    suspend fun ask(
        key: String,
        history: List<Pair<Boolean, String>>, // (fromUser, text)
        userText: String,
        imageB64: String? = null,
        mime: String = "image/jpeg",
        system: String = "You are Maya, a warm, helpful Hinglish-speaking AI assistant. Keep replies short and friendly."
    ): String = withContext(Dispatchers.IO) {
        try {
            val contents = JSONArray()
            history.takeLast(20).forEach { (u, t) ->
                contents.put(JSONObject().put("role", if (u) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            val parts = JSONArray().put(JSONObject().put("text", userText))
            if (imageB64 != null) parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", mime).put("data", imageB64)))
            contents.put(JSONObject().put("role", "user").put("parts", parts))
            val body = JSONObject().put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", system))))
            val req = Request.Builder().url("$BASE/models/$MODEL:generateContent")
                .header("x-goog-api-key", key.trim())
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@withContext "Error ${r.code}: " +
                    (runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("request failed"))
                JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
        } catch (e: Exception) { "Network error: ${e.message}" }
    }

    /** Pulls short, durable facts about the user out of text / a document (resume etc.). */
    suspend fun extractFacts(key: String, text: String, b64: String? = null, mime: String = "application/pdf"): List<String> {
        val r = ask(key, emptyList(),
            "Extract up to 12 short durable facts about the user from the content below (name, work, skills, preferences, family, goals). " +
                "Return ONLY one fact per line, no numbering, no extra words. If there is nothing useful, return nothing.\n\n$text",
            b64, mime, "You extract user facts. Output plain lines only.")
        if (r.startsWith("Error") || r.startsWith("Network")) return emptyList()
        return r.lines().map { it.trim().trimStart('-', '•', '*', ' ') }.filter { it.length in 4..200 }.take(12)
    }
}
