package com.myra.assistant.services

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ai.AIResponseManager
import com.myra.assistant.ai.ConversationMemory
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.ai.IntentAnalyzer
import com.myra.assistant.ai.DynamicDecisionEngine
import com.myra.assistant.apps.InstalledAppsManager
import com.myra.assistant.overlay.EdgeGlowController
import com.myra.assistant.voice.LocalCommandRouter
import com.myra.assistant.voice.LocalSpeaker
import com.myra.assistant.voice.OfflineVoice
import com.myra.assistant.voice.PhoneEventMonitor
import com.myra.assistant.voice.Say
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import kotlinx.coroutines.Job
import org.json.JSONObject
import com.myra.assistant.notification.NotificationReaderService
import com.myra.assistant.ui.maya.MayaActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceActivityDetector
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.ArrayDeque

class ForegroundVoiceService : Service() {

    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private val preRoll = ArrayDeque<ByteArray>()
    private val silenceTail = ByteArray(1024)

    private lateinit var audioRecorder: AudioRecorder
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var vad: VoiceActivityDetector
    private lateinit var audioFocus: AudioFocusManager

    private var geminiClient: GeminiWebSocketClient? = null
    private var offlineVoice: OfflineVoice? = null

    // fast command path
    private val transcript = StringBuilder()
    private val doneKeys = HashSet<String>()
    private var routeJob: Job? = null
    @Volatile private var thinkingSince = 0L
    @Volatile private var reconnectPending = false
    @Volatile private var retryDelay = 1800L

    @Volatile
    private var micEnabled = false

    companion object {
        var instance: ForegroundVoiceService? = null
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()

        instance = this
        isRunning = true

        PersistentMemory.init(this)

        try {
            androidx.core.app.ServiceCompat.startForeground(
                this,
                Constants.NOTIF_ID_VOICE,
                buildNotification(),
                if (Build.VERSION.SDK_INT >= 30)
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                else 0
            )
        } catch (e: Exception) {
            // Android 14+ blocks mic FGS when started from background / without RECORD_AUDIO
            Logger.e("ForegroundVoiceService", "cannot start foreground", e)
            stopSelf()
            return
        }

        scope.launch {
            RootAccess.request(this@ForegroundVoiceService)
        }

        initComponents()

        // phone events (charger, battery, wifi...) and the screen-edge light live as long as this service
        PhoneEventMonitor.start(this)
        EdgeGlowController.start(this)
        // load the app list now so "open <app>" is instant the first time
        scope.launch { try { InstalledAppsManager.getAllApps(this@ForegroundVoiceService) } catch (_: Exception) {} }
    }

    private fun initComponents() {

        audioFocus = AudioFocusManager(this)

        audioPlayer = AudioPlayer()

        // The recorder keeps running while Maya talks (chunks are simply dropped), so there is no
        // microphone restart delay when she finishes.
        audioPlayer.onPlaybackStarted = {
            VoiceStateManager.setSpeaking()
        }

        audioPlayer.onPlaybackFinished = {
            scope.launch {
                delay(150)   // let the speaker tail die out so she does not hear herself
                if (!audioPlayer.isPlaying()) {
                    if (micEnabled) {
                        vad.reset()
                        preRoll.clear()
                        VoiceStateManager.setListening()
                    } else {
                        VoiceStateManager.setIdle()
                    }
                }
            }
        }

        vad = VoiceActivityDetector(

            onSpeechStart = {
                synchronized(doneKeys) { doneKeys.clear() }
                synchronized(transcript) { transcript.setLength(0) }
                geminiClient?.sendActivityStart()

                VoiceStateManager.setListening()

                preRoll.forEach {
                    geminiClient?.sendAudioChunk(it)
                }

                preRoll.clear()
            },

            onSpeechEnd = {
                repeat(2) {
                    geminiClient?.sendAudioChunk(silenceTail)
                }

                // tell Gemini we are done: it answers now instead of waiting for its own silence timer
                geminiClient?.sendActivityEnd()

                thinkingSince = SystemClock.elapsedRealtime()
                VoiceStateManager.setThinking()
                scheduleLocalRoute()
            }
        )

        audioRecorder = AudioRecorder(this) { chunk ->

            if (micEnabled && !VoiceStateManager.isAiSpeaking()) {

                if (preRoll.size >= 4) {
                    preRoll.removeFirst()
                }

                preRoll.addLast(chunk.copyOf())

                vad.processChunk(chunk)

                if (vad.isSpeechActive()) {
                    geminiClient?.sendAudioChunk(chunk)
                }
            }
        }

        val apiKey =
            prefs().getString(Constants.KEY_API_KEY, "") ?: ""

        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun connectGemini(apiKey: String) {

        geminiClient?.disconnect()

        geminiClient = GeminiWebSocketClient(

            apiKey = apiKey,

            systemPrompt = buildSystemPrompt(),

            onConnected = {
                retryDelay = 1800L
                reconnectPending = false
                // internet is back: hand the microphone back from the offline listener to Gemini
                offlineVoice?.stop()

                if (micEnabled) {
                    VoiceStateManager.setListening()
                    audioRecorder.start()
                } else {
                    VoiceStateManager.setIdle()
                }
            },

            onAudioReceived = { data ->
                audioPlayer.playChunk(data)
            },

            onTextReceived = { text ->

                val clean = AIResponseManager.clean(text)

                if (clean.isNotBlank()) {

                    ConversationMemory.addAssistant(clean)

                    // fallback only: normally commands come as a phone_action function call
                    val cmd = AIResponseManager.extractCommand(clean)

                    if (cmd != null && markExecuted(cmd)) {
                        scope.launch {
                            val result = runCommand(cmd)
                            sendBroadcast(Intent("MYRA_COMMAND_RESULT").putExtra("text", result))
                        }
                    }

                    sendBroadcast(Intent("MYRA_RESPONSE").putExtra("text", clean))
                }
            },

            onTurnComplete = {
                if (micEnabled && !audioPlayer.isPlaying()) {
                    if (!audioRecorder.isActive() && offlineVoice?.active != true) {
                        audioRecorder.start()
                    }
                    VoiceStateManager.setListening()
                }
            },

            onError = { msg ->

                Logger.e(TAG, "Gemini error: $msg")

                if (micEnabled && !isOnline()) {
                    // no internet: keep phone control alive with the on-device listener
                    goOffline()
                } else {
                    VoiceStateManager.setError("Reconnecting…")
                }

                scheduleReconnect()
            },

            onInputTranscript = { chunk ->
                synchronized(transcript) { transcript.append(chunk) }
                scheduleLocalRoute()
            },

            onToolCall = { id, name, args -> handleToolCall(id, name, args) },

            onInterrupted = { audioPlayer.clearAndStop() }
        )

        geminiClient?.connect()
    }

    private fun scheduleReconnect() {
        if (reconnectPending) return
        reconnectPending = true
        scope.launch {
            delay(retryDelay)
            retryDelay = minOf(retryDelay * 2, 8000L)
            reconnectPending = false
            if (geminiClient?.isConnected() != true) {
                val key = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
                if (key.isNotEmpty()) connectGemini(key)
            }
        }
    }

    // ------------------------------------------------------------------ fast command path

    /** True the first time this action is seen in the current spoken turn. Stops double execution. */
    private fun markExecuted(cmd: String): Boolean =
        synchronized(doneKeys) { doneKeys.add(LocalCommandRouter.keyOf(cmd)) }

    private suspend fun runCommand(cmd: String): String {
        val intent = IntentAnalyzer.analyze(cmd)
        return DynamicDecisionEngine.execute(this, intent)
    }

    /**
     * Gemini's own transcript of what the user said arrives while it is still thinking. If it is a
     * plain phone command (torch, volume, home, open an app) we run it right now. When Gemini then
     * asks for the same thing, it is answered "already done", so it happens once.
     */
    private fun scheduleLocalRoute() {
        routeJob?.cancel()
        routeJob = scope.launch {
            delay(120)
            if (vad.isSpeechActive()) return@launch
            val text = synchronized(transcript) { transcript.toString() }.trim()
            if (text.isEmpty()) return@launch
            val cmd = LocalCommandRouter.match(this@ForegroundVoiceService, text) ?: return@launch
            if (!markExecuted(cmd)) return@launch
            Logger.d(TAG, "fast path: $cmd")
            runCommand(cmd)
        }
    }

    private fun handleToolCall(id: String, name: String, args: JSONObject) {
        scope.launch {
            val result = if (name == "phone_action") {
                val cmd = args.optString("command").trim()
                when {
                    cmd.isEmpty() -> "no command given"
                    !markExecuted(cmd) -> "already done"
                    else -> runCommand(cmd).ifBlank { "done" }
                }
            } else "unknown function"
            geminiClient?.sendToolResponse(id, name, result)
        }
    }

    /** Used for phone events: Maya says it in her own voice. False means "not possible, use the on-device voice". */
    fun askModelToSay(text: String): Boolean {
        val c = geminiClient ?: return false
        if (!c.isConnected()) return false
        c.sendTextTurn(
            "[PHONE EVENT - just tell the user, do not call any function] $text " +
                    "Say it in one short natural sentence in Bangla."
        )
        return true
    }

    fun sendVideoFrame(jpeg: ByteArray) {
        geminiClient?.sendVideoFrame(jpeg)
    }

    fun isGeminiConnected(): Boolean = geminiClient?.isConnected() == true

    // ------------------------------------------------------------------ offline mode

    private fun isOnline(): Boolean {
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) { false }
    }

    private fun goOffline() {
        if (!micEnabled) return
        if (offlineVoice?.active == true) return
        audioRecorder.stop()
        vad.reset()
        preRoll.clear()
        if (offlineVoice == null) offlineVoice = OfflineVoice(this) { text -> onOfflineText(text) }
        VoiceStateManager.setListening()
        offlineVoice?.start()
    }

    private fun onOfflineText(text: String) {
        // ignore what the speaker just said (otherwise "volume badha diya" would trigger itself)
        if (LocalSpeaker.busy || SystemClock.elapsedRealtime() - LocalSpeaker.lastEndAt < 1500) return
        scope.launch {
            val cmd = LocalCommandRouter.match(this@ForegroundVoiceService, text)
            if (cmd != null) {
                val reply = runCommand(cmd)
                LocalSpeaker.speak(this@ForegroundVoiceService, Say(reply.ifBlank { "ঠিক আছে।" }, "Ho gaya.", "Done"))
            } else if (Regex("maya|myra|মায়া|মাইরা", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
                LocalSpeaker.speak(this@ForegroundVoiceService, Say(
                    "ইন্টারনেট নেই, তাই এখন শুধু ফোনের সাধারণ কাজ করতে পারি।",
                    "Internet nahi hai, abhi sirf phone ke simple kaam kar sakti hoon.", ""))
            }
        }
    }

    fun setMicEnabled(enabled: Boolean) {

        micEnabled = enabled

        prefs()
            .edit()
            .putBoolean(
                "mic_enabled",
                enabled
            )
            .apply()

        if (enabled) {

            VoiceStateManager.setListening()

            if (geminiClient?.isConnected() == true) {
                offlineVoice?.stop()
                audioRecorder.start()
            } else if (!isOnline()) {
                goOffline()
            } else {
                reconnectGemini()
            }

        } else {

            offlineVoice?.stop()

            audioRecorder.stop()

            vad.reset()

            preRoll.clear()

            VoiceStateManager.setIdle()
        }

        sendBroadcast(
            Intent("MYRA_MIC_STATE")
                .putExtra(
                    "enabled",
                    enabled
                )
        )
    }

    fun isMicEnabled(): Boolean {
        return micEnabled
    }

    /*
     * Image message
     *
     * GeminiWebSocketClient-এর মধ্যে sendImageMessage()
     * function না থাকায় এখানে image-এর caption/text পাঠানো হচ্ছে।
     *
     * এতে build error হবে না।
     */
    fun sendImageToGemini(
        text: String,
        imageBytes: ByteArray,
        mimeType: String
    ) {

        if (
            geminiClient?.isConnected() != true
        ) {

            reconnectGemini()
            return
        }

        val message =
            if (text.isBlank()) {
                "[Image attached]"
            } else {
                text
            }

        ConversationMemory.addUser(message)

        VoiceStateManager.setThinking()

        geminiClient?.sendTextTurn(message)
    }

    fun sendTextToGemini(text: String) {

        if (
            geminiClient?.isConnected() != true
        ) {

            reconnectGemini()
            return
        }

        ConversationMemory.addUser(text)

        VoiceStateManager.setThinking()

        geminiClient?.sendTextTurn(text)
    }

    fun replyToLatestNotification(
        message: String
    ): Boolean {

        return NotificationReaderService
            .instance
            ?.replyToLatest(message) == true
    }

    fun replyToNotification(
        target: String?,
        message: String
    ): Boolean {

        return NotificationReaderService
            .instance
            ?.replyTo(
                target,
                message
            ) == true
    }

    fun reconnectGemini() {

        val apiKey =
            prefs().getString(
                Constants.KEY_API_KEY,
                ""
            ) ?: ""

        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun buildSystemPrompt(): String {

        val userName =
            prefs().getString(
                Constants.KEY_USER_NAME,
                "Boss"
            ) ?: "Boss"

        val personality =
            prefs().getString(
                Constants.KEY_PERSONALITY,
                "friendly"
            ) ?: "friendly"

        return """
YOU ARE MYRA - My Yours Responsive Assistant.
User's name is $userName.
Personality: $personality.
Custom memory saved on this device:
${PersistentMemory.contextForAI()}

STRICT RULES:

- Never explain or think aloud. Keep every spoken reply to one or two short sentences.

- For ANY action on the phone (open an app, call, message, play something, torch, volume,
  home/back/recents, notifications, SMS, replying to a notification) call the function
  phone_action immediately. NEVER say a command name out loud and never read it out.
  The command values are:
  OPEN_APP <name> | CALL <name> | WHATSAPP_CALL <name> | WHATSAPP_MSG <name> <message> |
  YOUTUBE_PLAY <query> | SPOTIFY_PLAY <query> | FLASHLIGHT_ON | FLASHLIGHT_OFF |
  VOLUME_UP | VOLUME_DOWN | HOME | BACK | RECENTS | NOTIFICATIONS | SMS <name> <message> |
  REPLY_NOTIFICATION <message> | REPLY_NOTIFICATION_TO <app-or-name> <message>

- After phone_action returns, confirm in at most four words in Bangla (for example "ঠিক আছে"). If
  the result says "already done", still just confirm briefly. Do not repeat the action.

- Messages that start with [PHONE EVENT] are notes from the phone itself (charger, battery,
  wifi...). Say them to the user in one short natural sentence. Do not call any function for them.

- If camera frames are being streamed you can see what the user is pointing the phone at.

- For conversation: reply short, natural, and primarily in Bangla (বাংলা).

- Understand Bangla, Banglish, Hindi and English commands.

- Address user as $userName.

- Be warm, concise, witty, and human-like.

- Do not claim to be offline unless the service is actually stopped.

        """.trimIndent()
    }

    private fun buildNotification(): Notification {

        createChannel()

        val pi =
            PendingIntent.getActivity(
                this,
                0,
                Intent(
                    this,
                    MayaActivity::class.java
                ),
                PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
            )

        return NotificationCompat.Builder(
            this,
            Constants.NOTIF_CHANNEL_VOICE
        )
            .setContentTitle(
                "MYRA AI • Online"
            )
            .setContentText(
                "Maya is ready."
            )
            .setSmallIcon(
                R.drawable.ic_myra_notif
            )
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(
                NotificationCompat.PRIORITY_LOW
            )
            .build()
    }

    private fun createChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val ch =
                NotificationChannel(
                    Constants.NOTIF_CHANNEL_VOICE,
                    "MYRA Voice Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    setShowBadge(false)
                }

            getSystemService(
                NotificationManager::class.java
            ).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            Constants.ACTION_START_LISTENING ->
                setMicEnabled(true)

            Constants.ACTION_STOP_LISTENING ->
                setMicEnabled(false)
        }

        return START_STICKY
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    override fun onDestroy() {

        isRunning = false

        instance = null

        micEnabled = false

        if (::audioRecorder.isInitialized) {
            audioRecorder.stop()
        }

        if (::audioPlayer.isInitialized) {
            audioPlayer.release()
        }

        offlineVoice?.stop()

        EdgeGlowController.stop()

        geminiClient?.disconnect()

        job.cancel()

        super.onDestroy()
    }
}
