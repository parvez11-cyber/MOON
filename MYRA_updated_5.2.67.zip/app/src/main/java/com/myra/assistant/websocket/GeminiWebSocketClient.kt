package com.myra.assistant.websocket

import android.util.Base64
import android.util.Log
import com.myra.assistant.utils.Constants
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini Live websocket.
 *
 * Speed / correctness notes:
 *  - Device actions arrive as a real function call (phone_action) instead of text the model would
 *    have to speak aloud. Audio-only models never produced the text path, which caused both the
 *    lag and the "command read out loud" double voice.
 *  - Turn detection is driven by our own VAD (activityStart / activityEnd), so the server does not
 *    wait for its own silence timeout before it starts answering.
 *  - Input transcription is enabled so the app can run obvious commands locally, before the model
 *    has even replied.
 */
class GeminiWebSocketClient(
    private val apiKey: String,
    private val systemPrompt: String,
    private val onConnected: () -> Unit,
    private val onAudioReceived: (ByteArray) -> Unit,
    private val onTextReceived: (String) -> Unit,
    private val onTurnComplete: () -> Unit,
    private val onError: (String) -> Unit,
    private val onInputTranscript: (String) -> Unit = {},
    private val onToolCall: (id: String, name: String, args: JSONObject) -> Unit = { _, _, _ -> },
    private val onInterrupted: () -> Unit = {}
) {
    private val TAG = "GEMINI_WS"
    private var webSocket: WebSocket? = null
    @Volatile private var isSetupComplete = false
    @Volatile private var manualClose = false

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(12, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val url = "${Constants.GEMINI_WS_BASE}?key=$apiKey"

    fun connect() {
        isSetupComplete = false
        manualClose = false
        val request = Request.Builder()
            .url(url)
            .addHeader("Origin", "https://generativelanguage.googleapis.com")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "Connected")
                sendSetup(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleResponse(text)
            }

            override fun onMessage(ws: WebSocket, bytes: ByteString) {
                try { handleResponse(bytes.utf8()) } catch (e: Exception) { Log.e(TAG, "Binary parse error") }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isSetupComplete = false
                Log.e(TAG, "WS Failure: ${t.message}")
                if (!manualClose) onError("Connection failed: ${t.message}")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                val wasReady = isSetupComplete
                isSetupComplete = false
                Log.d(TAG, "WS Closed: $code $reason")
                if (!manualClose && wasReady) onError("Connection closed: $reason")
            }
        })
    }

    private fun sendSetup(ws: WebSocket) {
        val phoneAction = JSONObject().apply {
            put("name", "phone_action")
            put("description",
                "Perform an action on the phone. Call this immediately whenever the user asks to open an app, " +
                "call or message someone, play something, switch the torch on/off, change volume, or go home/back. " +
                "Never say the command out loud.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("command", JSONObject().apply {
                        put("type", "STRING")
                        put("description",
                            "Exactly one of: OPEN_APP <name> | CALL <name> | WHATSAPP_CALL <name> | WHATSAPP_MSG <name> <message> | " +
                            "YOUTUBE_PLAY <query> | SPOTIFY_PLAY <query> | FLASHLIGHT_ON | FLASHLIGHT_OFF | VOLUME_UP | VOLUME_DOWN | " +
                            "HOME | BACK | RECENTS | NOTIFICATIONS | SMS <name> <message> | REPLY_NOTIFICATION <message> | " +
                            "REPLY_NOTIFICATION_TO <app-or-name> <message>")
                    })
                })
                put("required", JSONArray().put("command"))
            })
        }

        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", Constants.GEMINI_MODEL)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", Constants.GEMINI_VOICE)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                })
                put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().put(phoneAction))))
                put("inputAudioTranscription", JSONObject())
                if (Constants.MANUAL_ACTIVITY) {
                    put("realtimeInputConfig", JSONObject().apply {
                        put("automaticActivityDetection", JSONObject().put("disabled", true))
                    })
                }
            })
        }
        ws.send(setup.toString())
        Log.d(TAG, "Setup sent")
    }

    private fun send(obj: JSONObject) {
        try { webSocket?.send(obj.toString()) } catch (e: Exception) { Log.e(TAG, "send error: ${e.message}") }
    }

    fun sendAudioChunk(pcm: ByteArray) {
        if (!isSetupComplete) return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject().apply {
            put("mimeType", "audio/pcm;rate=16000")
            put("data", b64)
        })))
    }

    /** Tell the server the user started talking (only used when automatic detection is disabled). */
    fun sendActivityStart() {
        if (!isSetupComplete || !Constants.MANUAL_ACTIVITY) return
        send(JSONObject().put("realtimeInput", JSONObject().put("activityStart", JSONObject())))
    }

    /** Tell the server the user finished, so it answers right away instead of waiting for silence. */
    fun sendActivityEnd() {
        if (!isSetupComplete || !Constants.MANUAL_ACTIVITY) return
        send(JSONObject().put("realtimeInput", JSONObject().put("activityEnd", JSONObject())))
    }

    fun sendTextMessage(text: String) {
        if (!isSetupComplete) return
        send(JSONObject().put("realtimeInput", JSONObject().put("text", text)))
    }

    /** A complete typed turn. Wrapped in activityStart/End so it also works with automatic detection off. */
    fun sendTextTurn(text: String) {
        if (!isSetupComplete) return
        sendActivityStart()
        sendTextMessage(text)
        sendActivityEnd()
    }

    /** One camera frame (JPEG) so Maya can see while she talks. */
    fun sendVideoFrame(jpeg: ByteArray) {
        if (!isSetupComplete) return
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        send(JSONObject().put("realtimeInput", JSONObject().put("video", JSONObject().apply {
            put("mimeType", "image/jpeg")
            put("data", b64)
        })))
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        if (!isSetupComplete) return
        val fr = JSONObject().apply {
            put("id", id)
            put("name", name)
            put("response", JSONObject().put("result", result))
        }
        send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr))))
    }

    private fun handleResponse(json: String) {
        try {
            val obj = JSONObject(json)

            if (obj.has("setupComplete")) {
                isSetupComplete = true
                Log.d(TAG, "Gemini Ready")
                onConnected()
                return
            }

            obj.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
                for (i in 0 until calls.length()) {
                    val c = calls.getJSONObject(i)
                    onToolCall(c.optString("id"), c.optString("name"), c.optJSONObject("args") ?: JSONObject())
                }
                return
            }

            val serverContent = obj.optJSONObject("serverContent") ?: return

            serverContent.optJSONObject("inputTranscription")?.optString("text")?.let {
                if (it.isNotEmpty()) onInputTranscript(it)
            }

            if (serverContent.optBoolean("interrupted", false)) onInterrupted()

            val parts = serverContent.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    part.optJSONObject("inlineData")?.optString("data")?.let { data ->
                        if (data.isNotEmpty()) onAudioReceived(Base64.decode(data, Base64.DEFAULT))
                    }
                    if (part.has("text")) onTextReceived(part.getString("text"))
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) onTurnComplete()
        } catch (e: Exception) {
            Log.e(TAG, "Parse error: ${e.message} | ${json.take(200)}")
        }
    }

    fun disconnect() {
        manualClose = true
        try { webSocket?.close(1000, "Bye") } catch (_: Exception) {}
        webSocket = null
        isSetupComplete = false
    }

    fun isConnected() = isSetupComplete
}
