
package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class Anime3DAssistantView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    companion object {
        private const val TAG = "MYRA_AVATAR"

        private const val AVATAR_URL =
            "https://appassets.androidplatform.net/assets/riya_floating.html"
    }

    private val assetLoader =
        WebViewAssetLoader.Builder()
            .addPathHandler(
                "/assets/",
                WebViewAssetLoader.AssetsPathHandler(context)
            )
            .build()

    private var pageLoaded = false

    private var currentListening = false
    private var currentSpeaking = false

    init {

        setBackgroundColor(Color.TRANSPARENT)

        settings.apply {

            javaScriptEnabled = true
            domStorageEnabled = true

            allowFileAccess = false
            allowContentAccess = true

            javaScriptCanOpenWindowsAutomatically = false

            setSupportMultipleWindows(false)

            cacheMode =
                android.webkit.WebSettings.LOAD_DEFAULT

            // Needed for external Three.js modules and VRM resources.
            mixedContentMode =
                android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false

        overScrollMode = View.OVER_SCROLL_NEVER

        isFocusable = false
        isFocusableInTouchMode = false

        // Keep WebView touch available for Three.js gestures.
        isClickable = true

        webChromeClient = object : WebChromeClient() {

            override fun onConsoleMessage(
                consoleMessage: ConsoleMessage
            ): Boolean {

                Log.d(
                    TAG,
                    "${consoleMessage.message()} " +
                        "(${consoleMessage.sourceId()}:" +
                        "${consoleMessage.lineNumber()})"
                )

                return true
            }
        }

        webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {

                return assetLoader.shouldInterceptRequest(
                    request.url
                )
            }

            @Suppress("DEPRECATION")
            override fun shouldInterceptRequest(
                view: WebView,
                url: String
            ): android.webkit.WebResourceResponse? {

                return assetLoader.shouldInterceptRequest(
                    android.net.Uri.parse(url)
                )
            }

            override fun onPageFinished(
                view: WebView,
                url: String
            ) {

                super.onPageFinished(view, url)

                if (url == AVATAR_URL) {

                    pageLoaded = true

                    Log.d(
                        TAG,
                        "RIYA avatar HTML loaded"
                    )

                    sendStateToJavascript()
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {

                super.onReceivedError(
                    view,
                    request,
                    error
                )

                Log.e(
                    TAG,
                    "WebView error: ${error.description}, " +
                        "URL: ${request.url}"
                )
            }
        }

        loadUrl(AVATAR_URL)
    }

    // =========================================
    // SEND LISTENING / SPEAKING STATE
    // =========================================

    fun setState(
        listening: Boolean,
        speaking: Boolean
    ) {

        currentListening = listening
        currentSpeaking = speaking

        post {

            if (pageLoaded) {
                sendStateToJavascript()
            }
        }
    }

    private fun sendStateToJavascript() {

        if (!pageLoaded) return

        if (Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.KITKAT
        ) {

            val js =
                "if (typeof window.setAvatarState === 'function') {" +
                    "window.setAvatarState(" +
                    "$currentListening, $currentSpeaking" +
                    ");" +
                    "}"

            evaluateJavascript(
                js,
                null
            )
        }
    }

    // =========================================
    // ROTATE AVATAR FROM KOTLIN IF NEEDED
    // =========================================

    fun rotateAvatar(degrees: Float) {

        post {

            if (!pageLoaded) return@post

            if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.KITKAT
            ) {

                evaluateJavascript(
                    "if (typeof window.rotateAvatar === 'function') {" +
                        "window.rotateAvatar($degrees);" +
                        "}",
                    null
                )
            }
        }
    }

    // =========================================
    // CLEANUP
    // =========================================

    override fun onDetachedFromWindow() {

        pageLoaded = false

        stopLoading()

        onPause()

        super.onDetachedFromWindow()

        destroy()
    }
}