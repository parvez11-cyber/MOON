package com.myra.assistant.notification

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import com.myra.assistant.utils.prefs
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Reads user notifications and uses notification RemoteInput when a reply action exists. */
class NotificationReaderService : NotificationListenerService() {
    private var tts: TextToSpeech? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
        }
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.isOngoing) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        if (title.contains("MYRA", true)) return

        val actions = sbn.notification.actions
        if (actions != null) for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            val reply = ReplyTarget(sbn.key, title, text, action.actionIntent, remoteInputs)
            targets[sbn.key] = reply
            latest = reply
            break
        }

        if (prefs().getBoolean("notification_read_aloud", true)) {
            val spoken = when {
                title.isNotBlank() && text.isNotBlank() -> "$title. $text"
                title.isNotBlank() -> title
                else -> text
            }
            if (spoken.isNotBlank()) tts?.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "myra_notification")
        }
    }

    fun replyToLatest(message: String): Boolean = latest?.let { sendReply(it, message) } ?: false

    fun replyTo(titleOrApp: String?, message: String): Boolean {
        val query = titleOrApp?.trim()?.lowercase(Locale.getDefault()).orEmpty()
        val target = if (query.isBlank()) latest else targets.values.firstOrNull {
            it.title.lowercase(Locale.getDefault()).contains(query)
        }
        return target?.let { sendReply(it, message) } ?: false
    }

    private fun sendReply(target: ReplyTarget, message: String): Boolean {
        return try {
            val fillIn = Intent()
            val results = Bundle()
            target.remoteInputs.forEach { input -> results.putCharSequence(input.resultKey, message) }
            android.app.RemoteInput.addResultsToIntent(target.remoteInputs, fillIn, results)
            target.actionIntent.send(this, 0, fillIn)
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onListenerDisconnected() {
        latest = null
    }

    override fun onDestroy() {
        latest = null
        targets.clear()
        tts?.stop()
        tts?.shutdown()
        tts = null
        instance = null
        super.onDestroy()
    }

    data class ReplyTarget(
        val key: String,
        val title: String,
        val text: String,
        val actionIntent: PendingIntent,
        val remoteInputs: Array<android.app.RemoteInput>
    )

    companion object {
        @Volatile var instance: NotificationReaderService? = null
        @Volatile private var latest: ReplyTarget? = null
        private val targets = ConcurrentHashMap<String, ReplyTarget>()
    }
}
