package com.myra.assistant.utils

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Optional root bridge. Android itself does not grant root to an APK;
 * this only requests a superuser shell when the device is already rooted.
 */
object RootAccess {
    @Volatile var isRootAvailable: Boolean = false
        private set

    fun request(context: Context): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val code = process.waitFor()
            isRootAvailable = code == 0 && output.contains("uid=0")
            Logger.d("ROOT", "root=$isRootAvailable")
            isRootAvailable
        } catch (e: Exception) {
            isRootAvailable = false
            Logger.d("ROOT", "not available: ${e.message}")
            false
        }
    }

    fun exec(command: String): String? {
        if (!isRootAvailable) return null
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            process.waitFor()
            output.trim()
        } catch (_: Exception) {
            null
        }
    }
}
