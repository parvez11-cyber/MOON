# Play Protect "blocked" - ki kora jay

Kono app ke Play Protect-er "blocked" theke ami code diye 100% ber korte pari na. Karon Play Protect Google-er server/on-device scan, ar MYRA-r moto app (Accessibility + SMS + overlay + notification access ek shathe) shobshomoy "risky" dhore.

## Ami je jinish kore diyechi
- Manifest theke 3 ta onabashyok permission soriyechi: REQUEST_INSTALL_PACKAGES, MANAGE_EXTERNAL_STORAGE, GET_TASKS.
- Release build-e nijer key diye sign korar setup add korechi (nicher dhap). Debug key diye banano APK shobcheye beshi block hoy.

## Tomar jeta korte hobe (nijer phone-e)
1. Install-er shomoy block dekhale: **More details -> Install anyway** (ba "Install without scanning").
2. Bar bar block korle: Play Store -> profile icon -> **Play Protect -> Settings (gear)** -> "Scan apps with Play Protect" **off**.
3. Install hole: Settings -> Accessibility -> Maya -> on. (Android 13+ e "Restricted setting" dekhale: Settings -> Apps -> Maya -> 3 dot -> **Allow restricted settings**.)

## Nijer key diye sign (block kom hoy)
```
keytool -genkey -v -keystore myra.jks -alias myra -keyalg RSA -keysize 2048 -validity 10000
```
`myra.jks` ta project root-e rakho ar `keystore.properties` file banao (git-e dio na):
```
storeFile=myra.jks
storePassword=****
keyAlias=myra
keyPassword=****
```
Tarpor Android Studio: Build -> Generate Signed Bundle/APK -> APK -> release. Ba `./gradlew assembleRelease`.
Ek-i key diye shob update sign koro; key hariye gele purano app-er upor update hobe na.

## Ar ekta kotha
Google Play-te publish korle ei permission (SMS, Accessibility, all-files) policy-te reject hobe. Eta shudhu nijer phone-er sideload app.
