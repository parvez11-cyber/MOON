// Project-level build file (AGP 9.5 uses built-in Kotlin, so no kotlin-android plugin)
plugins {
    id("com.android.application") version "9.5.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
}
