package com.myra.assistant.system

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.assistant.notification.NotificationReaderService
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.MyraDeviceAdminReceiver
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import com.myra.assistant.utils.prefs

/**
 * Gets Maya as much system access as Android allows.
 *
 * ROOT PHONE  : [grantAll] gives every permission silently (pm grant, appops, accessibility, notification access,
 *               device admin, battery whitelist). Android never lets an APK make itself root; the user must allow
 *               the "su" prompt of Magisk / KernelSU once.
 * NORMAL PHONE: Android keeps some permissions for the system / adb only. [missingRuntime] + [nextSpecialScreen]
 *               walk the user through everything that CAN be allowed, and [adbCommands] lists the rest
 *               (one time, from a PC, no root needed).
 */
object PermissionGranter {
    private const val TAG = "PERM_GRANT"

    private fun component(c: Context, cls: Class<*>) = ComponentName(c, cls).flattenToString()

    // ------------------------------------------------------------------ root
    private val grantLock = Any()

    // Activity and Service both call this at start-up; the lock stops two su sessions running the same grants at once.
    fun grantAll(context: Context): Boolean = synchronized(grantLock) { grantAllLocked(context) }

    private fun grantAllLocked(context: Context): Boolean {
        if (!RootAccess.isRootAvailable) return false
        val pkg = context.packageName
        val a11y = component(context, AccessibilityHelperService::class.java)
        val listener = component(context, NotificationReaderService::class.java)
        val admin = component(context, MyraDeviceAdminReceiver::class.java)

        val version = try { androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(context.packageManager.getPackageInfo(pkg, 0)) } catch (_: Exception) { 0L }
        val p = context.prefs()
        if (p.getLong("root_grant_version", -1L) != version) {
            // IMPORTANT: Android kills an app's process when a runtime / storage permission is granted to it from outside.
            // The marker is saved BEFORE granting (commit, not apply), so if the process dies mid-way the app does not
            // repeat the grants on every launch (that looked like the app being thrown out as soon as root was allowed).
            p.edit().putLong("root_grant_version", version).commit()

            val requested = try {
                context.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions?.toList().orEmpty()
            } catch (_: Exception) { emptyList() }
            val cmds = ArrayList<String>()
            // calm settings first (they do not restart the app)
            listOf(
                "SYSTEM_ALERT_WINDOW", "WRITE_SETTINGS", "GET_USAGE_STATS",
                "REQUEST_INSTALL_PACKAGES", "SCHEDULE_EXACT_ALARM", "USE_FULL_SCREEN_INTENT",
                "RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND", "ACCESS_NOTIFICATIONS", "READ_CLIPBOARD", "WRITE_CLIPBOARD"
            ).forEach { cmds.add("appops set $pkg $it allow") }
            cmds.add("dumpsys deviceidle whitelist +$pkg")
            cmds.add("dpm set-active-admin --user 0 $admin")
            RootAccess.execAll(cmds)
            Logger.d(TAG, "root: ${cmds.size} settings applied")

            // then only the runtime permissions that are still missing, and the process-killing ones last
            val missing = requested.filter { it.startsWith("android.permission.") }
                .filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
            val (risky, safe) = missing.partition {
                it.contains("STORAGE") || it.contains("MEDIA") || it.contains("SMS") || it.contains("CALL_LOG") || it.contains("CONTACTS")
            }
            if (safe.isNotEmpty()) RootAccess.execAll(safe.map { "pm grant $pkg $it" })
            val manageFiles = if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) listOf("appops set $pkg MANAGE_EXTERNAL_STORAGE allow") else emptyList()
            val last = risky.map { "pm grant $pkg $it" } + manageFiles
            if (last.isNotEmpty()) RootAccess.execAll(last)   // the app may be restarted by Android here; nothing is left to repeat
            Logger.d(TAG, "root: ${missing.size} runtime grants applied")
        }

        // services are re-checked every time (cheap) because the user can switch them off
        if (!AccessibilityHelperService.isEnabled(context)) {
            val cur = RootAccess.exec("settings get secure enabled_accessibility_services").orEmpty().let { if (it == "null") "" else it }
            if (!cur.split(':').contains(a11y)) {
                val v = if (cur.isBlank()) a11y else "$cur:$a11y"
                RootAccess.execAll(listOf(
                    "settings put secure enabled_accessibility_services $v",
                    "settings put secure accessibility_enabled 1"
                ))
            }
        }
        val listeners = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
        if (!listeners.contains(pkg)) {
            RootAccess.execAll(listOf(
                "cmd notification allow_listener $listener",
                "cmd notification allow_assistant $listener"
            ))
            val after = RootAccess.exec("settings get secure enabled_notification_listeners").orEmpty()
            if (!after.contains(pkg)) {
                val v = if (after.isBlank() || after == "null") listener else "$after:$listener"
                RootAccess.exec("settings put secure enabled_notification_listeners $v")
            }
        }
        return true
    }

    // ------------------------------------------------------------------ normal phone
    /** Runtime permissions from the manifest that are still not allowed (what the system dialog can ask for). */
    fun missingRuntime(context: Context): List<String> {
        val pm = context.packageManager
        val requested = try {
            pm.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toList().orEmpty()
        } catch (_: Exception) { emptyList() }
        return requested.filter { perm ->
            val dangerous = try {
                val info = pm.getPermissionInfo(perm, 0)
                (if (Build.VERSION.SDK_INT >= 28) info.protection else (info.protectionLevel and 0xF)) == android.content.pm.PermissionInfo.PROTECTION_DANGEROUS
            } catch (_: Exception) { false }
            dangerous && ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED
        }.filter {
            // background location can only be asked after normal location
            it != Manifest.permission.ACCESS_BACKGROUND_LOCATION ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    /** The next special-access screen that still needs the user, or null when all are done. */
    fun nextSpecialScreen(context: Context): Intent? {
        val pkgUri = Uri.parse("package:${context.packageName}")
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val checks: List<Pair<Boolean, Intent>> = listOf(
            Settings.canDrawOverlays(context) to Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri),
            AccessibilityHelperService.isEnabled(context) to Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
            Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty().contains(context.packageName)
                to Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
            Settings.System.canWrite(context) to Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri),
            (if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true)
                to Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri),
            nm.isNotificationPolicyAccessGranted to Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS),
            (context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(context.packageName)
                to Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri),
            usageAccessOk(context) to Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
            (context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager)
                .isAdminActive(ComponentName(context, MyraDeviceAdminReceiver::class.java)) to
                Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(context, MyraDeviceAdminReceiver::class.java))
        )
        return checks.firstOrNull { !it.first }?.second?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun usageAccessOk(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == android.app.AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    /** One-time commands for a PC with USB debugging (no root needed). They unlock what the app cannot give itself. */
    fun adbCommands(context: Context): List<String> {
        val pkg = context.packageName
        return listOf(
            "adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "adb shell pm grant $pkg android.permission.READ_LOGS",
            "adb shell pm grant $pkg android.permission.PACKAGE_USAGE_STATS",
            "adb shell pm grant $pkg android.permission.DUMP",
            "adb shell appops set $pkg MANAGE_EXTERNAL_STORAGE allow",
            "adb shell dumpsys deviceidle whitelist +$pkg"
        )
    }
}
