package com.myra.assistant.system

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

/**
 * Sends a real SMS and reports whether it actually left the phone.
 *
 * Old code problems fixed here:
 *  - "SMS Rahim Bhai hello" used to take only "Rahim" as the name. Now the name can be several words.
 *  - SEND_SMS permission was never checked (silent failure).
 *  - Contact lookup was a plain LIKE; now it ranks exact > starts-with > contains and also accepts a raw number.
 *  - It said "sent" without waiting for the radio. Now it waits for the sent callback.
 */
object SmsSender {
    private const val TAG = "SMS"
    private const val ACTION_SENT = "com.myra.assistant.SMS_SENT"

    data class Result(val ok: Boolean, val message: String)
    private data class Contact(val name: String, val number: String)

    /** [rest] is whatever follows the word SMS. Supports "name | message", "name :: message" or "name message words". */
    suspend fun sendFromCommand(context: Context, rest: String): Result {
        val text = rest.trim()
        if (text.isEmpty()) return Result(false, "SMS er jonno kar naam ar ki likhbo seta bolo.")
        val (target, body) = split(context, text)
        if (target.isBlank() || body.isBlank()) return Result(false, "Naam ba message bujhte parini.")
        return send(context, target, body)
    }

    suspend fun send(context: Context, nameOrNumber: String, message: String): Result {
        val app = context.applicationContext
        if (!granted(app, Manifest.permission.SEND_SMS)) {
            // with root we can grant it ourselves
            if (RootAccess.isRootAvailable) RootAccess.exec("pm grant ${app.packageName} ${Manifest.permission.SEND_SMS}")
            if (!granted(app, Manifest.permission.SEND_SMS)) {
                return Result(false, "SMS permission deya nai. Settings theke SMS permission on korte hobe.")
            }
        }
        val contact = resolve(app, nameOrNumber)
            ?: return Result(false, "'$nameOrNumber' naam e kono contact paini.")
        return when (val r = dispatch(app, contact.number, message)) {
            null -> Result(true, "SMS pathano hoyeche ${contact.name} ke.")
            else -> Result(false, "SMS jayni: $r")
        }
    }

    // ---------------------------------------------------------------- parsing & contacts

    private fun split(context: Context, text: String): Pair<String, String> {
        for (sep in listOf("|", "::")) {
            val i = text.indexOf(sep)
            if (i > 0) return text.substring(0, i).trim() to text.substring(i + sep.length).trim()
        }
        val words = text.split(Regex("\\s+"))
        if (words.size < 2) return text to ""
        // longest leading run of words that is really a contact name wins
        if (granted(context, Manifest.permission.READ_CONTACTS)) {
            for (n in minOf(4, words.size - 1) downTo 1) {
                val name = words.take(n).joinToString(" ")
                if (isNumber(name) || lookup(context, name).isNotEmpty()) {
                    return name to words.drop(n).joinToString(" ")
                }
            }
        }
        return words[0] to words.drop(1).joinToString(" ")
    }

    private fun isNumber(s: String) = s.replace(Regex("[\\s\\-()]"), "").matches(Regex("\\+?\\d{6,15}"))

    private fun resolve(context: Context, query: String): Contact? {
        if (isNumber(query)) return Contact(query, query.replace(Regex("[\\s\\-()]"), ""))
        if (!granted(context, Manifest.permission.READ_CONTACTS)) return null
        val q = norm(query)
        return lookup(context, query).minByOrNull {
            val n = norm(it.name)
            when {
                n == q -> 0
                n.startsWith(q) -> 1
                else -> 2
            }
        }
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()

    private fun lookup(context: Context, name: String): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${name.trim()}%"),
                null
            )?.use { c ->
                while (c.moveToNext() && out.size < 20) {
                    val num = c.getString(1)?.replace(Regex("[\\s\\-()]"), "").orEmpty()
                    if (num.isNotEmpty()) out.add(Contact(c.getString(0).orEmpty(), num))
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "contact lookup: ${e.message}")
        }
        return out
    }

    // ---------------------------------------------------------------- sending

    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    private fun smsManager(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()

    /** Returns null on success, otherwise a short reason. */
    private suspend fun dispatch(app: Context, number: String, message: String): String? {
        return try {
            val sms = smsManager(app)
            val parts = sms.divideMessage(message)
            val total = parts.size
            val okCount = AtomicInteger(0)
            val failReason = arrayOfNulls<String>(1)

            val outcome = withTimeoutOrNull(15_000) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val action = "$ACTION_SENT.${System.nanoTime()}"
                    val done = AtomicInteger(0)
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(c: Context, i: Intent) {
                            if (resultCode == Activity.RESULT_OK) okCount.incrementAndGet()
                            else failReason[0] = reason(resultCode)
                            if (done.incrementAndGet() >= total && cont.isActive) cont.resume(okCount.get() == total)
                        }
                    }
                    ContextCompat.registerReceiver(app, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                    cont.invokeOnCancellation { runCatching { app.unregisterReceiver(receiver) } }
                    try {
                        val flags = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                        val sent = ArrayList<PendingIntent>()
                        for (i in 0 until total) {
                            sent.add(PendingIntent.getBroadcast(app, i, Intent(action).setPackage(app.packageName), flags))
                        }
                        if (total == 1) sms.sendTextMessage(number, null, message, sent[0], null)
                        else sms.sendMultipartTextMessage(number, null, parts, sent, null)
                    } catch (e: Exception) {
                        failReason[0] = e.message ?: "error"
                        runCatching { app.unregisterReceiver(receiver) }
                        if (cont.isActive) cont.resume(false)
                    }
                }
            }
            when (outcome) {
                true -> null
                false -> failReason[0] ?: "unknown error"
                null -> "radio response dei nai (network/SIM check korun)"
            }
        } catch (e: Exception) {
            Logger.e(TAG, "send error: ${e.message}")
            e.message ?: "error"
        }
    }

    private fun reason(code: Int) = when (code) {
        SmsManager.RESULT_ERROR_NO_SERVICE -> "network nai"
        SmsManager.RESULT_ERROR_RADIO_OFF -> "airplane mode/radio off"
        SmsManager.RESULT_ERROR_NULL_PDU -> "message khali"
        else -> "generic failure ($code)"
    }

    /** Last resort when SEND_SMS is not allowed: open the composer prefilled so one tap sends it. */
    fun openComposer(context: Context, number: String, message: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
                    .putExtra("sms_body", message).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }
}
