package com.myra.assistant.ai

import android.content.Context
import org.json.JSONArray

/**
 * Simple on-device custom memory. Data stays in app-private SharedPreferences.
 */
object PersistentMemory {
    private const val PREFS = "myra_custom_memory"
    private const val KEY_ITEMS = "items"
    private var initialized = false
    private var context: Context? = null
    private val items = mutableListOf<String>()

    fun init(ctx: Context) {
        if (initialized) return
        context = ctx.applicationContext
        val raw = context!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        items.clear()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) items.add(arr.optString(i))
        } catch (_: Exception) {}
        initialized = true
    }

    @Synchronized
    fun add(text: String) {
        val value = text.trim()
        if (value.isBlank()) return
        if (items.none { it.equals(value, ignoreCase = true) }) items.add(value)
        persist()
    }

    @Synchronized
    fun remove(index: Int) {
        if (index in items.indices) {
            items.removeAt(index)
            persist()
        }
    }

    fun all(): List<String> = synchronized(this) { items.toList() }

    fun contextForAI(): String = synchronized(this) {
        if (items.isEmpty()) "" else items.joinToString("\n") { "- $it" }
    }

    private fun persist() {
        val arr = JSONArray()
        items.forEach(arr::put)
        context?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            ?.edit()?.putString(KEY_ITEMS, arr.toString())?.apply()
    }
}
