package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(Constants.KEY_API_KEY, "") ?: ""
        // Android 14+ forbids starting a microphone foreground service from BOOT_COMPLETED,
        // so the voice service is started when the user opens the app / taps the orb instead.
        if (apiKey.isNotEmpty() && Build.VERSION.SDK_INT < 34) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, ForegroundVoiceService::class.java))
            } catch (_: Exception) {}
        }
        if (Settings.canDrawOverlays(context)) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, MyraOverlayService::class.java).apply { action = Constants.ACTION_SHOW_OVERLAY }
                )
            } catch (_: Exception) {}
        }
    }
}
