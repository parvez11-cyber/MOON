package com.myra.assistant.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import androidx.lifecycle.Observer
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.voice.VoiceStateManager

/**
 * Puts the edge light on top of every app (system overlay) whenever Maya's mic session is live.
 * Needs the "Display over other apps" permission. Without it the in-app version in MayaApp is used.
 * Driven only by VoiceStateManager, so it follows the mic exactly: on when listening / thinking /
 * speaking, off when idle.
 */
object EdgeGlowController {
    private const val TAG = "EDGE_GLOW"
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var view: EdgeGlowView? = null
    private var started = false
    private var wantVisible = false

    private val stateObs = Observer<String> { st ->
        when (st) {
            Constants.STATE_LISTENING -> show(EdgeGlowView.Mode.LISTENING)
            Constants.STATE_THINKING -> show(EdgeGlowView.Mode.THINKING)
            Constants.STATE_SPEAKING -> show(EdgeGlowView.Mode.SPEAKING)
            else -> hide()
        }
    }
    private val ampObs = Observer<Float> { view?.setLevel(it) }

    fun start(context: Context) {
        main.post {
            if (started) return@post
            started = true
            app = context.applicationContext
            VoiceStateManager.state.observeForever(stateObs)
            VoiceStateManager.amplitude.observeForever(ampObs)
        }
    }

    fun stop() {
        main.post {
            if (!started) return@post
            started = false
            VoiceStateManager.state.removeObserver(stateObs)
            VoiceStateManager.amplitude.removeObserver(ampObs)
            removeNow()
        }
    }

    private fun show(mode: EdgeGlowView.Mode) {
        val ctx = app ?: return
        wantVisible = true
        if (!Settings.canDrawOverlays(ctx)) return
        try {
            val v = view ?: EdgeGlowView(ctx).also { nv ->
                nv.alpha = 0f
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT
                )
                if (Build.VERSION.SDK_INT >= 30) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                wm.addView(nv, lp)
                view = nv
            }
            v.setMode(mode)
            v.animate().cancel()
            v.animate().alpha(1f).setDuration(220).start()
        } catch (e: Exception) {
            Logger.e(TAG, "cannot show glow: ${e.message}")
        }
    }

    private fun hide() {
        wantVisible = false
        val v = view ?: return
        v.animate().cancel()
        v.animate().alpha(0f).setDuration(260).withEndAction { if (!wantVisible) removeNow() }.start()
    }

    private fun removeNow() {
        val v = view ?: return
        view = null
        try {
            val wm = app?.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            wm?.removeViewImmediate(v)
        } catch (_: Exception) {}
    }
}
