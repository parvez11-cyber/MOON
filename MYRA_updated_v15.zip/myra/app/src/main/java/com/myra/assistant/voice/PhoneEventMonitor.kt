package com.myra.assistant.voice

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Logger

/**
 * Watches the phone itself (charger, battery, headset, bluetooth, wifi/data, airplane mode) and
 * tells the user. Every one of these is a local system broadcast, so it all works offline.
 */
object PhoneEventMonitor {
    private const val TAG = "PHONE_EVENTS"
    private var started = false
    private var startedAt = 0L
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())

    private var charging: Boolean? = null
    private var fullAnnounced = false
    private val lowAnnounced = HashSet<Int>()
    private val lowSteps = listOf(20, 15, 10, 5)

    private enum class Net { NONE, WIFI, CELL }
    private var netNow = Net.NONE
    private var netAnnounced: Net? = null
    private val settleNet = Runnable { settleNetwork() }

    fun start(context: Context) {
        if (started) return
        started = true
        app = context.applicationContext
        startedAt = SystemClock.elapsedRealtime()
        LocalSpeaker.init(app)
        // remember where we are so the first broadcast does not sound like news
        batteryIntent()?.let { charging = isPlugged(it) }
        registerBroadcasts()
        registerNetwork()
        Logger.d(TAG, "started")
    }

    // ---------------------------------------------------------------- battery & friends
    private fun batteryIntent(): Intent? = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    private fun isPlugged(i: Intent) = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0

    private fun percent(i: Intent?): Int {
        i ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level < 0 || scale <= 0) -1 else level * 100 / scale
    }

    private fun quiet() = SystemClock.elapsedRealtime() - startedAt < 3000

    private fun registerBroadcasts() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        ContextCompat.registerReceiver(app, object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                try { handle(i) } catch (e: Exception) { Logger.e(TAG, "event error: ${e.message}") }
            }
        }, f, ContextCompat.RECEIVER_EXPORTED)
    }

    private fun handle(i: Intent) {
        if (quiet()) return
        when (i.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                charging = true; fullAnnounced = false; lowAnnounced.clear()
                val b = batteryIntent()
                val p = percent(b)
                val kind = when (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "ওয়্যারলেস চার্জার" to "wireless charger"
                    BatteryManager.BATTERY_PLUGGED_USB -> "ইউএসবি" to "USB"
                    else -> "চার্জার" to "charger"
                }
                Announcer.announce(app, "power_on", Say(
                    "${kind.first} লাগানো হয়েছে, চার্জ হচ্ছে। ব্যাটারি $p শতাংশ।",
                    "${kind.second} laga diya gaya hai, charge ho raha hai. Battery $p percent.",
                    "The ${kind.second} was connected and the phone is charging. Battery is $p percent."))
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                charging = false; fullAnnounced = false
                val p = percent(batteryIntent())
                Announcer.announce(app, "power_off", Say(
                    "চার্জার খুলে ফেলা হয়েছে। ব্যাটারি $p শতাংশ।",
                    "Charger nikal diya gaya hai. Battery $p percent.",
                    "The charger was unplugged. Battery is $p percent."))
            }
            Intent.ACTION_BATTERY_CHANGED -> onBatteryChanged(i)
            Intent.ACTION_BATTERY_LOW -> { /* covered by our own step levels below */ }
            Intent.ACTION_HEADSET_PLUG -> {
                val plugged = i.getIntExtra("state", 0) == 1
                Announcer.announce(app, if (plugged) "headset_on" else "headset_off", if (plugged) Say(
                    "হেডফোন লাগানো হয়েছে।", "Headphone laga diya gaya hai.", "Headphones were plugged in.")
                else Say("হেডফোন খুলে ফেলা হয়েছে।", "Headphone nikal diya gaya hai.", "Headphones were unplugged."))
            }
            Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
                val on = i.getBooleanExtra("state", false)
                Announcer.announce(app, "airplane", if (on) Say(
                    "ফ্লাইট মোড চালু হয়েছে।", "Flight mode on ho gaya hai.", "Airplane mode was turned on.")
                else Say("ফ্লাইট মোড বন্ধ হয়েছে।", "Flight mode off ho gaya hai.", "Airplane mode was turned off."))
            }
            BluetoothDevice.ACTION_ACL_CONNECTED, BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                val on = i.action == BluetoothDevice.ACTION_ACL_CONNECTED
                val name = try {
                    @Suppress("DEPRECATION")
                    i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)?.name
                } catch (_: SecurityException) { null } ?: ""
                val nbn = if (name.isBlank()) "ব্লুটুথ ডিভাইস" else name
                val nen = if (name.isBlank()) "A Bluetooth device" else name
                Announcer.announce(app, "bt_${if (on) "on" else "off"}_$name", if (on) Say(
                    "$nbn কানেক্ট হয়েছে।", "$nen connect ho gaya.", "$nen connected over Bluetooth.")
                else Say("$nbn ডিসকানেক্ট হয়েছে।", "$nen disconnect ho gaya.", "$nen disconnected from Bluetooth."))
            }
        }
    }

    private fun onBatteryChanged(i: Intent) {
        val p = percent(i)
        if (p < 0) return
        val plugged = isPlugged(i)
        if (plugged) {
            lowAnnounced.clear()
            if (p >= 100 && !fullAnnounced && charging == true) {
                fullAnnounced = true
                Announcer.announce(app, "battery_full", Say(
                    "ব্যাটারি ফুল হয়ে গেছে, চার্জার খুলে নিন।",
                    "Battery full ho gayi hai, charger nikal lijiye.",
                    "The battery is full. Suggest unplugging the charger."), 60_000)
            }
            if (p < 95) fullAnnounced = false
        } else {
            fullAnnounced = false
            for (step in lowSteps) {
                if (p <= step && lowAnnounced.add(step)) {
                    // only the lowest step crossed gets spoken; mark the higher ones as done
                    lowSteps.filter { it > step }.forEach { lowAnnounced.add(it) }
                    Announcer.announce(app, "battery_low_$step", Say(
                        "ব্যাটারি মাত্র $p শতাংশ, চার্জে দিন।",
                        "Battery sirf $p percent hai, charge pe laga dijiye.",
                        "The battery is down to $p percent. Ask the user to plug in the charger."), 60_000)
                    break
                }
            }
            lowSteps.filter { p > it + 3 }.forEach { lowAnnounced.remove(it) }
        }
    }

    // ---------------------------------------------------------------- network
    private fun registerNetwork() {
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            netNow = currentNet(cm)
            netAnnounced = netNow
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    netNow = currentNet(cm); schedule()
                    // internet is back: bring Maya's live session up straight away
                    ForegroundVoiceService.instance?.let { if (!it.isGeminiConnected()) it.reconnectGemini() }
                }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    netNow = netOf(caps); schedule()
                }
                override fun onLost(network: Network) { netNow = currentNet(cm); schedule() }
            })
        } catch (e: Exception) {
            Logger.e(TAG, "network callback failed: ${e.message}")
        }
    }

    private fun netOf(caps: NetworkCapabilities?): Net = when {
        caps == null -> Net.NONE
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Net.WIFI
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Net.CELL
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Net.WIFI
        else -> Net.NONE
    }

    private fun currentNet(cm: ConnectivityManager): Net =
        netOf(cm.getNetworkCapabilities(cm.activeNetwork ?: return Net.NONE))

    /** Wifi -> mobile data flips through "lost" for a moment; wait for it to settle before speaking. */
    private fun schedule() {
        main.removeCallbacks(settleNet)
        main.postDelayed(settleNet, 2500)
    }

    private fun settleNetwork() {
        val now = netNow
        if (now == netAnnounced || quiet()) { netAnnounced = now; return }
        netAnnounced = now
        val say = when (now) {
            Net.WIFI -> Say("ওয়াইফাই কানেক্ট হয়েছে।", "WiFi connect ho gaya.", "Wi-Fi connected. The internet is back.")
            Net.CELL -> Say("মোবাইল ডেটা চালু আছে।", "Mobile data chal raha hai.", "Now on mobile data.")
            Net.NONE -> Say("ইন্টারনেট চলে গেছে। তবে ফোনের কাজ আমি অফলাইনেও করতে পারব।",
                "Internet chala gaya hai. Phone ke kaam main offline bhi kar sakti hoon.",
                "The internet connection was lost.")
        }
        // when the internet drops the live session is gone, so this one is always spoken on-device
        Announcer.announce(app, "net_$now", say, 6000)
    }
}
