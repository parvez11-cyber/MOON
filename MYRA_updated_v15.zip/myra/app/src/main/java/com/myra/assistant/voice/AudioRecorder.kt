package com.myra.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import com.myra.assistant.utils.AudioUtils
import com.myra.assistant.utils.Logger
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Microphone capture that copes with phones whose mic is quiet or returns silence for one audio source.
 *  - tries several audio sources (speech-recognition, plain mic, voice-communication) and keeps the first one that
 *    really delivers sound,
 *  - lifts a quiet microphone with a slow automatic gain so the speech detector and Gemini can hear it,
 *  - reports a problem (via [onProblem]) instead of staying silent when nothing works.
 */
class AudioRecorder(
    private val context: Context,
    private val onChunk: (ByteArray) -> Unit
) {
    private val TAG = "RECORDER"
    private val SAMPLE_RATE = 16000
    private val CHUNK_SIZE = 1024  // 512 samples, ~32 ms at 16 kHz

    /** Called on the recording thread with a short Banglish message when the mic gives no usable sound. */
    var onProblem: (String) -> Unit = {}

    private var audioRecord: AudioRecord? = null
    private var recordThread: Thread? = null
    @Volatile private var isRecording = false

    private val sources = intArrayOf(
        MediaRecorder.AudioSource.VOICE_RECOGNITION,
        MediaRecorder.AudioSource.MIC,
        MediaRecorder.AudioSource.VOICE_COMMUNICATION
    )

    fun start() {
        if (isRecording) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            Logger.e(TAG, "RECORD_AUDIO permission not granted")
            onProblem("Microphone permission deya nei")
            return
        }
        isRecording = true
        recordThread = Thread { loop() }.also {
            it.name = "MYRA_RecordThread"
            it.isDaemon = true
            it.start()
        }
    }

    private fun open(source: Int): AudioRecord? {
        val bufferSize = maxOf(AudioUtils.getMinBufferSize(SAMPLE_RATE), 8192)
        return try {
            val r = AudioRecord(source, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
            EchoCancellationManager.attach(r.audioSessionId)
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                r.release(); EchoCancellationManager.release(); return null
            }
            r
        } catch (e: Exception) {
            Logger.e(TAG, "open($source) failed: ${e.message}")
            null
        }
    }

    private fun closeRecord() {
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        EchoCancellationManager.release()
    }

    private fun loop() {
        val buffer = ByteArray(CHUNK_SIZE)
        var gain = 1f
        var loud = 0.003f
        var idx = 0
        var anyOpened = false

        while (isRecording && idx < sources.size) {
            val rec = open(sources[idx])
            if (rec == null) { idx++; continue }
            anyOpened = true
            audioRecord = rec
            Logger.d(TAG, "Recording with source ${sources[idx]}")

            var reads = 0
            var peak = 0
            var healthy = false
            while (isRecording && !Thread.interrupted()) {
                val read = rec.read(buffer, 0, buffer.size)
                if (read <= 0) {
                    if (read < 0) break          // AudioRecord error: try the next source
                    continue
                }
                // ---- measure + software gain ----
                var sum = 0.0
                var i = 0
                while (i + 1 < read) {
                    val s = ((buffer[i].toInt() and 0xFF) or (buffer[i + 1].toInt() shl 8)).toShort().toInt()
                    sum += s.toDouble() * s
                    if (abs(s) > peak && !healthy) peak = abs(s)
                    i += 2
                }
                val rms = sqrt(sum / (read / 2).coerceAtLeast(1)).toFloat() / 32768f
                loud = maxOf(rms, loud * 0.9995f)
                val target = (0.07f / maxOf(loud, 0.004f)).coerceIn(1f, 8f)
                gain += (target - gain) * 0.05f
                if (gain > 1.05f) {
                    i = 0
                    while (i + 1 < read) {
                        val s = ((buffer[i].toInt() and 0xFF) or (buffer[i + 1].toInt() shl 8)).toShort().toInt()
                        val v = (s * gain).toInt().coerceIn(-32768, 32767)
                        buffer[i] = (v and 0xFF).toByte()
                        buffer[i + 1] = ((v shr 8) and 0xFF).toByte()
                        i += 2
                    }
                }

                // ---- does this source deliver real sound at all? (digital silence = wrong source on some phones) ----
                reads++
                if (!healthy) {
                    if (peak >= 12) healthy = true
                    else if (reads >= 60) {                      // ~2 seconds of nothing
                        Logger.e(TAG, "source ${sources[idx]} is silent")
                        break
                    }
                }

                if (!VoiceStateManager.isAiSpeaking()) onChunk(buffer.copyOf(read))
            }
            closeRecord()
            if (!isRecording) return
            if (healthy) { idx = 0; continue }                   // it worked and then broke: start over from the best source
            idx++
        }

        if (isRecording) {
            isRecording = false
            onProblem(
                if (anyOpened) "Mic theke kono awaj ashche na. Onno app (call/recorder) mic dhore ache kina dekho, ba Settings > Permissions > Microphone allow koro."
                else "Microphone khola jachche na. Permission ba onno app mic use korche."
            )
        }
    }

    fun stop() {
        isRecording = false
        recordThread?.interrupt()
        recordThread = null
        closeRecord()
        Logger.d(TAG, "Recording stopped")
    }

    fun isActive() = isRecording
}
