package com.myra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * Light that runs round the four edges of the screen while Maya is listening / thinking / talking.
 * Colours come from the Maya palette (blue, sky blue, violet, rose). No blur filter is used, so it
 * stays smooth: a few stacked strokes with falling opacity make the glow.
 */
class EdgeGlowView(context: Context) : View(context) {

    enum class Mode { LISTENING, THINKING, SPEAKING }

    private val d = resources.displayMetrics.density
    private val widths = floatArrayOf(104f, 68f, 42f, 22f, 9f)
    private val alphas = intArrayOf(16, 30, 58, 125, 240)
    private val paints = Array(widths.size) { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE } }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var phase = 0f
    private var level = 0f
    private var target = 0f
    private var mode = Mode.LISTENING
    private var animator: ValueAnimator? = null

    private fun colorsFor(m: Mode): IntArray = when (m) {
        Mode.LISTENING -> intArrayOf(0xFF3B8EEA.toInt(), 0xFF5CB0FF.toInt(), 0xFF8E7CFF.toInt(), 0xFF5CB0FF.toInt(), 0xFF3B8EEA.toInt())
        Mode.THINKING -> intArrayOf(0xFF8E7CFF.toInt(), 0xFFE0457B.toInt(), 0xFF3B8EEA.toInt(), 0xFF8E7CFF.toInt(), 0xFF8E7CFF.toInt())
        Mode.SPEAKING -> intArrayOf(0xFF5CB0FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF3B8EEA.toInt(), 0xFF5CE1E6.toInt(), 0xFF5CB0FF.toInt())
    }

    fun setMode(m: Mode) {
        if (m == mode && shader != null) return
        mode = m
        buildShader()
        invalidate()
    }

    /** 0..1 microphone level; the glow breathes with the voice. */
    fun setLevel(l: Float) {
        target = l.coerceIn(0f, 1f)
    }

    private fun buildShader() {
        if (width == 0 || height == 0) return
        shader = SweepGradient(width / 2f, height / 2f, colorsFor(mode), null)
        paints.forEach { it.shader = shader }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        buildShader()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3600
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                angle = 360f * f
                phase = (f * 2f * Math.PI).toFloat()
                level += (target - level) * 0.25f
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val sh = shader ?: return
        matrix.setRotate(angle, width / 2f, height / 2f)
        sh.setLocalMatrix(matrix)
        val breathe = 0.84f + 0.16f * sin(phase * 2f) + level * 0.55f
        val corner = 40f * d
        for (i in paints.indices) {
            val p = paints[i]
            p.strokeWidth = widths[i] * d * (0.85f + level * 0.6f)
            p.alpha = (alphas[i] * breathe).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(rect, corner, corner, p)
        }
    }
}
