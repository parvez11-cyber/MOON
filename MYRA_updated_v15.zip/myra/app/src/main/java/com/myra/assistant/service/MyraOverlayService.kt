
package com.myra.assistant.service

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ui.main.Anime3DAssistantView
import com.myra.assistant.ui.maya.MayaActivity
import com.myra.assistant.utils.Constants
import kotlin.math.abs

class MyraOverlayService : Service() {

    companion object {
        var isRunning = false

        const val CHANNEL_ID = "myra_overlay_channel"
        const val NOTIF_ID = 1001
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var isVisible = false

    private var downX = 0f
    private var downY = 0f

    private var startX = 0
    private var startY = 0

    private var moved = false

    private val touchSlop by lazy {
        android.view.ViewConfiguration
            .get(this)
            .scaledTouchSlop
    }

    override fun onCreate() {
        super.onCreate()

        isRunning = true

        createNotificationChannel()

        androidx.core.app.ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            buildNotification(),
            if (Build.VERSION.SDK_INT >= 34)
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else 0
        )

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            Constants.ACTION_SHOW_OVERLAY -> {
                showOverlay()
            }

            Constants.ACTION_HIDE_OVERLAY -> {
                hideOverlay()
            }

            Constants.ACTION_TOGGLE_OVERLAY -> {
                if (isVisible) {
                    hideOverlay()
                } else {
                    showOverlay()
                }
            }
        }

        return START_STICKY
    }

    // =========================================
    // SHOW OVERLAY
    // =========================================

    private fun showOverlay() {

        if (
            isVisible ||
            overlayView != null ||
            !Settings.canDrawOverlays(this)
        ) {
            return
        }

        val root = LayoutInflater
            .from(this)
            .inflate(
                R.layout.overlay_orb,
                null
            )

        overlayView = root

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },

            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,

            PixelFormat.TRANSLUCENT

        ).apply {

            gravity = Gravity.TOP or Gravity.START

            x = 20
            y = 180
        }

        try {

            windowManager?.addView(
                root,
                overlayParams
            )

            isVisible = true

            setupOverlayInteraction()

        } catch (e: Exception) {

            e.printStackTrace()

            overlayView = null
            overlayParams = null
            isVisible = false
        }
    }

    // =========================================
    // TOUCH AND DRAG
    // =========================================

    private fun setupOverlayInteraction() {

        val root = overlayView ?: return

        val orb =
            root.findViewById<FrameLayout>(
                R.id.orbContainer
            )

        val close =
            root.findViewById<ImageView>(
                R.id.closeOverlayBtn
            )

        val anime =
            root.findViewById<Anime3DAssistantView>(
                R.id.overlayAnimeView
            )

        // Close button

        close?.setOnClickListener {
            hideOverlay()
        }

        // One shared listener for WebView and container.
        // Returning false allows WebView touch events
        // to continue to the HTML / Three.js code.

        val dragListener =
            View.OnTouchListener { view, event ->

                val params =
                    overlayParams
                        ?: return@OnTouchListener false

                when (event.actionMasked) {

                    MotionEvent.ACTION_DOWN -> {

                        downX = event.rawX
                        downY = event.rawY

                        startX = params.x
                        startY = params.y

                        moved = false

                        // Do not consume the touch.
                        // WebView must receive ACTION_DOWN.

                        false
                    }

                    MotionEvent.ACTION_MOVE -> {

                        val dx =
                            event.rawX - downX

                        val dy =
                            event.rawY - downY

                        if (
                            abs(dx) > touchSlop ||
                            abs(dy) > touchSlop
                        ) {
                            moved = true
                        }

                        if (moved) {

                            val metrics = DisplayMetrics()

                            @Suppress("DEPRECATION")
                            if (Build.VERSION.SDK_INT >=
                                Build.VERSION_CODES.R
                            ) {

                                val bounds =
                                    windowManager
                                        ?.currentWindowMetrics
                                        ?.bounds

                                if (bounds != null) {

                                    val screenWidth =
                                        bounds.width()

                                    val screenHeight =
                                        bounds.height()

                                    params.x =
                                        (startX + dx.toInt())
                                            .coerceIn(
                                                0,
                                                (screenWidth -
                                                        root.width)
                                                    .coerceAtLeast(0)
                                            )

                                    params.y =
                                        (startY + dy.toInt())
                                            .coerceIn(
                                                0,
                                                (screenHeight -
                                                        root.height)
                                                    .coerceAtLeast(0)
                                            )

                                }

                            } else {

                                @Suppress("DEPRECATION")
                                windowManager?.defaultDisplay
                                    ?.getMetrics(metrics)

                                params.x =
                                    (startX + dx.toInt())
                                        .coerceIn(
                                            0,
                                            (metrics.widthPixels -
                                                    root.width)
                                                .coerceAtLeast(0)
                                        )

                                params.y =
                                    (startY + dy.toInt())
                                        .coerceIn(
                                            0,
                                            (metrics.heightPixels -
                                                    root.height)
                                                .coerceAtLeast(0)
                                        )
                            }

                            try {

                                windowManager?.updateViewLayout(
                                    root,
                                    params
                                )

                            } catch (e: Exception) {

                                e.printStackTrace()
                            }
                        }

                        // Let the WebView receive MOVE too.
                        false
                    }

                    MotionEvent.ACTION_UP -> {

                        if (!moved) {

                            openMainActivity()
                        }

                        false
                    }

                    MotionEvent.ACTION_CANCEL -> {

                        false
                    }

                    else -> false
                }
            }

        // Container handles touches outside the WebView
        orb?.setOnTouchListener(dragListener)

        // WebView handles touches directly on the avatar
        anime?.setOnTouchListener(dragListener)

        anime?.setState(
            false,
            false
        )
    }

    // =========================================
    // OPEN MAIN ACTIVITY
    // =========================================

    private fun openMainActivity() {

        try {

            val intent =
                Intent(
                    this,
                    MayaActivity::class.java
                ).apply {

                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                }

            startActivity(intent)

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

    // =========================================
    // HIDE OVERLAY
    // =========================================

    fun hideOverlay() {

        overlayView?.let { view ->

            try {

                windowManager?.removeView(view)

            } catch (_: Exception) {
            }
        }

        overlayView = null
        overlayParams = null

        isVisible = false
    }

    // =========================================
    // NOTIFICATION CHANNEL
    // =========================================

    private fun createNotificationChannel() {

        if (Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val channel = NotificationChannel(
                CHANNEL_ID,
                "MYRA Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {

                description =
                    "MYRA floating assistant"

                setShowBadge(false)
            }

            getSystemService(
                NotificationManager::class.java
            ).createNotificationChannel(channel)
        }
    }

    // =========================================
    // FOREGROUND NOTIFICATION
    // =========================================

    private fun buildNotification(): Notification {

        val intent =
            Intent(
                this,
                MayaActivity::class.java
            )

        val pi =
            PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
            )

        return NotificationCompat.Builder(
            this,
            CHANNEL_ID
        )
            .setContentTitle("MYRA AI • Online")
            .setContentText("MYRA is ready.")
            .setSmallIcon(
                R.drawable.ic_myra_notif
            )
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(
                NotificationCompat.PRIORITY_LOW
            )
            .build()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    override fun onDestroy() {

        isRunning = false

        hideOverlay()

        super.onDestroy()
    }
}