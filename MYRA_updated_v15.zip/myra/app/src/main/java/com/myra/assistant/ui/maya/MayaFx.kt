package com.myra.assistant.ui.maya

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.lifecycle.Observer
import com.myra.assistant.ai.EmotionEngine
import com.myra.assistant.utils.Constants
import com.myra.assistant.voice.VoiceStateManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Living background for the home screen: a soft aura behind Maya whose colour follows her feeling,
 * rings that pulse out while she listens / speaks, and slow floating light particles.
 * One infinite transition drives everything, so it stays smooth and cheap.
 */
@Composable
fun MayaAmbientFx(modifier: Modifier = Modifier.fillMaxSize()) {
    var emotion by remember { mutableStateOf("neutral") }
    var voice by remember { mutableStateOf(Constants.STATE_IDLE) }
    DisposableEffect(Unit) {
        val e = Observer<String> { emotion = it ?: "neutral" }
        val v = Observer<String> { voice = it ?: Constants.STATE_IDLE }
        EmotionEngine.current.observeForever(e)
        VoiceStateManager.state.observeForever(v)
        onDispose { EmotionEngine.current.removeObserver(e); VoiceStateManager.state.removeObserver(v) }
    }

    val tint = when (emotion) {
        "happy" -> Color(0xFFFFB84D)
        "sad" -> Color(0xFF6C8CD5)
        "angry" -> Color(0xFFE5484D)
        "surprised" -> Color(0xFF38C7E8)
        "relaxed" -> Color(0xFF52C9A0)
        "love" -> Color(0xFFFF6FA5)
        "worried" -> Color(0xFF9B7FE6)
        "sleepy" -> Color(0xFF7A84B8)
        else -> Color(0xFF3B8EEA)
    }
    val active = voice == Constants.STATE_LISTENING || voice == Constants.STATE_SPEAKING
    val speaking = voice == Constants.STATE_SPEAKING

    val t by rememberInfiniteTransition(label = "fx").animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0f, 1f, infiniteRepeatable(tween(if (speaking) 1100 else 1900, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )

    Canvas(modifier) {
        val w = size.width; val h = size.height
        val centre = Offset(w / 2f, h * 0.36f)

        // breathing aura in the feeling's colour
        val breathe = 0.5f + 0.5f * sin(t * 2f * PI.toFloat() * 3f)
        val r = w * (0.62f + 0.06f * breathe)
        drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = 0.30f + 0.10f * breathe), Color.Transparent), centre, r), r, centre)

        // pulse rings while she listens / speaks
        if (active) {
            for (k in 0..2) {
                val p = (pulse + k / 3f) % 1f
                val rr = w * (0.22f + 0.40f * p)
                drawCircle(tint.copy(alpha = (1f - p) * 0.35f), rr, centre, style = Stroke(width = 3f + 5f * (1f - p)))
            }
        }

        // floating particles (fixed seeds, so no allocation of state per frame)
        for (i in 0 until 22) {
            val seed = i * 0.6180339f
            val phase = (t + seed) % 1f
            val x = w * ((seed * 7.3f) % 1f) + sin((phase * 2f * PI.toFloat()) + i) * w * 0.03f
            val y = h * (1.05f - phase * 1.15f)
            val size = 2.5f + (i % 4) * 1.8f
            val a = sin(phase * PI.toFloat()).coerceIn(0f, 1f) * 0.45f
            drawCircle(tint.copy(alpha = a), size, Offset(x, y))
            drawCircle(tint.copy(alpha = a * 0.25f), size * 3f, Offset(x, y))
        }
    }
}
