package com.myra.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** What to say for one phone event, in each language we might be able to speak. */
data class Say(val bn: String, val roman: String, val en: String)

/**
 * On-device voice. Works with no internet at all.
 * Picks Bangla if the phone has a Bangla voice, otherwise Hindi/English in Roman letters.
 */
object LocalSpeaker {
    private const val TAG = "LOCAL_SPEAKER"
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var bangla = false
    @Volatile var busy = false
        private set
    /** When the last on-device speech ended (SystemClock.elapsedRealtime), used to ignore our own echo. */
    @Volatile var lastEndAt = 0L
        private set
    private val waiters = ConcurrentHashMap<String, () -> Unit>()

    fun init(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        tts = TextToSpeech(app) { status ->
            if (status != TextToSpeech.SUCCESS) { Logger.e(TAG, "TTS init failed"); return@TextToSpeech }
            val t = tts ?: return@TextToSpeech
            val choices = listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("hi", "IN"), Locale("en", "IN"), Locale.ENGLISH)
            for (l in choices) {
                val r = t.setLanguage(l)
                if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                    bangla = l.language == "bn"
                    break
                }
            }
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { VoiceStateManager.setSpeaking() }
                override fun onDone(id: String?) { finish(id) }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish(id) }
                override fun onError(id: String?, errorCode: Int) { finish(id) }
            })
            ready = true
            Logger.d(TAG, "TTS ready, bangla=$bangla")
        }
    }

    private fun finish(id: String?) {
        busy = false
        lastEndAt = android.os.SystemClock.elapsedRealtime()
        // hand the mic back exactly as the voice service wants it
        val svc = ForegroundVoiceService.instance
        if (svc != null && svc.isMicEnabled()) VoiceStateManager.setListening() else VoiceStateManager.setIdle()
        id?.let { waiters.remove(it)?.invoke() }
    }

    /** Speaks and suspends until finished (or 15 s). Returns false if no voice is available. */
    suspend fun speak(context: Context, say: Say): Boolean {
        init(context)
        var waited = 0
        while (!ready && waited < 3000) { kotlinx.coroutines.delay(100); waited += 100 }
        val t = tts
        if (!ready || t == null) return false
        val id = "evt_${System.nanoTime()}"
        val text = if (bangla) say.bn else say.roman
        busy = true
        val done = withTimeoutOrNull(15_000) {
            suspendCancellableCoroutine<Unit> { cont ->
                waiters[id] = { if (cont.isActive) cont.resume(Unit) }
                val r = t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
                if (r != TextToSpeech.SUCCESS) { waiters.remove(id); busy = false; if (cont.isActive) cont.resume(Unit) }
            }
        }
        if (done == null) { waiters.remove(id); busy = false }
        return true
    }

    fun stopNow() {
        try { tts?.stop() } catch (_: Exception) {}
        busy = false
    }
}
