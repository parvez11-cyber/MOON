package com.myra.assistant.voice

import android.content.Context
import android.os.SystemClock
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * The ONE place phone events are spoken from, so the user never hears two voices.
 *
 *  - Online and Maya's live session is connected  -> Maya says it herself (natural voice).
 *  - Otherwise (offline, or session not up)       -> on-device voice.
 *  Never both. Same event inside a few seconds is dropped. Events are spoken one at a time and
 *  wait while Maya is already talking.
 */
object Announcer {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val lock = Mutex()
    private val last = HashMap<String, Long>()

    fun announce(
        context: Context, key: String, say: Say, dedupeMs: Long = 4000,
        modelPrompt: String? = null, respectEventsSwitch: Boolean = true
    ) {
        val app = context.applicationContext
        if (respectEventsSwitch && !app.prefs().getBoolean(Constants.KEY_ANNOUNCE_EVENTS, true)) return
        val now = SystemClock.elapsedRealtime()
        synchronized(last) {
            val prev = last[key]
            if (prev != null && now - prev < dedupeMs) return
            last[key] = now
        }
        scope.launch {
            lock.withLock {
                // wait for any current speech to end
                var waited = 0
                while ((VoiceStateManager.isAiSpeaking() || LocalSpeaker.busy) && waited < 10_000) { delay(150); waited += 150 }

                val svc = ForegroundVoiceService.instance
                val asked = if (svc == null) false else if (modelPrompt != null) svc.askModelRaw(modelPrompt) else svc.askModelToSay(say.en)
                if (asked) {
                    // let her start, then wait until she is done before the next event
                    delay(1200)
                    var w = 0
                    while (VoiceStateManager.isAiSpeaking() && w < 10_000) { delay(150); w += 150 }
                } else {
                    LocalSpeaker.speak(app, say)
                }
            }
        }
    }
}
