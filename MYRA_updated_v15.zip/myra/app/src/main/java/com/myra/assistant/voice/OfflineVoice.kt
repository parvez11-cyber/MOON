package com.myra.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Bundle
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs

/**
 * Fallback listener for when there is no internet. Uses the phone's own speech recognition
 * (offline language pack) so basic phone commands still work. The voice service switches it on
 * only while Gemini is unreachable and off again the moment the connection is back, so the two
 * never fight over the microphone.
 */
class OfflineVoice(context: Context, private val onText: (String) -> Unit) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    @Volatile var active = false
        private set

    fun start() {
        if (active) return
        active = true
        main.post { listen() }
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        main.post {
            try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
            rec = null
        }
    }

    private fun listen() {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            Logger.e("OFFLINE_VOICE", "no recognizer on this phone")
            active = false
            return
        }
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { VoiceStateManager.setListening() }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) { VoiceStateManager.updateAmplitude(((rmsdB + 2f) / 12f)) }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { VoiceStateManager.setThinking() }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onResults(results: Bundle?) {
                        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList<String>()
                        VoiceStateManager.setListening()
                        for (t in list) if (t.isNotBlank()) { onText(t); break }
                        again(250)
                    }
                    override fun onError(error: Int) {
                        when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { active = false; return }
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> again(1500)
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(200)
                            else -> again(1200)
                        }
                    }
                })
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, app.prefs().getString("offline_lang", "bn-BD"))
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
            }
            rec?.startListening(i)
        } catch (e: Exception) {
            Logger.e("OFFLINE_VOICE", "listen failed: ${e.message}")
            again(2000)
        }
    }

    private fun again(delayMs: Long) {
        if (active) main.postDelayed({ listen() }, delayMs)
    }
}
