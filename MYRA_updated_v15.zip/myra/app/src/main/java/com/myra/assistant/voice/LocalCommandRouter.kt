package com.myra.assistant.voice

import android.content.Context
import com.myra.assistant.apps.InstalledAppsManager

/**
 * Understands the everyday phone commands on the device itself (Bangla, Banglish, Hindi, English),
 * so they run instantly: no network round trip, and they also work offline.
 *
 * Deliberately strict: only short, clear commands match. Anything else returns null and is left to
 * Gemini. Returns the same structured command string the rest of the app already understands.
 */
object LocalCommandRouter {

    private val FILLER = setOf(
        "maya", "myra", "মায়া", "মাইরা", "please", "plz", "pls", "প্লিজ", "ভাই", "bhai", "ek", "ekta", "একটু", "একটা",
        "zara", "jara", "ji", "জি", "na", "না", "to", "তো", "hey", "hi", "ok", "okay", "দাও", "dao", "do", "de", "দে", "দিন", "dijiye"
    )
    private val DOERS = setOf("koro", "karo", "kar", "kro", "করো", "কর", "করুন", "করে", "kijiye", "kijie")

    private val TORCH = listOf("torch", "flashlight", "flash light", "tarch", "টর্চ", "ফ্ল্যাশলাইট", "ফ্ল্যাশ লাইট", "टॉर्च")
    private val ON = listOf(" on", "chalu", "jalao", "jalaw", "jalo", "jala", "চালু", "জ্বালাও", "জ্বালিয়ে", "জ্বেলে", "জ্বাল", "অন", "চালাও", "चालू", "जलाओ")
    private val OFF = listOf(" off", "band", "bondho", "bondo", "nibhao", "nivao", "বন্ধ", "নিভাও", "নিভিয়ে", "অফ", "बंद", "बन्द")
    private val VOL = listOf("volume", "ভলিউম", "আওয়াজ", "awaj", "awaz", "sound", "শব্দ", "আওয়াজ", "वॉल्यूम", "आवाज")
    private val UP = listOf(" up", "badhao", "barao", "baro", "বাড়াও", "বাড়িয়ে", "বেশি", "zyada", "jyada", "increase", "louder", "tez", "बढ़ाओ", "बढ़ा")
    private val DOWN = listOf(" down", "kam", "komao", "কমাও", "কমিয়ে", "কম", "decrease", "lower", "dhire", "ধীরে", "कम")

    private val HOME = setOf("home", "go home", "home jao", "home chalo", "হোম", "হোমে যাও", "হোমে চলো", "হোমে নাও", "होम", "घर जाओ")
    private val BACK = setOf("back", "go back", "back jao", "peeche jao", "pichhe jao", "ব্যাক", "পিছনে যাও", "পেছনে যাও", "ফিরে যাও", "वापस जाओ", "पीछे जाओ")
    private val RECENTS = setOf("recent", "recents", "recent apps", "recent app", "রিসেন্ট", "রিসেন্ট অ্যাপ", "রিসেন্ট অ্যাপস", "सेंट")

    private val OPEN_PREFIX = listOf("open ", "launch ", "start ", "খোলো ", "ওপেন ")
    private val OPEN_SUFFIX = listOf(
        " kholo", " khulo", " khol", " kholiye", " open", " chalao", " chalu", " chalu karo", " launch",
        " খোলো", " খুলো", " খুলুন", " খুলে", " ওপেন", " চালাও", " চালু", " খোল", " खोलो", " खोल", " चलाओ"
    )

    private val ALIAS = mapOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটসঅ্যাপে" to "whatsapp", "ইউটিউব" to "youtube", "ফেসবুক" to "facebook",
        "মেসেঞ্জার" to "messenger", "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "গ্যালারী" to "gallery",
        "সেটিংস" to "settings", "সেটিং" to "settings", "ক্রোম" to "chrome", "গুগল" to "google", "জিমেইল" to "gmail",
        "টেলিগ্রাম" to "telegram", "ইনস্টাগ্রাম" to "instagram", "টিকটক" to "tiktok", "স্পটিফাই" to "spotify",
        "ম্যাপস" to "maps", "ম্যাপ" to "maps", "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock", "ফোন" to "phone",
        "মেসেজ" to "messages", "বিকাশ" to "bkash", "নগদ" to "nagad", "व्हाट्सएप" to "whatsapp"
    )

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Strips Maya's name, politeness words and "karo" so "maya torch on karo please" becomes "torch on". */
    private fun clean(s: String): String =
        norm(s).split(' ').filter { it.isNotEmpty() && it !in FILLER && it !in DOERS }.joinToString(" ")

    fun match(context: Context, raw: String): String? {
        val t0 = clean(raw)
        if (t0.isEmpty()) return null
        val t = " $t0"
        if (t0.split(' ').size > 6) return null

        // torch
        if (TORCH.any { t.contains(it) }) {
            return when {
                OFF.any { t.contains(it) } -> "FLASHLIGHT_OFF"
                ON.any { t.contains(it) } -> "FLASHLIGHT_ON"
                else -> null
            }
        }
        // volume
        if (VOL.any { t.contains(it) }) {
            return when {
                UP.any { t.contains(it) } -> "VOLUME_UP"
                DOWN.any { t.contains(it) } -> "VOLUME_DOWN"
                else -> null
            }
        }
        // navigation: only when that is the whole sentence
        if (t0 in HOME) return "HOME"
        if (t0 in BACK) return "BACK"
        if (t0 in RECENTS) return "RECENTS"

        // open <app> / <app> kholo
        var app: String? = null
        for (p in OPEN_PREFIX) if (t0.startsWith(p)) { app = t0.removePrefix(p); break }
        if (app == null) for (sfx in OPEN_SUFFIX) {
            val s = sfx.trim()
            if (t0.endsWith(" $s")) { app = t0.removeSuffix(" $s"); break }
        }
        if (app != null) {
            val name = app.trim().split(' ').joinToString(" ") { ALIAS[it] ?: it }.trim()
            if (name.isEmpty() || name.split(' ').size > 3) return null
            // only claim it if the app really exists on this phone, otherwise let Gemini sort it out
            val found = InstalledAppsManager.findApp(context, name) ?: return null
            if (!(found.name.contains(name) || name.contains(found.name))) return null
            return "OPEN_APP $name"
        }
        return null
    }

    /** Same action = same key, so a command that ran locally is not run again when Gemini sends it too. */
    fun keyOf(command: String): String {
        val c = command.trim()
        val head = c.substringBefore(' ').uppercase()
        // commands that carry their own content (a message, a target) are keyed by that content,
        // so two different SMS in one go are both sent, while the same one is never sent twice
        val withArgs = setOf("OPEN_APP", "SMS", "WHATSAPP_MSG", "REPLY_NOTIFICATION", "REPLY_NOTIFICATION_TO", "SYSTEM", "BRIGHTNESS", "CALL", "WHATSAPP_CALL")
        return if (head in withArgs) head + " " + c.substringAfter(' ', "").lowercase().trim() else head
    }
}
