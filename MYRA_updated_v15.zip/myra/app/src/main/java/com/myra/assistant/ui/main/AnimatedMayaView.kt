package com.myra.assistant.ui.main

import android.content.Context
import android.util.AttributeSet
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.widget.AppCompatImageView
import com.myra.assistant.R

/** Small Maya character with lightweight idle/listening/speaking motion. */
class AnimatedMayaView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    private var animatorRunning = false

    init {
        setImageResource(R.drawable.myra_anime)
        scaleType = ScaleType.FIT_CENTER
        adjustViewBounds = true
        alpha = 0.98f
    }

    fun startMayaAnimation() {
        if (animatorRunning) return
        animatorRunning = true
        animate().cancel()
        animate()
            .translationY(-5f)
            .rotation(-1.2f)
            .setDuration(900)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                animate()
                    .translationY(2f)
                    .rotation(1.2f)
                    .setDuration(900)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .withEndAction { if (animatorRunning) startMayaAnimation() }
                    .start()
            }
            .start()
    }

    fun setAssistantState(listening: Boolean, speaking: Boolean) {
        val scale = when {
            speaking -> 1.06f
            listening -> 1.03f
            else -> 1f
        }
        animate().scaleX(scale).scaleY(scale).setDuration(220).start()
        alpha = if (listening || speaking) 1f else 0.96f
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startMayaAnimation()
    }

    override fun onDetachedFromWindow() {
        animatorRunning = false
        animate().cancel()
        super.onDetachedFromWindow()
    }
}
