# MYRA ProGuard rules
