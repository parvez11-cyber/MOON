package com.myra.assistant.ui.maya

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.launch

@Composable
fun MayaLogo(size: Int = 56) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF05070F))
            .border(1.dp, MC.Accent, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) { Text("MAYA", color = Color(0xFF7FB2FF), fontSize = (size / 5).sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun Pill(done: Boolean) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (done) MC.DoneBg else MC.PendingBg)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(if (done) "Allowed" else "Pending", color = if (done) MC.DoneFg else MC.PendingFg,
            fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DarkRow(icon: ImageVector, title: String, desc: String, done: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MC.DarkCard)
            .border(1.dp, MC.DarkBorder, RoundedCornerShape(20.dp)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF1F2B52)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MC.Accent)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = MC.DarkText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = MC.DarkSub, fontSize = 15.sp, lineHeight = 21.sp)
        }
        Spacer(Modifier.width(8.dp))
        Pill(done)
    }
}

@Composable
private fun DarkButton(text: String, icon: ImageVector, enabled: Boolean, filled: Boolean, onClick: () -> Unit) {
    val bg = when { filled && enabled -> MC.Accent; else -> Color.Transparent }
    val fg = if (enabled) Color.White else MC.DarkSub
    Row(
        Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(30.dp))
            .background(if (!enabled) MC.DarkCard else bg)
            .then(if (!filled && enabled) Modifier.border(1.dp, MC.DarkBorder, RoundedCornerShape(30.dp)) else Modifier)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = fg, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    var step by rememberSaveable { mutableIntStateOf(1) }
    var tick by remember { mutableIntStateOf(0) } // bumps on resume so statuses refresh
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }

    Column(Modifier.fillMaxSize().background(MC.DarkBg).statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            MayaLogo(56)
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Set up Maya", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Step $step of 3", color = MC.DarkSub, fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            repeat(3) { i ->
                Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (i < step) MC.Accent else MC.DarkBorder))
            }
        }
        Spacer(Modifier.height(28.dp))
        when (step) {
            1 -> KeyStep(prefs.getString(Constants.KEY_API_KEY, "").orEmpty().isNotEmpty(),
                onSave = { prefs.edit().putString(Constants.KEY_API_KEY, it.trim()).apply(); step = 2 },
                onSkip = { step = 2 })
            2 -> PermStep(tick) { step = 3 }
            else -> BgStep(tick) { prefs.edit().putBoolean("onboarded", true).apply(); onDone() }
        }
    }
}

@Composable
private fun ColumnScope.KeyStep(hasKey: Boolean, onSave: (String) -> Unit, onSkip: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val valid = key.trim().length > 20 && (key.trim().startsWith("AQ") || key.trim().startsWith("AIza"))

    Text("Add your Gemini key", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Text("Maya's voice and brain run on Google's Gemini. Without a key she cannot hear you or answer. The key is free and takes about a minute.",
        color = MC.DarkSub, fontSize = 18.sp, lineHeight = 26.sp)
    Spacer(Modifier.height(18.dp))
    listOf(
        "Tap \"Get a free key\" — Google AI Studio opens. Sign in with any Google account.",
        "Tap \"Create API key\", pick any project, and copy the key. It starts with \"AQ.\" (older keys start with \"AIza\").",
        "Come back and paste it below — the key itself, not your name or email."
    ).forEachIndexed { i, t ->
        Row(Modifier.padding(vertical = 7.dp)) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF1F2B52)), contentAlignment = Alignment.Center) {
                Text("${i + 1}", color = MC.Accent, fontSize = 14.sp)
            }
            Spacer(Modifier.width(14.dp))
            Text(t, color = Color(0xFFE6EAF5), fontSize = 18.sp, lineHeight = 26.sp)
        }
    }
    Spacer(Modifier.height(14.dp))
    DarkButton("Get a free key", Icons.Outlined.OpenInNew, true, false) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    Spacer(Modifier.height(18.dp))
    Row(
        Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(16.dp)).background(MC.DarkCard)
            .border(1.dp, MC.DarkBorder, RoundedCornerShape(16.dp)).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (key.isEmpty()) Text("AQ....", color = MC.DarkSub, fontSize = 19.sp)
            BasicTextField(key, { key = it; status = "" }, singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 19.sp),
                cursorBrush = SolidColor(Color.White),
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth())
        }
        Icon(if (show) Icons.Filled.LockOpen else Icons.Filled.Lock, null, tint = MC.DarkSub,
            modifier = Modifier.size(26.dp).clickable { show = !show })
    }
    Spacer(Modifier.height(12.dp))
    DarkButton(if (busy) "Testing…" else "Test key", Icons.Outlined.Refresh, valid && !busy, false) {
        busy = true
        scope.launch { status = if (GeminiChat.testKey(key)) "✓ Key works" else "✗ Key rejected — check and paste again"; busy = false }
    }
    if (status.isNotEmpty()) Text(status, color = if (status.startsWith("✓")) MC.DoneFg else MC.PendingFg,
        fontSize = 16.sp, modifier = Modifier.padding(top = 10.dp))
    Spacer(Modifier.height(14.dp))
    Text("The key is free. It is stored encrypted and used only to run Maya for you.", color = MC.DarkSub, fontSize = 17.sp)
    Spacer(Modifier.weight(1f))
    DarkButton("Save & continue", Icons.Filled.ArrowForward, valid, true) { onSave(key) }
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.Center) {
        Text("Added a key on this phone before? ", color = MC.DarkSub, fontSize = 17.sp)
        Text("Skip", color = if (hasKey) Color.White else MC.DarkSub, fontSize = 17.sp,
            modifier = Modifier.clickable(enabled = hasKey, onClick = onSkip))
    }
}

private val permIcons = listOf(Icons.Filled.Mic, Icons.Filled.Notifications, Icons.Filled.PhotoCamera, Icons.Filled.Call,
    Icons.Filled.Contacts, Icons.Filled.Sms, Icons.Filled.LocationOn, Icons.Filled.PhotoLibrary,
    Icons.Filled.Headset, Icons.Filled.Bluetooth)

@Composable
private fun ColumnScope.PermStep(tick: Int, onContinue: () -> Unit) {
    val ctx = LocalContext.current
    val items = remember { Perms.runtimeItems() }
    var refresh by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh++ }
    val micOk = remember(tick, refresh) { Perms.granted(ctx, items[0]) }

    Text("Let Maya use your phone", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Text("One tap — Android asks for each in turn. Only the microphone is required; the rest make her useful.",
        color = MC.DarkSub, fontSize = 18.sp, lineHeight = 26.sp)
    Spacer(Modifier.height(18.dp))
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEachIndexed { i, it ->
            DarkRow(permIcons[i], it.title, it.desc, tick >= 0 && refresh >= 0 && (Perms.granted(ctx, it) || it.perms.isEmpty())) {
                if (it.perms.isNotEmpty()) launcher.launch(it.perms.toTypedArray())
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    DarkButton("Allow all", Icons.Filled.Check, true, true) {
        val missing = items.filter { !Perms.granted(ctx, it) }.flatMap { it.perms }.distinct()
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }
    Spacer(Modifier.height(12.dp))
    DarkButton("Continue", Icons.Filled.ArrowForward, micOk, false, onContinue)
    Text(if (micOk) "" else "Continue unlocks once the microphone is allowed.", color = MC.DarkSub, fontSize = 17.sp,
        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
}

@Composable
private fun ColumnScope.BgStep(tick: Int, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val rows = listOf(
        Triple("Battery — no optimisation", "Required. Without it the phone kills Maya in the background and she goes quiet. Tap, then choose Allow.", Icons.Filled.BatteryChargingFull) to Perms.batteryOk(ctx),
        Triple("Display over other apps", "So her orb can float on top of whatever you are doing.", Icons.Filled.Layers) to Perms.overlayOk(ctx),
        Triple("Notification access", "To read WhatsApp messages and know who is calling. Turn on \"Maya\" in the list.", Icons.Filled.Notifications) to Perms.notifAccessOk(ctx),
        Triple("Accessibility service", "So she can open apps, tap, and read the screen for you. Turn on \"Maya\" in the list.", Icons.Filled.Accessibility) to Perms.accessibilityOk(ctx),
        Triple("Default assistant", "Long-press the power button or swipe from a corner to call her, even on the lock screen. Pick \"MAYA\".", Icons.Filled.Headset) to Perms.assistantOk(ctx)
    )
    Text("Keep Maya alive in the background", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Text("Battery is required — it is what stops her going quiet when the screen is off. The rest are optional but make her far more useful.",
        color = MC.DarkSub, fontSize = 18.sp, lineHeight = 26.sp)
    Spacer(Modifier.height(18.dp))
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEachIndexed { i, (t, done) ->
            DarkRow(t.third, t.first, t.second, done) { Perms.open(ctx, i) }
        }
        Text("Tap a Pending row to open its system screen — come back here when you are done. You can change any of them later in Settings → Advanced → Permissions.",
            color = MC.DarkSub, fontSize = 17.sp, lineHeight = 25.sp, modifier = Modifier.padding(top = 6.dp))
    }
    val ok = rows[0].second
    Spacer(Modifier.height(12.dp))
    DarkButton("Finish", Icons.Filled.Check, ok, true, onFinish)
    Text(if (ok) "" else "Finish unlocks once battery optimisation is off for Maya — tap the Battery row.",
        color = MC.DarkSub, fontSize = 17.sp, textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
}
