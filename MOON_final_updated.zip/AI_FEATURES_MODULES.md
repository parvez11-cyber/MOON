# Notun AI module (Dialog, Zero-shot, Adaptive learning, Workload balance)

Sob kichu phone-e cholbe (SharedPreferences), kono notun dependency nei, internet lage na.

| Feature | File | Ki kore |
|---|---|---|
| Advanced dialog management | `ai/DialogManager.kt` | "call" -> "Kake call korbo?" -> naam -> `CALL naam`. "abar", "ar ektu", "ke call dao", "thak". Risky command repeat korle age confirm chay. |
| Zero-shot learning capability | `ai/ZeroShotIntentResolver.kt` | Notun/ochena phrase ("alo jalao", "kaj onek beshi") description-er sathe milie command bujhe. Training lage na. `register(Intent(...))` diye runtime-e notun capability. |
| Automated adaptive learning | `ai/AdaptiveLearner.kt` | Kon guess thik/vul seta shikhe score bariye/komay (shomoy onujayi), 2 bar ek-i bhabe bujhle alias hoye jay. Risky command (SMS, call, tap, system...) kokhono alias hoy na. |
| Automatic workload balance | `ai/WorkloadBalancer.kt` | `TaskStore` er kaj-er chap mape, tarikh-chhara kaj halka dine boshay, bhari din-er age-r din-e shuru korar poramorsho dey, ar busy thakle proactive kotha kom bole. Deadline nijer theke bodlay na. |
| Proactive suggestion engine | `ProactiveCompanion.kt` (agei chilo) + `WorkloadBalancer.nudge` | Overloaded din-e ek bar offer: "kichu kaj soriye dii?" |
| Predictive AI | `PredictiveEngine.kt` (agei chilo) | Ekhon `AdaptiveLearner` er sathe clear hoy. |
| Multi-modal interaction | `screenvision/` (agei chilo) | Voice + screen/OCR + text agei ache; notun route `AiHub` shob input-e kaj kore. |
| Glue | `ai/AiHub.kt`, `ai/AiText.kt` | Order: feedback -> WORKLOAD -> Dialog -> alias -> rules -> zero-shot -> Gemini. |

## Je file gulo bodlano hoyeche
- `viewmodel/MainViewModel.kt`: `processCommand` ekhon age `AiHub.route` chalay.
- `services/ForegroundVoiceService.kt`: `runCommand`-e `AiHub.onExecuted` (last command / last contact mone rakhe).
- `ai/ProactiveCompanion.kt`: busy dine gap boro, kaj-er chape chup, overload hole din-e ek bar nudge.
- `ai/PredictiveEngine.kt`: `clearAll` ekhon learning-o muche dey.

## Commands (voice / chat)
`WORKLOAD` (chap koto), `WORKLOAD plan` (poramorsho), `WORKLOAD apply` (tarikh-chhara kaj boshiye dao).

## Settings keys (`myra_prefs`)
- `workload_capacity_min` (240): ek dine koto minute kaj dhorbe.
- `dialog_confirm_risky` (false): true korle SMS/CALL/TAP/SYSTEM-er age "pathiye debo?" jiggesh korbe (`DialogManager.guard` diye).

## Jante rakho
- Ami compile korte parini (ei environment-e Android SDK/Kotlin nai). Android Studio-te Build kore error ashle pathao.
- Voice-e jodi Gemini nijei phone_action call kore, tahole `AiHub.route` shudhu typed/`MainViewModel` path-e ashe. Voice path-e `AiHub.route(this, text)` `ForegroundVoiceService`-er jekhane user text paoa jay sekhane boshalei dialog/zero-shot oikhaneo kaj korbe.

---

# Performance + Focus package (`perf/`)

| Feature | File | Ki kore |
|---|---|---|
| Smart Resource / Dynamic Resource Allocator | `perf/DeviceState.kt`, `perf/DynamicResourceAllocator.kt` | Battery, charge, power-saver, tap (thermal), free RAM, network dekhe profile (FULL / BALANCED / ECO / CRITICAL) ar budget ThikThak kore: koyta background job, image-er size, proactive kotha-r gap, screen-watch speed, cache size. |
| Real-time Latency Optimizer | `perf/LatencyOptimizer.kt` | Gemini round-trip ar command-er somoy mape (p50/p95), `adaptiveTimeout()`, slow hole allocator chhoto image pathay. |
| AI Neural Processing Unit Optimizer | `perf/NpuOptimizer.kt` | On-device model NPU/GPU/CPU-r kon-te chalabe seta bachhe, fail korle porer backend-e fallback, 3 bar fail korle 10 min bondho. **Ekhon app-e kono on-device NN model nei**, tai eta ekta selection layer: `NpuOptimizer.run(ctx, Workload.VISION, mapOf(Backend.NPU to {..}, Backend.CPU to {..}))`. |
| Predictive Cache Pre-warmer | `perf/PredictiveCachePrewarmer.kt` | `PredictiveEngine`-er habit dekhe app-package, contact ar Gemini DNS age-i cache kore rakhe. `appPackage()` / `contact()` diye cache theke pora jay. |
| Smart Background Task Optimizer | `perf/BackgroundTaskOptimizer.kt` | Priority queue: charging / unmetered / battery / heat shorto dekhe job chalay, same name-er job merge hoy, LOW job 30 min por uthe ashe. |
| AI Data Compression | `perf/DataCompressor.kt` | Screenshot-er JPEG size/quality adaptive (ScreenReader e boshano), OCR text-e duplicate line-bad, boro JSON-er jonno GZIP `packText/unpackText`. |
| AI-powered Focus Mode | `perf/FocusMode.kt` | `FOCUS on 45`: proactive kotha ar notification read-aloud bondho (jaruri/OTP/allow-list chhara), shesh-e "3 ta notification chilo: ..." summary. Nijei suggest kore (jaruri task kachhe ba onekkhon ek app), kokhono nijer theke chalu kore na. |
| Glue | `perf/PerfHub.kt` | `PERF` (shob status), `FOCUS ...`, minute-tick. |

## Aro je file gulo bodlano hoyeche
- `ProactiveCompanion.kt`: `PerfHub.init/tick`, focus-e chup, gap x allocator factor, focus suggestion.
- `NotificationReaderService.kt`: focus-e notification held.
- `GeminiLiveClient.kt`: latency mark (send -> first response).
- `ScreenReader.kt`: adaptive JPEG + OCR text squeeze.
- `ScreenWatcher.kt`: interval allocator factor diye barano.
- `ForegroundVoiceService.kt`: `WORKLOAD/FOCUS/PERF` ekhon voice path-e-o cholbe (age WORKLOAD apply voice path-e dhorto na), command-er somoy mapa hoy, system prompt-e command gulo joda holo.
- `ai/AiHub.kt`, `ai/ZeroShotIntentResolver.kt`: FOCUS / PERF route ar zero-shot phrase.

## Settings keys
- `resource_profile`: `auto` (default) | `full` | `balanced` | `eco`
- `focus_allow_pkgs`: focus-e-o jar notification pora hobe tader package, comma diye (e.g. `com.whatsapp,com.google.android.gm`)

## Songkhep-e shotti kotha
- Ei gulo adaptive heuristic ar statistics (p95, moving average, circuit breaker); kono neural model noy. NPU-r shorashori control Android e nei; delegate (LiteRT/NNAPI) lage.
- Ami compile korte parini. Android Studio-te Build kore error pathao.
