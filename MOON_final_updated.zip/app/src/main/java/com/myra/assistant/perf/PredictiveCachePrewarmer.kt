package com.myra.assistant.perf

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.myra.assistant.ai.PredictiveEngine
import com.myra.assistant.utils.ContactResolver
import java.net.InetAddress

/**
 * Predictive cache pre-warmer. [PredictiveEngine] already knows which harmless actions the user repeats around
 * this hour. Shortly before, this module quietly prepares them so they feel instant:
 *
 *  - OPEN_APP x   -> the app label -> package lookup is resolved and cached
 *  - CALL / SMS x -> the contact lookup is resolved and cached
 *  - always       -> one DNS lookup of the Gemini host (the first voice turn skips that wait)
 *
 * Only when the allocator allows it (full, or balanced on an unmetered network), at most once per 10 minutes,
 * and run as a LOW-priority background job. Results sit in a small LRU cache with a TTL.
 * Use [appPackage] / [contact] anywhere to read through the cache.
 */
object PredictiveCachePrewarmer {
    private class Entry(val value: Any?, val expires: Long)
    private val cache = object : LinkedHashMap<String, Entry>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?) = size > maxEntries
    }
    @Volatile private var maxEntries = 64
    @Volatile private var lastWarm = 0L
    @Volatile var hits = 0L; private set
    @Volatile var misses = 0L; private set

    private const val TTL_MS = 30 * 60_000L
    private const val EVERY_MS = 10 * 60_000L
    private const val GEMINI_HOST = "generativelanguage.googleapis.com"

    @Synchronized private fun getRaw(key: String): Entry? = cache[key]?.takeIf { it.expires > System.currentTimeMillis() }
    @Synchronized private fun put(key: String, v: Any?) { cache[key] = Entry(v, System.currentTimeMillis() + TTL_MS) }
    @Synchronized fun clear() { cache.clear(); hits = 0; misses = 0 }
    @Synchronized fun size() = cache.size

    /** "youtube" -> "com.google.android.youtube" (cached). */
    fun appPackage(c: Context, name: String): String? {
        val key = "app:" + name.trim().lowercase()
        getRaw(key)?.let { hits++; return it.value as String? }
        misses++
        val pkg = resolveApp(c, name)
        put(key, pkg)
        return pkg
    }

    fun contact(c: Context, name: String): ContactResolver.Contact? {
        val key = "contact:" + name.trim().lowercase()
        getRaw(key)?.let { hits++; return it.value as ContactResolver.Contact? }
        misses++
        val r = ContactResolver.resolve(c, name)
        put(key, r)
        return r
    }

    private fun resolveApp(c: Context, name: String): String? {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return null
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
        val labelled = apps.map { it.activityInfo.packageName to pm.getApplicationLabel(it.activityInfo.applicationInfo).toString().lowercase() }
        return (labelled.firstOrNull { it.second == q } ?: labelled.firstOrNull { it.second.startsWith(q) }
            ?: labelled.firstOrNull { it.second.contains(q) || it.first.contains(q) })?.first
    }

    /** Runs the warm-up. Cheap and safe to call often; it rate-limits itself. */
    fun warm(c: Context) {
        val b = DynamicResourceAllocator.budget(c)
        if (!b.prewarm) return
        val now = System.currentTimeMillis()
        if (now - lastWarm < EVERY_MS) return
        lastWarm = now
        maxEntries = b.cacheEntries
        for (h in PredictiveEngine.peek(c, 4)) {
            val cmd = h.command.trim()
            val head = cmd.substringBefore(' ').uppercase()
            val arg = cmd.substringAfter(' ', "").substringBefore('|').trim()
            if (arg.isEmpty()) continue
            try {
                when (head) {
                    "OPEN_APP" -> appPackage(c, arg)
                    "CALL", "SMS", "WHATSAPP_CALL" -> if (ContactResolver.granted(c)) contact(c, arg)
                }
            } catch (_: Exception) {}
        }
        try { InetAddress.getByName(GEMINI_HOST) } catch (_: Exception) {}
    }

    fun status() = "Cache: ${size()} entry, hit $hits / miss $misses"
}
