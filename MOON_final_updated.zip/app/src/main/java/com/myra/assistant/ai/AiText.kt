package com.myra.assistant.ai

/** Small text helpers shared by the dialog / zero-shot / learning modules (Bangla, Banglish and English). */
internal object AiText {
    private val PUNCT = Regex("[^\\p{L}\\p{N}\\p{M}\\s_]")
    private val SPACES = Regex("\\s+")

    fun norm(s: String): String = SPACES.replace(PUNCT.replace(s.lowercase(), " "), " ").trim()

    fun tokens(s: String): List<String> = norm(s).split(' ').filter { it.isNotEmpty() }

    fun trigrams(s: String): Set<String> {
        val t = " " + norm(s) + " "
        if (t.length < 3) return setOf(t)
        return (0..t.length - 3).map { t.substring(it, it + 3) }.toSet()
    }

    fun jaccard(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val i = a.intersect(b).size
        return i.toDouble() / (a.size + b.size - i)
    }

    /** Same word, or one is the stem of the other ("barao" / "baraw", "kholo" / "kholon"). */
    fun sameWord(a: String, b: String): Boolean =
        a == b || (a.length >= 4 && b.length >= 4 && (a.startsWith(b) || b.startsWith(a)))

    /** True when [needle] occurs in [hay] as a run of whole words. */
    fun containsRun(hay: List<String>, needle: List<String>): Boolean {
        if (needle.isEmpty() || needle.size > hay.size) return false
        for (i in 0..hay.size - needle.size) {
            if (needle.indices.all { hay[i + it] == needle[it] }) return true
        }
        return false
    }

    /** [hay] with the first run of [needle] removed. */
    fun removeRun(hay: List<String>, needle: List<String>): List<String> {
        if (needle.isEmpty() || needle.size > hay.size) return hay
        for (i in 0..hay.size - needle.size) {
            if (needle.indices.all { hay[i + it] == needle[it] }) return hay.subList(0, i) + hay.subList(i + needle.size, hay.size)
        }
        return hay
    }

    /** Filler words that never carry meaning for a command. */
    val FILLER = setOf(
        "koro", "kor", "dao", "daw", "den", "please", "plz", "to", "ekta", "ekti", "ke", "ki", "the", "a", "an", "me", "my", "amar",
        "করো", "কর", "দাও", "দেন", "একটা", "একটি", "কে", "কি", "কী", "আমার", "প্লিজ", "তো", "ফোন", "টা", "টি"
    )
}
