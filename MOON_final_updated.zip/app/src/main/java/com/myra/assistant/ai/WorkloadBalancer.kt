package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.utils.Constants
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Automatic workload balancing on top of [TaskStore]. It never changes a deadline by itself.
 *
 *  - estimates the effort of every pending task ("30 min", "2 ghonta" in the title, default 30 min)
 *  - measures today's load against a daily capacity (setting "workload_capacity_min", default 240)
 *  - [plan]: undated tasks get a suggested day (SCHEDULE, can be applied); dated tasks on an overloaded day get
 *    a "start earlier" hint on a lighter earlier day (START_EARLIER, advice only - the deadline stays)
 *  - [gapFactor] / [shouldHold]: when you are busy, ProactiveCompanion talks less (longer gaps, silent when
 *    something is due within 3 hours) - so the assistant balances its own interruptions too
 *  - voice / chat: WORKLOAD | WORKLOAD plan | WORKLOAD apply
 */
object WorkloadBalancer {
    private const val HORIZON_DAYS = 7
    private const val DAY_MS = 86_400_000L
    private const val HOUR_MS = 3_600_000L
    private const val DEFAULT_MIN = 30

    enum class Level { LIGHT, NORMAL, HEAVY, OVERLOADED }
    enum class Kind { SCHEDULE, START_EARLIER }

    data class Move(val kind: Kind, val taskId: Long, val title: String, val dayOffset: Int, val reason: String)
    data class Snapshot(val level: Level, val todayMin: Int, val capacityMin: Int, val dueSoon: Int, val perDayMin: List<Int>)
    data class Nudge(val bn: String, val roman: String, val en: String, val prompt: String)

    private val EFFORT = Regex("(\\d+(?:\\.\\d+)?)\\s*(minutes?|mins?|মিনিট|hours?|hrs?|ঘণ্টা|ঘন্টা|ghonta|ghanta)", RegexOption.IGNORE_CASE)

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    private fun capacity(c: Context) = prefs(c).getInt("workload_capacity_min", 240).coerceIn(60, 960)

    fun effortMin(t: TaskStore.Task): Int {
        val m = EFFORT.find(t.title) ?: return DEFAULT_MIN
        val v = m.groupValues[1].toDoubleOrNull() ?: return DEFAULT_MIN
        val u = m.groupValues[2].lowercase()
        val hours = u.startsWith("h") || u.startsWith("ঘ") || u.startsWith("g")
        return (if (hours) v * 60 else v).toInt().coerceIn(5, 480)
    }

    private fun dayStart(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun dayIndex(now: Long, due: Long): Int =
        Math.round((dayStart(due) - dayStart(now)) / DAY_MS.toDouble()).toInt().coerceAtLeast(0)   // overdue counts as today

    private fun pending(c: Context) = TaskStore.all(c).filter { !it.done }

    fun snapshot(c: Context, now: Long = System.currentTimeMillis()): Snapshot {
        val cap = capacity(c)
        val tasks = pending(c)
        val load = IntArray(HORIZON_DAYS)
        tasks.forEach { t -> t.due?.let { d -> val i = dayIndex(now, d); if (i < HORIZON_DAYS) load[i] += effortMin(t) } }
        val ratio = load[0].toDouble() / cap
        val level = when { ratio < 0.4 -> Level.LIGHT; ratio < 0.8 -> Level.NORMAL; ratio < 1.1 -> Level.HEAVY; else -> Level.OVERLOADED }
        val soon = tasks.count { t -> t.due?.let { it < now + 3 * HOUR_MS } == true }
        return Snapshot(level, load[0], cap, soon, load.toList())
    }

    fun plan(c: Context, now: Long = System.currentTimeMillis()): List<Move> {
        val cap = capacity(c)
        val tasks = pending(c)
        val load = IntArray(HORIZON_DAYS)
        val byDay = Array(HORIZON_DAYS) { mutableListOf<TaskStore.Task>() }
        val undated = mutableListOf<TaskStore.Task>()
        tasks.forEach { t ->
            val d = t.due
            if (d == null) undated.add(t)
            else { val i = dayIndex(now, d); if (i < HORIZON_DAYS) { load[i] += effortMin(t); byDay[i].add(t) } }
        }
        val moves = mutableListOf<Move>()
        val hourNow = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)

        // dated tasks on an overloaded day: start earlier (advice only)
        for (i in 1 until HORIZON_DAYS) {
            if (load[i] <= cap) continue
            for (t in byDay[i].sortedByDescending { effortMin(it) }) {
                if (load[i] <= cap) break
                val e = effortMin(t)
                val j = (0 until i).firstOrNull { j -> load[j] + e <= cap && !(j == 0 && hourNow >= 20) } ?: continue
                load[i] -= e; load[j] += e
                moves.add(Move(Kind.START_EARLIER, t.id, t.title, j, "${dayName(i)} e kaj onek beshi, tai ${dayName(j)} e shuru kore dao"))
            }
        }
        // undated tasks: most important first, into the lightest of the next 3 days
        for (t in undated.sortedByDescending { TaskStore.score(it) }) {
            val e = effortMin(t)
            val limit = if (hourNow >= 20) 1..2 else 0..2
            val fit = limit.filter { load[it] + e <= cap }
            val day = (if (fit.isNotEmpty()) fit else limit.toList()).minByOrNull { load[it] } ?: 1
            load[day] += e
            moves.add(Move(Kind.SCHEDULE, t.id, t.title, day, "${dayName(day)} e halka ache (${load[day]} min)"))
        }
        return moves
    }

    /** Gives the SCHEDULE moves a due time (18:00 on the chosen day). Deadlines of dated tasks are never touched. */
    fun apply(c: Context, moves: List<Move>, now: Long = System.currentTimeMillis()): Int {
        var n = 0
        for (m in moves.filter { it.kind == Kind.SCHEDULE }) {
            val old = TaskStore.all(c).firstOrNull { it.id == m.taskId && !it.done && it.due == null } ?: continue
            val due = Calendar.getInstance().apply {
                timeInMillis = dayStart(now) + m.dayOffset * DAY_MS
                set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0)
            }.timeInMillis
            TaskStore.delete(c, old.id)
            TaskStore.add(c, old.title, if (due > now) due else now + HOUR_MS)
            n++
        }
        return n
    }

    /** How much longer the proactive gap should be right now. */
    fun gapFactor(c: Context): Double = try {
        when (snapshot(c).level) { Level.LIGHT, Level.NORMAL -> 1.0; Level.HEAVY -> 1.5; Level.OVERLOADED -> 2.0 }
    } catch (_: Exception) { 1.0 }

    /** True when the user is swamped and something is due within 3 hours: stay quiet. */
    fun shouldHold(c: Context): Boolean = try {
        val s = snapshot(c)
        (s.level == Level.HEAVY || s.level == Level.OVERLOADED) && s.dueSoon > 0
    } catch (_: Exception) { false }

    /** One gentle heads-up per day when today is overloaded. */
    fun nudge(c: Context): Nudge? = try {
        val s = snapshot(c)
        val key = "workload_nudge_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val p = prefs(c)
        if (s.level != Level.OVERLOADED || p.getBoolean(key, false)) null
        else {
            p.edit().putBoolean(key, true).apply()
            Nudge(
                "আজ কাজের চাপ একটু বেশি। চাইলে কিছু কাজ হালকা দিনে সরিয়ে দিই?",
                "Aj kajer chap ektu beshi. Chaile kichu kaj halka dine soriye dii?",
                "Today looks heavy. Want me to spread some tasks over lighter days?",
                "[CHECK-IN] Today's task load is above capacity (${s.todayMin}/${s.capacityMin} min). In one short, warm Bangla sentence (tumi) " +
                    "offer to spread tasks over lighter days. If the user says yes, call phone_action with exactly: WORKLOAD apply"
            )
        }
    } catch (_: Exception) { null }

    fun summary(c: Context): String {
        val s = snapshot(c)
        val lvl = when (s.level) { Level.LIGHT -> "halka"; Level.NORMAL -> "thik-thak"; Level.HEAVY -> "beshi"; Level.OVERLOADED -> "onek beshi (overload)" }
        return "Aj kajer chap $lvl: ${s.todayMin}/${s.capacityMin} min. ${s.dueSoon} ta kaj 3 ghontar moddhe. Porer ${HORIZON_DAYS - 1} din: " +
            s.perDayMin.drop(1).joinToString(", ") { "${it}m" } + "."
    }

    fun handle(c: Context, raw: String): String {
        val arg = raw.trim().substringAfter(' ', "").trim().lowercase()
        return when {
            arg.isEmpty() -> summary(c)
            arg.startsWith("plan") -> {
                val moves = plan(c)
                if (moves.isEmpty()) "Kono kaj shajate hobe na, shob thik ache."
                else moves.take(6).joinToString("\n") { "- ${it.title.take(40)}: ${it.reason}" } +
                    (if (moves.any { it.kind == Kind.SCHEDULE }) "\n'WORKLOAD apply' bolle undated kaj gulo ei din e boshiye debo." else "")
            }
            arg.startsWith("apply") -> {
                val n = apply(c, plan(c))
                if (n == 0) "Shajanor moto kono tarikh-chhara kaj nei." else "$n ta kaj halka dine boshiye dilam."
            }
            else -> summary(c)
        }
    }

    private fun dayName(offset: Int) = when (offset) { 0 -> "aj"; 1 -> "kal"; 2 -> "porshu"; else -> "$offset din por" }
}
