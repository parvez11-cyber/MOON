package com.myra.assistant.perf

import android.content.Context
import com.myra.assistant.utils.Constants

/**
 * Dynamic resource allocator. Turns the live [DeviceState] (+ measured latency) into one [Profile] and a [Budget]
 * that every other module obeys: how many background jobs may run, how often the assistant may speak up,
 * how big the images sent to Gemini are, whether pre-warming is allowed, how big the caches may grow.
 *
 * Override with the setting "resource_profile": auto (default) | full | balanced | eco.
 * The PERF command shows the current profile.
 */
object DynamicResourceAllocator {
    enum class Profile { FULL, BALANCED, ECO, CRITICAL }

    data class Budget(
        val profile: Profile,
        val bgParallelism: Int,
        val proactiveGapFactor: Double,   // multiplies the gap between proactive check-ins
        val screenWatchFactor: Double,    // multiplies the screen-watch interval (1 = normal)
        val imageMaxWidth: Int,
        val jpegQuality: Int,
        val imageMaxBytes: Int,
        val prewarm: Boolean,
        val background: Boolean,          // false: only HIGH priority background jobs run
        val cacheEntries: Int
    )

    fun profile(c: Context? = null): Profile {
        val snap = DeviceState.now(c)
        val ctx = c?.applicationContext
        if (ctx != null) {
            when (ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getString("resource_profile", "auto")?.lowercase()) {
                "full" -> return Profile.FULL
                "balanced" -> return Profile.BALANCED
                "eco" -> return Profile.ECO
            }
        }
        val onBattery = !snap.charging
        return when {
            (snap.batteryPct <= 10 && onBattery) || snap.thermal >= 3 || snap.lowMemory -> Profile.CRITICAL
            (snap.batteryPct <= 20 && onBattery) || snap.powerSave || snap.thermal == 2 -> Profile.ECO
            (snap.batteryPct <= 50 && onBattery) || snap.thermal == 1 || (snap.net == DeviceState.Net.CELLULAR && snap.metered) ||
                LatencyOptimizer.degraded("gemini") -> Profile.BALANCED
            else -> Profile.FULL
        }
    }

    fun budget(c: Context? = null): Budget {
        val p = profile(c)
        val snap = DeviceState.now(c)
        return when (p) {
            Profile.FULL -> Budget(p, 3, 1.0, 1.0, 768, 75, 200_000, true, true, 64)
            Profile.BALANCED -> Budget(p, 2, 1.25, 1.5, 640, 65, 140_000, !snap.metered, true, 48)
            Profile.ECO -> Budget(p, 1, 2.0, 3.0, 512, 55, 90_000, false, true, 32)
            Profile.CRITICAL -> Budget(p, 1, 3.0, 5.0, 384, 45, 60_000, false, false, 16)
        }
    }

    /** Share (0..1) of the background budget a component should get right now: each component gets its weight, scaled down when resources are tight. */
    fun share(c: Context?, component: String): Double {
        val w = when (component) { "voice" -> 0.45; "vision" -> 0.25; "proactive" -> 0.10; "prewarm" -> 0.10; else -> 0.10 }
        return when (profile(c)) {
            Profile.FULL -> w
            Profile.BALANCED -> if (component == "voice") w else w * 0.8
            Profile.ECO -> if (component == "voice") w else w * 0.5
            Profile.CRITICAL -> if (component == "voice") w else 0.0
        }
    }

    fun status(c: Context?): String {
        val s = DeviceState.now(c); val b = budget(c)
        return "Profile ${b.profile}: battery ${s.batteryPct}%${if (s.charging) " (charge hocche)" else ""}, thermal ${s.thermal}, " +
            "free RAM ${s.availMemMb}MB, net ${s.net}${if (s.metered) " (metered)" else ""}. " +
            "Background ${b.bgParallelism}, image ${b.imageMaxWidth}px q${b.jpegQuality}, prewarm ${if (b.prewarm) "on" else "off"}. " + LatencyOptimizer.report()
    }
}
