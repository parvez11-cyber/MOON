package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.utils.Constants
import org.json.JSONObject

/**
 * Automated adaptive learning, fully on the phone (SharedPreferences, nothing is sent anywhere).
 *
 *  1. Intent bias: every zero-shot guess that the user accepted / rejected nudges that intent up or down,
 *     overall and for the part of the day (night / morning / afternoon / evening). Old evidence fades (half-life 21 days).
 *  2. Aliases: a phrase that was understood the same way [ALIAS_AFTER] times becomes a shortcut, so next time it is instant.
 *     Risky commands (SMS, calls, typing, taps, system, root) are never turned into aliases.
 *
 * [forget] wipes everything (hook it to "clear memory").
 */
object AdaptiveLearner {
    private const val KEY = "adaptive_learner_json"
    private const val ALIAS_AFTER = 2
    private const val MAX_ALIASES = 100
    private const val HALF_LIFE_DAYS = 21.0
    private const val MAX_BIAS = 0.12
    private const val DAY_MS = 86_400_000.0

    private val NEVER_ALIAS = setOf(
        "SMS", "CALL", "WHATSAPP_CALL", "WHATSAPP_MSG", "SYSTEM", "ROOT", "TYPE_TEXT", "TAP_BUTTON", "TAP_NUMBER",
        "TAP_AT", "LONG_PRESS", "REPLY_NOTIFICATION", "REPLY_NOTIFICATION_TO"
    )

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    private fun load(c: Context): JSONObject = try { JSONObject(p(c).getString(KEY, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun save(c: Context, o: JSONObject) { p(c).edit().putString(KEY, o.toString()).apply() }

    private fun bucket(now: Long = System.currentTimeMillis()): String {
        val h = java.util.Calendar.getInstance().apply { timeInMillis = now }.get(java.util.Calendar.HOUR_OF_DAY)
        return when (h) { in 5..11 -> "m"; in 12..16 -> "a"; in 17..21 -> "e"; else -> "n" }
    }

    @Synchronized
    fun recordOutcome(c: Context, intentId: String, accepted: Boolean) {
        val root = load(c)
        val stats = root.optJSONObject("stats") ?: JSONObject().also { root.put("stats", it) }
        val now = System.currentTimeMillis()
        for (k in listOf(intentId, "$intentId@${bucket(now)}")) {
            val o = stats.optJSONObject(k) ?: JSONObject()
            val f = decay(now - o.optLong("at", now))
            o.put("u", o.optDouble("u", 0.0) * f + if (accepted) 1.0 else 0.0)
            o.put("d", o.optDouble("d", 0.0) * f + if (accepted) 0.0 else 1.0)
            o.put("at", now)
            stats.put(k, o)
        }
        save(c, root)
    }

    /** -0.12 .. +0.12, added to the zero-shot score of [intentId]. */
    @Synchronized
    fun bias(c: Context, intentId: String): Double {
        val stats = load(c).optJSONObject("stats") ?: return 0.0
        val now = System.currentTimeMillis()
        fun one(k: String): Double {
            val o = stats.optJSONObject(k) ?: return 0.0
            val f = decay(now - o.optLong("at", now))
            val u = o.optDouble("u", 0.0) * f
            val d = o.optDouble("d", 0.0) * f
            return (u - d) / (u + d + 3.0)          // +3 = prior, so one sample can't swing it
        }
        return ((0.6 * one(intentId) + 0.4 * one("$intentId@${bucket(now)}")) * MAX_BIAS).coerceIn(-MAX_BIAS, MAX_BIAS)
    }

    @Synchronized
    fun learnAlias(c: Context, phrase: String, command: String) {
        val key = AiText.norm(phrase)
        if (key.length !in 3..60 || key.all { it.isDigit() || it == ' ' }) return
        if (command.trim().substringBefore(' ').uppercase() in NEVER_ALIAS) return
        val root = load(c)
        val al = root.optJSONObject("alias") ?: JSONObject().also { root.put("alias", it) }
        val o = al.optJSONObject(key) ?: JSONObject()
        if (o.optString("cmd") == command) o.put("n", o.optInt("n", 0) + 1) else { o.put("cmd", command); o.put("n", 1) }
        o.put("at", System.currentTimeMillis())
        al.put(key, o)
        if (al.length() > MAX_ALIASES) {
            val weakest = al.keys().asSequence().minByOrNull { al.getJSONObject(it).optInt("n", 0) * 1_000_000_000L + al.getJSONObject(it).optLong("at", 0) / 1000 }
            if (weakest != null) al.remove(weakest)
        }
        save(c, root)
    }

    @Synchronized
    fun aliasFor(c: Context, text: String): String? {
        val o = load(c).optJSONObject("alias")?.optJSONObject(AiText.norm(text)) ?: return null
        return if (o.optInt("n", 0) >= ALIAS_AFTER) o.optString("cmd").ifBlank { null } else null
    }

    @Synchronized
    fun aliasCount(c: Context): Int = load(c).optJSONObject("alias")?.length() ?: 0

    @Synchronized
    fun forget(c: Context) { p(c).edit().remove(KEY).apply() }

    private fun decay(ageMs: Long): Double = Math.pow(0.5, (ageMs.coerceAtLeast(0) / DAY_MS) / HALF_LIFE_DAYS)
}
