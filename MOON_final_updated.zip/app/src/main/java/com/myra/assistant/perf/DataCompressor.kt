package com.myra.assistant.perf

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Data compression that adapts to the phone and the network.
 *
 *  - [jpeg]: screenshot -> JPEG sized by [DynamicResourceAllocator] (width, quality, byte cap). Starts at the budget's
 *    quality and steps it down (then shrinks the picture) until it fits the cap: less upload on slow / metered networks,
 *    faster answers. Used by ScreenReader.
 *  - [squeezeText]: screen / OCR text with repeated lines and spaces removed, cut at a limit, before it goes to Gemini.
 *  - [packText] / [unpackText]: GZIP + Base64 for large stored JSON ("z1:" prefix, only when it really gets smaller;
 *    plain text still reads fine, so old data keeps working).
 *
 * This is classic lossless / adaptive-lossy compression, not a neural codec.
 */
object DataCompressor {
    private val savedBytes = AtomicLong(0)
    private val inBytes = AtomicLong(0)
    private const val PREFIX = "z1:"

    fun gzip(s: String): ByteArray {
        val out = ByteArrayOutputStream()
        GZIPOutputStream(out).use { it.write(s.toByteArray(Charsets.UTF_8)) }
        return out.toByteArray()
    }

    fun gunzip(b: ByteArray): String = GZIPInputStream(ByteArrayInputStream(b)).use { String(it.readBytes(), Charsets.UTF_8) }

    fun packText(s: String): String {
        if (s.length < 600 || s.startsWith(PREFIX)) return s
        return try {
            val z = PREFIX + Base64.encodeToString(gzip(s), Base64.NO_WRAP)
            if (z.length < s.length * 0.9) { inBytes.addAndGet(s.length.toLong()); savedBytes.addAndGet((s.length - z.length).toLong()); z } else s
        } catch (_: Exception) { s }
    }

    fun unpackText(s: String): String {
        if (!s.startsWith(PREFIX)) return s
        return try { gunzip(Base64.decode(s.substring(PREFIX.length), Base64.NO_WRAP)) } catch (_: Exception) { s }
    }

    fun squeezeText(s: String, maxChars: Int = 4000): String {
        val seen = HashSet<String>()
        val sb = StringBuilder()
        for (line in s.lineSequence()) {
            val t = line.trim().replace(Regex("[ \\t]+"), " ")
            if (t.isEmpty() || !seen.add(t)) continue
            if (sb.length + t.length + 1 > maxChars) break
            sb.append(t).append('\n')
        }
        inBytes.addAndGet(s.length.toLong()); savedBytes.addAndGet((s.length - sb.length).coerceAtLeast(0).toLong())
        return sb.toString().trimEnd()
    }

    fun jpeg(src: Bitmap, c: Context? = null): ByteArray {
        val b = DynamicResourceAllocator.budget(c)
        var w = minOf(src.width, b.imageMaxWidth)
        var q = b.jpegQuality
        var best = ByteArray(0)
        for (attempt in 0 until 6) {
            val scaled = if (src.width > w) Bitmap.createScaledBitmap(src, w, (src.height * w.toFloat() / src.width).toInt().coerceAtLeast(1), true) else src
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (scaled !== src) scaled.recycle()
            best = out.toByteArray()
            if (best.size <= b.imageMaxBytes) break
            if (q > 35) q -= 10 else w = (w * 0.8).toInt().coerceAtLeast(240)
        }
        inBytes.addAndGet(src.byteCount.toLong()); savedBytes.addAndGet((src.byteCount - best.size).coerceAtLeast(0).toLong())
        return best
    }

    fun status() = "Compression: ${savedBytes.get() / 1024} KB bachano (${inBytes.get() / 1024} KB theke)"
}
