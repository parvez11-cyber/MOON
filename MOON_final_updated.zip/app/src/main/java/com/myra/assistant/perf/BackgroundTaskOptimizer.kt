package com.myra.assistant.perf

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Smart background task optimizer: one in-process queue for the assistant's own housekeeping
 * (pre-warming, cleanups, syncs). A job runs only when the phone is in a good state for it:
 *
 *  - priority HIGH / NORMAL / LOW (a LOW job that waited 30 min is promoted, so it never starves)
 *  - constraints: charging, unmetered network, minimum battery, maximum heat
 *  - parallelism comes from [DynamicResourceAllocator] (1-3); in the CRITICAL profile only HIGH jobs run
 *  - a job with the same name replaces the waiting one (no pile-ups), and every job has a 60 s timeout
 *
 * Jobs are started by [pump], which PerfHub.tick calls every minute. It is not WorkManager: jobs live while the
 * assistant's service lives, which is exactly the lifetime of what it schedules.
 */
object BackgroundTaskOptimizer {
    enum class Priority { HIGH, NORMAL, LOW }

    data class Constraints(val charging: Boolean = false, val unmetered: Boolean = false, val minBattery: Int = 0, val maxThermal: Int = 2)

    class Job(val name: String, val priority: Priority, val constraints: Constraints, val block: suspend (Context) -> Unit, val addedAt: Long = System.currentTimeMillis())

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val waiting = ArrayList<Job>()
    private val running = HashSet<String>()
    @Volatile var done = 0L; private set
    @Volatile var skipped = 0L; private set
    private const val PROMOTE_AFTER_MS = 30 * 60_000L
    private const val TIMEOUT_MS = 60_000L

    @Synchronized
    fun submit(c: Context, name: String, priority: Priority = Priority.NORMAL, constraints: Constraints = Constraints(), block: suspend (Context) -> Unit) {
        waiting.removeAll { it.name == name }
        if (name in running) return
        waiting.add(Job(name, priority, constraints, block))
        pump(c)
    }

    private fun ok(j: Job, s: DeviceState.Snapshot, bgAllowed: Boolean): Boolean {
        if (!bgAllowed && j.priority != Priority.HIGH) return false
        val k = j.constraints
        if (k.charging && !s.charging) return false
        if (k.unmetered && s.metered) return false
        if (s.batteryPct < k.minBattery && !s.charging) return false
        if (s.thermal > k.maxThermal) return false
        return true
    }

    @Synchronized
    fun pump(c: Context) {
        val app = c.applicationContext
        val b = DynamicResourceAllocator.budget(app)
        val s = DeviceState.now(app)
        val now = System.currentTimeMillis()
        val order = waiting.sortedBy { j ->
            val p = if (j.priority == Priority.LOW && now - j.addedAt > PROMOTE_AFTER_MS) Priority.NORMAL else j.priority
            p.ordinal
        }
        for (j in order) {
            if (running.size >= b.bgParallelism) break
            if (!ok(j, s, b.background)) { skipped++; continue }
            waiting.remove(j)
            running.add(j.name)
            scope.launch {
                try { withTimeoutOrNull(TIMEOUT_MS) { j.block(app) } } catch (_: Throwable) {}
                synchronized(this@BackgroundTaskOptimizer) { running.remove(j.name); done++ }
            }
        }
    }

    @Synchronized fun status() = "Background: ${waiting.size} opekkhay, ${running.size} cholche, $done shesh, $skipped bar pichiye dewa"
}
