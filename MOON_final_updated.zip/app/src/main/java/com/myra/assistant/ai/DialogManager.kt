package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.utils.Constants

/**
 * Advanced dialog management: keeps the thread of a conversation so short, incomplete or follow-up
 * sentences still work.
 *
 *  - slot filling:   "call" -> "Kake call korbo?" -> "Rahim" -> CALL Rahim      (also sms, open app, youtube, add task)
 *  - follow-ups:     "abar" / "again" repeats the last command, "ar ektu" repeats volume / scroll
 *  - references:     "ke call dao" / "call him" uses the last contact
 *  - cancel:         "thak", "cancel", "না" while a question is open
 *  - confirmation:   repeating a risky command (sms, typing, taps...) asks first; optional confirm for every
 *                    risky command with the setting "dialog_confirm_risky" (default off)
 * A pending question expires after [TTL_MS].
 */
object DialogManager {

    sealed class Outcome {
        object Pass : Outcome()
        data class Proceed(val command: String) : Outcome()
        data class Ask(val question: String) : Outcome()
        data class Confirm(val question: String) : Outcome()
        data class Cancelled(val reply: String) : Outcome()
    }

    private const val TTL_MS = 120_000L
    private const val MAX_WORDS_FOR_TEMPLATE = 5

    private class Tpl(val name: String, val triggers: List<String>, val slots: List<String>, val build: (List<String>) -> String)

    private val templates = listOf(
        Tpl("call", listOf("call", "phone", "kol", "কল", "ফোন"), listOf("Kake call korbo?")) { "CALL ${it[0]}" },
        Tpl("sms", listOf("sms", "message", "msg", "মেসেজ", "এসএমএস"), listOf("Kake message pathabo?", "Ki likhbo?")) { "SMS ${it[0]} | ${it[1]}" },
        Tpl("open", listOf("open", "launch", "kholo", "খোলো", "খুলে দাও"), listOf("Kon app khulbo?")) { "OPEN_APP ${it[0]}" },
        Tpl("youtube", listOf("youtube", "ইউটিউব"), listOf("Youtube e ki chalabo?")) { "YOUTUBE_PLAY ${it[0]}" },
        Tpl("task", listOf("add task", "task add", "remind me", "কাজ যোগ করো", "মনে করিয়ে দাও"), listOf("Ki kaj?")) { "TASK add ${it[0]}" }
    )

    private val AGAIN = listOf("again", "repeat", "same again", "one more time", "abar", "ar ekbar", "arekbar", "আবার", "আরেকবার", "আর একবার")
    private val MORE = listOf("more", "a bit more", "ar ektu", "aro ektu", "ektu aro", "আরেকটু", "আরও একটু", "আর একটু")
    private val YES = setOf("yes", "yeah", "ok", "okay", "sure", "haa", "ha", "hya", "hmm", "ji", "thik ache", "হ্যাঁ", "হ্যা", "হা", "ঠিক আছে", "ঠিকাছে", "জি")
    private val NO = setOf("no", "nope", "na", "না", "cancel", "thak", "thaak", "থাক", "বাদ দাও", "bad dao", "stop", "লাগবে না")
    private val PRONOUNS = setOf("him", "her", "them", "take", "tare", "ওকে", "তাকে", "ওনাকে", "oke", "take")
    private val RISKY = setOf("SMS", "CALL", "WHATSAPP_CALL", "WHATSAPP_MSG", "TYPE_TEXT", "SYSTEM", "ROOT", "TAP_BUTTON", "TAP_NUMBER", "TAP_AT", "LONG_PRESS")
    private val REPEAT_CONFIRM = setOf("SMS", "WHATSAPP_MSG", "TYPE_TEXT", "SYSTEM", "ROOT", "TAP_BUTTON", "TAP_NUMBER", "TAP_AT", "LONG_PRESS")
    private val MORE_OK = setOf("VOLUME_UP", "VOLUME_DOWN", "SCROLL", "SWIPE", "BRIGHTNESS")

    private class PendingSlots(val tpl: Tpl, val values: MutableList<String>, val at: Long = System.currentTimeMillis())
    private class PendingConfirm(val command: String, val at: Long = System.currentTimeMillis())

    private var slots: PendingSlots? = null
    private var confirm: PendingConfirm? = null
    private var lastCommand: String? = null
    private var lastContact: String? = null

    private fun head(cmd: String) = cmd.trim().substringBefore(' ').uppercase()

    @Synchronized
    fun handle(c: Context, text: String): Outcome {
        val now = System.currentTimeMillis()
        val norm = AiText.norm(text)
        val words = AiText.tokens(text)
        if (words.isEmpty()) return Outcome.Pass
        if (slots?.let { now - it.at > TTL_MS } == true) slots = null
        if (confirm?.let { now - it.at > TTL_MS } == true) confirm = null

        // 1. an open confirmation
        confirm?.let { cf ->
            confirm = null
            if (norm in YES) return Outcome.Proceed(cf.command)
            if (norm in NO || words.all { it in NO }) return Outcome.Cancelled("Thik ache, korlam na.")
        }

        // 2. an open question (slot filling)
        slots?.let { ps ->
            if (norm in NO || words.all { it in NO }) { slots = null; return Outcome.Cancelled("Thik ache, thak.") }
            if (words.size <= 12) {
                ps.values.add(text.trim())
                if (ps.values.size >= ps.tpl.slots.size) {
                    slots = null
                    return Outcome.Proceed(ps.tpl.build(ps.values))
                }
                return Outcome.Ask(ps.tpl.slots[ps.values.size])
            }
            slots = null          // a long sentence is a new request, not an answer
        }

        // 3. follow-ups: "again" / "a bit more"
        val last = lastCommand
        if (last != null) {
            if (AGAIN.any { norm == it }) return repeat(last)
            if (MORE.any { norm == it } && head(last) in MORE_OK) return Outcome.Proceed(last)
        }

        // 4. "call him": use the last contact
        val contact = lastContact
        if (contact != null && words.size <= 4 && words.any { it in PRONOUNS }) {
            if (words.any { it in setOf("call", "phone", "কল", "kol") }) return Outcome.Proceed("CALL $contact")
        }

        // 5. incomplete command -> ask for what is missing
        if (words.size <= MAX_WORDS_FOR_TEMPLATE) {
            for (t in templates) {
                for (trig in t.triggers) {
                    val tt = AiText.tokens(trig)
                    if (!AiText.containsRun(words, tt)) continue
                    val rest = AiText.removeRun(words, tt).filter { it !in AiText.FILLER }
                    return when {
                        rest.isEmpty() -> start(t, mutableListOf())
                        t.slots.size > 1 && t.name == "sms" -> start(t, mutableListOf(rest.joinToString(" ")))
                        else -> Outcome.Pass          // already complete: the normal analyzer handles it
                    }
                }
            }
        }
        return Outcome.Pass
    }

    /** Call before running a command. With "dialog_confirm_risky" on, risky commands are confirmed first. */
    @Synchronized
    fun guard(c: Context, command: String): Outcome {
        val on = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getBoolean("dialog_confirm_risky", false)
        if (!on || head(command) !in RISKY) return Outcome.Proceed(command)
        confirm = PendingConfirm(command)
        return Outcome.Confirm("Pathiye debo? ($command) Ha / na bolo.")
    }

    @Synchronized
    fun remember(command: String) {
        val h = head(command)
        if (h == "TASK" || h == "WORKLOAD") return
        lastCommand = command
        val arg = command.trim().substringAfter(' ', "")
        val name = when (h) {
            "CALL", "WHATSAPP_CALL" -> arg
            "SMS" -> arg.substringBefore('|')
            "WHATSAPP_MSG" -> arg.substringBefore(' ')
            else -> ""
        }.trim()
        if (name.isNotEmpty()) lastContact = name
    }

    @Synchronized fun reset() { slots = null; confirm = null; lastCommand = null; lastContact = null }

    private fun start(t: Tpl, filled: MutableList<String>): Outcome {
        if (filled.size >= t.slots.size) return Outcome.Proceed(t.build(filled))
        slots = PendingSlots(t, filled)
        return Outcome.Ask(t.slots[filled.size])
    }

    private fun repeat(last: String): Outcome {
        if (head(last) in REPEAT_CONFIRM) {
            confirm = PendingConfirm(last)
            return Outcome.Confirm("Ager ta-i abar korbo? ($last) Ha / na bolo.")
        }
        return Outcome.Proceed(last)
    }
}
