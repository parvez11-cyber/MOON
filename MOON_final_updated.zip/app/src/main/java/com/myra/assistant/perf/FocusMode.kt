package com.myra.assistant.perf

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import com.myra.assistant.ai.TaskStore
import com.myra.assistant.ai.WorkloadBalancer
import com.myra.assistant.utils.Constants
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AI-powered focus mode. While it is on, the assistant stops being a source of interruption:
 *  - no proactive check-ins, no predictions, no workload nudges
 *  - notifications are not read aloud, except calls/alarms (already skipped elsewhere), apps in "focus_allow_pkgs"
 *    (comma separated package names) and messages that look urgent (urgent / jaruri / OTP / emergency ...)
 *  - what was held is counted and summarised when focus ends ("3 ta notification chilo: WhatsApp 2, Gmail 1")
 *
 * It also suggests focus by itself, never switches on silently: (a) an important task is due within 2 hours,
 * or (b) one productivity app has been in the foreground for 25+ minutes (needs Usage access, which MOON already asks for).
 * At most 2 suggestions a day.
 *
 * Commands: FOCUS on [minutes] | FOCUS off | FOCUS status. Auto-ends after the time (default 45 min).
 */
object FocusMode {
    private const val K_UNTIL = "focus_until"
    private const val DEFAULT_MIN = 45
    private val URGENT = Regex("(?i)urgent|jaruri|joruri|জরুরি|emergency|asap|otp|verification code|\\bcode\\b|ভেরিফিকেশন|ওটিপি")

    private class Held(val app: String, val at: Long)
    private val held = ArrayList<Held>()

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun isActive(c: Context): Boolean {
        val until = p(c).getLong(K_UNTIL, 0L)
        if (until == 0L) return false
        if (System.currentTimeMillis() < until) return true
        stop(c)                                   // time is up: end quietly (the summary is kept for the next "FOCUS status")
        return false
    }

    fun start(c: Context, minutes: Int?): String {
        val m = (minutes ?: DEFAULT_MIN).coerceIn(5, 480)
        synchronized(held) { held.clear() }
        p(c).edit().putLong(K_UNTIL, System.currentTimeMillis() + m * 60_000L).apply()
        return "Focus mode chalu, $m minute. Ami chup thakbo, shudhu jaruri jinish bolbo."
    }

    fun stop(c: Context): String {
        val wasOn = p(c).getLong(K_UNTIL, 0L) != 0L
        p(c).edit().putLong(K_UNTIL, 0L).apply()
        if (!wasOn) return "Focus mode ager theke-i bondho."
        return "Focus mode shesh. " + digest()
    }

    private fun digest(): String {
        val list = synchronized(held) { held.toList() }
        if (list.isEmpty()) return "Kono notification miss hoyni."
        val top = list.groupBy { it.app }.entries.sortedByDescending { it.value.size }.take(3).joinToString(", ") { "${it.key} ${it.value.size}" }
        return "${list.size} ta notification chilo: $top."
    }

    /** True = this notification may still be read aloud during focus. */
    fun allowNotification(c: Context, pkg: String, title: String, text: String): Boolean {
        val allow = p(c).getString("focus_allow_pkgs", "").orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg in allow) return true
        return URGENT.containsMatchIn("$title $text")
    }

    fun hold(c: Context, pkg: String) {
        val label = try { c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        synchronized(held) { held.add(Held(label, System.currentTimeMillis())); if (held.size > 100) held.removeAt(0) }
    }

    /** One suggestion at most twice a day, only when focus is off. Marks itself as offered. */
    fun nudge(c: Context): WorkloadBalancer.Nudge? = try {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val key = "focus_nudge_$day"
        val n = p(c).getInt(key, 0)
        val reason = if (isActive(c) || n >= 2) null else reason(c)
        if (reason == null) null
        else {
            p(c).edit().putInt(key, n + 1).apply()
            WorkloadBalancer.Nudge(
                "$reason ফোকাস মোড চালু করে দিই? আমি চুপ থাকব।",
                "$reason Focus mode chalu kore dii? Ami chup thakbo.",
                "Want me to turn on focus mode? I'll stay quiet.",
                "[CHECK-IN] $reason In one short, warm Bangla sentence (tumi) offer to start focus mode. If the user says yes, call phone_action with exactly: FOCUS on 45"
            )
        }
    } catch (_: Exception) { null }

    private fun reason(c: Context): String? {
        val now = System.currentTimeMillis()
        TaskStore.all(c).filter { !it.done }.firstOrNull { t ->
            val d = t.due; d != null && d > now && d - now < 2 * 3_600_000L && TaskStore.score(t) >= 60
        }?.let { return "\"${it.title.take(40)}\" er somoy kachhe." }
        return if (longSession(c)) "Tumi onekkhon ek-i kaje moggo." else null
    }

    private fun longSession(c: Context): Boolean = try {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 30 * 60_000L, end)
        val e = UsageEvents.Event()
        val pkgs = HashSet<String>()
        var first = Long.MAX_VALUE
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) { pkgs.add(e.packageName); if (e.timeStamp < first) first = e.timeStamp }
        }
        if (pkgs.size != 1) false
        else {
            val pkg = pkgs.first()
            val cat = if (android.os.Build.VERSION.SDK_INT >= 26) c.packageManager.getApplicationInfo(pkg, 0).category else -1
            pkg != c.packageName && cat == ApplicationInfo.CATEGORY_PRODUCTIVITY && end - first >= 25 * 60_000L
        }
    } catch (_: Exception) { false }

    fun status(c: Context): String {
        val until = p(c).getLong(K_UNTIL, 0L)
        val left = ((until - System.currentTimeMillis()) / 60_000L).toInt()
        return if (isActive(c)) "Focus mode chalu, aro $left minute. " + digest() else "Focus mode bondho. " + digest()
    }

    fun handle(c: Context, raw: String): String {
        val arg = raw.trim().substringAfter(' ', "").trim().lowercase()
        val parts = arg.split(' ').filter { it.isNotEmpty() }
        return when (parts.firstOrNull()) {
            "off", "stop", "end", "bondho" -> stop(c)
            "status" -> status(c)
            else -> start(c, parts.firstNotNullOfOrNull { it.toIntOrNull() })
        }
    }
}
