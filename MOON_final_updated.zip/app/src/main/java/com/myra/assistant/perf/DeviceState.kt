package com.myra.assistant.perf

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

/**
 * One cheap, cached (5 s) look at the phone: battery, power-saver, heat, free memory, network.
 * Every optimizer in this package reads from here, so they all agree on what "busy" or "low" means.
 */
object DeviceState {
    enum class Net { NONE, WIFI, CELLULAR, OTHER }

    data class Snapshot(
        val batteryPct: Int, val charging: Boolean, val powerSave: Boolean,
        val thermal: Int,                 // 0 none, 1 light, 2 moderate, 3 severe, 4+ critical (API 29+, else 0)
        val lowMemory: Boolean, val availMemMb: Int,
        val net: Net, val metered: Boolean, val at: Long
    )

    private val DEFAULT = Snapshot(100, true, false, 0, false, 1024, Net.WIFI, false, 0L)
    private const val TTL_MS = 5_000L

    @Volatile private var app: Context? = null
    @Volatile private var cached: Snapshot = DEFAULT

    /** Call once with any context (ProactiveCompanion.start does it). */
    fun init(c: Context) { app = c.applicationContext }

    fun now(c: Context? = null): Snapshot {
        val t = System.currentTimeMillis()
        if (t - cached.at < TTL_MS) return cached
        val ctx = c?.applicationContext ?: app ?: return DEFAULT
        if (app == null) app = ctx
        cached = read(ctx, t)
        return cached
    }

    private fun read(c: Context, t: Long): Snapshot {
        var pct = 100; var charging = true
        try {
            val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (level >= 0 && scale > 0) pct = level * 100 / scale
                val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        } catch (_: Exception) {}

        var save = false; var thermal = 0
        try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            save = pm.isPowerSaveMode
            if (Build.VERSION.SDK_INT >= 29) thermal = pm.currentThermalStatus
        } catch (_: Exception) {}

        var low = false; var avail = 1024
        try {
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            low = mi.lowMemory
            avail = (mi.availMem / (1024 * 1024)).toInt()
        } catch (_: Exception) {}

        var net = Net.OTHER; var metered = false
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork
            val caps = if (n != null) cm.getNetworkCapabilities(n) else null
            net = when {
                caps == null -> Net.NONE
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Net.WIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Net.CELLULAR
                else -> Net.OTHER
            }
            metered = cm.isActiveNetworkMetered
        } catch (_: Exception) {}

        return Snapshot(pct, charging, save, thermal, low, avail, net, metered, t)
    }
}
