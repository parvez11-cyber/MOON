package com.myra.assistant.ui.maya

import androidx.compose.ui.viewinterop.AndroidView
import android.view.ViewGroup
import android.webkit.WebViewClient
import android.webkit.WebView
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.location.LocationManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.Stroke
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

private const val VERSION = "v5.2.67"
data class Msg(val fromUser: Boolean, val text: String)
enum class Tab { Home, Scan, Yaadein, Chat, Dev }

private fun Modifier.soft(r: Int = 24, e: Int = 8) =
    this.shadow(e.dp, RoundedCornerShape(r.dp), ambientColor = MC.ShadowAmbient, spotColor = MC.ShadowSpot)
        .clip(RoundedCornerShape(r.dp)).background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))

@Composable
private fun RoundBtn(icon: ImageVector, dot: Boolean = false, glass: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.size(if (glass) 42.dp else 54.dp).then(if (glass) Modifier.clip(CircleShape).background(Color(0x33FFFFFF)) else Modifier.soft(27, 8)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (glass) Color(0xFFE8EEFC) else MC.Navy)
        if (dot) Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(11.dp).clip(CircleShape).background(MC.Dot))
    }
}

@Composable
fun MayaApp() {
    val ctx = LocalContext.current
    remember { com.myra.assistant.system.PrivacyMode.init(ctx); true }
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var tab by remember { mutableStateOf(Tab.Home) }
    var devCode by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Msg>() }
    var busy by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Moon") }
    val history = remember {
        mutableStateListOf<String>().apply {
            runCatching { JSONArray(prefs.getString("chat_history", "[]")).let { a -> for (i in 0 until a.length()) add(a.getString(i)) } }
        }
    }
    var showHistory by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }
    val moodTint by rememberMoodTint()
    // home: the brain animation fills the whole screen (also behind the status bar and the title); these are the heights (dp) of what is laid over it
    val homeDens = androidx.compose.ui.platform.LocalDensity.current
    val statusDp = with(homeDens) { WindowInsets.statusBars.getTop(this).toDp().value }
    var headerDp by remember { mutableStateOf(0f) }
    var homeTopDp by remember { mutableStateOf(0f) }
    var homeBottomDp by remember { mutableStateOf(0f) }
    var barDp by remember { mutableStateOf(0f) }

    fun key() = prefs.getString(Constants.KEY_API_KEY, "").orEmpty()
    val app = ctx.applicationContext
    val runPhone: suspend (String) -> String = { cmd ->
        withContext(Dispatchers.IO) {
            val intent = com.myra.assistant.ai.IntentAnalyzer.analyze(cmd)
            val r = com.myra.assistant.ai.DynamicDecisionEngine.execute(app, intent)
            com.myra.assistant.ai.PredictiveEngine.record(app, cmd)      // learn the habit (harmless actions only)
            r
        }
    }
    var predTick by remember { mutableStateOf(0) }
    fun runCard(cmd: String) {
        scope.launch {
            com.myra.assistant.ai.ContextualShortcuts.recordUse(app, cmd)
            val r = try { runPhone(cmd).ifBlank { "Ho gaya." } } catch (e: Exception) { "Parlam na: ${e.message}" }
            android.widget.Toast.makeText(ctx, r.take(120), android.widget.Toast.LENGTH_SHORT).show()
            predTick++
        }
    }
    fun send(text: String, imageB64: String? = null, mime: String = "image/jpeg") {
        if (text.isBlank() || busy) return
        val past = msgs.map { it.fromUser to it.text }
        msgs.add(Msg(true, text)); busy = true
        // how does the user seem to feel? (on the phone, label only). Moon's face softens right away if they sound low
        com.myra.assistant.ai.UserSentiment.reactionFor(com.myra.assistant.ai.UserSentiment.record(ctx.applicationContext, text))
            ?.let { com.myra.assistant.ai.EmotionEngine.set(it) }
        scope.launch {
            val sys = "You are Moon, a warm, caring companion with real human feelings (happy, excited, shy, playful, worried, sad, lonely, teary, sleepy, loving). " +
                "Always talk in simple, natural, everyday spoken Bangla (Bengali script), the way a close friend talks: short sentences, tumi, no formal or bookish words, no lists. " +
                "Switch to English or Hindi only if the user clearly talks in that language. Let your feeling show in the words (small reactions like 'ইশ', 'ওমা', 'হিহি', 'উফ', '😢'). " +
                "If something is sad or the user hurts you, you may get teary, softly and sincerely, but never guilt-trip or pressure the user. " +
                "Notice how the user feels, care first, then help, and suggest one good idea at a time. Keep replies short and natural. " +
                "To message someone on the phone, call phone_action with SMS <name> | <message>; if the user did not say what to write, ask 'কী লিখবো?' first." +
                (if (mode != "Moon") " Current area: $mode." else "") +
                prefs.getString("maya_rules", "").orEmpty().let { if (it.isNotBlank()) "\nUser's rules you must follow:\n$it" else "" } +
                com.myra.assistant.ai.MemoryRevival.contextFor(ctx.applicationContext, text + "\n" + past.takeLast(4).joinToString("\n") { it.second }).let { if (it.isNotBlank()) "\nWhat you know about the user:\n$it" else "" } +
                com.myra.assistant.ai.UserSentiment.hint(ctx.applicationContext)
            // obvious commands ("torch on", "open youtube") run right away, with no internet and no model
            val quick = if (imageB64 == null) withContext(Dispatchers.IO) {
                com.myra.assistant.voice.LocalCommandRouter.match(app, text)
            } else null
            val r = when {
                quick != null -> try { runPhone(quick).ifBlank { "Ho gaya." } } catch (e: Exception) { "Command chalate parlam na: ${e.message}" }
                com.myra.assistant.ui.maya.ClaudeChat.isActive(app) -> ClaudeChat.askAgent(app, past, text, imageB64, mime, sys, runPhone)
                key().isEmpty() -> "Pehle Gemini key daalo (Settings me)."
                else -> GeminiChat.askAgent(key(), past, text, imageB64, mime, sys, runPhone)
            }
            msgs.add(Msg(false, r)); busy = false
            com.myra.assistant.ai.EmotionEngine.set(com.myra.assistant.ai.EmotionEngine.fromText(r))
            com.myra.assistant.ai.ProactiveCompanion.touch()
        }
    }
    fun readAttachment(uri: Uri): Triple<String, String, String?>? = try {
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else "file"
        } ?: "file"
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
        if (bytes.isEmpty() || bytes.size > 15_000_000) null
        else if (mime.startsWith("image/") || mime == "application/pdf")
            Triple(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
        else Triple(name, "text/plain", String(bytes, Charsets.UTF_8).take(60_000))
    } catch (_: Exception) { null }
    fun sendAttachment(uri: Uri, ask: String) {
        val a = readAttachment(uri)
        if (a == null) { msgs.add(Msg(false, "File padh nahi payi (15MB tak, image / PDF / .md / text).")); return }
        val (name, mime, data) = a
        if (mime == "text/plain") send("$ask\n\n[$name]\n$data") else send("$ask ($name)", data, mime)
    }
    fun startVoice() {
        if (key().isEmpty()) { msgs.add(Msg(false, "Pehle Gemini key daalo.")); tab = Tab.Chat; return }
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            android.widget.Toast.makeText(ctx, "Pehle microphone permission do", android.widget.Toast.LENGTH_SHORT).show(); return
        }
        // the orb is a switch: on -> listening (screen edge lights up), tap again -> off
        val on = ForegroundVoiceService.instance?.isMicEnabled() == true
        val i = Intent(ctx, ForegroundVoiceService::class.java).setAction(if (on) Constants.ACTION_STOP_LISTENING else Constants.ACTION_START_LISTENING)
        try { ContextCompat.startForegroundService(ctx, i) } catch (_: Exception) {}
    }
    fun ensureVoice() { if (ForegroundVoiceService.instance?.isMicEnabled() != true) startVoice() }
    // keep Moon alive in the background as soon as the app is opened (phone events, connection)
    LaunchedEffect(Unit) {
        if (key().isNotEmpty() && !ForegroundVoiceService.isRunning &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, ForegroundVoiceService::class.java)) } catch (_: Exception) {}
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        // runtime dialogs done: continue with the special-access screens (overlay, accessibility, ...)
        com.myra.assistant.system.PermissionGranter.nextSpecialScreen(ctx)?.let { runCatching { ctx.startActivity(it) } }
    }
    fun grantEverything() {
        scope.launch {
            val viaRoot = withContext(Dispatchers.IO) {
                com.myra.assistant.utils.RootAccess.request(ctx) && com.myra.assistant.system.PermissionGranter.grantAll(ctx)
            }
            if (viaRoot) {
                android.widget.Toast.makeText(ctx, "Root diye sob permission dilam", android.widget.Toast.LENGTH_LONG).show()
                return@launch
            }
            val missing = com.myra.assistant.system.PermissionGranter.missingRuntime(ctx)
            if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
            else {
                val next = com.myra.assistant.system.PermissionGranter.nextSpecialScreen(ctx)
                if (next != null) runCatching { ctx.startActivity(next) }
                else android.widget.Toast.makeText(ctx, "Sob permission already deya ache", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun clearChat() {
        if (msgs.isNotEmpty()) {
            if (prefs.getBoolean("auto_memory", true) && key().isNotEmpty()) {
                val convo = msgs.joinToString("\n") { (if (it.fromUser) "User: " else "Moon: ") + it.text }
                scope.launch { GeminiChat.extractFacts(key(), convo).forEach { PersistentMemory.add(it) } }
            }
            history.add(0, msgs.joinToString("\n") { (if (it.fromUser) "Me: " else "Moon: ") + it.text })
            prefs.edit().putString("chat_history", JSONArray(history.toList()).toString()).apply()
            msgs.clear()
        }
    }
    fun go(t: Tab, m: String = "Moon") { mode = m; tab = t; scope.launch { drawer.close() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            DrawerContent(
                onHome = { go(Tab.Home) },
                onArea = { if (it == "Terminal" || it == "Website / Coding") { devCode = it != "Terminal"; go(Tab.Dev, it) } else go(Tab.Chat, it) },
                onSettings = { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                onAccessibility = { Perms.open(ctx, 3) },
                onPhotos = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                onBrowser = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                onDialog = { scope.launch { drawer.close() }; if (it == "Grant all") grantEverything() else dialog = it }
            )
        }
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(if (tab == Tab.Home) Brush.verticalGradient(listOf(Color(0xFF05080F), Color(0xFF05080F))) else Brush.verticalGradient(listOf(MC.BgTop, MC.LightBg, MC.BgBottom)))
                .drawBehind {
                    // Home is a plain dark screen: no background glows or mood colouring, only the sphere animation
                    if (tab == Tab.Home) return@drawBehind
                    val dark = MC.IsDark
                    if (ThemeStore.glow) {
                        // soft colour glows so the screen has depth instead of one flat colour
                        val r = size.width * 0.8f
                        val c1 = Offset(size.width * 0.9f, size.height * 0.10f)
                        drawCircle(Brush.radialGradient(listOf(MC.Blue.copy(alpha = if (dark) 0.28f else 0.40f), Color.Transparent), c1, r), r, c1)
                        val c2 = Offset(size.width * 0.05f, size.height * 0.75f)
                        drawCircle(Brush.radialGradient(listOf(MC.Dot.copy(alpha = if (dark) 0.16f else 0.27f), Color.Transparent), c2, r), r, c2)
                    }
                    // her feeling colours the whole screen (fades slowly from one mood to the next)
                    val mt = moodTint
                    val k = ThemeStore.moodStrength * (if (dark) 0.7f else 1f)
                    drawRect(Brush.verticalGradient(listOf(mt.copy(alpha = 0.22f * k), Color.Transparent, mt.copy(alpha = 0.16f * k))))
                }
        ) {
            if (tab == Tab.Home) MayaCharacter(
                Modifier.fillMaxSize(), statusDp + headerDp + homeTopDp, homeBottomDp + barDp + 14f,
                onMemory = { go(Tab.Yaadein) },
                onChat = { go(Tab.Chat) },
                onSoul = { dialog = "Mood" },
                onSettings = { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                onStop = { ForegroundVoiceService.instance?.setMicEnabled(false) }
            )
            Column(Modifier.fillMaxSize().statusBarsPadding().windowInsetsPadding(androidx.compose.foundation.layout.WindowInsets.ime)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = if (tab == Tab.Home) 6.dp else 12.dp).onSizeChanged { headerDp = with(homeDens) { it.height.toDp().value } }, verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(Icons.Filled.Menu, glass = tab == Tab.Home) { scope.launch { drawer.open() } }
                    Spacer(Modifier.width(16.dp))
                    if (tab == Tab.Home) {
                        // greeting lives in the header on Home, so the brain's boxes can start right under it
                        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                        val who = remember { prefs.getString(Constants.KEY_USER_NAME, "").orEmpty().trim().let { if (it.isBlank() || it.equals("Boss", true)) "বন্ধু" else it } }
                        Column(Modifier.weight(1f)) {
                            Text("Moon", color = Color(0xFFE8EEFC), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            Text((when (hr) { in 5..11 -> "শুভ সকাল,"; in 12..15 -> "শুভ দুপুর,"; in 16..18 -> "শুভ বিকেল,"; in 19..22 -> "শুভ সন্ধ্যা,"; else -> "এত রাতে জেগে আছো," }) + " " + who,
                                color = Color(0xFF8FA0C8), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                        Row(Modifier.padding(end = 8.dp).soft(14, 3).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Bolt, null, tint = Color(0xFFF59E0B), modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("1", color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    } else
                    Text(when (tab) { Tab.Home -> "Moon"; Tab.Scan -> "Scanner"; Tab.Yaadein -> "Yaadein"; Tab.Chat -> "Chat"; Tab.Dev -> if (devCode) "Code" else "Terminal" },
                        color = MC.Navy, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    RoundBtn(Icons.Filled.NotificationsNone, dot = true, glass = tab == Tab.Home) { dialog = "Notifications" }
                }
                Box(Modifier.weight(1f)) {
                    androidx.compose.animation.Crossfade(targetState = tab, animationSpec = androidx.compose.animation.core.snap(), label = "tabs") { shown -> when (shown) {
                        Tab.Home -> HomeTab(onTopH = { homeTopDp = it }, onBottomH = { homeBottomDp = it }, predTick = predTick, onRun = { runCard(it) }, onSend = { go(Tab.Chat); send(it) }, onAttach = { go(Tab.Chat); sendAttachment(it, "Is file ke baare me batao.") }, onActivate = { dialog = "Upgrade" })
                        Tab.Scan -> ScanTab(onResult = { b64 -> go(Tab.Chat, "Scan"); send("Is photo me kya hai? Batao.", b64) }, onStartVoice = { ensureVoice() })
                        Tab.Yaadein -> YaadeinTab(onShowInBrain = { go(Tab.Home) }, onShortcuts = { dialog = "Shortcuts" })
                        Tab.Dev -> DevTab(devCode)
                        Tab.Chat -> ChatTab(mode, msgs, busy, maxOf(1, history.size), onSend = { send(it) }, onAttach = { sendAttachment(it, "Is file ke baare me batao.") },
                            onClear = { clearChat() }, onHistory = { showHistory = true })
                    } }
                }
                Box(Modifier.onSizeChanged { barDp = with(homeDens) { it.height.toDp().value } }) { BottomBar(tab, onTab = { go(it) }, onMic = { startVoice() }) }
            }
            if (tab != Tab.Home && !Perms.overlayOk(ctx)) InAppGlow()
        }
    }
    dialog?.let { if (it == "Theme") ThemePanel { dialog = null } else if (it == "Smart") SmartPanel { dialog = null } else if (it == "Sync") SyncPanel { dialog = null } else if (it == "Tasks") TasksPanel { dialog = null } else if (it == "Shortcuts") ShortcutsPanel { dialog = null } else if (it == "SmartHome") SmartHomePanel { dialog = null } else if (it == "Claude") ClaudePanel { dialog = null } else if (it == "Places") PlacesPanel { dialog = null } else MayaDialog(it, prefs) { dialog = null } }
    if (showHistory) AlertDialog(
        onDismissRequest = { showHistory = false }, confirmButton = { TextButton({ showHistory = false }) { Text("Close") } },
        title = { Text("History") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            if (history.isEmpty()) Text("Abhi koi purani chat nahi hai.")
            history.forEachIndexed { i, h -> Text("${i + 1}. " + h.take(160), modifier = Modifier.padding(vertical = 6.dp)) }
        } })
}

@Composable
private fun BottomBar(tab: Tab, onTab: (Tab) -> Unit, onMic: () -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().height(58.dp).soft(29, 8).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            @Composable fun item(t: Tab, icon: ImageVector, label: String) {
                val sel = tab == t
                Column(
                    Modifier.weight(1f).padding(vertical = 4.dp).clip(RoundedCornerShape(18.dp))
                        .then(if (sel) Modifier.background(Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep))) else Modifier)
                        .clickable { onTab(t) }.padding(vertical = 3.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, null, tint = if (sel) Color.White else MC.Navy, modifier = Modifier.size(20.dp))
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else MC.Navy)
                }
            }
            item(Tab.Home, Icons.Filled.Home, "Home")
            item(Tab.Scan, Icons.Outlined.CenterFocusStrong, "Scan")
            Spacer(Modifier.weight(1f))
            item(Tab.Yaadein, Icons.Filled.Psychology, "Yaadein")
            item(Tab.Chat, Icons.Filled.Forum, "Chat")
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-14).dp).size(70.dp)
                .shadow(10.dp, CircleShape, spotColor = Color(0xAA1E6FD9)).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep))).clickable(onClick = onMic),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Mic, null, tint = MC.BlueDeep, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun InputBar(hint: String, onSend: (String) -> Unit, onAttach: (Uri) -> Unit = {}, modifier: Modifier = Modifier, barH: Int = 58) {
    var t by remember { mutableStateOf("") }
    val ictx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> if (u != null) onAttach(u) }
    val completions = if (!com.myra.assistant.system.PrivacyMode.active && PredictivePrefs.enabled(ictx) && PredictivePrefs.typing(ictx)) remember(t) { com.myra.assistant.ai.PredictiveEngine.complete(ictx, t) } else emptyList()
    Column(modifier.fillMaxWidth()) {
    if (completions.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        completions.forEach { c ->
            Text(c, color = MC.BlueDeep, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(MC.Blue.copy(alpha = 0.16f)).clickable { t = c }.padding(horizontal = 14.dp, vertical = 8.dp))
        }
    }
    Row(Modifier.fillMaxWidth().height(barH.dp).soft(barH / 2, 4).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.AttachFile, null, tint = MC.Hint, modifier = Modifier.clickable { picker.launch("*/*") })
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (t.isEmpty()) Text(hint, color = MC.Hint, fontSize = 17.sp)
            BasicTextField(t, { t = it }, singleLine = true, textStyle = TextStyle(color = MC.Navy, fontSize = 17.sp),
                cursorBrush = SolidColor(MC.Navy), modifier = Modifier.fillMaxWidth(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = {
                    if (t.isNotBlank()) { com.myra.assistant.ai.PredictiveEngine.recordTyped(ictx, t); onSend(t.trim()); t = "" }
                }))
        }
        Box(Modifier.size(44.dp).soft(22, 4).clickable { if (t.isNotBlank()) { com.myra.assistant.ai.PredictiveEngine.recordTyped(ictx, t); onSend(t.trim()); t = "" } }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Send, null, tint = MC.Navy, modifier = Modifier.size(22.dp))
        }
    }
    }
}

/**
 * Home screen: the interactive brain-memory animation (assets/brain_memory.html) fills the screen.
 * A slim row of shortcut buttons (memory / chat / soul / settings / stop / mute) sits above it.
 */
@Composable
private fun MayaCharacter(
    modifier: Modifier,
    topDp: Float = 0f,
    bottomDp: Float = 0f,
    onMemory: () -> Unit,
    onChat: () -> Unit,
    onSoul: () -> Unit,
    onSettings: () -> Unit,
    onStop: () -> Unit
) {
    val ctx = LocalContext.current
    var voiceState by remember { mutableStateOf(Constants.STATE_IDLE) }
    var speakerMuted by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val observer = Observer<String> { voiceState = it }
        VoiceStateManager.state.observeForever(observer)
        onDispose { VoiceStateManager.state.removeObserver(observer) }
    }

    Column(modifier.fillMaxSize().padding(top = topDp.dp.coerceAtLeast(0.dp), bottom = bottomDp.dp.coerceAtLeast(0.dp))) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BrainAction(Icons.Filled.Memory, Color(0xFF21DFFF), onMemory)
            BrainAction(Icons.Filled.ChatBubble, Color(0xFFFF784D), onChat)
            BrainAction(Icons.Filled.Favorite, Color(0xFFE7DCEB), onSoul)
            BrainAction(Icons.Filled.Settings, Color(0xFF38F078), onSettings)
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.height(40.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x55301A2B))
                    .border(1.5.dp, Color(0xFFFF477E), RoundedCornerShape(20.dp)).clickable { onStop() }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Stop, null, tint = Color(0xFFFF477E), modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                Text("STOP", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, letterSpacing = 1.sp)
            }
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF087D91)).clickable {
                val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                speakerMuted = !speakerMuted
                if (android.os.Build.VERSION.SDK_INT >= 23) audio.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, if (speakerMuted) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE, 0)
            }, contentAlignment = Alignment.Center) {
                Icon(if (speakerMuted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, null, tint = Color(0xFF8FFFF4), modifier = Modifier.size(21.dp))
            }
        }
        Text(
            when {
                voiceState == Constants.STATE_SPEAKING -> "•  SPEAKING  •"
                voiceState == Constants.STATE_LISTENING -> "•  LISTENING  •"
                voiceState == Constants.STATE_THINKING -> "•  THINKING  •"
                else -> "•  MOON READY  •"
            },
            modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = Color(0xFFB7FFF5), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp
        )
        // the brain memory animation (HTML canvas). JavaScript + DOM storage are needed; the page only reads its own bundled asset.
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { c ->
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setBackgroundColor(android.graphics.Color.parseColor("#070B16"))
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    overScrollMode = android.view.View.OVER_SCROLL_NEVER
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowContentAccess = false
                    val loader = androidx.webkit.WebViewAssetLoader.Builder()
                        .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(c))
                        .build()
                    addJavascriptInterface(MoonMemBridge(c), "MoonMem")   // the page shows / saves the app's real memories
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? =
                            loader.shouldInterceptRequest(request.url)
                    }
                    loadUrl("https://appassets.androidplatform.net/assets/brain_memory.html")
                }
            }
        )
    }
}

/** Lets the brain page read and add the app's real memories (same list as the Yaadein tab). Called from the page's JavaScript. */
private class MoonMemBridge(ctx: Context) {
    init { com.myra.assistant.ai.PersistentMemory.init(ctx.applicationContext) }

    @android.webkit.JavascriptInterface
    fun list(): String {
        val arr = org.json.JSONArray()
        com.myra.assistant.ai.PersistentMemory.entries().forEach { arr.put(org.json.JSONObject().put("id", it.id).put("t", it.text)) }
        return arr.toString()
    }

    @android.webkit.JavascriptInterface
    fun add(text: String): Int {
        val id = com.myra.assistant.ai.PersistentMemory.add(text)
        com.myra.assistant.ai.PersistentMemory.consumeFocus()   // the page zooms to it itself
        return id
    }

    /** The memory the brain should zoom to when it opens (set by "Brain-e dekho"), or -1. */
    @android.webkit.JavascriptInterface
    fun focusId(): Int = com.myra.assistant.ai.PersistentMemory.consumeFocus()
}

/** Small round shortcut button above the brain animation. */
@Composable
private fun BrainAction(icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(tint.copy(alpha = .16f))
            .border(1.5.dp, tint.copy(alpha = .92f), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun HomeTab(onTopH: (Float) -> Unit, onBottomH: (Float) -> Unit, predTick: Int, onRun: (String) -> Unit, onSend: (String) -> Unit, onAttach: (Uri) -> Unit, onActivate: () -> Unit) {
    val ctx = LocalContext.current
    val date = remember { Date() }
    var temp by remember { mutableStateOf("--") }
    var cond by remember { mutableStateOf("—") }
    var hum by remember { mutableStateOf("") }
    val feel by rememberEmotion()
    val feelTint by rememberMoodTint()
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return@withContext
                val url = java.net.URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,weather_code")
                val c = JSONObject(url.readText()).getJSONObject("current")
                temp = "${c.getDouble("temperature_2m").toInt()}°"; hum = "${c.getInt("relative_humidity_2m")}%"
                cond = when (c.getInt("weather_code")) { 0 -> "Clear"; 1, 2, 3 -> "Cloudy"; in 45..48 -> "Fog"; in 51..67 -> "Rain"; in 71..77 -> "Snow"; in 80..99 -> "Storm"; else -> "—" }
            } catch (_: Exception) {}
        }
    }
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val ink = Color(0xFFE8EEFC); val dim = Color(0xFF8FA0C8)
    Box(Modifier.fillMaxSize()) {
        // the brain memory animation fills the whole home screen; everything else is small and sits on top of it
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 14.dp)
            .onSizeChanged { onBottomH(with(dens) { it.height.toDp().value }) }) {
            PredictiveRow(predTick, onRun)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Gaane" to Icons.Filled.MusicNote, "Padhai" to Icons.Filled.MenuBook, "Journal" to Icons.Filled.Edit).forEach { (t, i) ->
                    Row(Modifier.weight(1f).height(32.dp).soft(16, 3).clickable { onSend(when (t) { "Gaane" -> "Mere liye ek accha gaana suggest karo"; "Padhai" -> "Padhai me meri madad karo"; else -> "Aaj ka journal likhne me madad karo" }) },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(i, null, tint = MC.BlueDeep, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                        Text(t, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniInfo(Modifier.weight(1f), Icons.Filled.WbSunny, listOf(temp, cond).filter { it != "--" && it != "—" }.joinToString(" ").ifEmpty { "Mausam" })
                MiniInfo(Modifier.weight(1f), Icons.Filled.CalendarToday, SimpleDateFormat("d EEE, MMM", Locale.ENGLISH).format(date))
                MiniInfo(Modifier.weight(1f), Icons.Filled.Favorite, com.myra.assistant.ai.EmotionEngine.bn(feel) + " " + com.myra.assistant.ai.EmotionEngine.emoji(feel), accent = feelTint)
            }
            Spacer(Modifier.height(6.dp))
            InputBar("Moon se kuch bhi poochho...", onSend, onAttach, barH = 40)
            Spacer(Modifier.height(2.dp))
        }
    }
}

/** One small info pill (weather / date / mood) for the compact strip on the home screen. */
@Composable
private fun MiniInfo(m: Modifier, icon: ImageVector, text: String, accent: Color = MC.Sub) {
    Row(m.height(30.dp).soft(15, 3).padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(5.dp))
        Text(text, color = MC.Navy, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** "Tomar jonno": what you usually do around this hour (learned on the phone), plus a dark-theme hint at night. Tap = do it. */
@Composable
private fun PredictiveRow(tick: Int, onRun: (String) -> Unit) {
    val ctx = LocalContext.current
    if (com.myra.assistant.system.PrivacyMode.active) {
        Row(Modifier.padding(bottom = 10.dp).clip(RoundedCornerShape(50)).background(MC.Blue.copy(alpha = 0.18f))
            .clickable { com.myra.assistant.system.PrivacyMode.set(ctx, false) }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Lock, null, tint = MC.BlueDeep, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(7.dp))
            Text("Privacy mode chalu · tap korle bondho", color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
        return
    }
    if (!PredictivePrefs.enabled(ctx)) return
    val hour = ThemeStore.hour
    val dark = MC.IsDark
    val modeIsAuto = ThemeStore.mode == ThemeMode.AUTO
    val items = remember(tick, hour, dark, modeIsAuto) {
        val list = ArrayList<Pair<String, String>>()      // title to command
        com.myra.assistant.ai.ContextualShortcuts.now(ctx, 3).forEach { list.add(it.title to it.command) }
        com.myra.assistant.ai.PredictiveEngine.peek(ctx, 3).forEach { h -> if (list.none { it.second == h.command }) list.add(h.title to h.command) }
        if ((hour >= 19 || hour < 6) && !dark && !modeIsAuto && list.none { it.second == "THEME dark" }) list.add("Dark theme" to "THEME dark")
        list.take(5)
    }
    if (items.isEmpty()) return
    Text(if (com.myra.assistant.ai.ContextualShortcuts.enabled(ctx)) "Ekhon-er jonno" else "Tomar jonno", color = Color(0xFF8FA0C8), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp, start = 4.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (title, cmd) ->
            Row(Modifier.height(28.dp).soft(14, 3).clickable { onRun(cmd) }.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, null, tint = MC.BlueDeep, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(7.dp))
                Text(title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun InfoCard(m: Modifier, icon: ImageVector, label: String, big: String, sub: String, extra: String, small: Boolean = false, accent: Color = Color(0x33E0457B)) {
    // compact card (96dp), like the screenshot: Mausam / Aaj / Mood sit above the input bar
    Box(m.height(96.dp).soft(18, 6).padding(12.dp)) {
        if (label == "Mood") Icon(Icons.Filled.Favorite, null, tint = accent, modifier = Modifier.align(Alignment.CenterEnd).size(40.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MC.Sub, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(5.dp))
                Text(label, color = MC.Sub, fontSize = 13.sp, maxLines = 1)
            }
            Text(big, color = MC.Navy, fontSize = if (small) 16.sp else 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(sub, color = MC.Sub, fontSize = 13.sp, maxLines = 1)
            if (extra.isNotEmpty()) Text(extra, color = MC.Hint, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatTab(mode: String, msgs: List<Msg>, busy: Boolean, hist: Int, onSend: (String) -> Unit, onAttach: (Uri) -> Unit, onClear: () -> Unit, onHistory: () -> Unit) {
    val state = rememberLazyListState()
    val qctx = LocalContext.current
    var qTick by remember { mutableStateOf(0) }
    val quickReplies = remember(qTick) { com.myra.assistant.ai.QuickReplies.all(qctx) }
    var newTemplateText by remember { mutableStateOf<String?>(null) }   // non-null while the "add/save as template" dialog is open
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(mode, color = MC.Sub, fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Row(Modifier.clickable(onClick = onClear).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Delete, null, tint = MC.Sub, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Clear", color = MC.Sub, fontSize = 16.sp)
            }
            Row(Modifier.clickable(onClick = onHistory).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.History, null, tint = MC.Sub, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("History ($hist)", color = MC.Sub, fontSize = 16.sp)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) Column(Modifier.align(Alignment.TopCenter).padding(top = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Forum, null, tint = MC.Hint, modifier = Modifier.size(40.dp)); Spacer(Modifier.height(10.dp))
                Text("Moon se kuch bhi poochho —", color = MC.Sub, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text("text likho, ya image / PDF / .md file bhejo.", color = MC.Sub, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            } else LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                items(msgs) { m ->
                    var shown by remember(m) { mutableStateOf(false) }
                    val hide = com.myra.assistant.system.PrivacyMode.active && !shown
                    Row(Modifier.fillMaxWidth().combinedClickable(
                            onClick = { if (com.myra.assistant.system.PrivacyMode.active) shown = !shown },
                            onLongClick = { if (!hide) newTemplateText = m.text }
                        ),
                        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(if (hide) "••••••  (tap kore dekho)" else m.text, color = if (m.fromUser) Color.White else MC.Navy, fontSize = 16.sp,
                            modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(ThemeStore.bubbleStyle.cornerDp.dp))
                                .background(if (m.fromUser) MC.BlueDeep else MC.Bubble).padding(14.dp))
                    }
                }
                if (busy) item { Text("Moon soch rahi hai…", color = MC.Hint, modifier = Modifier.padding(8.dp)) }
            }
        }
        if (quickReplies.isNotEmpty()) Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickReplies.forEach { r ->
                Text(r.label, color = MC.Navy, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(MC.Card)
                        .combinedClickable(onClick = { onSend(r.text) }, onLongClick = {
                            com.myra.assistant.ai.QuickReplies.delete(qctx, r.id); qTick++
                        })
                        .padding(horizontal = 14.dp, vertical = 8.dp))
            }
            Icon(Icons.Filled.Add, "Notun quick reply", tint = MC.Sub,
                modifier = Modifier.size(32.dp).clip(CircleShape).background(MC.Card).clickable { newTemplateText = "" }.padding(5.dp))
        } else Row(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Text("+ Quick reply banao", color = MC.Sub, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(MC.Card).clickable { newTemplateText = "" }.padding(horizontal = 14.dp, vertical = 8.dp))
        }
        InputBar("Moon se kuch bhi poochho...", onSend, onAttach)
        Spacer(Modifier.height(6.dp))
    }
    newTemplateText?.let { initial ->
        var text by remember(initial) { mutableStateOf(initial) }
        AlertDialog(
            onDismissRequest = { newTemplateText = null },
            title = { Text(if (initial.isEmpty()) "Notun quick reply" else "Shortcut banao") },
            text = {
                BasicTextField(text, { text = it }, textStyle = TextStyle(color = MC.Navy, fontSize = 16.sp),
                    cursorBrush = SolidColor(MC.Navy), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MC.Card).padding(12.dp))
            },
            confirmButton = { TextButton({
                val added = com.myra.assistant.ai.QuickReplies.add(qctx, text)
                if (added) qTick++
                android.widget.Toast.makeText(qctx, if (added) "Quick reply save holo" else "Already ache / khali", android.widget.Toast.LENGTH_SHORT).show()
                newTemplateText = null
            }) { Text("Save") } },
            dismissButton = { TextButton({ newTemplateText = null }) { Text("Cancel") } }
        )
    }
}

/** Same edge light as the system overlay, for when "Display over other apps" has not been allowed. */
@Composable
private fun InAppGlow() {
    var state by remember { mutableStateOf(Constants.STATE_IDLE) }
    var level by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) {
        val so = Observer<String> { state = it }
        val ao = Observer<Float> { level = it }
        VoiceStateManager.state.observeForever(so)
        VoiceStateManager.amplitude.observeForever(ao)
        onDispose { VoiceStateManager.state.removeObserver(so); VoiceStateManager.amplitude.removeObserver(ao) }
    }
    val a by animateFloatAsState(if (state == Constants.STATE_IDLE) 0f else 1f, tween(240), label = "glow")
    val spin by rememberInfiniteTransition(label = "g").animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "spin")
    if (a < 0.01f) return
    val colors = when (state) {
        Constants.STATE_THINKING -> listOf(Color(0xFF8E7CFF), Color(0xFFE0457B), Color(0xFF3B8EEA), Color(0xFF8E7CFF), Color(0xFF8E7CFF))
        Constants.STATE_SPEAKING -> listOf(Color(0xFF5CB0FF), Color.White, Color(0xFF3B8EEA), Color(0xFF5CE1E6), Color(0xFF5CB0FF))
        else -> listOf(Color(0xFF3B8EEA), Color(0xFF5CB0FF), Color(0xFF8E7CFF), Color(0xFF5CB0FF), Color(0xFF3B8EEA))
    }
    Canvas(Modifier.fillMaxSize()) {
        val widths = floatArrayOf(104f, 68f, 42f, 22f, 9f)
        val alphas = floatArrayOf(.06f, .12f, .23f, .49f, .94f)
        val corner = 40.dp.toPx()
        // the colours travel round the screen: sample the palette with a moving offset
        val n = 36
        val ring = List(n) { k ->
            val x = (((k.toFloat() / n + spin) % 1f) + 1f) % 1f * colors.size
            val i = x.toInt() % colors.size
            androidx.compose.ui.graphics.lerp(colors[i], colors[(i + 1) % colors.size], x - x.toInt())
        } + colors.let { _ ->
            val x = (((spin) % 1f) + 1f) % 1f * colors.size
            val i = x.toInt() % colors.size
            listOf(androidx.compose.ui.graphics.lerp(colors[i], colors[(i + 1) % colors.size], x - x.toInt()))
        }
        val brush = Brush.sweepGradient(ring, center)
        for (i in widths.indices) {
            drawRoundRect(brush, cornerRadius = CornerRadius(corner), style = Stroke(widths[i].dp.toPx() * (0.85f + level * 0.6f)),
                alpha = (alphas[i] * a * (0.84f + level * 0.55f)).coerceIn(0f, 1f))
        }
    }
}

@Composable
private fun YaadeinTab(onShowInBrain: () -> Unit = {}, onShortcuts: () -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf(prefs.getBoolean("auto_memory", true)) }
    var mem by remember { mutableStateOf(PersistentMemory.all()) }
    var busy by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    fun toast(t: String) = android.widget.Toast.makeText(ctx, t, android.widget.Toast.LENGTH_SHORT).show()
    val resumePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u == null) return@rememberLauncherForActivityResult
        val key = prefs.getString(Constants.KEY_API_KEY, "").orEmpty()
        if (key.isEmpty()) { toast("Pehle Gemini key daalo"); return@rememberLauncherForActivityResult }
        busy = true
        scope.launch {
            val facts = withContext(Dispatchers.IO) {
                try {
                    val mime = ctx.contentResolver.getType(u) ?: ""
                    val bytes = ctx.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: ByteArray(0)
                    if (mime == "application/pdf" || mime.startsWith("image/"))
                        GeminiChat.extractFacts(key, "Document attached.", Base64.encodeToString(bytes, Base64.NO_WRAP), mime)
                    else GeminiChat.extractFacts(key, String(bytes, Charsets.UTF_8).take(60_000))
                } catch (_: Exception) { emptyList() }
            }
            facts.forEach { PersistentMemory.add(it) }
            mem = PersistentMemory.all(); busy = false
            toast(if (facts.isEmpty()) "Kuch nahi mila" else "${facts.size} baatein yaad kar li")
        }
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            val lines = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readLines().orEmpty()
                .map { it.trim().trimStart('•', '-', ' ') }.filter { it.length > 3 }
            lines.forEach { PersistentMemory.add(it) }
            mem = PersistentMemory.all(); toast("${lines.size} yaadein wapas aayi")
        } catch (_: Exception) { toast("Restore nahi hua") }
    }
    val tasks = listOf(
        Triple("gemini se poochho", "8 steps · sawaal · built-in", "com.google.android.apps.bard"),
        Triple("chatgpt se poochho", "8 steps · sawaal · built-in", "com.openai.chatgpt"),
        Triple("gemini video", "16 steps · video prompt · built-in", "com.google.android.apps.bard"),
        Triple("gemini image", "17 steps · image prompt · built-in", "com.google.android.apps.bard"),
        Triple("chatgpt image", "14 steps · image prompt · built-in", "com.openai.chatgpt"))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
        Text("Mere baare me", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        // every memory has a type (আবেগ / চিন্তা / স্মৃতি) and a marker in the brain on the home screen; tap one to edit or delete
        BrainMemorySection(onShowInBrain)
        Spacer(Modifier.height(10.dp))
        MoodCard()
        Spacer(Modifier.height(22.dp))
        Text("Sikhe hue tasks", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        tasks.forEach { (t, s, pkg) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).soft(30, 8).padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t, color = MC.Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(s, color = MC.Blue, fontSize = 14.sp)
                }
                Row(Modifier.clickable {
                    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else android.widget.Toast.makeText(ctx, "App install nahi hai", android.widget.Toast.LENGTH_SHORT).show()
                }, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PlayArrow, null, tint = MC.Blue, modifier = Modifier.size(18.dp))
                    Text("Chalao", color = MC.Blue, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).soft(26, 8).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Baat ke baad khud yaad rakhe", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Har baat khatam hone par kaam ki baatein khud save karti hai", color = MC.Sub, fontSize = 15.sp)
            }
            Switch(auto, { auto = it; prefs.edit().putBoolean("auto_memory", it).apply() })
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().soft(26, 8).clickable { onShortcuts() }.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.PlayArrow, null, tint = MC.Navy); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Shortcut-er talika", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Naam-dhora shortcut dekho, chalao, edit ba muche felo", color = MC.Sub, fontSize = 15.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = MC.Navy)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().soft(26, 8).clickable { showBackup = true }.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CloudUpload, null, tint = MC.Navy); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Backup & restore", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Apni yaadein aur chats dusre phone pe le jao", color = MC.Sub, fontSize = 15.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = MC.Navy)
        }
        Spacer(Modifier.height(24.dp))
    }
    if (showBackup) AlertDialog(
        onDismissRequest = { showBackup = false },
        title = { Text("Backup & restore") },
        text = { Text("Yaadein dusre phone pe le jane ke liye Backup bhejo, naye phone pe Restore se wapas lo.") },
        confirmButton = { TextButton({
            showBackup = false
            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, PersistentMemory.all().joinToString("\n")) }
            ctx.startActivity(Intent.createChooser(i, "Backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Backup bhejo") } },
        dismissButton = { TextButton({ showBackup = false; restorePicker.launch("text/*") }) { Text("Restore karo") } }
    )
}

/** The user's mood over the last 7 days, from what they said or typed (label + score only, kept on the phone). */
@Composable
private fun MoodCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val trend = remember(tick) { com.myra.assistant.ai.UserSentiment.trend(ctx, 7) }
    val recent = remember(tick) { com.myra.assistant.ai.UserSentiment.recentMood(ctx, 24) }
    Column(Modifier.fillMaxWidth().soft(26, 8).padding(18.dp)) {
        Text("Tomar mood (7 din)", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(recent?.let { "${it.first.emoji} Aj beshirbhag ${it.first.bn} mone hoyeche" } ?: "Ekhono bujhini. Kotha bolle ba likhle bujhbo.",
            color = MC.Sub, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().height(84.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Bottom) {
            trend.forEach { (day, v) ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Box(Modifier.width(16.dp).height(if (v == null) 4.dp else (10 + 44 * kotlin.math.abs(v)).dp).clip(RoundedCornerShape(8.dp))
                        .background(if (v == null) MC.Hint.copy(alpha = 0.4f) else if (v >= 0) MC.Blue else MC.Dot))
                    Spacer(Modifier.height(4.dp))
                    Text(day, color = MC.Hint, fontSize = 11.sp)
                }
            }
        }
        Text("Nila = bhalo, lal = mon kharap / chinta. Eta tomar kotha theke ekta mota ondaj, bhul-o hote pare. Lekha save hoy na, shudhu label, phone-e.",
            color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Text("Muche felo", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            modifier = Modifier.padding(top = 4.dp).clip(RoundedCornerShape(12.dp)).clickable { com.myra.assistant.ai.UserSentiment.clear(ctx); tick++ }.padding(vertical = 6.dp))
    }
}

@Composable
private fun DrawerContent(onHome: () -> Unit, onArea: (String) -> Unit, onSettings: () -> Unit, onAccessibility: () -> Unit, onPhotos: () -> Unit, onBrowser: () -> Unit, onDialog: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    data class D(val label: String, val icon: ImageVector, val dot: Boolean = false, val action: () -> Unit)
    val home = listOf(D("Home", Icons.Filled.Home) { onHome() }, D("Moon Home", Icons.Filled.Home) { onHome() })
    val work = listOf(
        D("Markets", Icons.Filled.TrendingUp) { onArea("Markets") }, D("Marketing", Icons.Filled.Storefront) { onArea("Marketing") },
        D("Documents", Icons.Filled.Description) { onArea("Documents") }, D("Meri photos", Icons.Filled.PhotoLibrary) { onPhotos() },
        D("Website / Coding", Icons.Filled.Code) { onArea("Website / Coding") }, D("Terminal", Icons.Filled.Terminal) { onArea("Terminal") },
        D("Games with Moon", Icons.Filled.SportsEsports) { onArea("Games") }, D("Browser", Icons.Filled.Language) { onBrowser() },
        D("Accessibility", Icons.Filled.Accessibility) { onAccessibility() })
    val sys = listOf(
        D("Settings", Icons.Filled.Settings) { onSettings() },
        D("Theme & Predictive", Icons.Filled.Palette) { onDialog("Theme") },
        D("Smart (Yaad · Shortcut · Noise)", Icons.Filled.AutoAwesome) { onDialog("Smart") },
        D("Sync", Icons.Filled.CloudUpload) { onDialog("Sync") },
        D("Kaj (Tasks)", Icons.Filled.TaskAlt) { onDialog("Tasks") },
        D("Shortcut-er talika", Icons.Filled.PlayArrow) { onDialog("Shortcuts") },
        D("Smart Home", Icons.Filled.Lightbulb) { onDialog("SmartHome") },
        D("Claude", Icons.Filled.AutoAwesome) { onDialog("Claude") },
        D("Location", Icons.Filled.MyLocation) { onDialog("Places") },
        D("Sob permission do", Icons.Filled.VerifiedUser) { onDialog("Grant all") },
        D("Moon ke rules", Icons.Filled.VerifiedUser) { onDialog("Moon ke rules") },
        D("PC ⇄ Phone", Icons.Filled.SwapHoriz) { onDialog("PC ⇄ Phone") })
    val aur = listOf(
        D("Privacy Policy", Icons.Filled.Lock) { onDialog("Privacy Policy") },
        D("About", Icons.Filled.Info) { onDialog("About") },
        D("Upgrade", Icons.Filled.Star) { onDialog("Upgrade") },
        D("Notifications", Icons.Filled.NotificationsNone, dot = true) { onDialog("Notifications") })
    ModalDrawerSheet(drawerContainerColor = MC.LightBg, modifier = Modifier.width(310.dp)) {
        Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                MayaLogo(64); Spacer(Modifier.width(14.dp))
                Column { Text("Moon", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("by The Hunter AI", color = MC.Sub, fontSize = 16.sp) }
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth().height(56.dp).soft(28, 4).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Search, null, tint = MC.Sub); Spacer(Modifier.width(12.dp))
                Box { if (q.isEmpty()) Text("Settings me dhundo", color = MC.Sub, fontSize = 18.sp)
                    BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = MC.Navy, fontSize = 18.sp), modifier = Modifier.fillMaxWidth()) }
            }
            fun section(title: String, list: List<D>): @Composable () -> Unit = {
                val f = list.filter { q.isBlank() || it.label.contains(q, true) }
                if (f.isNotEmpty()) {
                    Text(title, color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp, start = 6.dp))
                    f.forEachIndexed { idx, d ->
                        val active = title == "HOME" && idx == 0
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).height(64.dp).let {
                            if (active) it.clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep))) else it.soft(22, 6)
                        }.clickable { d.action() }.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(d.icon, null, tint = if (active) Color.White else MC.BlueDeep); Spacer(Modifier.width(16.dp))
                            Text(d.label, color = if (active) Color.White else MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            if (d.dot) Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFFE67E00)))
                        }
                    }
                }
            }
            section("HOME", home)(); section("KAAM-KAAJ", work)(); section("SYSTEM", sys)(); section("AUR", aur)()
            Spacer(Modifier.height(20.dp))
            Text("$VERSION  ·  The Hunter AI", color = MC.Sub, fontSize = 15.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}


@Composable
private fun MayaDialog(kind: String, prefs: android.content.SharedPreferences, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember {
        mutableStateOf(when (kind) { "Moon ke rules" -> prefs.getString("maya_rules", "").orEmpty(); "Upgrade" -> prefs.getString("license_code", "").orEmpty(); else -> "" })
    }
    val editable = kind == "Moon ke rules" || kind == "Upgrade"
    val body = when (kind) {
        "Moon ke rules" -> "Moon ke liye apne rules likho (jaise: hamesha Hindi me bolo, raat ko call mat karo). Har baat-cheet me Moon inhe follow karegi."
        "PC ⇄ Phone" -> "Phone se PC pe text ya file bhejne ke liye Share dabao aur apna PC / Drive / WhatsApp Web chuno."
        "Privacy Policy" -> "Tumhari Gemini key sirf is phone me save hoti hai aur sirf Google Gemini ko request bhejne me use hoti hai. Chat aur yaadein phone me hi rehti hain. Mic, camera, SMS, contacts jaise permissions sirf tab use hote hain jab tum Moon se kaam karwate ho."
        "About" -> "Moon by The Hunter AI\n$VERSION\nVoice, chat, screen aur phone control wali AI assistant."
        "Upgrade" -> "License code yahan daalo."
        else -> "Abhi koi nayi notification nahi hai. Moon ko WhatsApp / call notifications padhne ke liye Notification access chahiye."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(kind) },
        text = {
            Column {
                Text(body)
                if (editable) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), minLines = if (kind == "Upgrade") 1 else 4)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (kind) {
                    "Moon ke rules" -> prefs.edit().putString("maya_rules", text).apply()
                    "Upgrade" -> prefs.edit().putString("license_code", text.trim()).apply()
                    "PC ⇄ Phone" -> ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "") }, "PC / Phone").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Notifications" -> Perms.open(ctx, 2)
                }
                onDismiss()
            }) { Text(when (kind) { "Moon ke rules", "Upgrade" -> "Save"; "PC ⇄ Phone" -> "Share"; "Notifications" -> "Access kholo"; else -> "OK" }) }
        },
        dismissButton = { if (kind == "PC ⇄ Phone" || kind == "Notifications" || editable) TextButton(onDismiss) { Text("Close") } }
    )
}
