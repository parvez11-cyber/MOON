package com.myra.assistant.perf

import android.content.Context

/**
 * Entry point of the performance / focus package.
 *  - [init]  : give DeviceState a context (ProactiveCompanion.start calls it)
 *  - [tick]  : once a minute: ends expired focus, pumps the background queue, schedules the predictive pre-warm
 *  - [handle]: commands  PERF (status of everything) | FOCUS on [min] | FOCUS off | FOCUS status
 */
object PerfHub {
    fun init(c: Context) { DeviceState.init(c) }

    fun tick(c: Context) {
        val app = c.applicationContext
        try { FocusMode.isActive(app) } catch (_: Exception) {}
        try {
            BackgroundTaskOptimizer.submit(app, "prewarm", BackgroundTaskOptimizer.Priority.LOW,
                BackgroundTaskOptimizer.Constraints(maxThermal = 1, minBattery = 20)) { PredictiveCachePrewarmer.warm(it) }
            BackgroundTaskOptimizer.pump(app)
        } catch (_: Exception) {}
    }

    fun handles(raw: String): Boolean {
        val h = raw.trim().substringBefore(' ').uppercase()
        return h == "PERF" || h == "FOCUS"
    }

    fun handle(c: Context, raw: String): String {
        val h = raw.trim().substringBefore(' ').uppercase()
        return when (h) {
            "FOCUS" -> FocusMode.handle(c, raw)
            else -> listOf(
                DynamicResourceAllocator.status(c), NpuOptimizer.status(), PredictiveCachePrewarmer.status(),
                BackgroundTaskOptimizer.status(), DataCompressor.status()
            ).joinToString("\n")
        }
    }
}
