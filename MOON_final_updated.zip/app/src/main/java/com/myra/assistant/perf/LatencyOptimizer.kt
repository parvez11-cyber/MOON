package com.myra.assistant.perf

import java.util.concurrent.ConcurrentHashMap

/**
 * Real-time latency optimizer. Measures how long things really take on this phone and this network
 * (Gemini round trip, command execution, anything you wrap in [track]) and keeps a rolling window per label.
 *
 *  - [adaptiveTimeout]: a timeout from the measured p95 (x1.5), instead of a fixed guess
 *  - [degraded]: true when the last few samples are far slower than this label's own normal
 *    -> [DynamicResourceAllocator] then sends smaller images and backs off background work
 *
 * Plain statistics (rolling window, p95, moving average). Nothing leaves the phone.
 */
object LatencyOptimizer {
    private const val WINDOW = 50
    private const val MIN_SAMPLES = 8

    private class Series {
        val ring = LongArray(WINDOW)
        var n = 0
        var idx = 0
        var ewma = 0.0
        var pendingAt = 0L
    }

    private val map = ConcurrentHashMap<String, Series>()
    private fun s(label: String) = map.getOrPut(label) { Series() }

    fun record(label: String, ms: Long) {
        val x = s(label)
        synchronized(x) {
            x.ring[x.idx] = ms.coerceAtLeast(0)
            x.idx = (x.idx + 1) % WINDOW
            if (x.n < WINDOW) x.n++
            x.ewma = if (x.n == 1) ms.toDouble() else 0.8 * x.ewma + 0.2 * ms
        }
    }

    inline fun <T> track(label: String, block: () -> T): T {
        val t = System.nanoTime()
        try { return block() } finally { record(label, (System.nanoTime() - t) / 1_000_000) }
    }

    /** Request sent: starts the clock (only the first unanswered send counts). */
    fun markSent(label: String) { val x = s(label); synchronized(x) { if (x.pendingAt == 0L) x.pendingAt = System.currentTimeMillis() } }

    /** First answer arrived: stops the clock and records the round trip. */
    fun markResponse(label: String) {
        val x = map[label] ?: return
        val started = synchronized(x) { val p = x.pendingAt; x.pendingAt = 0L; p }
        if (started > 0L) record(label, System.currentTimeMillis() - started)
    }

    private fun sorted(label: String): List<Long> {
        val x = map[label] ?: return emptyList()
        return synchronized(x) { x.ring.take(x.n).sorted() }
    }

    fun p95(label: String): Long? = sorted(label).let { if (it.size < MIN_SAMPLES) null else it[((it.size - 1) * 0.95).toInt()] }
    fun median(label: String): Long? = sorted(label).let { if (it.size < MIN_SAMPLES) null else it[it.size / 2] }
    fun average(label: String): Double? = map[label]?.let { x -> synchronized(x) { if (x.n < MIN_SAMPLES) null else x.ewma } }

    fun adaptiveTimeout(label: String, defaultMs: Long): Long {
        val p = p95(label) ?: return defaultMs
        return (p * 3 / 2).coerceIn(defaultMs / 2, defaultMs * 3)
    }

    /** Last 5 samples clearly slower (> 2x and > 800 ms) than this label's usual (20th percentile). */
    fun degraded(label: String): Boolean {
        val x = map[label] ?: return false
        val (recent, base) = synchronized(x) {
            if (x.n < MIN_SAMPLES) return false
            val last5 = (1..5).map { x.ring[(x.idx - it + WINDOW * 2) % WINDOW] }
            last5.average() to x.ring.take(x.n).sorted()[x.n / 5].toDouble()
        }
        return recent > 800 && recent > 2.0 * base.coerceAtLeast(100.0)
    }

    fun report(): String {
        if (map.isEmpty()) return "latency: kono data nei ekhono"
        return map.keys.sorted().joinToString("; ") { k ->
            val m = median(k); val p = p95(k)
            if (m == null) "$k: shuru hocche" else "$k: median ${m}ms, p95 ${p}ms" + if (degraded(k)) " (dhimi)" else ""
        }
    }
}
