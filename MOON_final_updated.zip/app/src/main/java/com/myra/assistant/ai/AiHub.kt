package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.models.CommandType

/**
 * Single entry point that connects the dialog manager, aliases, the rule-based [IntentAnalyzer], zero-shot
 * understanding and adaptive learning. Order for every user sentence:
 *
 *   settle feedback on the last guess -> WORKLOAD -> DialogManager -> learned alias -> IntentAnalyzer (rules) -> zero-shot -> Gemini
 *
 * [Routed.command] = a command line to execute; [Routed.reply] = something to say instead of running anything;
 * both null = nothing special, carry on with the normal flow (rules or Gemini conversation).
 */
object AiHub {

    data class Routed(val command: String?, val reply: String?, val source: String)

    private class Guess(val intentId: String, val phrase: String, val command: String, val at: Long = System.currentTimeMillis())

    private const val GUESS_WINDOW_MS = 90_000L
    private val NEGATIVE = setOf("না", "na", "no", "ভুল", "vul", "wrong", "ওটা না", "ota na", "এটা না")
    private var lastGuess: Guess? = null

    fun route(c: Context, text: String): Routed {
        val t = text.trim()
        if (t.isEmpty()) return Routed(null, null, "none")

        settlePrevious(c, t)?.let { return it }

        internalReply(c, t)?.let { return Routed(null, it, "internal") }

        when (val d = DialogManager.handle(c, t)) {
            is DialogManager.Outcome.Proceed -> return Routed(d.command, null, "dialog")
            is DialogManager.Outcome.Ask -> return Routed(null, d.question, "dialog")
            is DialogManager.Outcome.Confirm -> return Routed(null, d.question, "dialog")
            is DialogManager.Outcome.Cancelled -> return Routed(null, d.reply, "dialog")
            DialogManager.Outcome.Pass -> {}
        }

        AdaptiveLearner.aliasFor(c, t)?.let { return Routed(it, null, "alias") }

        val rule = IntentAnalyzer.analyze(t)
        if (rule.type != CommandType.CONVERSATION && rule.type != CommandType.UNKNOWN) return Routed(null, null, "rule")

        val m = ZeroShotIntentResolver.resolve(t, bias = { AdaptiveLearner.bias(c, it) })
        if (m != null) {
            val line = m.commandLine()
            internalReply(c, line)?.let { return Routed(null, it, "zeroshot") }
            lastGuess = Guess(m.intent.id, t, line)
            return Routed(line, null, "zeroshot")
        }
        return Routed(null, null, "none")
    }

    /** Commands the app answers itself (no phone action): WORKLOAD, FOCUS, PERF. Null for anything else. */
    fun internalReply(c: Context, line: String): String? {
        val h = line.trim().substringBefore(' ').uppercase()
        return when {
            h == "WORKLOAD" -> WorkloadBalancer.handle(c, line)
            h == "FOCUS" || h == "PERF" -> com.myra.assistant.perf.PerfHub.handle(c, line)
            else -> null
        }
    }

    /** Call after any command was actually executed. */
    fun onExecuted(c: Context, command: String) {
        try { DialogManager.remember(command) } catch (_: Exception) {}
    }

    /** Explicit feedback (e.g. a thumbs up/down in the UI) for the last zero-shot guess. */
    fun feedback(c: Context, accepted: Boolean) {
        val g = lastGuess ?: return
        lastGuess = null
        AdaptiveLearner.recordOutcome(c, g.intentId, accepted)
        if (accepted) AdaptiveLearner.learnAlias(c, g.phrase, g.command)
    }

    /** Implicit feedback: a "no" right after a guess rejects it; any other next sentence counts as acceptance. */
    private fun settlePrevious(c: Context, text: String): Routed? {
        val g = lastGuess ?: return null
        lastGuess = null
        if (System.currentTimeMillis() - g.at > GUESS_WINDOW_MS) return null
        return if (AiText.norm(text) in NEGATIVE) {
            AdaptiveLearner.recordOutcome(c, g.intentId, false)
            Routed(null, "Ei, bhul bujhechhi. Ki chao abar bolo.", "feedback")
        } else {
            AdaptiveLearner.recordOutcome(c, g.intentId, true)
            AdaptiveLearner.learnAlias(c, g.phrase, g.command)
            null
        }
    }
}
