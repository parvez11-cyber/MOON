package com.myra.assistant.ai

/**
 * Zero-shot intent understanding: a phrase the rule-based [IntentAnalyzer] has never seen
 * ("alo jalao", "ar jore", "আজ কাজের চাপ কেমন") is matched against *descriptions* of what each
 * command does. No training data and no network: a new capability is added with [register]
 * and works immediately.
 *
 * Score (0..1) = 0.45 word coverage of the example phrase + 0.25 character-trigram overlap
 * + 0.30 how much of what the user said is explained by the phrase (ignored for intents that take an argument).
 * A match needs [minScore] and must beat the runner-up by [minMargin], otherwise null
 * (so the message goes on to the normal Gemini conversation instead of a wrong action).
 */
object ZeroShotIntentResolver {

    /** [command] is the exact line DynamicDecisionEngine understands; "{arg}" is replaced by the leftover words. */
    data class Intent(val id: String, val command: String, val phrases: List<String>, val takesArg: Boolean = false)

    data class Match(val intent: Intent, val score: Double, val arg: String) {
        fun commandLine(): String = intent.command.replace("{arg}", arg).trim()
    }

    private val registry = LinkedHashMap<String, Intent>()

    @Synchronized fun register(intent: Intent) { registry[intent.id] = intent }
    @Synchronized fun unregister(id: String) { registry.remove(id) }
    @Synchronized fun all(): List<Intent> = registry.values.toList()

    init {
        fun r(id: String, cmd: String, vararg p: String, arg: Boolean = false) = register(Intent(id, cmd, p.toList(), arg))
        r("FLASH_ON", "FLASHLIGHT_ON", "torch jalao", "alo jalao", "flashlight on", "turn on the torch", "টর্চ জ্বালাও", "আলো জ্বালাও", "টর্চ চালু করো")
        r("FLASH_OFF", "FLASHLIGHT_OFF", "torch nibhao", "alo nibhao", "flashlight off", "turn off the torch", "টর্চ নিভাও", "আলো নিভাও", "টর্চ বন্ধ করো")
        r("VOL_UP", "VOLUME_UP", "awaj barao", "volume barao", "ar jore", "make it louder", "increase the volume", "শব্দ বাড়াও", "আওয়াজ বাড়াও", "আরও জোরে")
        r("VOL_DOWN", "VOLUME_DOWN", "awaj komao", "volume komao", "ektu halka", "make it quieter", "lower the sound", "শব্দ কমাও", "আওয়াজ কমাও", "একটু আস্তে")
        r("HOME", "HOME", "home e jao", "go to the home screen", "হোম স্ক্রিনে যাও", "হোমে যাও")
        r("BACK", "BACK", "pichone jao", "go back", "ফিরে যাও", "পেছনে যাও")
        r("RECENTS", "RECENTS", "recent app dekhao", "show recent apps", "চলমান অ্যাপ দেখাও", "রিসেন্ট অ্যাপ দেখাও")
        r("READ_SCREEN", "READ_SCREEN", "screen e ki ache", "what is on the screen", "screen poro", "স্ক্রিনে কী আছে", "স্ক্রিন পড়ো")
        r("WIFI_ON", "SYSTEM wifi on", "wifi chalu koro", "turn on wifi", "ওয়াইফাই চালু করো")
        r("WIFI_OFF", "SYSTEM wifi off", "wifi bondho koro", "turn off wifi", "ওয়াইফাই বন্ধ করো")
        r("TASK_LIST", "TASK list", "amar kaj gulo dekhao", "what are my tasks", "show my to do list", "আমার কাজের তালিকা", "কাজগুলো দেখাও")
        r("TASK_TOP", "TASK top", "ekhon ki korbo", "what should i do first", "most urgent task", "সবচেয়ে জরুরি কাজ কোনটা", "এখন কী করব")
        r("WORKLOAD", "WORKLOAD", "kaj onek beshi", "am i overloaded", "how busy am i", "আজ কাজের চাপ কেমন", "কাজের চাপ")
        r("FOCUS_ON", "FOCUS on 45", "focus mode chalu koro", "ami kaj korbo disturb koro na", "do not disturb me for a while", "ফোকাস মোড চালু করো", "আমাকে বিরক্ত করো না", "পড়তে বসছি")
        r("FOCUS_OFF", "FOCUS off", "focus mode bondho koro", "end focus mode", "ফোকাস মোড বন্ধ করো", "কাজ শেষ")
        r("PERF", "PERF", "phone slow keno", "how is the phone doing", "battery ar speed kemon", "ফোন স্লো কেন", "ফোনের অবস্থা কেমন")
        r("OPEN_APP", "OPEN_APP {arg}", "app kholo", "open the app", "launch app", "অ্যাপ খোলো", "অ্যাপ চালু করো", arg = true)
    }

    fun resolve(text: String, bias: (String) -> Double = { 0.0 }, minScore: Double = 0.5, minMargin: Double = 0.08): Match? {
        val tt = AiText.tokens(text)
        if (tt.isEmpty() || tt.size > 12) return null
        val tg = AiText.trigrams(text)

        data class Scored(val intent: Intent, val score: Double, val phrase: List<String>)
        val scored = all().map { intent ->
            var best = 0.0
            var bestPhrase = emptyList<String>()
            for (ph in intent.phrases) {
                val pt = AiText.tokens(ph)
                if (pt.isEmpty()) continue
                val covered = pt.count { p -> tt.any { AiText.sameWord(it, p) } }
                val cover = covered.toDouble() / pt.size
                val explained = tt.count { t -> pt.any { AiText.sameWord(t, it) } }.toDouble() / tt.size
                val s = 0.45 * cover + 0.25 * AiText.jaccard(tg, AiText.trigrams(ph)) + 0.30 * (if (intent.takesArg) cover else explained)
                if (s > best) { best = s; bestPhrase = pt }
            }
            Scored(intent, (best + bias(intent.id)).coerceIn(0.0, 1.0), bestPhrase)
        }.sortedByDescending { it.score }

        val top = scored.firstOrNull() ?: return null
        if (top.score < minScore) return null
        val second = scored.getOrNull(1)?.score ?: 0.0
        if (top.score - second < minMargin) return null

        var arg = ""
        if (top.intent.takesArg) {
            arg = tt.filter { t -> top.phrase.none { AiText.sameWord(t, it) } && t !in AiText.FILLER }.joinToString(" ")
            if (arg.isBlank()) return null    // "open app" with no app name: let the DialogManager ask for it
        }
        return Match(top.intent, top.score, arg)
    }
}
