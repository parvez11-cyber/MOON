package com.myra.assistant.perf

import android.content.Context
import android.os.Build
import java.util.concurrent.ConcurrentHashMap

/**
 * NPU / accelerator optimizer: decides WHICH compute backend (NPU, GPU, CPU) an on-device model should run on right now,
 * and runs it with automatic fallback.
 *
 * Honest scope: Android gives apps no direct control of the NPU. A model runs on it only through a delegate
 * (LiteRT / NNAPI / vendor SDK). This app has no such model today (OCR uses ML Kit, which accelerates itself),
 * so this module is the selection + fallback + measurement layer you plug a model into:
 *
 *   NpuOptimizer.run(ctx, Workload.VISION, mapOf(Backend.NPU to { npuInfer() }, Backend.CPU to { cpuInfer() }))
 *
 * Order = preference for the workload, adjusted by heat / battery ([DynamicResourceAllocator]), by measured speed
 * (after 3+ runs of each) and by a circuit breaker (3 failures -> that backend is skipped for 10 minutes).
 */
object NpuOptimizer {
    enum class Backend { NPU, GPU, CPU }
    enum class Workload { VISION, SPEECH, TEXT, TINY }

    private class Stat { var n = 0; var ewma = 0.0; var fails = 0; var blockedUntil = 0L }
    private val stats = ConcurrentHashMap<String, Stat>()
    private fun st(b: Backend, w: Workload) = stats.getOrPut("$b/$w") { Stat() }
    private const val BREAKER_MS = 10 * 60_000L

    /** What the chip is called (only a hint: Android has no API that says "this phone has an NPU"). */
    fun hardwareHint(): String = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE

    fun order(c: Context?, w: Workload): List<Backend> {
        val profile = DynamicResourceAllocator.profile(c)
        var base = when (w) {
            Workload.VISION, Workload.SPEECH -> listOf(Backend.NPU, Backend.GPU, Backend.CPU)
            Workload.TEXT -> listOf(Backend.NPU, Backend.CPU, Backend.GPU)
            Workload.TINY -> listOf(Backend.CPU, Backend.NPU, Backend.GPU)     // too small to repay the delegate start-up cost
        }
        if (profile == DynamicResourceAllocator.Profile.ECO || profile == DynamicResourceAllocator.Profile.CRITICAL) {
            base = base.filter { it != Backend.GPU } + Backend.GPU              // GPU is the thirstiest: last resort when hot / low battery
        }
        val now = System.currentTimeMillis()
        val open = base.filter { st(it, w).blockedUntil <= now }
        val usable = if (open.isEmpty()) listOf(Backend.CPU) else open
        // measured speed: swap two neighbours when the later one is clearly faster (>25%) with enough samples
        val out = usable.toMutableList()
        for (i in 0 until out.size - 1) {
            val a = st(out[i], w); val b = st(out[i + 1], w)
            if (a.n >= 3 && b.n >= 3 && b.ewma < a.ewma * 0.75) { val t = out[i]; out[i] = out[i + 1]; out[i + 1] = t }
        }
        return out
    }

    fun report(b: Backend, w: Workload, ms: Long, ok: Boolean) {
        val s = st(b, w)
        synchronized(s) {
            if (ok) { s.n++; s.ewma = if (s.n == 1) ms.toDouble() else 0.8 * s.ewma + 0.2 * ms; s.fails = 0 }
            else { s.fails++; if (s.fails >= 3) { s.blockedUntil = System.currentTimeMillis() + BREAKER_MS; s.fails = 0 } }
        }
    }

    /** Tries the preferred backend first; on an exception falls back to the next one. Throws only if all fail. */
    fun <T> run(c: Context?, w: Workload, impls: Map<Backend, () -> T>): T {
        var last: Throwable? = null
        for (b in order(c, w)) {
            val f = impls[b] ?: continue
            val t = System.nanoTime()
            try {
                val r = f()
                val ms = (System.nanoTime() - t) / 1_000_000
                report(b, w, ms, true)
                LatencyOptimizer.record("npu:$b/$w", ms)
                return r
            } catch (e: Throwable) {
                report(b, w, 0, false)
                last = e
            }
        }
        throw last ?: IllegalStateException("no backend implementation given")
    }

    fun status(): String = "Compute: chip ${hardwareHint()}; " +
        stats.entries.filter { it.value.n > 0 }.joinToString { "${it.key} ${it.value.ewma.toInt()}ms" }.ifBlank { "kono on-device model ekhono cholte dekhini" }
}
