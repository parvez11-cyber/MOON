package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.apps.AppLauncher
import com.myra.assistant.models.CommandType
import com.myra.assistant.notification.NotificationReaderService
import com.myra.assistant.screenvision.ScreenReader
import com.myra.assistant.service.SmartAccessibilityEngine
import com.myra.assistant.system.SmsSender
import com.myra.assistant.system.SystemSettings
import com.myra.assistant.utils.Logger

object DynamicDecisionEngine {
    private val TAG = "DECISION"

    suspend fun execute(context: Context, command: com.myra.assistant.models.VoiceCommand): String {
        Logger.d(TAG, "Executing: ${command.type} - ${command.raw}")
        return when (command.type) {
            CommandType.OPEN_APP -> {
                val app = command.args["app"] ?: ""
                if (AppLauncher.launch(context, app)) "ঠিক আছে, $app খুলছি।" else "$app অ্যাপটি পাওয়া যাচ্ছে না।"
            }
            CommandType.VOLUME_UP -> { adjustVolume(context, true); "ভলিউম বাড়িয়ে দিলাম।" }
            CommandType.VOLUME_DOWN -> { adjustVolume(context, false); "ভলিউম কমিয়ে দিলাম।" }
            CommandType.FLASHLIGHT_ON -> { toggleFlashlight(context, true); "টর্চ চালু করে দিলাম।" }
            CommandType.FLASHLIGHT_OFF -> { toggleFlashlight(context, false); "টর্চ বন্ধ করে দিলাম।" }
            CommandType.WHATSAPP_CALL -> {
                SmartAccessibilityEngine.execute("WHATSAPP_CALL ${command.args["name"] ?: ""}")
                "WhatsApp কল করছি।"
            }
            CommandType.WHATSAPP_MSG -> {
                val name = command.args["name"] ?: ""
                val msg = command.args["message"] ?: ""
                SmartAccessibilityEngine.execute("WHATSAPP_MSG $name $msg")
                "মেসেজ পাঠাচ্ছি।"
            }
            CommandType.YOUTUBE_PLAY -> {
                SmartAccessibilityEngine.execute("YOUTUBE_PLAY ${command.args["query"] ?: ""}")
                "YouTube চালু করে দিচ্ছি।"
            }
            CommandType.SPOTIFY_PLAY -> {
                SmartAccessibilityEngine.execute("SPOTIFY_PLAY ${command.args["query"] ?: ""}")
                "Spotify চালু করে দিচ্ছি।"
            }
            CommandType.CALL -> {
                val r = com.myra.assistant.automation.CallAutomation.callByName(context, command.args["name"] ?: "")
                r.message
            }
            CommandType.NAVIGATE -> {
                val action = command.args["action"].orEmpty()
                if (SmartAccessibilityEngine.execute(action).success) "ঠিক আছে।" else "কাজটি করা গেল না।"
            }
            CommandType.SMS -> {
                // the result text goes back to the model, which then tells the user the real outcome
                val rest = command.args["rest"] ?: "${command.args["name"].orEmpty()} | ${command.args["message"].orEmpty()}"
                // she now opens the messages app, types the message on the display and presses Send (see ScreenTyper)
                com.myra.assistant.system.ScreenTyper.smsOnScreen(context, rest)
            }
            CommandType.TYPE_TEXT -> com.myra.assistant.system.ScreenTyper.typeOnScreen(context, command.args["text"].orEmpty())
            CommandType.TAP_BUTTON -> com.myra.assistant.system.ScreenTyper.tapOnScreen(context, command.args["label"].orEmpty())
            CommandType.ROUTINE -> RoutineStore.handle(context, command.args["raw"].orEmpty())
            CommandType.SCROLL -> com.myra.assistant.system.ScreenControl.scroll(command.args["arg"].orEmpty())
            CommandType.SCROLL_TO -> com.myra.assistant.system.ScreenControl.scrollTo(command.args["text"].orEmpty())
            CommandType.SWIPE -> com.myra.assistant.system.ScreenControl.swipe(command.args["arg"].orEmpty().ifBlank { "down" })
            CommandType.TAP_AT -> {
                val n = Regex("[0-9]+(?:\\.[0-9]+)?").findAll(command.args["arg"].orEmpty()).map { it.value.toFloat() }.toList()
                if (n.size >= 2) com.myra.assistant.system.ScreenControl.tapAt(n[0], n[1]) else "TAP_AT <x%> <y%> dao, jemon TAP_AT 50 80."
            }
            CommandType.TAP_NUMBER -> com.myra.assistant.system.ScreenControl.tapNumber(command.args["arg"].orEmpty().trim().toIntOrNull() ?: -1)
            CommandType.LONG_PRESS -> com.myra.assistant.system.ScreenControl.longPress(command.args["arg"].orEmpty())
            CommandType.TASK -> com.myra.assistant.ai.TaskStore.handle(context, command.args["arg"].orEmpty())
            CommandType.PRIVACY -> com.myra.assistant.system.PrivacyMode.apply(context, command.args["arg"].orEmpty())
            CommandType.READ_SCREEN ->
                if (com.myra.assistant.system.PrivacyMode.isOn(context)) "Privacy mode chalu, tai screen porchi na."
                else ScreenReader.describe(context)
            CommandType.TRADE_SIGNAL ->
                if (com.myra.assistant.system.PrivacyMode.isOn(context)) "Privacy mode chalu, tai screen / chart dekhchi na."
                else com.myra.assistant.trading.ChartAnalyzer.analyze(context, command.args["note"].orEmpty())
            CommandType.SYSTEM_SETTING -> SystemSettings.apply(context, command.args["rest"].orEmpty())
            CommandType.NOISE -> com.myra.assistant.voice.NoiseControl.apply(context, command.args["arg"].orEmpty())
            CommandType.THEME -> com.myra.assistant.ui.maya.ThemeStore.apply(context, command.args["arg"].orEmpty())
            CommandType.SMART_HOME -> com.myra.assistant.home.SmartHome.apply(context, command.args["arg"].orEmpty())
            CommandType.LOCATION -> com.myra.assistant.system.LocationServices.apply(context, command.args["arg"].orEmpty())
            else -> {
                val raw = command.raw.trim()
                when {
                    raw.startsWith("READ_NOTIFICATIONS", true) && com.myra.assistant.system.PrivacyMode.isOn(context) ->
                        "Privacy mode chalu, tai notification porchi na."
                    raw.startsWith("READ_NOTIFICATIONS", true) ->
                        NotificationReaderService.instance?.recentSummary()
                            ?: "Notification access chalu kora nei. Settings theke on koro."
                    raw.startsWith("REPLY_NOTIFICATION_TO", true) -> {
                        val rest = raw.substringAfter("REPLY_NOTIFICATION_TO", "").trim()
                        val parts = rest.split(" ", limit = 2)
                        val target = parts.getOrNull(0)
                        val msg = parts.getOrNull(1).orEmpty()
                        if (msg.isNotBlank() && NotificationReaderService.instance?.replyTo(target, msg) == true) "রিপ্লাই পাঠিয়ে দিলাম।" else "রিপ্লাই পাঠাতে পারিনি।"
                    }
                    raw.startsWith("REPLY_NOTIFICATION", true) -> {
                        val msg = raw.substringAfter("REPLY_NOTIFICATION", "").trim()
                        if (msg.isNotBlank() && NotificationReaderService.instance?.replyToLatest(msg) == true) "রিপ্লাই পাঠিয়ে দিলাম।" else "রিপ্লাই পাঠাতে পারিনি।"
                    }
                    else -> ""
                }
            }
        }
    }

    /** Direct AudioManager call: instant, and works even when the accessibility service is off. */
    private fun adjustVolume(context: Context, up: Boolean) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            repeat(2) {
                am.adjustStreamVolume(
                    android.media.AudioManager.STREAM_MUSIC,
                    if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
                    if (it == 0) android.media.AudioManager.FLAG_SHOW_UI else 0
                )
            }
        } catch (e: Exception) { Logger.e(TAG, "Volume error: ${e.message}") }
    }

    private fun toggleFlashlight(context: Context, on: Boolean) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val cameraId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) cm.setTorchMode(cameraId, on)
        } catch (e: Exception) { Logger.e(TAG, "Flashlight error: ${e.message}") }
    }
}
