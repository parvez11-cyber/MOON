package com.myra.assistant.ui.maya

import android.content.Context
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.sync.SyncManager

/** Sync dashboard. Works fully offline: save a snapshot to Drive / Files, restore it on another phone. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
    fun ago(t: Long) = if (t == 0L) "ekhono na" else DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            ctx.contentResolver.openOutputStream(u, "wt")?.use { it.write(SyncManager.snapshot(ctx).toByteArray()) }
            toast("Snapshot save hoyeche"); tick++
        } catch (e: Exception) { toast("Save hoyni: ${e.message}") }
    }
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() }.orEmpty()
            toast(SyncManager.restore(ctx, text)); tick++
        } catch (e: Exception) { toast("Porte parini: ${e.message}") }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Sync dashboard", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(16.dp)) {
                Text("Offline-ready", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Sob data ei phone-e ache, internet na thakleo kaj kore.", color = MC.Sub, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                val key = tick
                Text("Shesh snapshot save: ${ago(SyncManager.lastSaved(ctx))}", color = MC.Navy, fontSize = 14.sp)
                Text("Shesh restore: ${ago(SyncManager.lastRestored(ctx))}", color = MC.Navy, fontSize = 14.sp)
                if (key < 0) Text("")
            }
            Text("Ki ki sync hobe", color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
            SyncManager.Cat.values().forEach { cat ->
                var on by remember(tick) { mutableStateOf(SyncManager.enabled(ctx, cat)) }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${cat.title}  (${SyncManager.count(ctx, cat)})", color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(cat.sub, color = MC.Sub, fontSize = 13.sp)
                    }
                    Switch(on, { on = it; SyncManager.setEnabled(ctx, cat, it) })
                }
            }
            Spacer(Modifier.height(14.dp))
            SyncBtn("Snapshot save koro (Drive / Files)", true) { saver.launch("myra-sync.json") }
            Spacer(Modifier.height(10.dp))
            SyncBtn("Snapshot restore koro (merge)", false) { loader.launch(arrayOf("application/json", "text/plain", "*/*")) }
            Text("Drive / Dropbox-er folder-e save korle onno phone-e oi file ei restore korte parbe. Restore-e kichu muche jay na, shudhu notun ta jog hoy. Shesh-e live cloud (Firebase / Supabase) chaile bolo.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun SyncBtn(label: String, primary: Boolean, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(18.dp))
        .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
