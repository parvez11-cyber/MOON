package com.myra.assistant.sync

import android.content.Context
import android.os.Build
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.ui.maya.ThemeStore
import com.myra.assistant.utils.Constants
import org.json.JSONArray
import org.json.JSONObject

/**
 * Offline-first sync. Everything lives on the phone and works with no internet; a snapshot (one JSON file) can be saved
 * anywhere the system file picker reaches (Google Drive, Dropbox, local storage) and restored on another phone / platform.
 * Restoring MERGES: nothing local is deleted. A real cloud backend (Firebase / Supabase) can implement [SyncBackend] later.
 */
interface SyncBackend {
    suspend fun push(json: String): Boolean
    suspend fun pull(): String?
}

object SyncManager {
    private const val PREFS = Constants.PREFS_NAME

    enum class Cat(val key: String, val title: String, val sub: String) {
        THEME("theme", "Theme settings", "mode, rong, AMOLED, lekhar size"),
        MEMORY("memory", "Yaadein", "Maya ja mone rekhechhe"),
        ROUTINES("routines", "Routines", "save kora routine"),
        PREDICT("predict", "Shikha abhyash", "predictive habit ar likhar suggestion"),
        RULES("rules", "Maya-r rules", "tomar likha rules"),
        HOME("home", "Smart Home device", "device-er naam (token kokhono na)"),
        PLACES("places", "Saved jaiga", "home / office-er location (default off)")
    }

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun enabled(c: Context, cat: Cat) = p(c).getBoolean("sync_cat_" + cat.key, cat != Cat.PLACES)
    fun setEnabled(c: Context, cat: Cat, on: Boolean) { p(c).edit().putBoolean("sync_cat_" + cat.key, on).apply() }
    fun lastSaved(c: Context) = p(c).getLong("sync_last_saved", 0L)
    fun lastRestored(c: Context) = p(c).getLong("sync_last_restored", 0L)

    private fun themeKeys() = listOf("theme_mode", "theme_accent", "theme_amoled", "theme_mood", "theme_glow", "theme_font")

    /** How many items each category holds right now (for the dashboard). */
    fun count(c: Context, cat: Cat): Int = try {
        val sp = p(c)
        when (cat) {
            Cat.THEME -> themeKeys().count { sp.contains(it) }
            Cat.MEMORY -> PersistentMemory.all().size
            Cat.ROUTINES -> JSONObject(sp.getString("routines_json", "{}") ?: "{}").length()
            Cat.PREDICT -> JSONObject(sp.getString("predict_data", "{}") ?: "{}").length() + JSONObject(sp.getString("predict_typed", "{}") ?: "{}").length()
            Cat.RULES -> if (sp.getString("maya_rules", "").isNullOrBlank()) 0 else 1
            Cat.HOME -> com.myra.assistant.home.SmartHome.deviceCount(c)
            Cat.PLACES -> com.myra.assistant.system.LocationServices.placeCount(c)
        }
    } catch (_: Exception) { 0 }

    fun snapshot(c: Context): String {
        val sp = p(c)
        val data = JSONObject()
        if (enabled(c, Cat.THEME)) data.put("theme", JSONObject().also { o ->
            themeKeys().forEach { k -> if (sp.contains(k)) o.put(k, sp.all[k]) }
        })
        if (enabled(c, Cat.MEMORY)) data.put("memory", JSONArray(PersistentMemory.all()))
        if (enabled(c, Cat.ROUTINES)) data.put("routines", JSONObject(sp.getString("routines_json", "{}") ?: "{}"))
        if (enabled(c, Cat.PREDICT)) data.put("predict", JSONObject()
            .put("data", JSONObject(sp.getString("predict_data", "{}") ?: "{}"))
            .put("typed", JSONObject(sp.getString("predict_typed", "{}") ?: "{}")))
        if (enabled(c, Cat.RULES)) data.put("rules", sp.getString("maya_rules", "").orEmpty())
        // aliases only: the Home Assistant URL and token are in encrypted storage and never leave this phone
        if (enabled(c, Cat.HOME)) data.put("home", JSONObject(sp.getString("smarthome_devices", "{}") ?: "{}"))
        if (enabled(c, Cat.PLACES)) data.put("places", JSONObject(sp.getString("saved_places", "{}") ?: "{}"))
        val out = JSONObject().put("app", "myra").put("version", 1).put("at", System.currentTimeMillis())
            .put("device", Build.MODEL ?: "android").put("data", data)
        sp.edit().putLong("sync_last_saved", System.currentTimeMillis()).apply()
        return out.toString(2)
    }

    /** Merges a snapshot into this phone. Returns a one-line summary. */
    fun restore(c: Context, json: String): String {
        val root = try { JSONObject(json) } catch (_: Exception) { return "File ta MYRA snapshot na." }
        if (root.optString("app") != "myra") return "File ta MYRA snapshot na."
        val data = root.optJSONObject("data") ?: return "Snapshot-e kono data nei."
        val sp = p(c)
        val done = ArrayList<String>()
        try {
            if (enabled(c, Cat.THEME)) data.optJSONObject("theme")?.let { o ->
                val e = sp.edit()
                o.keys().forEach { k ->
                    if (k in themeKeys()) when (val v = o.get(k)) {
                        is Boolean -> e.putBoolean(k, v)
                        is Number -> e.putFloat(k, v.toFloat())
                        else -> e.putString(k, v.toString())
                    }
                }
                e.apply(); ThemeStore.reload(c); done += "theme"
            }
            if (enabled(c, Cat.MEMORY)) data.optJSONArray("memory")?.let { a ->
                val have = PersistentMemory.all().map { it.trim().lowercase() }.toSet()
                var n = 0
                for (i in 0 until a.length()) { val t = a.optString(i).trim(); if (t.isNotEmpty() && t.lowercase() !in have) { PersistentMemory.add(t); n++ } }
                done += "$n ta notun yaad"
            }
            if (enabled(c, Cat.ROUTINES)) data.optJSONObject("routines")?.let { o ->
                val mine = JSONObject(sp.getString("routines_json", "{}") ?: "{}")
                var n = 0
                o.keys().forEach { k -> if (!mine.has(k)) { mine.put(k, o.get(k)); n++ } }
                sp.edit().putString("routines_json", mine.toString()).apply(); done += "$n ta routine"
            }
            if (enabled(c, Cat.PREDICT)) data.optJSONObject("predict")?.let { o ->
                // habits: union of the days seen; typed: highest count wins
                val mine = JSONObject(sp.getString("predict_data", "{}") ?: "{}")
                o.optJSONObject("data")?.let { theirs ->
                    theirs.keys().forEach { key ->
                        val tb = theirs.getJSONObject(key)
                        val mb = mine.optJSONObject(key) ?: JSONObject().also { mine.put(key, it) }
                        tb.keys().forEach { h ->
                            val td = tb.getJSONObject(h)
                            val md = mb.optJSONObject(h) ?: JSONObject().also { mb.put(h, it) }
                            td.keys().forEach { d -> md.put(d, maxOf(md.optInt(d, 0), td.optInt(d, 0))) }
                        }
                    }
                }
                val typed = JSONObject(sp.getString("predict_typed", "{}") ?: "{}")
                o.optJSONObject("typed")?.let { t -> t.keys().forEach { k -> typed.put(k, maxOf(typed.optInt(k, 0), t.optInt(k, 0))) } }
                sp.edit().putString("predict_data", mine.toString()).putString("predict_typed", typed.toString()).apply()
                done += "shikha abhyash"
            }
            if (enabled(c, Cat.RULES)) {
                val r = data.optString("rules", "")
                if (r.isNotBlank() && sp.getString("maya_rules", "").isNullOrBlank()) { sp.edit().putString("maya_rules", r).apply(); done += "rules" }
            }
            if (enabled(c, Cat.HOME)) data.optJSONObject("home")?.let { o -> mergeKeys(sp, "smarthome_devices", o)?.let { done += "$it ta device" } }
            if (enabled(c, Cat.PLACES)) data.optJSONObject("places")?.let { o -> mergeKeys(sp, "saved_places", o)?.let { done += "$it ta jaiga" } }
        } catch (e: Exception) { return "Restore-e somossa: ${e.message}" }
        sp.edit().putLong("sync_last_restored", System.currentTimeMillis()).apply()
        return if (done.isEmpty()) "Notun kichu paini." else "Merge hoyeche: " + done.joinToString(", ") + "."
    }

    /** Adds the keys of [theirs] that this phone does not have yet. Returns how many were added (null if none). */
    private fun mergeKeys(sp: android.content.SharedPreferences, key: String, theirs: JSONObject): Int? {
        val mine = JSONObject(sp.getString(key, "{}") ?: "{}")
        var n = 0
        theirs.keys().forEach { k -> if (!mine.has(k)) { mine.put(k, theirs.get(k)); n++ } }
        if (n > 0) sp.edit().putString(key, mine.toString()).apply()
        return if (n > 0) n else null
    }
}
