package com.myra.assistant.ui.maya

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.ai.TaskStore
import kotlinx.coroutines.launch

/** Task list sorted by priority (phone score, or AI score after "AI diye sajao"). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var title by remember { mutableStateOf("") }
    var whenText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val tasks = remember(tick) { TaskStore.ranked(ctx) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Kaj (priority onujayi)", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(title, { title = it }, label = { Text("Notun kaj") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(whenText, { whenText = it }, label = { Text("Kobe? (kal, aj 5pm, 3 din) - na dilew cholbe") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Jog koro", true, Modifier.weight(1f)) {
                    if (title.isNotBlank()) {
                        TaskStore.add(ctx, title, TaskStore.parseDue(whenText) ?: TaskStore.parseDue(title))
                        title = ""; whenText = ""; status = ""; tick++
                    }
                }
                Btn(if (busy) "..." else "AI diye sajao", false, Modifier.weight(1f)) {
                    if (!busy) { busy = true; scope.launch { status = TaskStore.aiPrioritize(ctx); busy = false; tick++ } }
                }
            }
            if (status.isNotBlank()) Text(status, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            if (tasks.isEmpty()) Text("Kono pending kaj nei. Voice-e bolte paro: \"add task bill dibo kal\".", color = MC.Sub, fontSize = 15.sp)
            tasks.forEach { t ->
                val sc = TaskStore.score(t)
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(false, { TaskStore.setDone(ctx, t.id); tick++ })
                    Column(Modifier.weight(1f)) {
                        Text(t.title, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        val sub = listOfNotNull(t.due?.let { TaskStore.dueLabel(t) }, t.reason.takeIf { it.isNotBlank() }).joinToString(" · ")
                        if (sub.isNotBlank()) Text(sub, color = MC.Sub, fontSize = 12.sp)
                    }
                    Text("${TaskStore.label(sc)} $sc", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sc >= 70) MC.Dot else if (sc >= 45) MC.BlueDeep else MC.Hint)
                            .padding(horizontal = 10.dp, vertical = 4.dp))
                    Icon(Icons.Filled.Delete, "delete", tint = MC.Hint, modifier = Modifier.padding(start = 8.dp).size(20.dp).clickable { TaskStore.delete(ctx, t.id); tick++ })
                }
            }
            Text("Priority = deadline, joruri shobdo, koto din dhore pore ache. \"AI diye sajao\" dile Gemini kajer naam pore sajay (Privacy mode-e pathay na).",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun Btn(label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(48.dp).clip(RoundedCornerShape(16.dp))
        .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!primary) { Icon(Icons.Filled.AutoAwesome, null, tint = MC.BlueDeep, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
            Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}
