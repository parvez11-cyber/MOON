package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.models.VoiceCommand
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * Routines that save themselves.
 *  - Every harmless command she runs is remembered for a few minutes.
 *  - If the same sequence of 2-4 commands happens 3 times, it is saved automatically as a routine and she tells the user.
 *  - By voice: ROUTINE_SAVE <name> (saves what you just did), ROUTINE_RUN <name>, ROUTINE_LIST, ROUTINE_DELETE <name>.
 * Anything that sends a message, calls, types, taps or changes system settings is never saved into a routine.
 */
object RoutineStore {
    private const val PREFS = "myra_prefs"
    private const val K_ROUTINES = "routines_json"      // { name: [cmd, cmd, ...] }
    private const val K_SEQ = "routine_seq_counts"      // { "a>b": count }
    private const val SESSION_GAP_MS = 5 * 60_000L

    private val SAFE_HEADS = setOf(
        "OPEN_APP", "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON", "FLASHLIGHT_OFF",
        "VOLUME_UP", "VOLUME_DOWN", "HOME", "BACK", "RECENTS", "NOTIFICATIONS", "BRIGHTNESS"
    )

    private class Entry(val cmd: String, val at: Long)
    private val recent = ArrayList<Entry>()

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun head(cmd: String) = cmd.trim().substringBefore(' ').uppercase()
    fun isSafe(cmd: String) = head(cmd) in SAFE_HEADS

    private fun load(c: Context): JSONObject = try { JSONObject(p(c).getString(K_ROUTINES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun save(c: Context, o: JSONObject) { p(c).edit().putString(K_ROUTINES, o.toString()).apply() }

    /** Call after a command ran. Returns a short note for the model when a routine was just auto-saved. */
    @Synchronized
    fun record(c: Context, cmd: String): String? {
        if (!isSafe(cmd)) return null
        val now = System.currentTimeMillis()
        if (recent.isNotEmpty() && now - recent.last().at > SESSION_GAP_MS) recent.clear()
        if (recent.isNotEmpty() && recent.last().cmd.equals(cmd, true)) return null
        recent.add(Entry(cmd.trim(), now))
        while (recent.size > 6) recent.removeAt(0)

        for (len in 4 downTo 2) {
            if (recent.size < len) continue
            val seq = recent.takeLast(len).map { it.cmd }
            if (seq.map { head(it) }.toSet().size == 1 && seq.map { it.lowercase() }.toSet().size == 1) continue
            val key = seq.joinToString(">") { it.lowercase() }
            val counts = try { JSONObject(p(c).getString(K_SEQ, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            val n = counts.optInt(key, 0) + 1
            counts.put(key, n)
            if (counts.length() > 60) counts.remove(counts.keys().next())
            p(c).edit().putString(K_SEQ, counts.toString()).apply()
            if (n == 3) {
                val all = load(c)
                val dup = all.keys().asSequence().any { name -> (0 until all.getJSONArray(name).length()).map { all.getJSONArray(name).getString(it).lowercase() } == seq.map { it.lowercase() } }
                if (!dup) {
                    val name = autoName(all, seq)
                    all.put(name, JSONArray(seq))
                    save(c, all)
                    return "[Routine auto-saved as \"$name\": ${seq.joinToString(" -> ")}. Briefly tell the user in Bangla that you noticed they repeat this and saved it; they can say \"routine $name chalao\".]"
                }
            }
        }
        return null
    }

    private fun autoName(all: JSONObject, seq: List<String>): String {
        val first = seq.first().substringAfter(' ', seq.first()).trim().lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "auto" }
        var name = "auto-$first"
        var i = 2
        while (all.has(name)) { name = "auto-$first-$i"; i++ }
        return name
    }

    suspend fun handle(context: Context, raw: String): String {
        val t = raw.trim()
        val verb = t.substringBefore(' ').uppercase()
        val arg = t.substringAfter(' ', "").trim()
        return when (verb) {
            "ROUTINE_LIST" -> {
                val all = load(context)
                if (all.length() == 0) "Ekhono kono routine save kora nei."
                else all.keys().asSequence().joinToString("; ") { n -> "$n: " + (0 until all.getJSONArray(n).length()).joinToString(" -> ") { all.getJSONArray(n).getString(it) } }
            }
            "ROUTINE_DELETE" -> {
                val all = load(context)
                val name = all.keys().asSequence().firstOrNull { it.equals(arg, true) }
                if (name == null) "'$arg' naam-er routine pai ni." else { all.remove(name); save(context, all); "Routine '$name' muche dilam." }
            }
            "ROUTINE_SAVE" -> {
                if (arg.isBlank()) return "Routine-er ekta naam bolo."
                val seq = synchronized(this) { recent.filter { System.currentTimeMillis() - it.at < SESSION_GAP_MS }.map { it.cmd } }
                if (seq.isEmpty()) return "Save korar moto kichu mone nei. Age kaj gulo koro, tarpor save bolo. (Message, call ba tap routine-e save hoy na.)"
                val all = load(context)
                all.put(arg.lowercase(), JSONArray(seq.takeLast(6)))
                save(context, all)
                "Routine '${arg.lowercase()}' save korlam: ${seq.takeLast(6).joinToString(" -> ")}."
            }
            "ROUTINE_RUN" -> {
                val all = load(context)
                val name = all.keys().asSequence().firstOrNull { it.equals(arg, true) }
                    ?: all.keys().asSequence().firstOrNull { it.contains(arg.lowercase()) && arg.isNotBlank() }
                    ?: return "'$arg' naam-er routine pai ni."
                val steps = all.getJSONArray(name)
                var ok = 0
                for (i in 0 until steps.length()) {
                    val cmd = steps.getString(i)
                    if (!isSafe(cmd)) continue                       // a routine can never run anything sensitive
                    try {
                        val intent: VoiceCommand = IntentAnalyzer.analyze(cmd)
                        DynamicDecisionEngine.execute(context, intent)
                        ok++
                    } catch (_: Exception) {}
                    delay(1500)
                }
                "Routine '$name' chalalam ($ok ta dhap)."
            }
            else -> "Routine command bujhini."
        }
    }
}
