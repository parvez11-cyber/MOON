package com.myra.assistant.ui.maya

import android.content.Context
import android.view.ViewGroup
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.RootAccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/*
 * Terminal + Code screen.
 *
 *  - Terminal: YOU type a command, it runs in a shell (as the app, or as root if you switch Root on and the phone is rooted).
 *  - Code: describe what you want, Moon writes the file, you can Save / Preview (HTML) / Copy / Run it.
 *
 * Safety rule kept on purpose: nothing Moon writes (and nothing she reads from a screen, notification or SMS) is ever
 * run by itself. A command only runs when you type it, or when you press Run on code you can see.
 */

private val TermBg = Color(0xFF0D1117)
private val TermFg = Color(0xFFC9D1D9)
private val TermGreen = Color(0xFF3FB950)
private val TermRed = Color(0xFFFF7B72)
private val TermDim = Color(0xFF8B949E)
private val TermBlue = Color(0xFF79C0FF)

private class TermLine(val text: String, val kind: Int) // 0 command, 1 output, 2 error, 3 info

/** Kept outside the composable so the terminal and the code survive switching tabs. */
private object DevState {
    val lines = mutableStateListOf<TermLine>()
    var cwd by mutableStateOf<File?>(null)
    var root by mutableStateOf(false)
    var codeMode by mutableStateOf(false)
    var prompt by mutableStateOf("")
    var code by mutableStateOf("")
    var lang by mutableStateOf("")
    var note by mutableStateOf("")
    var working by mutableStateOf(false)
    var lastSaved by mutableStateOf<File?>(null)
}

private fun workspace(ctx: Context): File = File(ctx.filesDir, "workspace").also { it.mkdirs() }

private fun shQuote(s: String) = "'" + s.replace("'", "'\\''") + "'"

/** Runs one shell command with a 30 s limit and a cap on how much output is kept. Returns (output, exit code). */
private suspend fun runShell(cwd: File, cmd: String, asRoot: Boolean): Pair<String, Int> = withContext(Dispatchers.IO) {
    try {
        val argv = if (asRoot) listOf("su", "-c", "cd ${shQuote(cwd.absolutePath)} && $cmd") else listOf("sh", "-c", cmd)
        val pb = ProcessBuilder(argv).redirectErrorStream(true)
        if (!asRoot) pb.directory(cwd)
        val p = pb.start()
        val out = StringBuilder()
        val reader = Thread {
            try {
                p.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(2048)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        if (out.length < 20_000) synchronized(out) { out.append(buf, 0, n) }
                    }
                }
            } catch (_: Exception) {}
        }
        reader.start()
        val done = p.waitFor(30, TimeUnit.SECONDS)
        if (!done) p.destroyForcibly()
        reader.join(800)
        val text = synchronized(out) { out.toString() }.trimEnd()
        if (!done) (text + "\n[30 second por bondho kora holo]").trim() to 124
        else text to p.exitValue()
    } catch (e: Exception) {
        "Command chalano gelo na: ${e.message}" to 127
    }
}

private fun resolveDir(base: File, arg: String): File? {
    val target = when {
        arg.isEmpty() || arg == "~" -> base
        arg.startsWith("/") -> File(arg)
        else -> File(base, arg)
    }
    val c = try { target.canonicalFile } catch (_: Exception) { return null }
    return if (c.isDirectory) c else null
}

private fun extractCode(reply: String): Triple<String, String, String> { // code, lang, note
    val m = Regex("```([A-Za-z0-9+#_-]*)\\s*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL).find(reply)
        ?: return Triple(reply.trim(), "", "")
    val note = (reply.substring(0, m.range.first) + reply.substring(m.range.last + 1)).trim()
    return Triple(m.groupValues[2].trimEnd(), m.groupValues[1].lowercase(), note)
}

private fun extFor(lang: String, code: String): String = when (lang) {
    "html", "htm" -> "html"
    "python", "py" -> "py"
    "bash", "sh", "shell", "zsh" -> "sh"
    "javascript", "js", "node" -> "js"
    "kotlin", "kt" -> "kt"
    "java" -> "java"
    "c" -> "c"
    "cpp", "c++" -> "cpp"
    "css" -> "css"
    "json" -> "json"
    "" -> if (code.trimStart().startsWith("<!DOCTYPE", true) || code.trimStart().startsWith("<html", true)) "html" else "txt"
    else -> "txt"
}

@Composable
fun DevTab(startInCode: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(startInCode) { DevState.codeMode = startInCode }
    LaunchedEffect(Unit) {
        if (DevState.cwd == null) {
            DevState.cwd = workspace(ctx)
            DevState.lines.add(TermLine("Moon terminal. Folder: ${DevState.cwd!!.absolutePath}", 3))
            DevState.lines.add(TermLine("'help' likhe dekho. Command shudhu tumi likhle ba Run chapole cholbe.", 3))
        }
    }

    fun runCommand(raw: String) {
        val cmd = raw.trim()
        if (cmd.isEmpty() || DevState.working) return
        val cwd = DevState.cwd ?: workspace(ctx)
        DevState.lines.add(TermLine(cmd, 0))
        when {
            cmd == "clear" -> DevState.lines.clear()
            cmd == "pwd" -> DevState.lines.add(TermLine(cwd.absolutePath, 1))
            cmd == "help" -> DevState.lines.add(TermLine(
                "clear   screen mochho\ncd <folder>   folder bodlao\npwd   ekhon kothay\nbaki shob normal shell command (ls, cat, echo, ping, python3 ...)\n" +
                    "Root switch on korle command root hisebe cholbe (phone rooted hole).", 3))
            cmd == "cd" || cmd.startsWith("cd ") -> {
                val d = resolveDir(cwd, cmd.removePrefix("cd").trim())
                if (d == null) DevState.lines.add(TermLine("cd: folder pawa gelo na", 2)) else DevState.cwd = d
            }
            else -> {
                DevState.working = true
                scope.launch {
                    val (out, code) = runShell(cwd, cmd, DevState.root)
                    if (out.isNotEmpty()) DevState.lines.add(TermLine(out, if (code == 0) 1 else 2))
                    if (code != 0 && out.isEmpty()) DevState.lines.add(TermLine("exit code $code", 2))
                    DevState.working = false
                }
            }
        }
    }

    fun setRoot(on: Boolean) {
        if (!on) { DevState.root = false; return }
        scope.launch {
            val ok = withContext(Dispatchers.IO) { RootAccess.request(ctx) }
            DevState.root = ok
            if (!ok) DevState.lines.add(TermLine("Root pawa gelo na (phone rooted noy, ba su prompt-e Allow dao ni).", 2))
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeChip("Terminal", !DevState.codeMode) { DevState.codeMode = false }
            ModeChip("Code", DevState.codeMode) { DevState.codeMode = true }
        }
        Box(Modifier.weight(1f)) {
            if (DevState.codeMode) CodePane(ctx, onRun = { cmd -> DevState.codeMode = false; runCommand(cmd) })
            else TerminalPane(onRun = ::runCommand, onRoot = ::setRoot)
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) MC.BlueDeep else MC.Navy.copy(alpha = 0.2f))
            .clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 9.dp)
    ) { Text(label, color = if (selected) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
private fun TerminalPane(onRun: (String) -> Unit, onRoot: (Boolean) -> Unit) {
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    LaunchedEffect(DevState.lines.size) { if (DevState.lines.isNotEmpty()) listState.animateScrollToItem(DevState.lines.size - 1) }
    Column(Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)).background(TermBg).padding(12.dp)) {
        LazyColumn(Modifier.weight(1f), state = listState) {
            items(DevState.lines) { l ->
                val color = when (l.kind) { 0 -> TermBlue; 2 -> TermRed; 3 -> TermDim; else -> TermFg }
                Text(if (l.kind == 0) "$ ${l.text}" else l.text, color = color, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 2.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("root", color = if (DevState.root) TermRed else TermDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Switch(DevState.root, onRoot, modifier = Modifier.padding(horizontal = 6.dp))
            Text(DevState.cwd?.name?.let { "$it $" } ?: "$", color = TermGreen, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (input.isEmpty()) Text("command likho", color = TermDim, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                BasicTextField(
                    input, { input = it }, singleLine = true,
                    textStyle = TextStyle(color = TermFg, fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                    cursorBrush = SolidColor(TermGreen), modifier = Modifier.fillMaxWidth()
                )
            }
            TextButton({ if (input.isNotBlank()) { onRun(input); input = "" } }, enabled = !DevState.working) {
                Text(if (DevState.working) "..." else "Run", color = TermGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CodePane(ctx: Context, onRun: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var preview by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val key = ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getString(Constants.KEY_API_KEY, "").orEmpty()

    fun generate() {
        val ask = DevState.prompt.trim()
        if (ask.isEmpty() || DevState.working) return
        if (key.isEmpty()) { msg = "Pehle Gemini key daalo (Settings)."; return }
        DevState.working = true; msg = ""
        scope.launch {
            val sys = "You are a careful coding assistant inside a phone app. Reply with exactly ONE complete, runnable file in a single " +
                "fenced code block that has a language tag. For websites or UI, write one self-contained HTML file (inline CSS and JS, " +
                "no external links). After the code block add at most three short lines in simple Banglish explaining how to use it."
            val reply = GeminiChat.ask(key, emptyList(), ask, null, "application/pdf", sys)
            if (reply.startsWith("Error") || reply.startsWith("Network")) msg = reply
            else {
                val (code, lang, note) = extractCode(reply)
                DevState.code = code; DevState.lang = lang; DevState.note = note; DevState.lastSaved = null
            }
            DevState.working = false
        }
    }

    fun save(): File? = try {
        val ext = extFor(DevState.lang, DevState.code)
        val f = File(workspace(ctx), "maya_${System.currentTimeMillis() / 1000}.$ext")
        f.writeText(DevState.code); DevState.lastSaved = f; msg = "Save holo: ${f.name}"; f
    } catch (e: Exception) { msg = "Save hoy ni: ${e.message}"; null }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MC.Card).padding(12.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.weight(1f).heightIn(min = 48.dp)) {
                if (DevState.prompt.isEmpty()) Text("Ki banate chao? jemon: ekta todo list website", color = MC.Hint, fontSize = 15.sp)
                BasicTextField(DevState.prompt, { DevState.prompt = it }, textStyle = TextStyle(color = MC.Navy, fontSize = 15.sp),
                    cursorBrush = SolidColor(MC.Navy), modifier = Modifier.fillMaxWidth())
            }
            TextButton({ generate() }, enabled = !DevState.working) {
                Text(if (DevState.working) "..." else "Banao", color = MC.BlueDeep, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(TermBg).padding(12.dp)) {
            if (DevState.code.isEmpty()) Text("Code ekhane ashbe.", color = TermDim, fontSize = 14.sp)
            else Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())) {
                Text(DevState.code, color = TermFg, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
        if (DevState.note.isNotBlank()) Text(DevState.note, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        if (msg.isNotBlank()) Text(msg, color = MC.Navy, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
        if (DevState.code.isNotEmpty()) {
            val ext = extFor(DevState.lang, DevState.code)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton({ save() }) { Text("Save") }
                TextButton({ clipboard.setText(AnnotatedString(DevState.code)); msg = "Copy holo" }) { Text("Copy") }
                if (ext == "html") TextButton({ preview = true }) { Text("Preview") }
                val runner = when (ext) { "sh" -> "sh"; "py" -> "python3"; "js" -> "node"; else -> null }
                if (runner != null) TextButton({
                    val f = DevState.lastSaved ?: save()
                    if (f != null) onRun("$runner ${shQuote(f.name)}")
                }) { Text("Terminal-e chalao") }
            }
        }
    }

    if (preview) AlertDialog(
        onDismissRequest = { preview = false },
        confirmButton = { TextButton({ preview = false }) { Text("Close") } },
        text = {
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(420.dp),
                factory = { c ->
                    WebView(c).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        settings.javaScriptEnabled = true
                        settings.allowFileAccess = false      // the preview page cannot read the phone's files
                        settings.allowContentAccess = false
                        loadDataWithBaseURL(null, DevState.code, "text/html", "utf-8", null)
                    }
                }
            )
        }
    )
}
