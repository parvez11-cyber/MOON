package com.myra.assistant.service

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.system.PrivacyMode
import com.myra.assistant.ui.maya.MayaActivity

/** Opens Moon, collapsing the shade first (the API changed in Android 14). */
private fun TileService.openMaya() {
    val i = Intent(this, MayaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION") startActivityAndCollapse(i)
        }
    } catch (_: Exception) {}
}

/**
 * Quick Settings tile "Moon": tap = mic on / off. If Moon's voice service is not running yet, it is started.
 * Without the microphone permission it opens the app instead, so the permission can be granted.
 */
class MyraMicTileService : TileService() {
    private val ui = Handler(Looper.getMainLooper())

    override fun onStartListening() { super.onStartListening(); refresh() }
    override fun onTileAdded() { super.onTileAdded(); refresh() }

    override fun onClick() {
        super.onClick()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { openMaya(); return }
        val svc = ForegroundVoiceService.instance
        if (svc != null) {
            svc.setMicEnabled(!svc.isMicEnabled())
        } else {
            try {
                val i = Intent(this, ForegroundVoiceService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } catch (_: Exception) { openMaya(); return }   // the system refused a background start: open the app instead
        }
        refresh()
        ui.postDelayed({ refresh() }, 1200)   // the service needs a moment to come up
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = ForegroundVoiceService.instance?.isMicEnabled() == true
        t.label = "Moon"
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.icon = Icon.createWithResource(this, if (on) R.drawable.ic_tile_mic else R.drawable.ic_tile_mic_off)
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "Listening" else "Mic off"
        t.updateTile()
    }
}

/**
 * Quick Settings tile "Privacy": tap = privacy mode on / off. Turning it OFF needs the phone to be unlocked,
 * so nobody can switch it off from the lock screen.
 */
class MyraPrivacyTileService : TileService() {
    override fun onStartListening() { super.onStartListening(); refresh() }
    override fun onTileAdded() { super.onTileAdded(); refresh() }

    override fun onClick() {
        super.onClick()
        val ctx: Context = applicationContext
        val turnOn = !PrivacyMode.isOn(ctx)
        if (!turnOn && isLocked) unlockAndRun { PrivacyMode.set(ctx, false); refresh() }
        else { PrivacyMode.set(ctx, turnOn); refresh() }
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = PrivacyMode.isOn(applicationContext)
        t.label = "Privacy"
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.icon = Icon.createWithResource(this, R.drawable.ic_tile_privacy)
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "On" else "Off"
        t.updateTile()
    }
}
