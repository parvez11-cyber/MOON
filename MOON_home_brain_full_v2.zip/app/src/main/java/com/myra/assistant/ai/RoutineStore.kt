package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.models.VoiceCommand
import com.myra.assistant.voice.LocalCommandRouter
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * Routines that save themselves.
 *  - Every harmless command she runs is remembered for a few minutes.
 *  - If the same sequence of 2-4 commands happens 3 times, it is saved automatically as a routine and she tells the user.
 *  - By voice: ROUTINE_SAVE <name> (saves what you just did), ROUTINE_RUN <name>, ROUTINE_LIST, ROUTINE_DELETE <name>.
 * Anything that sends a message, calls, types, taps or changes system settings is never saved into a routine.
 */
object RoutineStore {
    private const val PREFS = "myra_prefs"
    private const val K_ROUTINES = "routines_json"      // { name: [cmd, cmd, ...] }
    private const val K_SEQ = "routine_seq_counts"      // { "a>b": count }
    private const val SESSION_GAP_MS = 5 * 60_000L

    private val SAFE_HEADS = setOf(
        "OPEN_APP", "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON", "FLASHLIGHT_OFF",
        "VOLUME_UP", "VOLUME_DOWN", "HOME", "BACK", "RECENTS", "NOTIFICATIONS", "BRIGHTNESS"
    )

    private class Entry(val cmd: String, val at: Long)
    private val recent = ArrayList<Entry>()

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun head(cmd: String) = cmd.trim().substringBefore(' ').uppercase()
    fun isSafe(cmd: String) = head(cmd) in SAFE_HEADS

    private fun load(c: Context): JSONObject = try { JSONObject(p(c).getString(K_ROUTINES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun save(c: Context, o: JSONObject) { p(c).edit().putString(K_ROUTINES, o.toString()).apply() }

    /** Call after a command ran. Returns a short note for the model when a routine was just auto-saved. */
    @Synchronized
    fun record(c: Context, cmd: String): String? {
        if (!isSafe(cmd)) return null
        val now = System.currentTimeMillis()
        if (recent.isNotEmpty() && now - recent.last().at > SESSION_GAP_MS) recent.clear()
        if (recent.isNotEmpty() && recent.last().cmd.equals(cmd, true)) return null
        recent.add(Entry(cmd.trim(), now))
        while (recent.size > 6) recent.removeAt(0)

        for (len in 4 downTo 2) {
            if (recent.size < len) continue
            val seq = recent.takeLast(len).map { it.cmd }
            if (seq.map { head(it) }.toSet().size == 1 && seq.map { it.lowercase() }.toSet().size == 1) continue
            val key = seq.joinToString(">") { it.lowercase() }
            val counts = try { JSONObject(p(c).getString(K_SEQ, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            val n = counts.optInt(key, 0) + 1
            counts.put(key, n)
            if (counts.length() > 60) counts.remove(counts.keys().next())
            p(c).edit().putString(K_SEQ, counts.toString()).apply()
            if (n == 3) {
                val all = load(c)
                val dup = all.keys().asSequence().any { name -> (0 until all.getJSONArray(name).length()).map { all.getJSONArray(name).getString(it).lowercase() } == seq.map { it.lowercase() } }
                if (!dup) {
                    val name = autoName(all, seq)
                    all.put(name, JSONArray(seq))
                    save(c, all)
                    return "[Routine auto-saved as \"$name\": ${seq.joinToString(" -> ")}. Briefly tell the user in Bangla that you noticed they repeat this and saved it; they can say \"routine $name chalao\".]"
                }
            }
        }
        return null
    }

    private fun autoName(all: JSONObject, seq: List<String>): String {
        val first = seq.first().substringAfter(' ', seq.first()).trim().lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "auto" }
        var name = "auto-$first"
        var i = 2
        while (all.has(name)) { name = "auto-$first-$i"; i++ }
        return name
    }


    // ---- named shortcuts: save by typing or voice, then just say / type the name ----
    private val STEP_SPLIT = Regex("\\s*(?:[,;+|]|->)\\s*|\\s+(?:then|tarpor|erpor|and|ar)\\s+|\\s+(?:তারপর|এরপর|এবং|আর)\\s+", RegexOption.IGNORE_CASE)
    private val RUN_WORDS = listOf("chalu koro", "shuru koro", "chalao", "chalu", "run", "start", "koro", "karo", "করো", "চালাও", "চালু করো", "চালু", "শুরু করো")
    private val LEAD_WORDS = listOf("run", "start", "routine", "shortcut", "শর্টকাট", "রুটিন")
    private val TAIL_WORDS = listOf("routine", "shortcut", "শর্টকাট", "রুটিন")

    private fun normName(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Splits "youtube kholo, torch on tarpor volume baraw" into separate steps. */
    fun splitSteps(s: String): List<String> = STEP_SPLIT.split(s).map { it.trim() }.filter { it.isNotEmpty() }

    /** If the spoken / typed text is just the name of a saved shortcut (optionally + "chalao"), returns that name. */
    fun nameFor(c: Context, text: String): String? {
        val all = load(c)
        if (all.length() == 0) return null
        var t = normName(text)
        for (w in LEAD_WORDS) if (t.startsWith("$w ")) { t = t.removePrefix("$w ").trim(); break }
        for (w in RUN_WORDS.sortedByDescending { it.length }) if (t.endsWith(" $w")) { t = t.removeSuffix(" $w").trim(); break }
        for (w in TAIL_WORDS) if (t.endsWith(" $w")) { t = t.removeSuffix(" $w").trim(); break }
        if (t.isEmpty()) return null
        return all.keys().asSequence().firstOrNull { normName(it) == t }
    }

    // ---- used by the Shortcut screen (list / edit / delete / run) ----

    /** Every saved shortcut and routine: name -> its steps (as commands). */
    fun all(c: Context): List<Pair<String, List<String>>> {
        val o = load(c)
        return o.keys().asSequence().toList().map { n ->
            val a = o.getJSONArray(n)
            n to (0 until a.length()).map { a.getString(it) }
        }
    }

    /**
     * Saves a shortcut. Steps can be plain phrases ("youtube kholo") or commands. [oldName] is the name being edited (it is
     * removed when the name changes). Returns null on success, or a short message saying why nothing was saved.
     */
    fun define(c: Context, oldName: String?, rawName: String, rawSteps: List<String>): String? {
        val name = normName(rawName)
        if (name.isBlank() || name.split(' ').size > 3) return "Naam choto rakho (maximum 3 shobdo)."
        if (LocalCommandRouter.match(c, name, false) != null) return "'$name' ekta built-in command-er moto shunay, onno naam dao."
        val steps = ArrayList<String>()
        for (s in rawSteps.map { it.trim() }.filter { it.isNotEmpty() }) {
            // a stored command ("OPEN_APP youtube", as shown when editing) is kept exactly; a plain phrase is understood first
            val raw = Regex("^[A-Z_]+(\\s|$)").containsMatchIn(s) && isSafe(s)
            val cmd = if (raw) s else LocalCommandRouter.match(c, s, false)
            if (cmd == null || !isSafe(cmd)) return "'$s' dhapta bujhini ba eta shortcut-e rakha jay na (message, call, tap, system setting nirapod noy). Kichu save kori ni."
            steps.add(cmd)
        }
        if (steps.isEmpty()) return "Ekta dhap to dao."
        if (steps.size > 8) return "Ekta shortcut-e maximum 8 ta kaj rakha jay."
        val all = load(c)
        if (oldName != null && oldName != name && all.has(name)) return "'$name' naam-e ager ekta shortcut ache."
        if (oldName != null && oldName != name) all.remove(oldName)
        all.put(name, JSONArray(steps))
        save(c, all)
        return null
    }

    /** Deletes one shortcut / routine by its exact name. */
    fun remove(c: Context, name: String) {
        val all = load(c)
        if (all.has(name)) { all.remove(name); save(c, all) }
    }

    suspend fun handle(context: Context, raw: String): String {
        val t = raw.trim()
        val verb = t.substringBefore(' ').uppercase()
        val arg = t.substringAfter(' ', "").trim()
        return when (verb) {
            "ROUTINE_LIST" -> {
                val all = load(context)
                if (all.length() == 0) "Ekhono kono routine save kora nei."
                else all.keys().asSequence().joinToString("; ") { n -> "$n: " + (0 until all.getJSONArray(n).length()).joinToString(" -> ") { all.getJSONArray(n).getString(it) } }
            }
            "ROUTINE_DELETE" -> {
                val all = load(context)
                val name = all.keys().asSequence().firstOrNull { it.equals(arg, true) }
                if (name == null) "'$arg' naam-er routine pai ni." else { all.remove(name); save(context, all); "Routine '$name' muche dilam." }
            }
            "ROUTINE_SAVE" -> {
                if (arg.isBlank()) return "Routine-er ekta naam bolo."
                val seq = synchronized(this) { recent.filter { System.currentTimeMillis() - it.at < SESSION_GAP_MS }.map { it.cmd } }
                if (seq.isEmpty()) return "Save korar moto kichu mone nei. Age kaj gulo koro, tarpor save bolo. (Message, call ba tap routine-e save hoy na.)"
                val all = load(context)
                all.put(arg.lowercase(), JSONArray(seq.takeLast(6)))
                save(context, all)
                "Routine '${arg.lowercase()}' save korlam: ${seq.takeLast(6).joinToString(" -> ")}."
            }
            "ROUTINE_ADD" -> {
                // ROUTINE_ADD <name> | <step> | <step> ...   (steps are plain phrases like "youtube kholo" or commands like OPEN_APP youtube)
                val parts = arg.split("|").map { it.trim() }.filter { it.isNotEmpty() }
                if (parts.size < 2) return "Shortcut-er naam ar kaj gulo bolo. Jemon: shortcut morning: youtube kholo, torch on"
                val existed = load(context).has(normName(parts[0]))
                val err = define(context, null, parts[0], parts.drop(1))
                if (err != null) return err
                val name = normName(parts[0])
                val steps = load(context).getJSONArray(name)
                "Shortcut '$name' ${if (existed) "update" else "save"} korlam: ${(0 until steps.length()).joinToString(" -> ") { steps.getString(it) }}. Ekhon shudhu '$name' bolle ba likhle eigulo nijei hoye jabe."
            }
            "ROUTINE_RUN" -> {
                val all = load(context)
                val name = all.keys().asSequence().firstOrNull { it.equals(arg, true) }
                    ?: all.keys().asSequence().firstOrNull { it.contains(arg.lowercase()) && arg.isNotBlank() }
                    ?: return "'$arg' naam-er routine pai ni."
                val steps = all.getJSONArray(name)
                var ok = 0
                for (i in 0 until steps.length()) {
                    val cmd = steps.getString(i)
                    if (!isSafe(cmd)) continue                       // a routine can never run anything sensitive
                    try {
                        val intent: VoiceCommand = IntentAnalyzer.analyze(cmd)
                        DynamicDecisionEngine.execute(context, intent)
                        ok++
                    } catch (_: Exception) {}
                    delay(1500)
                }
                "Routine '$name' chalalam ($ok ta dhap)."
            }
            else -> "Routine command bujhini."
        }
    }
}
