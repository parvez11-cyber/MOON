package com.myra.assistant.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.myra.assistant.ai.TaskStore
import com.myra.assistant.ui.maya.MayaActivity
import com.myra.assistant.utils.Constants

/**
 * Reminders for tasks that have a due time: a heads-up 30 minutes before, and one at the due time.
 * Scheduled with AlarmManager, so they ring even when the app is closed. [sync] is called after every task change,
 * on app open, and after a reboot (alarms are cleared by a reboot), and it cancels reminders of tasks that were done / deleted.
 * Nothing leaves the phone. The notification text is hidden on the lock screen.
 */
object TaskReminder {
    private const val CHANNEL = "myra_task_reminders"
    private const val IDS = "task_reminder_codes"      // request codes we scheduled, so removed ones can be cancelled
    private const val HEADS_UP_MS = 30 * 60_000L

    private fun code(id: Long, kind: Int) = ((id and 0x3FFFFFFFL).toInt() * 2) + kind   // kind 0 = at due time, 1 = heads-up

    private fun pi(c: Context, id: Long, kind: Int, title: String, flags: Int = PendingIntent.FLAG_UPDATE_CURRENT): PendingIntent? =
        PendingIntent.getBroadcast(c, code(id, kind),
            Intent(c, TaskReminderReceiver::class.java).putExtra("id", id).putExtra("kind", kind).putExtra("title", title),
            flags or PendingIntent.FLAG_IMMUTABLE)

    /** Makes the scheduled alarms match [list] exactly. */
    fun sync(c: Context, list: List<TaskStore.Task>) {
        val app = c.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val prefs = app.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val old = prefs.getStringSet(IDS, emptySet()).orEmpty()
        val mine = HashSet<String>()
        list.filter { !it.done && it.due != null && it.due > now }.forEach { t ->
            val due = t.due!!
            val times = listOf(0 to due) + if (due - now > HEADS_UP_MS) listOf(1 to due - HEADS_UP_MS) else emptyList()
            times.forEach { (kind, at) ->
                val p = pi(app, t.id, kind, t.title) ?: return@forEach
                schedule(am, at, p)
                mine += "${t.id}:$kind"
            }
        }
        (old - mine).forEach { s ->
            val id = s.substringBefore(':').toLongOrNull() ?: return@forEach
            val kind = s.substringAfter(':').toIntOrNull() ?: return@forEach
            pi(app, id, kind, "")?.let { am.cancel(it); it.cancel() }
        }
        prefs.edit().putStringSet(IDS, mine).apply()
    }

    fun syncAll(c: Context) = try { sync(c, TaskStore.all(c)) } catch (_: Exception) {}

    private fun schedule(am: AlarmManager, at: Long, p: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)   // exact-alarm permission not granted: may be a few minutes late
        }
    }

    internal fun notify(c: Context, id: Long, kind: Int, title: String) {
        // skip if the task was finished or deleted after the alarm was set
        val t = TaskStore.all(c).firstOrNull { it.id == id }
        if (t == null || t.done) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Kaj-er reminder", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, code(id, kind),
            Intent(c, MayaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val head = if (kind == 1) "Ar 30 minute-e: kaj-er shomoy" else "Kaj-er shomoy hoyeche"
        val publicVer = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Moon").setContentText("Ekta kaj-er reminder").build()
        val n = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(head).setContentText(t.title).setStyle(NotificationCompat.BigTextStyle().bigText(t.title))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setPublicVersion(publicVer)
            .setAutoCancel(true).setContentIntent(open).build()
        try { NotificationManagerCompat.from(c).notify(code(id, kind), n) } catch (_: SecurityException) {}   // notification permission off
    }
}

class TaskReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        if (id == 0L) return
        TaskReminder.notify(context.applicationContext, id, intent.getIntExtra("kind", 0), intent.getStringExtra("title").orEmpty())
    }
}
