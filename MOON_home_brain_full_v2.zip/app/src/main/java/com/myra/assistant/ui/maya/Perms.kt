package com.myra.assistant.ui.maya

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.myra.assistant.service.AccessibilityHelperService

data class PermItem(val title: String, val desc: String, val perms: List<String>, val required: Boolean = false)

object Perms {
    fun runtimeItems(): List<PermItem> = listOf(
        PermItem("Microphone", "So you can talk to Moon. Required.", listOf(Manifest.permission.RECORD_AUDIO), true),
        PermItem("Notifications", "Moon's own notification, which keeps her running in the background.",
            if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()),
        PermItem("Camera", "So she can take a photo or look at what you point the phone at.", listOf(Manifest.permission.CAMERA)),
        PermItem("Phone calls", "So she can place a call for you.", listOf(Manifest.permission.CALL_PHONE)),
        PermItem("Contacts", "So a name is enough — she looks up the number.",
            listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)),
        PermItem("SMS", "So she can send a text message.", listOf(Manifest.permission.SEND_SMS)),
        PermItem("Location", "Weather, navigation, and where you are.",
            listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)),
        PermItem("Gallery & files", "So she can find a photo or file and send it.",
            if (Build.VERSION.SDK_INT >= 33)
                listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)),
        PermItem("Answer & manage calls", "So she can announce who is calling and answer or reject it.",
            listOf(Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG)),
        PermItem("Bluetooth", "So her voice plays on your earbuds or speaker.",
            if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_CONNECT) else emptyList())
    )

    fun granted(c: Context, it: PermItem) = it.perms.all {
        ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED
    }

    fun batteryOk(c: Context) =
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
    fun overlayOk(c: Context) = Settings.canDrawOverlays(c)
    fun notifAccessOk(c: Context) =
        (Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)
    fun accessibilityOk(c: Context) = AccessibilityHelperService.isEnabled(c)
    fun assistantOk(c: Context) =
        (Settings.Secure.getString(c.contentResolver, "assistant") ?: "").contains(c.packageName)

    fun open(c: Context, which: Int) {
        val pkg = Uri.parse("package:${c.packageName}")
        val i = when (which) {
            0 -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)
            1 -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
            2 -> Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            3 -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (_: Exception) {
            try { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }
}
