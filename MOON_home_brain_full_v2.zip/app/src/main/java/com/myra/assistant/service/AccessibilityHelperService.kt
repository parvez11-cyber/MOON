package com.myra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AccessibilityHelperService : AccessibilityService() {

    companion object {
        private const val TAG = "MYRA_ACCESS"

        var instance: AccessibilityHelperService? = null
        var currentRoot: AccessibilityNodeInfo? = null

        fun isEnabled(context: Context): Boolean {
            val expectedComponentName =
                ComponentName(
                    context,
                    AccessibilityHelperService::class.java
                )

            val enabledServicesSetting =
                Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false

            val colonSplitter =
                TextUtils.SimpleStringSplitter(':')

            colonSplitter.setString(enabledServicesSetting)

            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()

                val enabledService =
                    ComponentName.unflattenFromString(
                        componentNameString
                    )

                if (enabledService == expectedComponentName) {
                    return true
                }
            }

            return false
        }

        fun getFreshRoot(): AccessibilityNodeInfo? {
            return instance?.rootInActiveWindow ?: currentRoot
        }

        /** Returns the current accessibility UI tree so MOON can inspect what is visible. */
        fun readVisibleScreen(): String {
            val root = getFreshRoot() ?: return ""
            return try {
                com.myra.assistant.automation.UiTreeSerializer.serialize(root)
            } catch (_: Exception) { "" }
        }

        /** Uses Android's accessibility screenshot API when supported. */
        fun takeScreenScreenshot(onResult: (Bitmap?) -> Unit) {
            val svc = instance
            if (svc == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                onResult(null)
                return
            }
            try {
                svc.takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    svc.mainExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                            try {
                                val bitmap = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                                    ?.copy(Bitmap.Config.ARGB_8888, false)
                                result.hardwareBuffer.close()
                                onResult(bitmap)
                            } catch (_: Exception) { onResult(null) }
                        }
                        override fun onFailure(errorCode: Int) { onResult(null) }
                    }
                )
            } catch (_: Exception) { onResult(null) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        instance = this
        SmartAccessibilityEngine.service = this

        serviceInfo = AccessibilityServiceInfo().apply {

            eventTypes =
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                        AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                        AccessibilityEvent.TYPE_VIEW_CLICKED or
                        AccessibilityEvent.TYPE_VIEW_FOCUSED or
                        AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                        AccessibilityEvent.TYPE_VIEW_SCROLLED

            feedbackType =
                AccessibilityServiceInfo.FEEDBACK_GENERIC

            flags =
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                        AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                        AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS

            notificationTimeout = 50
        }

        currentRoot = rootInActiveWindow

        Log.d(TAG, "==============================")
        Log.d(TAG, "MOON ACCESSIBILITY CONNECTED")
        Log.d(TAG, "==============================")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        currentRoot = rootInActiveWindow
        com.myra.assistant.accessibility.AccessibilityEventManager.onEvent(event)
        com.myra.assistant.ai.ContextualShortcuts.noteForeground(applicationContext, event)
        Log.d(TAG, "EVENT -> ${event.packageName} | ${event.className}")
    }

    override fun onInterrupt() {
        Log.d(TAG, "SERVICE INTERRUPTED")
    }

    override fun onDestroy() {
        super.onDestroy()

        instance = null
        currentRoot = null
        SmartAccessibilityEngine.service = null

        Log.d(TAG, "SERVICE DESTROYED")
    }
}