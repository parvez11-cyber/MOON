package com.myra.assistant.ui.maya

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.home.SmartHome
import com.myra.assistant.system.LocationServices
import kotlinx.coroutines.launch

/** Smart Home: connect Home Assistant, sync the device list, and switch devices by tap (voice works the same way). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartHomePanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(SmartHome.url(ctx)) }
    var token by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    val devices = remember(tick) { SmartHome.devices(ctx).toList() }

    fun exec(block: suspend () -> String) { if (!busy) { busy = true; scope.launch { status = block(); busy = false; tick++ } } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Smart Home", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (SmartHome.isConfigured(ctx)) "Home Assistant connected (${devices.size} ta device)" else "Home Assistant-er shathe jukto na",
                color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
            OutlinedTextField(url, { url = it }, label = { Text("Home Assistant URL (http://192.168.1.20:8123)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(token, { token = it }, label = { Text(if (SmartHome.hasToken(ctx)) "Token (save kora ache, bodlate chaile dao)" else "Long-lived access token") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HBtn("Save", true, Modifier.weight(1f)) {
                    val err = SmartHome.saveConfig(ctx, url, token)
                    status = err ?: "Save hoyeche."; if (err == null) token = ""; tick++
                }
                HBtn(if (busy) "..." else "Test", false, Modifier.weight(1f)) { exec { SmartHome.test(ctx) } }
                HBtn(if (busy) "..." else "Sync", false, Modifier.weight(1f)) { exec { SmartHome.sync(ctx) } }
            }
            if (status.isNotBlank()) Text(status, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            if (devices.isEmpty()) Text("Kono device nei. Connect kore \"Sync\" chapo, ba bolo: \"smart home sync\".", color = MC.Sub, fontSize = 15.sp)
            devices.forEach { (alias, entity) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(alias, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(entity, color = MC.Sub, fontSize = 12.sp)
                    }
                    val domain = entity.substringBefore('.')
                    if (domain == "scene" || domain == "script") HChip("Run") { exec { SmartHome.apply(ctx, "run $alias") } }
                    else { HChip("On") { exec { SmartHome.apply(ctx, "on $alias") } }; Spacer(Modifier.width(6.dp)); HChip("Off") { exec { SmartHome.apply(ctx, "off $alias") } } }
                    Icon(Icons.Filled.Delete, "remove", tint = MC.Hint, modifier = Modifier.padding(start = 10.dp).size(20.dp).clickable { SmartHome.removeAlias(ctx, alias); tick++ })
                }
            }
            if (SmartHome.isConfigured(ctx)) Text("Connection muche felo (token delete hobe)", color = MC.Dot, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 14.dp).clickable { SmartHome.clearConfig(ctx); url = ""; token = ""; status = "Disconnect hoyeche."; tick++ })
            Text("Home Assistant -> Profile -> Security -> Long-lived access tokens e token banao. Token phone-er encrypted storage-e thake, Sync snapshot-e jay na. " +
                "Lock, alarm, garage / gate / door voice-e chalano jay na (nirapotta-r jonno).",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

/** Location: where am I, saved places, distance, directions. Reads location only when you tap / ask. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlacesPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    val places = remember(tick) { LocationServices.places(ctx) }

    fun exec(cmd: String) { if (!busy) { busy = true; scope.launch { status = LocationServices.apply(ctx, cmd); busy = false; tick++ } } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Location", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(when {
                !LocationServices.hasPermission(ctx) -> "Permission nei: drawer -> Sob permission do"
                !LocationServices.isLocationOn(ctx) -> "Phone-er Location off ache"
                else -> "Location ready"
            }, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
            HBtn(if (busy) "..." else "Ami kothay?", true, Modifier.fillMaxWidth()) { exec("where") }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Ei jaiga-r naam (home, office...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            HBtn("Ekhon-er jaiga save koro", false, Modifier.fillMaxWidth()) { if (name.isNotBlank()) { exec("save $name"); name = "" } }
            if (status.isNotBlank()) Text(status, color = MC.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            if (places.isEmpty()) Text("Kono jaiga save kora nei. Voice-e bolo: \"location save home\".", color = MC.Sub, fontSize = 15.sp)
            places.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    HChip("Dur?") { exec("distance ${p.name}") }; Spacer(Modifier.width(6.dp))
                    HChip("Go") { exec("go ${p.name}") }
                    Icon(Icons.Filled.Delete, "delete", tint = MC.Hint, modifier = Modifier.padding(start = 10.dp).size(20.dp).clickable { LocationServices.deletePlace(ctx, p.name); tick++ })
                }
            }
            Text("Location shudhu tumi chaile (button / voice) porha hoy, background-e track kora hoy na. Voice-e jiggesh korle uttor Gemini-te jay; " +
                "Privacy mode chalu thakle ta-o bondho. Saved jaiga Sync snapshot-e shudhu tumi \"Saved jaiga\" on korle jay.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun HChip(label: String, onClick: () -> Unit) {
    Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(MC.BlueDeep).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp))
}

@Composable
private fun HBtn(label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(48.dp).clip(RoundedCornerShape(16.dp))
        .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}
