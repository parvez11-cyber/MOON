package com.myra.assistant.ui.main

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.WindowManager
import android.widget.*
import android.view.inputmethod.EditorInfo
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.security.BiometricManager
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.PermissionUtils
import com.myra.assistant.utils.prefs
import com.myra.assistant.viewmodel.MainViewModel
import com.myra.assistant.voice.VoiceStateManager
import java.text.SimpleDateFormat
import java.util.*
import android.net.Uri
import android.graphics.BitmapFactory

class MainActivity : AppCompatActivity() {

    private val TAG = "MAIN"
    private val viewModel: MainViewModel by viewModels()

    private lateinit var waveformView: WaveformView
    private lateinit var statusText: TextView
    private lateinit var micButton: ImageButton
    private lateinit var chatRecycler: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var batteryText: TextView
    private lateinit var ramText: TextView
    private lateinit var timeText: TextView
    private lateinit var textInput: EditText
    private var pendingImageName: String? = null

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendSelectedImage(uri)
    }

    private val timeHandler = Handler(Looper.getMainLooper())
    private val timeRunnable = object : Runnable {
        override fun run() {
            updateSystemInfo()
            timeHandler.postDelayed(this, 1000)
        }
    }

    private val responseReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text") ?: return
            addBotMessage(text)
        }
    }

    companion object {
        const val PERM_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)
        PersistentMemory.init(this)

        initViews()
        updateSystemInfo()
        timeHandler.post(timeRunnable)

        BiometricManager.authenticate(
            this,
            onSuccess = { setupAssistant() },
            onError = { setupAssistant() },
            onFallback = { setupAssistant() }
        )
    }

    private fun setupAssistant() {
        PermissionUtils.requestMissing(this, PERM_CODE)
        observeViewModel()
        observeVoiceState()
        startVoiceService()
        checkAccessibility()
        if (com.myra.assistant.utils.RootAccess.isRootAvailable) {
            addBotMessage("✅ Root access detected. Root shell is available to MOON.")
        }
        startFloatingAssistant()
    }

    private fun initViews() {
        waveformView = findViewById(R.id.waveformView)
        statusText  = findViewById(R.id.statusText)
        micButton   = findViewById(R.id.micButton)
        chatRecycler = findViewById(R.id.chatRecycler)
        batteryText = findViewById(R.id.batteryText)
        ramText     = findViewById(R.id.ramText)
        timeText    = findViewById(R.id.timeText)
        textInput   = findViewById(R.id.textInput)

        chatAdapter = ChatAdapter()
        chatRecycler.layoutManager = LinearLayoutManager(this).also { it.stackFromEnd = true }
        chatRecycler.adapter = chatAdapter

        micButton.setOnClickListener {
            val svc = ForegroundVoiceService.instance
            if (svc == null) {
                startVoiceService()
                Toast.makeText(this, "MOON service starting…", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            svc.setMicEnabled(!svc.isMicEnabled())
            updateMicButton(svc.isMicEnabled())
        }

        micButton.setOnLongClickListener {
            ForegroundVoiceService.instance?.reconnectGemini()
            addBotMessage("Reconnecting...")
            true
        }

        findViewById<ImageButton>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.memoryBtn).setOnClickListener {
            showMemoryDialog()
        }
        findViewById<ImageButton>(R.id.attachButton).setOnClickListener {
            imagePicker.launch("image/*")
        }

        val sendText = { sendTextCommand(textInput.text.toString()) }
        findViewById<ImageButton>(R.id.sendTextButton).setOnClickListener { sendText() }
        textInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendText(); true } else false
        }
    }

    private fun observeVoiceState() {
        VoiceStateManager.state.observe(this) { state ->
            when (state) {
                Constants.STATE_LISTENING -> {
                    val enabled = ForegroundVoiceService.instance?.isMicEnabled() == true
                    updateMicButton(enabled)
                    statusText.setTextColor(0xFF00E5FF.toInt())
                }
                Constants.STATE_THINKING -> {
                    statusText.setTextColor(0xFFD500F9.toInt())
                }
                Constants.STATE_SPEAKING -> {
                    val enabled = ForegroundVoiceService.instance?.isMicEnabled() == true
                    updateMicButton(enabled)
                    statusText.setTextColor(0xFFFF1744.toInt())
                }
                else -> {
                    micButton.setImageResource(R.drawable.ic_mic_off)
                    statusText.setTextColor(0xFFFF1744.toInt())
                }
            }
        }
        VoiceStateManager.amplitude.observe(this) { amp ->
            waveformView.updateAmplitude(amp)
        }
        VoiceStateManager.statusMessage.observe(this) { msg ->
            statusText.text = msg
        }
    }

    private fun observeViewModel() {
        viewModel.aiResponse.observe(this) { text ->
            if (!text.isNullOrBlank()) addBotMessage(text)
        }
    }


    private fun sendTextCommand(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return
        textInput.text?.clear()
        addUserMessage(text)

        if (viewModel.isDirectCommand(text)) {
            viewModel.processCommand(text)
            return
        }

        val service = ForegroundVoiceService.instance
        if (service != null) {
            service.sendTextToGemini(text)
        } else {
            startVoiceService()
            Handler(Looper.getMainLooper()).postDelayed({
                ForegroundVoiceService.instance?.sendTextToGemini(text)
            }, 700)
        }
    }

    private fun showMemoryDialog() {
        val input = EditText(this).apply {
            hint = "Example: I like purple themes"
            setPadding(32, 18, 32, 18)
        }
        val memories = PersistentMemory.all()
        val existing = if (memories.isEmpty()) "No saved memories yet." else
            memories.mapIndexed { i, m -> "${i + 1}. $m" }.joinToString("\n")

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(TextView(this@MainActivity).apply {
                text = existing
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(8, 8, 8, 18)
            })
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("MOON Memory")
            .setMessage("Saved privately on this phone. MOON can use these memories in future chats.")
            .setView(container)
            .setNegativeButton("Close", null)
            .setNeutralButton("Clear All") { _, _ ->
                PersistentMemory.all().indices.reversed().forEach { PersistentMemory.remove(it) }
                Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show()
            }
            .setPositiveButton("Save") { _, _ ->
                PersistentMemory.add(input.text.toString())
                Toast.makeText(this, "Saved to phone", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun sendSelectedImage(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val mime = contentResolver.getType(uri) ?: "image/jpeg"
            addUserMessage("📷 Image attached")
            val service = ForegroundVoiceService.instance
            if (service != null) {
                service.sendImageToGemini("", bytes, mime)
            } else {
                startVoiceService()
                Handler(Looper.getMainLooper()).postDelayed({
                    ForegroundVoiceService.instance?.sendImageToGemini("", bytes, mime)
                }, 700)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not attach image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVoiceService() {
        val apiKey = prefs().getString(Constants.KEY_API_KEY, "") ?: ""
        if (apiKey.isEmpty()) {
            addBotMessage("⚠️ API Key required. Please go to Settings → Enter Gemini API Key.")
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, ForegroundVoiceService::class.java))
        Logger.d(TAG, "Voice service started")
    }

    private fun updateMicButton(enabled: Boolean) {
        micButton.setImageResource(if (enabled) R.drawable.ic_mic_on else R.drawable.ic_mic_off)
        micButton.contentDescription = if (enabled) "Mic ON - tap to turn off" else "Mic OFF - tap to turn on"
        statusText.text = if (enabled) "MIC ON — LISTENING" else "MIC OFF — TAP TO LISTEN"
    }

    private fun startFloatingAssistant() {
        if (!Settings.canDrawOverlays(this)) {
            addBotMessage("⚠️ Floating MOON needs Display over other apps permission.")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
            } catch (_: Exception) {}
            return
        }
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, com.myra.assistant.service.MyraOverlayService::class.java).apply {
                    action = Constants.ACTION_SHOW_OVERLAY
                }
            )
        } catch (e: Exception) {
            Logger.e(TAG, "Overlay start failed: ${e.message}")
        }
    }

    private fun checkAccessibility() {
        if (!AccessibilityHelperService.isEnabled(this)) {
            addBotMessage("⚠️ Enable Accessibility Service for app control. Settings → Accessibility.")
        }
        if (!isNotificationListenerEnabled()) {
            addBotMessage("⚠️ Enable Notification Access so MOON can read notifications and use inline replies.")
            try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) {}
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    fun addUserMessage(text: String) = runOnUiThread {
        chatAdapter.addMessage(ChatMessage(text, true))
        chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
    }

    fun addBotMessage(text: String) = runOnUiThread {
        chatAdapter.addMessage(ChatMessage(text, false))
        chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
    }

    private fun updateSystemInfo() {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        timeText.text = sdf.format(Date())
        val bm = getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
        batteryText.text = "${bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 0}%"
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ramText.text = "${(mi.totalMem - mi.availMem) / 1048576}MB"
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"), Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(responseReceiver, IntentFilter("MYRA_RESPONSE"))
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(responseReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        timeHandler.removeCallbacks(timeRunnable)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CODE) {
            val micGranted = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (micGranted) startVoiceService()
        }
    }
}
