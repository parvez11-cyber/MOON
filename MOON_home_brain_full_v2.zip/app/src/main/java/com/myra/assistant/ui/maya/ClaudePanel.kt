package com.myra.assistant.ui.maya

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Drawer -> Claude. Key, model, and the switch that makes typed chat use Claude instead of Gemini. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClaudePanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
    var key by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(ClaudeChat.hasKey(ctx)) }
    var on by remember { mutableStateOf(ClaudeChat.isActive(ctx)) }
    var model by remember { mutableStateOf(ClaudeChat.model(ctx)) }
    var busy by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Claude", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("Chat-e Claude use koro: code lekha, bhul dhora, lomba uttor, ar phone-er kaj.", color = MC.Sub, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Chat-e Claude cholbe", color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(if (saved) "Off korle Gemini-i cholbe." else "Age key save koro.", color = MC.Sub, fontSize = 13.sp)
                }
                Switch(on, {
                    if (it && !saved) { toast("Age Claude API key save koro."); return@Switch }
                    on = it; ClaudeChat.setActive(ctx, it)
                })
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(key, { key = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                label = { Text(if (saved) "API key save kora ache (bodlate chaile dao)" else "Claude API key (sk-ant-...)") })
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClaudeBtn("Save", Modifier.weight(1f)) {
                    if (key.isBlank()) toast("Key ta paste koro.")
                    else if (ClaudeChat.saveKey(ctx, key)) { key = ""; saved = true; toast("Save hoyeche.") } else toast("Secure storage kaj korche na.")
                }
                ClaudeBtn(if (busy) "..." else "Test", Modifier.weight(1f)) {
                    if (!busy) { busy = true; scope.launch { toast(ClaudeChat.test(ctx)); busy = false } }
                }
                ClaudeBtn("Muche felo", Modifier.weight(1f)) {
                    ClaudeChat.clearKey(ctx); saved = false; on = false; toast("Key muche fela hoyeche.")
                }
            }
            Text("Model", color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClaudeChat.MODELS.forEach { (label, id) ->
                    val sel = model == id
                    Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
                        .clickable { model = id; ClaudeChat.setModel(ctx, id) }, contentAlignment = Alignment.Center) {
                        Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
            Text("Fast = shosta ar druto, Balanced = shob-er jonno bhalo (default), Best = kothin code / chinta-r jonno, beshi khoroch.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Text("Key console.anthropic.com theke nao (eta claude.ai subscription theke alada, API usage-r khoroch alada lage). " +
                "Key ta encrypted storage-e thake, Sync snapshot-e jay na. Claude on thakle tumi chat-e ja likho (ar ja attach koro) Anthropic-e jay. " +
                "Live mic conversation ekhono Gemini Live diye chole, karon Claude-r realtime voice API nei.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun ClaudeBtn(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(44.dp).clip(RoundedCornerShape(14.dp))
        .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}
