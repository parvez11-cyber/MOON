package com.myra.assistant.system

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.SystemClock
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Logger
import kotlin.math.sqrt

/**
 * Smart gestures, using only the accelerometer (tiny battery cost, no permission):
 *  - shake the phone twice  -> mic on/off (same as the floating mic button)
 *  - lay it face-down for 2 s -> ring mode goes to vibrate; turn it back up and the old mode returns
 * Each gesture has its own switch in prefs: "gesture_shake" (default on) and "gesture_flip" (default off).
 */
object GestureSensor : SensorEventListener {
    private const val TAG = "GESTURE"
    private var sm: SensorManager? = null
    private var app: Context? = null

    private var lastShakeAt = 0L
    private var shakeCount = 0
    private var firstShakeAt = 0L

    private var faceDownSince = 0L
    private var flipDone = false
    private var savedRinger = -1

    fun start(context: Context) {
        if (sm != null) return
        val a = context.applicationContext
        app = a
        val m = a.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val acc = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        m.registerListener(this, acc, SensorManager.SENSOR_DELAY_UI)
        sm = m
    }

    fun stop() {
        sm?.unregisterListener(this)
        sm = null
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val ctx = app ?: return
        val p = ctx.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        val now = SystemClock.elapsedRealtime()

        // ---- shake: strong acceleration well above gravity, twice within 1.2 s
        if (p.getBoolean("gesture_shake", true)) {
            val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            if (g > 2.6f && now - lastShakeAt > 250) {
                lastShakeAt = now
                if (shakeCount == 0 || now - firstShakeAt > 1200) { shakeCount = 1; firstShakeAt = now } else shakeCount++
                if (shakeCount >= 3) {      // two full back-and-forth swings register as 3 peaks
                    shakeCount = 0
                    val svc = ForegroundVoiceService.instance
                    if (svc != null) {
                        Logger.d(TAG, "shake -> toggle mic")
                        svc.setMicEnabled(!svc.isMicEnabled())
                    }
                }
            }
        }

        // ---- face-down: screen towards the table
        if (p.getBoolean("gesture_flip", false)) {
            val down = z < -8.5f
            if (down) {
                if (faceDownSince == 0L) faceDownSince = now
                if (!flipDone && now - faceDownSince > 2000) {
                    flipDone = true
                    try {
                        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                            savedRinger = am.ringerMode
                            am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                        }
                    } catch (_: Exception) {}
                }
            } else {
                faceDownSince = 0L
                if (flipDone && z > 5f) {
                    flipDone = false
                    try {
                        if (savedRinger >= 0) {
                            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode = savedRinger
                            savedRinger = -1
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }
}
