package com.myra.assistant.system

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.SmartAccessibilityEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Hands for the whole display: scroll, swipe, tap anywhere, long-press, and a numbered map of everything visible.
 *
 * Flow: READ_SCREEN returns a numbered list ("#7 [button] Send @(88%,93%)"), the model then says TAP_NUMBER 7,
 * TAP_AT 88 93, SCROLL down, SCROLL_TO <text>, ... Positions are percentages of the screen so they do not depend on
 * the size of the screenshot the model saw.
 */
object ScreenControl {

    private class Item(val label: String, val rect: Rect)

    @Volatile private var items: List<Item> = emptyList()

    private fun svc(): AccessibilityService? = SmartAccessibilityEngine.service ?: AccessibilityHelperService.instance
    private fun root(): AccessibilityNodeInfo? = svc()?.rootInActiveWindow ?: AccessibilityHelperService.getFreshRoot()

    private fun screenW(s: AccessibilityService) = s.resources.displayMetrics.widthPixels
    private fun screenH(s: AccessibilityService) = s.resources.displayMetrics.heightPixels

    // ------------------------------------------------------------------ numbered screen map

    /** Builds the numbered list of what is on screen. Also remembers positions for TAP_NUMBER. */
    fun buildMap(root: AccessibilityNodeInfo?, w: Int, h: Int): List<String> {
        val found = ArrayList<Item>()
        val lines = ArrayList<String>()
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || found.size >= 120) return
            try {
                if (n.isVisibleToUser) {
                    val text = (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.trim().orEmpty()
                    val interactive = n.isClickable || n.isCheckable || n.isEditable || n.isLongClickable
                    if (text.isNotEmpty() || interactive) {
                        val r = Rect(); n.getBoundsInScreen(r)
                        if (r.width() > 0 && r.height() > 0) {
                            val kind = when {
                                n.isEditable -> "[input] "
                                n.isCheckable -> "[switch] "
                                n.isClickable -> "[button] "
                                n.isScrollable -> "[list] "
                                else -> ""
                            }
                            val label = text.ifEmpty { n.viewIdResourceName?.substringAfter('/') ?: "item" }.take(80)
                            found.add(Item(label, r))
                            val px = (r.centerX() * 100f / w).toInt().coerceIn(0, 100)
                            val py = (r.centerY() * 100f / h).toInt().coerceIn(0, 100)
                            lines.add("#${found.size} $kind$label @($px%,$py%)")
                        }
                    }
                }
                for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
            } catch (_: Exception) {}
        }
        visit(root, 0)
        items = found
        return lines
    }

    // ------------------------------------------------------------------ gestures

    private suspend fun gesture(s: AccessibilityService, path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        return withTimeoutOrNull(durationMs + 2500) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val ok = s.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                    override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
                }, null)
                if (!ok && cont.isActive) cont.resume(false)
            }
        } ?: false
    }

    suspend fun tapPx(x: Float, y: Float, long: Boolean = false): Boolean {
        val s = svc() ?: return false
        TapPing.show(s, x, y)
        val p = Path().apply { moveTo(x, y) }
        return gesture(s, p, if (long) 800 else 60)
    }

    suspend fun tapAt(xPct: Float, yPct: Float): String {
        val s = svc() ?: return "Accessibility chalu nei, tai screen e chapte parbo na."
        val x = screenW(s) * xPct.coerceIn(0f, 100f) / 100f
        val y = screenH(s) * yPct.coerceIn(0f, 100f) / 100f
        return if (tapPx(x, y)) "Chepe diyechi." else "Ei jaygay chapte parini."
    }

    suspend fun tapNumber(n: Int, long: Boolean = false): String {
        if (svc() == null) return "Accessibility chalu nei, tai screen e chapte parbo na."
        val list = items
        if (n < 1 || n > list.size) return "#$n number ta screen map e nei. Age READ_SCREEN diye screen ta abar dekho."
        val r = list[n - 1].rect
        return if (tapPx(r.centerX().toFloat(), r.centerY().toFloat(), long)) {
            (if (long) "Chepe dhore rekhechi: " else "Chepe diyechi: ") + list[n - 1].label
        } else "Chapte parini."
    }

    /** Swipe the finger across the screen. dir = the direction the CONTENT should move to be seen (down = see lower content). */
    suspend fun swipe(dir: String): String {
        val s = svc() ?: return "Accessibility chalu nei, tai scroll korte parbo na."
        val w = screenW(s).toFloat(); val h = screenH(s).toFloat()
        val d = dir.trim().lowercase()
        // finger moves opposite to the content: to see lower content the finger goes up
        val (sx, sy, ex, ey) = when {
            d.startsWith("up") || d.startsWith("opor") || d.startsWith("upor") -> listOf(w * 0.5f, h * 0.30f, w * 0.5f, h * 0.72f)
            d.startsWith("left") || d.startsWith("bam") -> listOf(w * 0.25f, h * 0.5f, w * 0.80f, h * 0.5f)
            d.startsWith("right") || d.startsWith("dan") -> listOf(w * 0.80f, h * 0.5f, w * 0.25f, h * 0.5f)
            else -> listOf(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.30f)
        }
        TapPing.show(s, sx, sy)
        val p = Path().apply { moveTo(sx, sy); lineTo(ex, ey) }
        return if (gesture(s, p, 350)) "Scroll kore diyechi." else "Scroll korte parini."
    }

    private fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun visit(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            try {
                if (n.isScrollable && n.isVisibleToUser) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val a = r.width() * r.height()
                    if (a > bestArea) { best = n; bestArea = a }
                }
                for (i in 0 until n.childCount) visit(n.getChild(i), depth + 1)
            } catch (_: Exception) {}
        }
        visit(root, 0)
        return best
    }

    /** SCROLL down/up/left/right [times]. Uses the app's own scroll action first, a finger swipe if that does not work. */
    suspend fun scroll(arg: String): String {
        if (svc() == null) return "Accessibility chalu nei, tai scroll korte parbo na."
        val parts = arg.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val dir = parts.firstOrNull() ?: "down"
        val times = (parts.getOrNull(1)?.toIntOrNull() ?: 1).coerceIn(1, 10)
        var ok = 0
        repeat(times) {
            val node = findScrollable(root())
            val forward = !(dir.startsWith("up") || dir.startsWith("left") || dir.startsWith("opor") || dir.startsWith("upor"))
            val done = node?.performAction(
                if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            ) == true
            if (done) { ok++; delay(450) } else {
                if (swipe(dir).startsWith("Scroll kore")) ok++
                delay(250)
            }
        }
        return if (ok > 0) "Scroll korlam ($dir, $ok bar). Notun screen dekhte READ_SCREEN chaliye nao." else "Scroll korte parini."
    }

    /** Scrolls down (then up) until the given text is on screen, then reports where it is. */
    suspend fun scrollTo(text: String): String {
        if (svc() == null) return "Accessibility chalu nei."
        val q = text.trim().lowercase()
        if (q.isEmpty()) return "Ki khujbo seta bolo."
        fun visible(): Boolean = buildMap(root(), screenW(svc()!!), screenH(svc()!!)).any { it.lowercase().contains(q) }
        if (visible()) return "'$text' screen e-i ache. READ_SCREEN diye number dekho."
        for (dir in listOf("down", "up")) {
            repeat(8) {
                scroll("$dir 1"); delay(350)
                if (visible()) return "'$text' pawa gechhe. READ_SCREEN diye number dekho."
            }
            if (dir == "down") repeat(8) { scroll("up 1"); delay(120) }
        }
        return "'$text' khuje pai ni."
    }

    suspend fun longPress(arg: String): String {
        val a = arg.trim()
        if (a.startsWith("#")) return tapNumber(a.removePrefix("#").trim().toIntOrNull() ?: -1, long = true)
        a.toIntOrNull()?.let { return tapNumber(it, long = true) }
        val q = a.lowercase()
        val hit = items.firstOrNull { it.label.lowercase().contains(q) }
            ?: return "'$a' screen e pai ni. Age READ_SCREEN chaliye nao."
        return if (tapPx(hit.rect.centerX().toFloat(), hit.rect.centerY().toFloat(), true)) "Chepe dhore rekhechi." else "Parini."
    }
}
