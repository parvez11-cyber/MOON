package com.myra.assistant.ai

import android.content.Context
import androidx.lifecycle.MutableLiveData
import org.json.JSONArray
import org.json.JSONObject

/**
 * Simple on-device custom memory. Data stays in app-private SharedPreferences.
 *
 * The list of texts ("items") is exactly what it always was, so Backup / Restore / Sync keep working. Next to it a parallel
 * "meta" list keeps, for every text, a stable id, its type (emotion / thought / memory, see [BrainMemory]) and when it was saved.
 * [changes] ticks on every add / edit / delete so the brain animation and the lists can redraw.
 */
object PersistentMemory {
    private const val PREFS = "myra_custom_memory"
    private const val KEY_ITEMS = "items"
    private const val KEY_META = "meta"
    private var initialized = false
    private var context: Context? = null
    private val items = mutableListOf<String>()
    private val metas = mutableListOf<BrainMemory.Meta>()
    private var nextId = 1

    /** Ticks whenever something is added, edited or deleted. */
    val changes = MutableLiveData(0L)

    /** Id of the memory saved (or found again) last. */
    @Volatile var lastAddedId = -1
        private set

    @Volatile private var pendingFocus = -1

    /** The id the brain should zoom to after the latest change (-1 after a delete), handed out once. */
    /** Ask the brain to zoom to this memory the next time it opens (used by "Brain-e dekho"). */
    fun requestFocus(id: Int) { pendingFocus = id }

    fun consumeFocus(): Int { val f = pendingFocus; pendingFocus = -1; return f }

    fun init(ctx: Context) {
        if (initialized) return
        context = ctx.applicationContext
        val sp = context!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = sp.getString(KEY_ITEMS, "[]") ?: "[]"
        items.clear()
        metas.clear()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) items.add(arr.optString(i))
        } catch (_: Exception) {}
        val old = try { JSONArray(sp.getString(KEY_META, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        var maxId = 0
        for (i in 0 until old.length()) maxId = maxOf(maxId, old.optJSONObject(i)?.optInt("id", 0) ?: 0)
        nextId = maxId + 1
        // repair: texts without meta (older versions, Restore, Sync) get an id and a guessed type
        for (i in items.indices) {
            val o = old.optJSONObject(i)
            val id = o?.optInt("id", 0) ?: 0
            if (o != null && id > 0 && old.length() == items.size) {
                metas.add(BrainMemory.Meta(id, BrainMemory.Kind.of(o.optString("k")) ?: BrainMemory.classify(items[i]), o.optLong("t", now)))
            } else {
                metas.add(BrainMemory.Meta(nextId++, BrainMemory.classify(items[i]), now))
            }
        }
        initialized = true
        if (old.length() != items.size) persist()
    }

    /** Saves a memory. Returns its id (the id of the existing one when the same text is already there). */
    @Synchronized
    fun add(text: String, kind: BrainMemory.Kind? = null): Int {
        val value = text.trim()
        if (value.isBlank()) return -1
        val existing = items.indexOfFirst { it.equals(value, ignoreCase = true) }
        if (existing >= 0) {
            lastAddedId = metas[existing].id
            pendingFocus = lastAddedId
            notifyChanged()
            return lastAddedId
        }
        val meta = BrainMemory.Meta(nextId++, kind ?: BrainMemory.classify(value), System.currentTimeMillis())
        items.add(value)
        metas.add(meta)
        lastAddedId = meta.id
        pendingFocus = meta.id
        persist()
        context?.let { MemoryRevival.onAdded(it, value) }   // remember when it was learned (for revival)
        notifyChanged()
        return meta.id
    }

    /** Changes the text and / or type of a memory. The marker keeps its place in the brain. False when not possible. */
    @Synchronized
    fun update(id: Int, text: String, kind: BrainMemory.Kind): Boolean {
        val i = metas.indexOfFirst { it.id == id }
        val value = text.trim()
        if (i < 0 || value.isBlank()) return false
        if (items.indices.any { it != i && items[it].equals(value, ignoreCase = true) }) return false
        items[i] = value
        metas[i] = metas[i].copy(kind = kind)
        persist()
        context?.let { MemoryRevival.onAdded(it, value); MemoryRevival.prune(it) }
        lastAddedId = id
        pendingFocus = id
        notifyChanged()
        return true
    }

    @Synchronized
    fun remove(index: Int) {
        if (index in items.indices) {
            items.removeAt(index)
            metas.removeAt(index)
            persist()
            context?.let { MemoryRevival.prune(it) }
            pendingFocus = -1
            notifyChanged()
        }
    }

    @Synchronized
    fun removeById(id: Int) {
        val i = metas.indexOfFirst { it.id == id }
        if (i >= 0) remove(i)
    }

    fun all(): List<String> = synchronized(this) { items.toList() }

    /** Every memory with its id, type and time (oldest first). */
    fun entries(): List<BrainMemory.Entry> = synchronized(this) {
        items.indices.map { BrainMemory.Entry(metas[it].id, items[it], metas[it].kind, metas[it].at) }
    }

    fun contextForAI(): String = synchronized(this) {
        if (items.isEmpty()) "" else items.joinToString("\n") { "- $it" }
    }

    private fun notifyChanged() { changes.postValue(System.nanoTime()) }

    private fun persist() {
        val arr = JSONArray()
        items.forEach(arr::put)
        val meta = JSONArray()
        metas.forEach { meta.put(JSONObject().put("id", it.id).put("k", it.kind.key).put("t", it.at)) }
        context?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            ?.edit()?.putString(KEY_ITEMS, arr.toString())?.putString(KEY_META, meta.toString())?.apply()
    }
}
