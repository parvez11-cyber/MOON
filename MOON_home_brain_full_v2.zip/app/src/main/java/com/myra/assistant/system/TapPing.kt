package com.myra.assistant.system

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator

/**
 * A small glowing ring that blooms where Moon taps (and a trail for swipes), so the user can SEE what she is doing
 * on the display. Drawn as an accessibility overlay: no extra permission, and touches pass straight through it.
 */
object TapPing {
    private val main = Handler(Looper.getMainLooper())

    private class PingView(ctx: android.content.Context) : View(ctx) {
        var p = 0f
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.parseColor("#7DE3FF") }
        private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#FFFFFF") }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f
            val max = width / 2f
            ring.alpha = ((1f - p) * 230).toInt().coerceIn(0, 255)
            ring.strokeWidth = 10f * (1f - p) + 2f
            c.drawCircle(cx, cy, max * (0.25f + 0.75f * p), ring)
            core.alpha = ((1f - p) * 255).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, max * 0.18f * (1f - p * 0.6f), core)
        }
    }

    fun show(service: AccessibilityService?, x: Float, y: Float) {
        service ?: return
        main.post {
            try {
                val wm = service.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
                val size = (service.resources.displayMetrics.density * 96).toInt()
                val v = PingView(service)
                val lp = WindowManager.LayoutParams(
                    size, size,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = (x - size / 2f).toInt()
                    this.y = (y - size / 2f).toInt()
                }
                wm.addView(v, lp)
                ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 650
                    interpolator = DecelerateInterpolator()
                    addUpdateListener { v.p = it.animatedValue as Float; v.invalidate() }
                    addListener(object : android.animation.AnimatorListenerAdapter() {
                        override fun onAnimationEnd(a: android.animation.Animator) {
                            try { wm.removeView(v) } catch (_: Exception) {}
                        }
                    })
                    start()
                }
            } catch (_: Exception) { /* overlay is only decoration; never break the action because of it */ }
        }
    }
}
