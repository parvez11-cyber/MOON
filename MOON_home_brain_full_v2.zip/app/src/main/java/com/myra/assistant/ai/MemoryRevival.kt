package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.utils.Constants
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.ln
import kotlin.math.min

/**
 * AI-based memory revival (স্মৃতি পুনরুজ্জীবন).
 *
 * [PersistentMemory] only keeps a flat list of facts. Dumping all of them into every prompt makes the list grow
 * without end and old things are never brought back at the right moment. This object adds three things on top,
 * without changing how the facts themselves are stored (so Sync / Backup keep working):
 *
 *  1. Context recall   - [contextFor] picks the facts that matter for what is being talked about right now
 *                        (word overlap with the conversation, time of day, how often it was useful) instead of all of them.
 *  2. Revival          - [reviveCandidate] finds a fact that has been dormant for days and fits this moment, so Moon
 *                        can bring it up herself ("last week you said ... how did it go?"). Used by ProactiveCompanion.
 *  3. Spaced recall    - every time a fact is used it is marked, so the same fact is not repeated again and again and
 *                        different old facts get their turn.
 *
 * Everything runs on the phone: a small metadata file (created / last recalled / times recalled) in SharedPreferences.
 * Gemini only receives the few facts picked for the current moment, never the whole list. Privacy mode switches it all off.
 * Pref keys (myra_prefs): memory_revival_enabled (true), memory_revival_days (3).
 */
object MemoryRevival {
    private const val META_PREFS = "myra_memory_meta"
    private const val K_META = "meta"                 // { "<normalised fact>": { "c": created, "r": lastRecalled, "n": times } }
    private const val DAY = 24 * 3_600_000L
    private const val ALL_IF_SMALL = 12               // a short list is simply given whole
    private const val MAX_IN_PROMPT = 12

    private data class Meta(var created: Long, var lastRecalled: Long, var times: Int)

    private val STOP = setOf(
        "the", "a", "an", "is", "are", "to", "of", "and", "in", "on", "for", "my", "me", "i", "you", "it", "that", "this", "with",
        "ami", "tumi", "amar", "tomar", "ache", "achhe", "ki", "ke", "ta", "te", "er", "o", "na", "ar", "je", "jar", "hobe", "kore", "koro",
        "আমি", "তুমি", "আমার", "তোমার", "আছে", "কি", "কী", "কে", "এর", "ও", "না", "আর", "যে", "হবে", "করে", "করো", "একটা", "এই", "সেই"
    )

    @Volatile private var cache: MutableMap<String, Meta>? = null

    // ------------------------------------------------------------------ settings

    fun enabled(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .getBoolean("memory_revival_enabled", true)

    fun setEnabled(c: Context, on: Boolean) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .edit().putBoolean("memory_revival_enabled", on).apply()

    /** A fact must be quiet for this many days before Moon may bring it back herself. */
    fun dormantDays(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .getInt("memory_revival_days", 3).coerceIn(1, 30)

    fun setDormantDays(c: Context, d: Int) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .edit().putInt("memory_revival_days", d.coerceIn(1, 30)).apply()

    // ------------------------------------------------------------------ metadata store

    private fun key(fact: String) = fact.trim().lowercase()

    @Synchronized
    private fun load(c: Context): MutableMap<String, Meta> {
        cache?.let { return it }
        val out = HashMap<String, Meta>()
        try {
            val raw = c.applicationContext.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE).getString(K_META, "{}") ?: "{}"
            val o = JSONObject(raw)
            for (k in o.keys()) {
                val m = o.getJSONObject(k)
                out[k] = Meta(m.optLong("c", 0L), m.optLong("r", 0L), m.optInt("n", 0))
            }
        } catch (_: Exception) {}
        cache = out
        return out
    }

    @Synchronized
    private fun save(c: Context) {
        val m = cache ?: return
        val o = JSONObject()
        for ((k, v) in m) o.put(k, JSONObject().put("c", v.created).put("r", v.lastRecalled).put("n", v.times))
        c.applicationContext.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE).edit().putString(K_META, o.toString()).apply()
    }

    /** Called by [PersistentMemory] when a new fact is stored, so its age is known. */
    fun onAdded(c: Context, fact: String) {
        val m = load(c)
        synchronized(this) { if (key(fact) !in m) m[key(fact)] = Meta(System.currentTimeMillis(), 0L, 0) }
        save(c)
    }

    /** Facts that existed before this feature, or came from Restore / Sync, get "now" as their start, once. */
    @Synchronized
    private fun metaOf(c: Context, fact: String): Meta {
        val m = load(c)
        return m.getOrPut(key(fact)) { Meta(System.currentTimeMillis(), 0L, 0) }
    }

    /** Forget the bookkeeping of facts that were deleted. */
    fun prune(c: Context) {
        val live = PersistentMemory.all().map { key(it) }.toSet()
        val m = load(c)
        val changed = synchronized(this) { m.keys.retainAll(live) }
        if (changed) save(c)
    }

    fun clearAll(c: Context) {
        synchronized(this) { cache = HashMap() }
        c.applicationContext.getSharedPreferences(META_PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    // ------------------------------------------------------------------ relevance

    private fun words(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.length >= 2 && it !in STOP }.toSet()

    /** Bangla / Banglish words carry endings ("kaj-er", "কাজে"), so two words match when their first 4 letters agree. */
    private fun overlap(a: Set<String>, b: Set<String>): Int {
        if (a.isEmpty() || b.isEmpty()) return 0
        var n = 0
        for (x in a) for (y in b) {
            if (x == y || (x.length >= 4 && y.length >= 4 && x.take(4) == y.take(4))) { n++; break }
        }
        return n
    }

    private val MORNING = setOf("breakfast", "naasta", "nasta", "সকাল", "নাস্তা", "gym", "walk", "hanta", "হাঁটা", "office", "class", "exercise")
    private val NOON = setOf("lunch", "dupur", "দুপুর", "meeting", "office", "class", "khabar", "খাবার")
    private val NIGHT = setOf("sleep", "ghum", "ঘুম", "dinner", "raat", "রাত", "medicine", "ওষুধ", "alarm", "movie", "book")

    private fun timeBoost(fact: String): Double {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val w = words(fact)
        val set = when (h) { in 5..10 -> MORNING; in 11..16 -> NOON; else -> NIGHT }
        return if (w.any { it in set }) 1.0 else 0.0
    }

    /**
     * One score for how useful [fact] is right now. [queryWords] = what is being talked about (may be empty).
     * Word overlap counts most; then time of day; a little for "it has been useful before"; a little for being fresh.
     */
    private fun score(c: Context, fact: String, queryWords: Set<String>, now: Long): Double {
        val meta = metaOf(c, fact)
        val overlapScore = overlap(words(fact), queryWords) * 3.0
        val usedBefore = min(ln(1.0 + meta.times), 2.0) * 0.4
        val ageDays = ((now - meta.created) / DAY).toDouble()
        val fresh = if (ageDays < 2) 0.6 else 0.0
        // a fact just used a moment ago is not needed again right now
        val sinceUse = if (meta.lastRecalled == 0L) Double.MAX_VALUE else (now - meta.lastRecalled).toDouble()
        val justUsed = if (sinceUse < 10 * 60_000.0) -1.5 else 0.0
        return overlapScore + timeBoost(fact) + usedBefore + fresh + justUsed
    }

    /**
     * The facts to put in a prompt, as "- fact" lines. A short list is returned whole; a long one is cut down to the
     * [MAX_IN_PROMPT] that fit [about] best. Falls back to everything when revival is off.
     */
    fun contextFor(c: Context, about: String = ""): String {
        val all = PersistentMemory.all()
        if (all.isEmpty()) return ""
        if (!enabled(c) || all.size <= ALL_IF_SMALL) return all.joinToString("\n") { "- $it" }
        val now = System.currentTimeMillis()
        val q = words(about)
        val picked = all.map { it to score(c, it, q, now) }
            .sortedByDescending { it.second }
            .take(MAX_IN_PROMPT)
            .map { it.first }
        markRecalled(c, picked)
        return picked.joinToString("\n") { "- $it" }
    }

    @Synchronized
    private fun markRecalledLocked(c: Context, facts: List<String>) {
        val now = System.currentTimeMillis()
        facts.forEach { f -> metaOf(c, f).also { it.lastRecalled = now; it.times++ } }
    }

    fun markRecalled(c: Context, facts: List<String>) {
        if (facts.isEmpty()) return
        markRecalledLocked(c, facts)
        save(c)
    }

    // ------------------------------------------------------------------ revival

    /** A dormant fact worth bringing up now. [days] = how long since it was last used (or learned). */
    data class Revival(val fact: String, val days: Int, val prompt: String)

    /**
     * Picks at most one fact that (a) has not been used for [dormantDays] days, (b) fits this part of the day or the
     * recent conversation, and returns a ready-made prompt for Gemini. It marks the fact as recalled, so the same one
     * does not come back next time. Returns null when there is nothing good.
     */
    fun reviveCandidate(c: Context, recentTalk: String): Revival? {
        if (!enabled(c) || com.myra.assistant.system.PrivacyMode.isOn(c)) return null
        val all = PersistentMemory.all()
        if (all.isEmpty()) return null
        val now = System.currentTimeMillis()
        val need = dormantDays(c) * DAY
        val q = words(recentTalk)
        val best = all.mapNotNull { f ->
            val m = metaOf(c, f)
            val quiet = now - maxOf(m.lastRecalled, m.created)
            if (quiet < need) return@mapNotNull null
            // facts that fit now (time of day or the recent talk) are worth interrupting for; a fact forgotten for twice
            // as long as the limit gets a small chance anyway, so nothing stays buried forever
            val fit = timeBoost(f) + overlap(words(f), q) * 2.0 + (if (quiet >= 2 * need) 0.3 else 0.0)
            if (fit <= 0.0) return@mapNotNull null
            Triple(f, quiet, fit + min(quiet / DAY.toDouble(), 30.0) / 30.0)
        }.maxByOrNull { it.third } ?: return null

        markRecalled(c, listOf(best.first))
        val days = (best.second / DAY).toInt()
        val prompt = "[CHECK-IN] You suddenly remembered something about the user from $days days ago: \"${best.first}\". " +
            "Do not call phone_action. In one or two short, warm sentences of simple spoken Bangla (tumi), bring it up naturally, " +
            "the way a close friend remembers ('মনে পড়লো, তুমি বলেছিলে…'), and ask how it went or if you can help. " +
            "Do not repeat it word for word if that sounds stiff, and never pressure the user. If the fact is private or sad, be gentle."
        return Revival(best.first, days, prompt)
    }

    /** For the Smart panel: how many facts are dormant right now and the oldest one. */
    fun dormantSummary(c: Context): Pair<Int, String?> {
        val all = PersistentMemory.all()
        val now = System.currentTimeMillis()
        val need = dormantDays(c) * DAY
        val dormant = all.filter { now - maxOf(metaOf(c, it).lastRecalled, metaOf(c, it).created) >= need }
        return dormant.size to dormant.minByOrNull { maxOf(metaOf(c, it).lastRecalled, metaOf(c, it).created) }
    }
}
