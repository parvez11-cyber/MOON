package com.myra.assistant.sync

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.myra.assistant.system.PrivacyMode
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONTokener
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cloud sync through Supabase (plain REST, no SDK). See SUPABASE_SETUP.md for the one-time SQL.
 *
 * - The snapshot is encrypted ON THE PHONE (AES-256-GCM, key derived from your Sync code) before it leaves. Supabase
 *   only ever stores a random-looking blob. The Sync code itself is never sent: the row id is a SHA-256 of it.
 * - The Supabase table has no public access at all; the phone talks only to two SQL functions (myra_push / myra_pull)
 *   and needs to know the row id, which is derived from the Sync code. No Sync code = no data.
 * - URL, anon key and Sync code live in EncryptedSharedPreferences, never in myra_prefs and never in a snapshot.
 * - "Real-time" here means: pull + merge + push every few minutes while the app is open, and a final push when the app
 *   goes to the background. It is not a live WebSocket. Merging only ever ADDS (same rule as Restore), so a delete
 *   on one phone does not delete it on the other.
 * - Privacy mode on => nothing is sent or pulled.
 */
class SupabaseBackend(private val c: Context) : SyncBackend {
    override suspend fun push(json: String): Boolean = CloudSync.rpcPush(c, json)
    override suspend fun pull(): String? = CloudSync.rpcPull(c)
}

object CloudSync {
    private const val SECURE_FILE = "myra_cloud_secure"
    private const val K_URL = "sb_url"
    private const val K_KEY = "sb_anon_key"
    private const val K_CODE = "sync_code"
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val http by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).writeTimeout(15, TimeUnit.SECONDS).build()
    }
    private val lock = Mutex()
    @Volatile private var job: Job? = null
    @Volatile private var securePrefs: SharedPreferences? = null
    @Volatile private var cachedKeyFor: String? = null
    @Volatile private var cachedKey: SecretKeySpec? = null

    // ---------- config ----------
    private fun secure(c: Context): SharedPreferences? {
        securePrefs?.let { return it }
        return try {
            val mk = MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(c.applicationContext, SECURE_FILE, mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM).also { securePrefs = it }
        } catch (_: Exception) { null }
    }
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun url(c: Context) = secure(c)?.getString(K_URL, "").orEmpty()
    fun hasKey(c: Context) = !secure(c)?.getString(K_KEY, "").isNullOrBlank()
    fun code(c: Context) = secure(c)?.getString(K_CODE, "").orEmpty()
    fun isConfigured(c: Context) = url(c).isNotBlank() && hasKey(c) && code(c).isNotBlank()
    fun isEnabled(c: Context) = p(c).getBoolean("cloud_enabled", false) && isConfigured(c)
    fun setEnabled(c: Context, on: Boolean) { p(c).edit().putBoolean("cloud_enabled", on).apply(); if (on) start(c) else stop() }
    fun lastSync(c: Context) = p(c).getLong("cloud_last_sync", 0L)
    fun lastError(c: Context) = p(c).getString("cloud_last_error", "").orEmpty()
    fun intervalMin(c: Context) = p(c).getInt("cloud_interval_min", 3).coerceIn(1, 60)

    private fun normCode(s: String) = s.uppercase().filter { it.isLetterOrDigit() }

    fun generateCode(): String {
        val abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   // no 0/O/1/I
        val r = SecureRandom()
        return (0 until 24).map { abc[r.nextInt(abc.length)] }.chunked(4).joinToString("-") { it.joinToString("") }
    }

    /** Returns null when saved, otherwise the reason it was refused. Blank url/key/code keep what is already saved. */
    fun saveConfig(c: Context, rawUrl: String, anonKey: String, rawCode: String): String? {
        val s = secure(c) ?: return "Phone-er secure storage kaj korche na, save kora gelo na."
        val u = rawUrl.trim().trimEnd('/').ifBlank { url(c) }
        if (u.isBlank()) return "Supabase Project URL dao (https://xxxx.supabase.co)."
        val parsed = u.toHttpUrlOrNull()
        if (parsed == null || parsed.scheme != "https") return "URL https:// diye shuru hote hobe. Jemon: https://abcd.supabase.co"
        val key = anonKey.trim().ifBlank { s.getString(K_KEY, "").orEmpty() }
        if (key.isBlank()) return "Supabase anon (public) key dao."
        val code = normCode(rawCode).ifBlank { normCode(code(c)) }
        if (code.length < 16) return "Sync code kom-pokkho 16 ta okkhor / songkha hote hobe (Generate chapo)."
        s.edit().putString(K_URL, u).putString(K_KEY, key).putString(K_CODE, code).apply()
        cachedKeyFor = null
        return null
    }

    fun clearConfig(c: Context) {
        stop(); secure(c)?.edit()?.clear()?.apply()
        p(c).edit().remove("cloud_enabled").remove("cloud_last_sync").remove("cloud_last_error")
            .remove("cloud_remote_at").remove("cloud_last_hash").apply()
    }

    // ---------- crypto ----------
    private fun sha256Hex(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun rowId(c: Context) = sha256Hex("myra-id|" + normCode(code(c)))

    private fun aesKey(c: Context): SecretKeySpec {
        val code = normCode(code(c))
        if (cachedKeyFor == code) cachedKey?.let { return it }
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val k = f.generateSecret(PBEKeySpec(code.toCharArray(), "myra-sync-v1".toByteArray(), 100_000, 256)).encoded
        return SecretKeySpec(k, "AES").also { cachedKey = it; cachedKeyFor = code }
    }

    private fun encrypt(c: Context, plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val ci = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, aesKey(c), GCMParameterSpec(128, iv)) }
        return Base64.encodeToString(iv + ci.doFinal(plain.toByteArray()), Base64.NO_WRAP)
    }

    private fun decrypt(c: Context, b64: String): String? = try {
        val all = Base64.decode(b64, Base64.NO_WRAP)
        val ci = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, aesKey(c), GCMParameterSpec(128, all.copyOfRange(0, 12))) }
        String(ci.doFinal(all, 12, all.size - 12))
    } catch (_: Exception) { null }   // wrong Sync code or corrupted blob

    // ---------- http (Supabase RPC) ----------
    private class Resp(val code: Int, val body: String)

    private suspend fun rpc(c: Context, fn: String, body: JSONObject): Resp? = withContext(Dispatchers.IO) {
        val s = secure(c) ?: return@withContext null
        val base = s.getString(K_URL, "").orEmpty(); val key = s.getString(K_KEY, "").orEmpty()
        if (base.isBlank() || key.isBlank() || base.toHttpUrlOrNull()?.scheme != "https") return@withContext null
        val r = Request.Builder().url("$base/rest/v1/rpc/$fn").header("apikey", key).header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody(JSON)).build()
        try { http.newCall(r).execute().use { Resp(it.code, it.body?.string().orEmpty()) } } catch (_: Exception) { null }
    }

    private fun failText(r: Resp?, fn: String) = when {
        r == null -> "Supabase-er shathe connect hocche na (internet / URL / key dekho)."
        r.code == 401 || r.code == 403 -> "Key thik na (${r.code}). Supabase-er anon public key dao."
        r.code == 404 -> "$fn function pawa jay ni. SUPABASE_SETUP.md-er SQL ek-bar chalao."
        else -> "Supabase error ${r.code}."
    }

    private var lastFail: String = ""

    suspend fun rpcPush(c: Context, plainJson: String): Boolean {
        val r = rpc(c, "myra_push", JSONObject().put("p_id", rowId(c)).put("p_data", encrypt(c, plainJson)))
        if (r == null || r.code !in 200..299) { lastFail = failText(r, "myra_push"); return false }
        return true
    }

    /** Decrypted snapshot, or null (nothing stored yet, wrong code, or an error: see [lastFail]). */
    suspend fun rpcPull(c: Context): String? {
        lastFail = ""
        val r = rpc(c, "myra_pull", JSONObject().put("p_id", rowId(c)))
        if (r == null || r.code != 200) { lastFail = failText(r, "myra_pull"); return null }
        val v = try { JSONTokener(r.body).nextValue() } catch (_: Exception) { null }
        val blob = v as? String ?: return null
        val plain = decrypt(c, blob)
        if (plain == null) lastFail = "Cloud-er data khulte parlam na: Sync code onno phone-er code-er shathe mile na."
        return plain
    }

    suspend fun test(c: Context): String {
        if (!isConfigured(c)) return "Age URL, key ar Sync code save koro."
        val r = rpc(c, "myra_pull", JSONObject().put("p_id", rowId(c)))
        return if (r != null && r.code == 200) "Supabase connected." else failText(r, "myra_pull")
    }

    // ---------- sync ----------
    private fun dataHash(snapshot: String): String =
        sha256Hex(try { JSONObject(snapshot).optJSONObject("data")?.toString().orEmpty() } catch (_: Exception) { snapshot })

    /**
     * One round: pull -> merge -> push. If something changed on THIS phone since the last round, the remote theme is
     * not applied (so a theme you just changed is not overwritten by an older copy). Returns a one-line result.
     */
    suspend fun syncNow(c: Context): String = lock.withLock {
        val app = c.applicationContext
        if (!isConfigured(app)) return@withLock "Cloud sync setup hoyni."
        if (PrivacyMode.isOn(app)) return@withLock "Privacy mode on, tai cloud sync bondho."
        val sp = p(app)
        val notes = ArrayList<String>()
        try {
            val localChanged = dataHash(SyncManager.snapshot(app)) != sp.getString("cloud_last_hash", "")
            val remote = rpcPull(app)
            if (remote == null && lastFail.isNotEmpty()) return@withLock fail(app, lastFail)
            if (remote != null) {
                val rAt = try { JSONObject(remote).optLong("at", 0L) } catch (_: Exception) { 0L }
                if (rAt > sp.getLong("cloud_remote_at", 0L)) {
                    val msg = withContext(Dispatchers.Main) { SyncManager.restore(app, remote, skipTheme = localChanged) }
                    sp.edit().putLong("cloud_remote_at", rAt).apply()
                    notes += "pull: $msg"
                }
            }
            val snap = SyncManager.snapshot(app)
            val h = dataHash(snap)
            if (h != sp.getString("cloud_last_hash", "") || remote == null) {
                if (!rpcPush(app, snap)) return@withLock fail(app, lastFail)
                sp.edit().putString("cloud_last_hash", h).putLong("cloud_remote_at", System.currentTimeMillis()).apply()
                notes += "push hoyeche"
            }
            sp.edit().putLong("cloud_last_sync", System.currentTimeMillis()).putString("cloud_last_error", "").apply()
            if (notes.isEmpty()) "Cloud sync: notun kichu nei." else "Cloud sync: " + notes.joinToString("; ")
        } catch (e: Exception) { fail(app, "Sync-e somossa: ${e.message}") }
    }

    private fun fail(c: Context, why: String): String {
        p(c).edit().putString("cloud_last_error", why).apply(); return why
    }

    /** App is open: sync now, then every [intervalMin] minutes. */
    fun start(c: Context) {
        val app = c.applicationContext
        if (!isEnabled(app) || job?.isActive == true) return
        job = CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            while (isActive) {
                if (isEnabled(app)) syncNow(app)
                delay(intervalMin(app) * 60_000L)
            }
        }
    }

    fun stop() { job?.cancel(); job = null }

    /** App went to the background: stop the timer and send what changed (fire and forget). */
    fun onBackground(c: Context) {
        val app = c.applicationContext
        stop()
        if (isEnabled(app)) CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { syncNow(app) }
    }
}
