package com.myra.assistant.system

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.service.SmartAccessibilityEngine
import com.myra.assistant.utils.ContactResolver
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.delay

/**
 * Lets Moon work ON the display with her voice, like a person using the phone:
 *  - [smsOnScreen]: opens the messages app for that contact, types the message into the box (you can watch it being
 *    written) and presses Send.
 *  - [typeOnScreen]: types into the text box that is open on the screen right now, in any app.
 *  - [tapOnScreen]: presses a button by its label (Send, Search ...).
 *
 * Needs the Accessibility service. If it is off, an SMS is still sent directly (the old way) and she tells you why.
 * The text she types always comes from what YOU said, never from something she read on the screen.
 */
object ScreenTyper {
    private const val TAG = "SCREEN_TYPER"

    private val SEND_WORDS = listOf("send", "পাঠান", "পাঠাও", "পাঠিয়ে", "भेजें", "भेजो", "envoyer", "enviar")

    private fun isReady() = SmartAccessibilityEngine.service != null

    private fun root(): AccessibilityNodeInfo? =
        SmartAccessibilityEngine.service?.rootInActiveWindow ?: AccessibilityHelperService.getFreshRoot()

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 40 || out.size > 700) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out, depth + 1)
    }

    private fun all(root: AccessibilityNodeInfo?): List<AccessibilityNodeInfo> {
        val l = ArrayList<AccessibilityNodeInfo>()
        walk(root, l)
        return l
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()

    /** The text box to write in. Message boxes sit at the bottom of the screen, so for SMS that one wins. */
    private fun pickEditable(root: AccessibilityNodeInfo?, ownPackage: String, preferFocused: Boolean): AccessibilityNodeInfo? {
        val edits = all(root).filter { it.isEditable && it.isVisibleToUser && it.packageName?.toString() != ownPackage }
        if (edits.isEmpty()) return null
        if (preferFocused) edits.firstOrNull { it.isFocused }?.let { return it }
        return edits.maxByOrNull { n -> Rect().also { n.getBoundsInScreen(it) }.bottom }
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var c = n
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable && c.isEnabled) return c
            c = c.parent
            depth++
        }
        return null
    }

    private fun findSendButton(root: AccessibilityNodeInfo?, ownPackage: String): AccessibilityNodeInfo? {
        val nodes = all(root).filter { it.packageName?.toString() != ownPackage }
        // 1) by view id: works whatever language the phone uses
        for (n in nodes) {
            val id = (n.viewIdResourceName ?: "").lowercase()
            if (id.contains("send") && !id.contains("sender") && !id.contains("send_as") && !id.contains("sent")) {
                clickableAncestor(n)?.let { return it }
            }
        }
        // 2) by a short label such as "Send" or "পাঠান"
        for (n in nodes) {
            val cd = n.contentDescription?.toString()?.lowercase().orEmpty()
            val tx = n.text?.toString()?.lowercase().orEmpty()
            val hit = (cd.isNotEmpty() && cd.length <= 30 && SEND_WORDS.any { cd.contains(it) }) ||
                (tx.isNotEmpty() && tx.length <= 12 && SEND_WORDS.any { tx.contains(it) })
            if (hit) clickableAncestor(n)?.let { return it }
        }
        return null
    }

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Writes [text] a little at a time, so it looks like typing. Long texts use bigger steps (never more than ~3 s). */
    private suspend fun typeVisibly(find: () -> AccessibilityNodeInfo?, text: String): Boolean {
        var node = find() ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        delay(150)
        val step = maxOf(1, text.length / 60)
        var i = 0
        while (i < text.length) {
            i = minOf(text.length, i + step)
            node = find() ?: node
            if (!setText(node, text.substring(0, i))) return false
            delay(45)
        }
        delay(150)
        node = find() ?: node
        node.refresh()
        val shown = norm(node.text?.toString().orEmpty())
        val want = norm(text)
        return shown == want || (want.isNotEmpty() && shown.contains(want.take(24)))
    }

    // ---------------------------------------------------------------- public commands

    suspend fun smsOnScreen(context: Context, rest: String): String {
        val app = context.applicationContext
        val (target, body) = SmsSender.parse(app, rest)
        if (target.isBlank()) return "Kake SMS korbo seta bujhte parini. User ke jigges koro: kake pathabo?"
        if (body.isBlank()) {
            return "Message ta ekhono bola hoyni. User ke ekta choto proshno koro: 'ki likhbo?' tarpor abar SMS command dao."
        }
        val contact = ContactResolver.resolve(app, target)
            ?: return "'$target' naam e kono contact paini (contact permission ba naam check koro). User ke naam ba number jigges koro."

        if (!isReady()) {
            // no accessibility: cannot type on the display, so send it directly like before
            val r = SmsSender.send(app, contact.number, body)
            return (if (r.ok) "Accessibility chalu nei tai screen e likhte parini, shorashori pathiye diyechi. " else "Accessibility chalu nei, ar ") + r.message
        }

        val own = app.packageName
        try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.number}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            (SmartAccessibilityEngine.service ?: app).startActivity(intent)
        } catch (e: Exception) {
            Logger.e(TAG, "cannot open messages: ${e.message}")
            return "Message app khola gelo na. User ke bolo."
        }

        // wait for the compose screen to appear
        delay(700)
        var waited = 0
        var box: AccessibilityNodeInfo? = null
        while (waited < 7000) {
            val r = root()
            if (r != null && r.packageName?.toString() != own) {
                box = pickEditable(r, own, false)
                if (box != null) break
            }
            delay(250)
            waited += 250
        }
        if (box == null) return "Message app khule gechhe kintu likhar ghor (text box) pai ni. User ke bolo."

        val typed = typeVisibly({ pickEditable(root(), own, false) }, body)
        if (!typed) return "Message ta box e likhte parini. User ke bolo."

        // the Send button shows up after there is text
        delay(400)
        var send: AccessibilityNodeInfo? = null
        var w2 = 0
        while (w2 < 2500) {
            send = findSendButton(root(), own)
            if (send != null) break
            delay(250)
            w2 += 250
        }
        if (send == null) {
            return "${contact.name} er jonno message likhe diyechi, kintu Send button khuje pai ni. User ke ekbar Send e chapte bolo."
        }
        val clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        delay(1200)
        // after sending, the box is empty again
        val left = norm(pickEditable(root(), own, false)?.text?.toString().orEmpty())
        val emptied = left.isBlank() || !left.contains(norm(body).take(24))
        return if (clicked && emptied) {
            "Screen e message likhe Send chepe diyechi (${contact.name} ke): \"$body\". Network er upor nirbhor kore, tai 'pathiye dilam' bolte paro."
        } else {
            "Send chapar chesta korechi, kintu message ta ekhono box e ache mone hocche. User ke screen ta ekbar dekhte bolo."
        }
    }

    suspend fun typeOnScreen(context: Context, text: String): String {
        if (text.isBlank()) return "Ki likhbo seta bolo."
        if (!isReady()) return "Accessibility chalu nei, tai screen e likhte parbo na. Settings theke Accessibility on korte hobe."
        val own = context.applicationContext.packageName
        if (pickEditable(root(), own, true) == null) return "Screen e kono text box pai ni. Age text box e ekbar chap dao ba oi app khulo."
        return if (typeVisibly({ pickEditable(root(), own, true) }, text)) "Screen e likhe diyechi." else "Likhte giye problem holo."
    }

    suspend fun tapOnScreen(context: Context, label: String): String {
        val l = label.trim()
        if (l.isEmpty()) return "Kon button chapbo seta bolo."
        if (!isReady()) return "Accessibility chalu nei, tai screen e chapte parbo na."
        val own = context.applicationContext.packageName
        val r = root() ?: return "Screen porte parlam na."
        val low = l.lowercase()
        val raw = all(r).firstOrNull { n ->
            n.isVisibleToUser && n.packageName?.toString() != own &&
                ((n.text?.toString() ?: "").contains(l, true) || (n.contentDescription?.toString() ?: "").contains(l, true))
        }
        val node = (if (low in SEND_WORDS) findSendButton(r, own) else null) ?: raw?.let { clickableAncestor(it) }
        if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Chepe diyechi."
        // no clickable parent, or the click was refused: touch the spot with a real finger tap instead
        val target = node ?: raw
        if (target != null) {
            val b = Rect(); target.getBoundsInScreen(b)
            if (b.width() > 0 && b.height() > 0 &&
                ScreenControl.tapPx(b.centerX().toFloat(), b.centerY().toFloat())) return "Chepe diyechi."
        }
        return "'$l' button ta screen e pai ni. READ_SCREEN diye number dekhe TAP_NUMBER dite paro."
    }
}
