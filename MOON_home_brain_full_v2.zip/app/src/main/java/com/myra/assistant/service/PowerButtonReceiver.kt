package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import com.myra.assistant.ui.maya.MayaActivity

/**
 * Double-press power button (screen off -> on -> off -> on within ~700ms) opens Moon.
 *
 * This receiver used to be registered only in the manifest with SCREEN_OFF / SCREEN_ON in its
 * intent-filter. Since Android 8 (API 26) those two broadcasts are "implicit" and the system never
 * delivers them to a manifest-declared receiver at all -- so this never fired on any real phone.
 * It now also registers itself at runtime (dynamic receiver), which is the only way SCREEN_ON / OFF
 * actually reach an app. [register] is called once from PhoneEventMonitor.start(), which already
 * runs for as long as Moon is alive in the background, so the double-press keeps working even with
 * the mic off.
 */
class PowerButtonReceiver : BroadcastReceiver() {

    companion object {
        private var pressCount = 0
        private var lastPressTime = 0L
        private const val DOUBLE_PRESS_WINDOW = 700L
        private const val TAG = "MYRA_POWER"

        @Volatile private var registered = false
        private val instance = PowerButtonReceiver()

        /** Registers the dynamic (runtime) receiver once. Safe to call many times. */
        fun register(context: Context) {
            if (registered) return
            registered = true
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            try { context.applicationContext.registerReceiver(instance, filter) } catch (e: Exception) {
                Log.e(TAG, "register failed: ${e.message}")
                registered = false
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF,
            Intent.ACTION_SCREEN_ON -> detectDoublePress(context)
        }
    }

    private fun detectDoublePress(context: Context) {
        val now = System.currentTimeMillis()

        if (now - lastPressTime <= DOUBLE_PRESS_WINDOW) {
            pressCount++

            if (pressCount >= 2) {
                pressCount = 0
                launchMyra(context)
            }

        } else {
            pressCount = 1
        }

        lastPressTime = now
    }

    private fun launchMyra(context: Context) {
        Log.d(TAG, "Double power press detected")

        val intent = Intent(context, MayaActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start activity: ${e.message}")
        }
    }
}
