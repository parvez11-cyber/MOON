package com.myra.assistant.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.myra.assistant.ai.TaskStore
import com.myra.assistant.system.PrivacyMode
import com.myra.assistant.ui.maya.MayaActivity
import com.myra.assistant.utils.Constants
import java.util.Calendar

/**
 * Morning briefing, all on the phone (no internet, nothing sent anywhere): greeting, how many tasks are waiting, the top 3,
 * what is overdue, and the battery. Shown as a notification at the chosen time every day (default OFF, 7:00).
 * Ask for it any time: "morning briefing" / "briefing". Change it: "TASK briefing on|off|<hour 0-23>".
 */
object MorningBriefing {
    private const val CHANNEL = "myra_morning_briefing"
    private const val CODE = 7001
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("briefing_enabled", false)
    fun hour(c: Context) = p(c).getInt("briefing_hour", 7).coerceIn(0, 23)
    fun setEnabled(c: Context, on: Boolean) { p(c).edit().putBoolean("briefing_enabled", on).apply(); schedule(c) }
    fun setHour(c: Context, h: Int) { p(c).edit().putInt("briefing_hour", h.coerceIn(0, 23)).apply(); schedule(c) }

    /** The briefing text (also what Moon says when you ask for it). */
    fun text(c: Context): String {
        val app = c.applicationContext
        val now = System.currentTimeMillis()
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when { h < 5 -> "Ki, ekhono jege?"; h < 12 -> "Suprobhat!"; h < 17 -> "Shubho dupur!"; h < 20 -> "Shubho shondhya!"; else -> "Shubho ratri!" }
        val pending = TaskStore.ranked(app)
        val parts = ArrayList<String>()
        parts += hello
        if (pending.isEmpty()) parts += "Aj kono pending kaj nei."
        else {
            val overdue = pending.count { it.due != null && it.due < now }
            parts += "${pending.size} ta kaj baki" + if (overdue > 0) ", tar moddhe $overdue ta shomoy-er por." else "."
            parts += "Sobcheye age: " + pending.take(3).mapIndexed { i, t -> "${i + 1}) ${t.title}" + (if (t.due != null) " [${TaskStore.dueLabel(t)}]" else "") }.joinToString("; ") + "."
        }
        val bm = app.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val lvl = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        if (lvl in 0..100) parts += "Battery $lvl%" + if (lvl <= 20) ", charge dio." else "."
        return parts.joinToString(" ")
    }

    private fun pi(c: Context) = PendingIntent.getBroadcast(c, CODE, Intent(c, MorningBriefingReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** Sets (or cancels) the next alarm. Called on app open, after a reboot, after a change, and after each briefing. */
    fun schedule(c: Context) {
        val app = c.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        if (!enabled(app)) { am.cancel(pi(app)); return }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(app)); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 30_000L) add(Calendar.DAY_OF_YEAR, 1)
        }
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(app))
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(app))
        } catch (_: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(app)) }
    }

    internal fun show(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sokal-er briefing", NotificationManager.IMPORTANCE_DEFAULT))
        val body = if (PrivacyMode.isOn(c)) "Tomar sokal-er briefing ready. App-e dekho." else text(c)
        val open = PendingIntent.getActivity(c, CODE, Intent(c, MayaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pub = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Moon").setContentText("Sokal-er briefing").build()
        val n = NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Moon: aj-er briefing").setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setPublicVersion(pub).setAutoCancel(true).setContentIntent(open).build()
        try { NotificationManagerCompat.from(c).notify(CODE, n) } catch (_: SecurityException) {}
    }
}

class MorningBriefingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (!MorningBriefing.enabled(app)) return
        MorningBriefing.show(app)
        MorningBriefing.schedule(app)   // tomorrow
    }
}
