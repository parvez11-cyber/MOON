package com.myra.assistant.ui.maya

import android.content.Context
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.assistant.sync.CloudSync
import com.myra.assistant.sync.SyncManager
import kotlinx.coroutines.launch

/** Sync dashboard. Works fully offline: save a snapshot to Drive / Files, restore it on another phone. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncPanel(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
    fun ago(t: Long) = if (t == 0L) "ekhono na" else DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            ctx.contentResolver.openOutputStream(u, "wt")?.use { it.write(SyncManager.snapshot(ctx).toByteArray()) }
            toast("Snapshot save hoyeche"); tick++
        } catch (e: Exception) { toast("Save hoyni: ${e.message}") }
    }
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() }.orEmpty()
            toast(SyncManager.restore(ctx, text)); tick++
        } catch (e: Exception) { toast("Porte parini: ${e.message}") }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MC.LightBg, contentColor = MC.Navy) {
        Column(Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp)) {
            Text("Sync dashboard", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(16.dp)) {
                Text("Offline-ready", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Sob data ei phone-e ache, internet na thakleo kaj kore.", color = MC.Sub, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                val key = tick
                Text("Shesh snapshot save: ${ago(SyncManager.lastSaved(ctx))}", color = MC.Navy, fontSize = 14.sp)
                Text("Shesh restore: ${ago(SyncManager.lastRestored(ctx))}", color = MC.Navy, fontSize = 14.sp)
                if (key < 0) Text("")
            }
            Text("Ki ki sync hobe", color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
            SyncManager.Cat.values().forEach { cat ->
                var on by remember(tick) { mutableStateOf(SyncManager.enabled(ctx, cat)) }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${cat.title}  (${SyncManager.count(ctx, cat)})", color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(cat.sub, color = MC.Sub, fontSize = 13.sp)
                    }
                    Switch(on, { on = it; SyncManager.setEnabled(ctx, cat, it) })
                }
            }
            CloudCard(ctx, scope, ::toast, ::ago) { tick++ }
            Spacer(Modifier.height(14.dp))
            SyncBtn("Snapshot save koro (Drive / Files)", true) { saver.launch("myra-sync.json") }
            Spacer(Modifier.height(10.dp))
            SyncBtn("Snapshot restore koro (merge)", false) { loader.launch(arrayOf("application/json", "text/plain", "*/*")) }
            Text("Drive / Dropbox-er folder-e save korle onno phone-e oi file ei restore korte parbe. Restore-e kichu muche jay na, shudhu notun ta jog hoy.",
                color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 28.dp))
        }
    }
}

@Composable
private fun SyncBtn(label: String, primary: Boolean, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(18.dp))
        .background(if (primary) Brush.verticalGradient(listOf(MC.AccentLight, MC.BlueDeep)) else Brush.verticalGradient(listOf(MC.CardTop, MC.Card)))
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.White else MC.Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

/** Live cloud (Supabase). Everything is encrypted on the phone with the Sync code before it is sent. */
@Composable
private fun CloudCard(ctx: Context, scope: kotlinx.coroutines.CoroutineScope, toast: (String) -> Unit, ago: (Long) -> String, refresh: () -> Unit) {
    var url by remember { mutableStateOf(CloudSync.url(ctx)) }
    var key by remember { mutableStateOf("") }                 // never shown again once saved
    var code by remember { mutableStateOf(CloudSync.code(ctx)) }
    var on by remember { mutableStateOf(CloudSync.isEnabled(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var stamp by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth().padding(top = 18.dp).clip(RoundedCornerShape(20.dp))
        .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Live cloud sync (Supabase)", color = MC.BlueDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Duto phone-e ek-i Sync code dile data nijei miley jay.", color = MC.Sub, fontSize = 13.sp)
            }
            Switch(on, {
                if (it && !CloudSync.isConfigured(ctx)) { toast("Age URL, key ar Sync code Save koro."); return@Switch }
                on = it; CloudSync.setEnabled(ctx, it); refresh()
            })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(url, { url = it }, label = { Text("Project URL (https://xxxx.supabase.co)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(key, { key = it }, label = { Text(if (CloudSync.hasKey(ctx)) "anon key (save kora ache, bodlate chaile dao)" else "anon public key") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(code, { code = it }, label = { Text("Sync code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniBtn("Generate", Modifier.weight(1f)) { code = CloudSync.generateCode() }
            MiniBtn("Save", Modifier.weight(1f)) {
                val err = CloudSync.saveConfig(ctx, url, key, code)
                if (err != null) toast(err) else { key = ""; code = CloudSync.code(ctx); toast("Save hoyeche."); refresh() }
            }
            MiniBtn(if (busy) "..." else "Test", Modifier.weight(1f)) {
                if (!busy) { busy = true; scope.launch { toast(CloudSync.test(ctx)); busy = false } }
            }
        }
        Spacer(Modifier.height(8.dp))
        MiniBtn(if (busy) "Sync cholche..." else "Ekhon sync koro", Modifier.fillMaxWidth()) {
            if (!busy) { busy = true; scope.launch { toast(CloudSync.syncNow(ctx)); busy = false; stamp++; refresh() } }
        }
        val k = stamp
        Text("Shesh cloud sync: ${ago(CloudSync.lastSync(ctx))}" + if (k < 0) "" else "", color = MC.Navy, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        CloudSync.lastError(ctx).takeIf { it.isNotBlank() }?.let { Text(it, color = MC.Hint, fontSize = 12.sp) }
        Text("Data phone-e encrypt hoye jay, Supabase shudhu ekta ortho-hin blob dekhe. Sync code ta ekhon-i kothao likhe rakho: hariye gele cloud-er data ar kholar upay nei. Notun jinish jog hoy, delete ek phone theke onno phone-e jay na. Privacy mode on thakle kichu pathay na.",
            color = MC.Hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun MiniBtn(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(44.dp).clip(RoundedCornerShape(14.dp))
        .background(Brush.verticalGradient(listOf(MC.CardTop, MC.Card))).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}
