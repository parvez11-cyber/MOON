package com.myra.assistant.system

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.myra.assistant.utils.Constants

/**
 * Privacy mode, switched by voice ("privacy mode on") or from the Theme panel. While it is on:
 *  - Moon does not speak on her own (check-ins, battery / charger / wifi announcements, notification reading)
 *  - she will not read the screen, read notifications or look at charts (nothing is sent to Gemini)
 *  - nothing new is learned (habits, typed text), and the home screen hides suggestions
 *  - chat text on screen is masked until you tap a message
 * Replies to what you ask her directly still work. Turning it OFF by voice needs a voice match when Voice Lock is on.
 */
object PrivacyMode {
    private const val KEY = "privacy_mode"
    var active by mutableStateOf(false)
        private set
    private var loaded = false

    fun init(c: Context) {
        if (loaded) return
        loaded = true
        active = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY, false)
    }

    /** Safe to call from services (reads the saved value, no UI needed). */
    fun isOn(c: Context): Boolean {
        init(c)
        return active
    }

    fun set(c: Context, on: Boolean) {
        init(c)
        active = on
        c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply()
    }

    private val OFF_W = setOf("off", "band", "bondho", "bondo", "বন্ধ", "অফ", "false", "no", "disable", "exit", "stop")

    /** PRIVACY on|off|status */
    fun apply(c: Context, arg: String): String {
        init(c)
        val w = arg.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }
        return when {
            w.any { it == "status" } -> if (active) "Privacy mode chalu ache." else "Privacy mode bondho."
            w.any { it in OFF_W } -> { set(c, false); "Privacy mode bondho korlam. Ami abar normal." }
            else -> { set(c, true); "Privacy mode chalu. Ami nijer theke kotha bolbo na, screen / notification porbo na, kichu shikhbo na." }
        }
    }
}
