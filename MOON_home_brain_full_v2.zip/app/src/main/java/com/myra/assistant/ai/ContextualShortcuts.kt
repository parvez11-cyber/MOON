package com.myra.assistant.ai

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.BatteryManager
import android.view.accessibility.AccessibilityEvent
import com.myra.assistant.apps.InstalledAppsManager
import com.myra.assistant.utils.Constants
import org.json.JSONObject
import java.util.Calendar

/**
 * Smart contextual shortcuts (স্মার্ট কন্টেক্সচুয়াল শর্টকাট).
 *
 * Looks at the situation right now - which app you were just in, headphones, charger, battery, time of day -
 * and offers the one-tap actions that make sense, on the home screen next to the learned habits of [PredictiveEngine].
 *
 *  - Only harmless commands (app open, torch, volume, brightness, DND, theme, task list, notification reading).
 *    Never SMS / call / typing / taps. A shortcut only runs when the user taps it.
 *  - Signals stay on the phone. Which app was in front is noted only while privacy mode is off, kept in memory, and is
 *    forgotten after [APP_FRESH_MS].
 *  - Taps are counted per shortcut so the ones you really use move to the front.
 * Pref (myra_prefs): smart_shortcuts_enabled (true).
 */
object ContextualShortcuts {
    private const val K_USE = "smart_shortcut_use"       // { "<id>": count }
    private const val APP_FRESH_MS = 10 * 60_000L

    data class Shortcut(val id: String, val title: String, val command: String, val reason: String, val weight: Int)

    @Volatile private var lastPkg: String? = null
    @Volatile private var lastPkgAt = 0L

    fun enabled(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .getBoolean("smart_shortcuts_enabled", true)

    fun setEnabled(c: Context, on: Boolean) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        .edit().putBoolean("smart_shortcuts_enabled", on).apply()

    /** Called from the accessibility service on window changes. MOON's own window is ignored (we want the app BEFORE her). */
    fun noteForeground(c: Context, event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == c.packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("launcher")) return
        if (com.myra.assistant.system.PrivacyMode.isOn(c)) { lastPkg = null; return }
        lastPkg = pkg; lastPkgAt = System.currentTimeMillis()
    }

    private fun recentApp(): String? =
        if (System.currentTimeMillis() - lastPkgAt <= APP_FRESH_MS) lastPkg else null

    // ---- signals

    private fun battery(c: Context): Pair<Int, Boolean> {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        return (if (level < 0 || scale <= 0) 100 else level * 100 / scale) to plugged
    }

    private fun headphones(c: Context): Boolean = try {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            when (it.type) {
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> true
                else -> false
            }
        }
    } catch (_: Exception) { false }

    private fun installed(c: Context, name: String): Boolean = try { InstalledAppsManager.findApp(c, name) != null } catch (_: Exception) { false }

    private fun appKind(pkg: String): String? {
        val p = pkg.lowercase()
        return when {
            "youtube" in p || "netflix" in p || "hotstar" in p || "primevideo" in p || "mxtech" in p || "vlc" in p -> "video"
            "spotify" in p || "music" in p || "gaana" in p || "wynk" in p -> "music"
            "whatsapp" in p || "messenger" in p || "telegram" in p || "mms" in p || "messaging" in p || "viber" in p || "imo" in p -> "chat"
            "camera" in p -> "camera"
            "maps" in p || "uber" in p || "pathao" in p -> "maps"
            "chrome" in p || "browser" in p || "firefox" in p || "facebook" in p || "instagram" in p || "tiktok" in p -> "browse"
            "kindle" in p || "reader" in p || "pdf" in p || "books" in p -> "read"
            else -> null
        }
    }

    // ---- the shortcuts

    /** The shortcuts for this moment, best first. Empty when the feature or privacy mode is off. */
    fun now(c: Context, limit: Int = 4): List<Shortcut> {
        val app = c.applicationContext
        if (!enabled(app) || com.myra.assistant.system.PrivacyMode.isOn(app)) return emptyList()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val (level, charging) = battery(app)
        val night = hour >= 22 || hour < 5
        val out = ArrayList<Shortcut>()

        // 1) what you were just doing
        val pkg = recentApp()
        if (pkg != null) {
            when (appKind(pkg)) {
                "video" -> {
                    out.add(Shortcut("video_vol", "Volume baaro", "VOLUME_UP", "Video dekhcho", 90))
                    if (night) out.add(Shortcut("video_bright", "Brightness 25%", "BRIGHTNESS 25", "Raat, video dekhcho", 80))
                }
                "music" -> out.add(Shortcut("music_vol", "Volume baaro", "VOLUME_UP", "Gaan shunchho", 85))
                "chat" -> out.add(Shortcut("chat_notif", "Notification poro", "READ_NOTIFICATIONS", "Message app theke ashle", 88))
                "camera" -> out.add(Shortcut("cam_torch", "Torch on", "FLASHLIGHT_ON", "Camera theke ashle", 80))
                "maps" -> out.add(Shortcut("maps_vol", "Volume baaro", "VOLUME_UP", "Route-e acho", 70))
                "browse", "read" -> if (night) out.add(Shortcut("read_dark", "Dark theme", "THEME dark", "Raate poro", 75))
                else -> {}
            }
        }
        // 2) headphones: music is the likely next thing
        if (headphones(app)) {
            val music = listOf("spotify", "youtube music", "youtube").firstOrNull { installed(app, it) }
            if (music != null) out.add(Shortcut("hp_music", "Gaan chalao ($music)", "OPEN_APP $music", "Headphone lagano", 78))
        }
        // 3) charger / battery
        if (!charging && level in 1..20) {
            out.add(Shortcut("bat_low", "Brightness komao", "BRIGHTNESS 30", "Battery $level%", 95))
        }
        if (charging && night) {
            out.add(Shortcut("night_dnd", "Do not disturb", "SYSTEM dnd on", "Raat, charge-e", 72))
            if (!com.myra.assistant.ui.maya.MC.IsDark) out.add(Shortcut("night_dark", "Dark theme", "THEME dark", "Raat", 70))
        }
        // 4) time of day
        if (hour in 5..10) out.add(Shortcut("morning_tasks", "Aajker kaj", "TASK top", "Shokal", 60))
        if (hour in 18..21 && !com.myra.assistant.ui.maya.MC.IsDark) out.add(Shortcut("eve_dark", "Dark theme", "THEME dark", "Sondhya", 50))

        // the ones you tap often come first
        val use = readUse(app)
        return out.distinctBy { it.command }
            .sortedByDescending { it.weight + (use.optInt(it.id, 0).coerceAtMost(10) * 4) }
            .take(limit)
    }

    private fun readUse(c: Context): JSONObject = try {
        JSONObject(c.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).getString(K_USE, "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }

    /** Counts a tap, so that shortcut is ranked higher next time. Safe to call with any command. */
    fun recordUse(c: Context, command: String) {
        if (com.myra.assistant.system.PrivacyMode.isOn(c)) return
        try {
            val sc = now(c, 12).firstOrNull { it.command == command } ?: return
            val o = readUse(c)
            o.put(sc.id, o.optInt(sc.id, 0) + 1)
            c.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).edit().putString(K_USE, o.toString()).apply()
        } catch (_: Exception) {}
    }

    fun clearAll(c: Context) {
        c.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE).edit().remove(K_USE).apply()
        lastPkg = null; lastPkgAt = 0L
    }

    /** One line for the Smart panel: why these shortcuts are showing. */
    fun describe(c: Context): String {
        val list = now(c, 6)
        return if (list.isEmpty()) "Ekhon kono shortcut dorkar nei."
        else list.joinToString(" · ") { "${it.title} (${it.reason})" }
    }
}
