package com.myra.assistant.home

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Smart Home Sync: controls the home through a Home Assistant server (REST API), so one integration reaches
 * Zigbee / Matter / Tuya / Hue / Sonoff etc. whatever Home Assistant already talks to.
 *
 * - URL + long-lived token live in EncryptedSharedPreferences (never in myra_prefs, never in a Sync snapshot).
 * - Only plain-HTTP to the local network is allowed (10.x, 192.168.x, 172.16-31.x, 100.64-127.x, *.local, localhost);
 *   anything else must be https.
 * - Safe domains only: light, switch, fan, cover, scene, script, input_boolean. Locks, alarms, garage / gate / door
 *   covers are refused on purpose: nobody should be able to unlock the house by shouting at the phone.
 * - "Sync" = pull the device list from Home Assistant and make a spoken alias for each one.
 *
 * Command: SMARTHOME on|off|toggle <alias> | set <alias> <0-100> | run <alias> | status [alias] | list | sync
 *          | alias <name> = <entity_id> | remove <alias> | test
 */
object SmartHome {
    private const val SECURE_FILE = "myra_home_secure"
    private const val KEY_URL = "ha_url"
    private const val KEY_TOKEN = "ha_token"
    private const val KEY_DEVICES = "smarthome_devices"   // in myra_prefs: {alias: entity_id}, no secrets

    val SAFE_DOMAINS = setOf("light", "switch", "fan", "cover", "scene", "script", "input_boolean")
    private val BLOCKED_COVER_CLASSES = setOf("garage", "gate", "door")
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).writeTimeout(8, TimeUnit.SECONDS).build()
    }

    // ---------- storage ----------
    @Volatile private var securePrefs: SharedPreferences? = null

    private fun secure(c: Context): SharedPreferences? {
        securePrefs?.let { return it }
        return try {
            val key = MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                c.applicationContext, SECURE_FILE, key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            ).also { securePrefs = it }
        } catch (_: Exception) { null }
    }

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    fun url(c: Context): String = secure(c)?.getString(KEY_URL, "").orEmpty()
    fun hasToken(c: Context): Boolean = !secure(c)?.getString(KEY_TOKEN, "").isNullOrBlank()
    fun isConfigured(c: Context): Boolean = url(c).isNotBlank() && hasToken(c)

    /** Returns null when saved, otherwise the reason it was refused. */
    fun saveConfig(c: Context, rawUrl: String, token: String): String? {
        val u = rawUrl.trim().trimEnd('/').let { if (it.contains("://")) it else "http://$it" }
        val parsed = u.toHttpUrlOrNull() ?: return "URL thik na. Jemon: http://192.168.1.20:8123"
        if (!hostAllowed(parsed.scheme, parsed.host)) return "Plain http shudhu ghorer network-e (192.168.x.x, 10.x.x.x, .local). Baire hole https lagbe."
        if (token.isBlank() && !hasToken(c)) return "Long-lived access token dao (Home Assistant -> Profile -> Security)."
        val s = secure(c) ?: return "Phone-er secure storage kaj korche na, token save kora gelo na."
        val e = s.edit().putString(KEY_URL, u)
        if (token.isNotBlank()) e.putString(KEY_TOKEN, token.trim())
        e.apply()
        return null
    }

    fun clearConfig(c: Context) { secure(c)?.edit()?.clear()?.apply() }

    fun hostAllowed(scheme: String, host: String): Boolean {
        if (scheme == "https") return true
        val h = host.lowercase()
        if (h == "localhost" || h.endsWith(".local")) return true
        val m = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$").matchEntire(h) ?: return false
        val a = m.groupValues[1].toInt(); val b = m.groupValues[2].toInt()
        return a == 10 || a == 127 || (a == 192 && b == 168) || (a == 172 && b in 16..31) || (a == 100 && b in 64..127)
    }

    // ---------- aliases ----------
    fun devices(c: Context): Map<String, String> {
        val o = try { JSONObject(prefs(c).getString(KEY_DEVICES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val out = LinkedHashMap<String, String>()
        o.keys().forEach { k -> out[k] = o.optString(k) }
        return out.toSortedMap().toMap(LinkedHashMap())
    }

    private fun saveDevices(c: Context, m: Map<String, String>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, v) }
        prefs(c).edit().putString(KEY_DEVICES, o.toString()).apply()
    }

    fun deviceCount(c: Context) = devices(c).size
    fun removeAlias(c: Context, alias: String): Boolean {
        val m = devices(c).toMutableMap(); val had = m.remove(norm(alias)) != null; saveDevices(c, m); return had
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Exact, then starts-with, then contains. More than one hit at the same level = ambiguous (null + candidates). */
    private fun resolve(c: Context, nameRaw: String): Pair<Pair<String, String>?, List<String>> {
        val name = norm(nameRaw)
        if (name.isEmpty()) return null to emptyList()
        val d = devices(c)
        d[name]?.let { return (name to it) to emptyList() }
        for (test in listOf<(String) -> Boolean>({ it.startsWith(name) }, { it.contains(name) }, { name.contains(it) && it.length >= 3 })) {
            val hits = d.keys.filter(test)
            if (hits.size == 1) return (hits[0] to d.getValue(hits[0])) to emptyList()
            if (hits.size > 1) return null to hits
        }
        return null to emptyList()
    }

    // ---------- http ----------
    private fun req(c: Context, path: String): Request.Builder? {
        val s = secure(c) ?: return null
        val base = s.getString(KEY_URL, "").orEmpty(); val tok = s.getString(KEY_TOKEN, "").orEmpty()
        if (base.isBlank() || tok.isBlank()) return null
        val parsed = base.toHttpUrlOrNull() ?: return null
        if (!hostAllowed(parsed.scheme, parsed.host)) return null
        return Request.Builder().url(base + path).header("Authorization", "Bearer $tok")
    }

    private class Resp(val code: Int, val body: String)

    private suspend fun get(c: Context, path: String): Resp? = withContext(Dispatchers.IO) {
        val r = req(c, path)?.get()?.build() ?: return@withContext null
        try { http.newCall(r).execute().use { Resp(it.code, it.body?.string().orEmpty()) } } catch (_: Exception) { null }
    }

    private suspend fun post(c: Context, path: String, json: JSONObject): Resp? = withContext(Dispatchers.IO) {
        val r = req(c, path)?.post(json.toString().toRequestBody(JSON))?.build() ?: return@withContext null
        try { http.newCall(r).execute().use { Resp(it.code, it.body?.string().orEmpty()) } } catch (_: Exception) { null }
    }

    private fun failText(r: Resp?): String = when {
        r == null -> "Home Assistant-er shathe connect hocche na (URL / wifi / token dekho)."
        r.code == 401 -> "Token thik na (401). Notun long-lived token dao."
        r.code == 404 -> "Eta Home Assistant-e nei (404)."
        else -> "Home Assistant error ${r.code}."
    }

    // ---------- command entry ----------
    suspend fun apply(c: Context, argRaw: String): String {
        val arg = argRaw.trim()
        val head = arg.substringBefore(' ').lowercase()
        val rest = arg.substringAfter(' ', "").trim()
        if (head.isEmpty() || head == "status" && rest.isEmpty() && !isConfigured(c)) return setupHint(c)
        if (head == "list") return list(c)
        if (head == "remove" || head == "delete") return if (removeAlias(c, rest)) "$rest muchhe dilam." else "$rest name-e kono device nei."
        if (!isConfigured(c)) return setupHint(c)
        return when (head) {
            "test" -> test(c)
            "sync" -> sync(c)
            "alias" -> addAlias(c, rest)
            "status" -> status(c, rest)
            "on", "off", "toggle", "run" -> act(c, head, rest)
            "set" -> setLevel(c, rest)
            else -> "SMARTHOME on|off|toggle <naam>, set <naam> <0-100>, status, list, sync bolo."
        }
    }

    private fun setupHint(c: Context) =
        if (isConfigured(c)) "Smart Home ready, ${deviceCount(c)} ta device."
        else "Smart Home ekhono setup hoyni. Drawer -> Smart Home e Home Assistant-er URL ar token dao."

    private fun list(c: Context): String {
        val d = devices(c)
        return if (d.isEmpty()) "Kono device nei. \"smart home sync\" bolo." else "${d.size} ta device: " + d.keys.take(25).joinToString(", ")
    }

    suspend fun test(c: Context): String {
        val r = get(c, "/api/")
        return if (r != null && r.code == 200) "Home Assistant connected." else failText(r)
    }

    /** Pull entities from Home Assistant and create an alias for each safe one. Existing aliases are kept. */
    suspend fun sync(c: Context): String {
        val r = get(c, "/api/states")
        if (r == null || r.code != 200) return failText(r)
        val arr = try { JSONArray(r.body) } catch (_: Exception) { return "Home Assistant-er uttor bujhte pari ni." }
        val have = devices(c).toMutableMap()
        val used = have.values.toMutableSet()
        var added = 0; var skipped = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("entity_id"); val domain = id.substringBefore('.')
            if (domain !in SAFE_DOMAINS) continue
            val attrs = o.optJSONObject("attributes")
            if (domain == "cover" && attrs?.optString("device_class") in BLOCKED_COVER_CLASSES) { skipped++; continue }
            if (id in used) continue
            val friendly = attrs?.optString("friendly_name").orEmpty().ifBlank { id.substringAfter('.').replace('_', ' ') }
            var alias = norm(friendly)
            if (alias.isBlank()) continue
            if (have.containsKey(alias)) alias = "$alias ${domain}"
            if (have.containsKey(alias)) continue
            have[alias] = id; used += id; added++
        }
        saveDevices(c, have)
        return "Sync hoyeche: $added ta notun device (mot ${have.size} ta)." + if (skipped > 0) " $skipped ta garage / gate / door nirapotta-r karone baad dilam." else ""
    }

    private fun addAlias(c: Context, rest: String): String {
        val name = norm(rest.substringBefore('=')); val id = rest.substringAfter('=', "").trim().lowercase()
        if (name.isEmpty() || !Regex("^[a-z_]+\\.[a-z0-9_]+$").matches(id)) return "Format: SMARTHOME alias <naam> = <light.xyz>"
        if (id.substringBefore('.') !in SAFE_DOMAINS) return "Ei dhoroner device (${id.substringBefore('.')}) voice-e chalano nirapod na, tai allow kora nei."
        val m = devices(c).toMutableMap(); m[name] = id; saveDevices(c, m)
        return "$name -> $id save hoyeche."
    }

    private suspend fun status(c: Context, rest: String): String {
        if (rest.isBlank()) return "${deviceCount(c)} ta device ache. Kon ta-r status?"
        val (hit, many) = resolve(c, rest)
        if (hit == null) return notFound(rest, many)
        val r = get(c, "/api/states/${hit.second}")
        if (r == null || r.code != 200) return failText(r)
        val o = JSONObject(r.body); val st = o.optString("state"); val a = o.optJSONObject("attributes")
        val extra = when {
            a?.has("brightness") == true && st == "on" -> ", brightness ${Math.round(a.optInt("brightness") * 100f / 255f)}%"
            a?.has("current_position") == true -> ", position ${a.optInt("current_position")}%"
            a?.has("percentage") == true && st == "on" -> ", speed ${a.optInt("percentage")}%"
            else -> ""
        }
        return "${hit.first}: $st$extra."
    }

    private fun notFound(name: String, many: List<String>) =
        if (many.size > 1) "\"$name\" onek gulo-r shathe mile: ${many.take(5).joinToString(", ")}. Ekta-r pura naam bolo."
        else "\"$name\" naam-er kono device pailam na. \"smart home list\" bolo."

    /** Covers must be re-checked live: a Home Assistant cover can be a garage door even if it was aliased by hand. */
    private suspend fun coverIsBlocked(c: Context, entity: String): Boolean {
        val r = get(c, "/api/states/$entity") ?: return true   // can't verify -> don't move it
        if (r.code != 200) return true
        val cls = JSONObject(r.body).optJSONObject("attributes")?.optString("device_class").orEmpty()
        return cls in BLOCKED_COVER_CLASSES
    }

    private suspend fun act(c: Context, verb: String, nameRaw: String): String {
        val (hit, many) = resolve(c, nameRaw)
        if (hit == null) return notFound(nameRaw, many)
        val (alias, entity) = hit
        val domain = entity.substringBefore('.')
        if (domain !in SAFE_DOMAINS) return "$alias voice-e chalano allow kora nei."
        if (domain == "cover" && coverIsBlocked(c, entity)) return "$alias garage / gate / door jatiyo, tai voice-e chalabo na."
        val (svcDomain, svc) = when {
            verb == "run" || domain == "scene" || domain == "script" -> domain to "turn_on"
            domain == "cover" -> "cover" to when (verb) { "on" -> "open_cover"; "off" -> "close_cover"; else -> "toggle" }
            else -> domain to when (verb) { "on" -> "turn_on"; "off" -> "turn_off"; else -> "toggle" }
        }
        if ((domain == "scene" || domain == "script") && verb == "off") return "$alias ke off kora jay na, shudhu chalano jay."
        val r = post(c, "/api/services/$svcDomain/$svc", JSONObject().put("entity_id", entity))
        if (r == null || r.code !in 200..299) return failText(r)
        return when {
            domain == "scene" || domain == "script" -> "$alias chalu korlam."
            verb == "toggle" -> "$alias toggle korlam."
            domain == "cover" -> if (verb == "on") "$alias khulchi." else "$alias bondho korchi."
            else -> "$alias ${if (verb == "on") "chalu" else "bondho"} korlam."
        }
    }

    private suspend fun setLevel(c: Context, rest: String): String {
        val m = Regex("^(.+?)\\s+(\\d{1,3})\\s*%?$").matchEntire(rest.trim()) ?: return "Format: SMARTHOME set <naam> <0-100>"
        val pct = m.groupValues[2].toInt().coerceIn(0, 100)
        val (hit, many) = resolve(c, m.groupValues[1])
        if (hit == null) return notFound(m.groupValues[1], many)
        val (alias, entity) = hit
        val domain = entity.substringBefore('.')
        if (domain == "cover" && coverIsBlocked(c, entity)) return "$alias garage / gate / door jatiyo, tai voice-e chalabo na."
        val (path, body) = when (domain) {
            "light" -> "/api/services/light/turn_on" to JSONObject().put("entity_id", entity).put("brightness_pct", pct)
            "fan" -> "/api/services/fan/set_percentage" to JSONObject().put("entity_id", entity).put("percentage", pct)
            "cover" -> "/api/services/cover/set_cover_position" to JSONObject().put("entity_id", entity).put("position", pct)
            else -> return "$alias-e percentage set kora jay na."
        }
        val r = post(c, path, body)
        return if (r != null && r.code in 200..299) "$alias $pct% korlam." else failText(r)
    }

    // ---------- spoken shortcut for LocalCommandRouter ----------
    private val ON_W = setOf("on", "chalu", "jalao", "jalo", "jala", "চালু", "জ্বালাও", "জ্বালো", "অন")
    private val OFF_W = setOf("off", "band", "bondho", "bondo", "nibhao", "নিভাও", "বন্ধ", "অফ")
    private val NOISE_W = setOf("turn", "switch", "the", "my", "please", "to")

    /**
     * "bedroom light on", "turn off the fan", "ঘরের লাইট বন্ধ" -> "SMARTHOME on|off <alias>", but ONLY when the rest
     * of the sentence is a device the user has synced. Otherwise null, and the sentence goes on to the other handlers.
     */
    fun matchSpoken(c: Context, t0: String): String? {
        if (!isConfigured(c)) return null
        val words = t0.split(' ').filter { it.isNotEmpty() }
        val on = words.any { it in ON_W }; val off = words.any { it in OFF_W }
        if (on == off) return null
        val name = words.filter { it !in ON_W && it !in OFF_W && it !in NOISE_W }.joinToString(" ")
        if (name.isEmpty()) return null
        val (hit, _) = resolve(c, name)
        return if (hit != null) "SMARTHOME ${if (on) "on" else "off"} ${hit.first}" else null
    }
}
