package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.voice.Say
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Predictive actions. Learns, on the phone only, which harmless actions the user repeats around the same hour
 * (open YouTube at night, torch, volume...) and later offers them at that time. It only ASKS; the user says yes.
 * Needs the same action on at least 3 different days within +-1 hour before it ever suggests it.
 */
object PredictiveEngine {
    private const val PREFS = "myra_prefs"
    private const val K_DATA = "predict_data"          // { "OPEN_APP youtube": { "21": {"20250101":1,...} } }
    private const val K_ASKED = "predict_asked_"       // + yyyyMMdd -> comma separated keys already offered today
    private const val MIN_DAYS = 3

    private val SAFE_HEADS = setOf("OPEN_APP", "YOUTUBE_PLAY", "SPOTIFY_PLAY", "FLASHLIGHT_ON", "FLASHLIGHT_OFF", "VOLUME_UP", "VOLUME_DOWN", "THEME")

    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun record(c: Context, cmd: String) {
        if (com.myra.assistant.system.PrivacyMode.isOn(c)) return
        val clean = cmd.trim()
        val head = clean.substringBefore(' ').uppercase()
        if (head !in SAFE_HEADS) return
        val key = if (head == "OPEN_APP" || head == "THEME") head + " " + clean.substringAfter(' ', "").trim().lowercase() else head
        if (key.isBlank()) return
        try {
            val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val root = JSONObject(p.getString(K_DATA, "{}") ?: "{}")
            val byHour = root.optJSONObject(key) ?: JSONObject().also { root.put(key, it) }
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY).toString()
            val days = byHour.optJSONObject(hour) ?: JSONObject().also { byHour.put(hour, it) }
            days.put(day(), days.optInt(day(), 0) + 1)
            // keep it small: drop days older than 45 entries per hour
            if (days.length() > 45) {
                val names = days.keys().asSequence().sorted().toList()
                names.take(days.length() - 45).forEach { days.remove(it) }
            }
            p.edit().putString(K_DATA, root.toString()).apply()
        } catch (_: Exception) {}
    }

    /** Short human label for a habit key, used in speech and on the home-screen cards. */
    fun titleOf(key: String): String = when {
        key.startsWith("OPEN_APP ") -> key.removePrefix("OPEN_APP ")
        key.startsWith("THEME ") -> key.removePrefix("THEME ") + " theme"
        else -> key.lowercase().replace('_', ' ')
    }

    /** One habit shown as a card on the home screen. [days] = on how many different days it was seen around this hour. */
    data class Habit(val command: String, val title: String, val days: Int)

    /**
     * The habits that fit the current hour (+-1), best first. Unlike [suggestNow] this does NOT mark anything as
     * offered, so the home screen can show it any number of times. It needs the same action on 2+ other days.
     */
    fun peek(c: Context, limit: Int = 3): List<Habit> {
        try {
            val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val root = JSONObject(p.getString(K_DATA, "{}") ?: "{}")
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val out = ArrayList<Habit>()
            for (key in root.keys()) {
                val byHour = root.getJSONObject(key)
                val days = HashSet<String>()
                for (h in listOf((hour + 23) % 24, hour, (hour + 1) % 24)) {
                    val d = byHour.optJSONObject(h.toString()) ?: continue
                    d.keys().forEach { if (it != day()) days.add(it) }
                }
                if (days.size >= 2) out.add(Habit(key, titleOf(key), days.size))
            }
            return out.sortedByDescending { it.days }.take(limit)
        } catch (_: Exception) { return emptyList() }
    }

    // ---- typed text: finish what the user starts typing, from what they typed before (stored on the phone only) ----
    private const val K_TYPED = "predict_typed"          // { "text": count }

    fun recordTyped(c: Context, text: String) {
        if (com.myra.assistant.system.PrivacyMode.isOn(c)) return
        val t = text.trim()
        if (t.length < 4 || t.length > 80 || t.contains('\n')) return
        try {
            val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val o = JSONObject(p.getString(K_TYPED, "{}") ?: "{}")
            o.put(t, o.optInt(t, 0) + 1)
            if (o.length() > 60) {          // drop the least used ones
                val keep = o.keys().asSequence().map { it to o.getInt(it) }.sortedByDescending { it.second }.take(50).toList()
                val n = JSONObject(); keep.forEach { n.put(it.first, it.second) }
                p.edit().putString(K_TYPED, n.toString()).apply()
            } else p.edit().putString(K_TYPED, o.toString()).apply()
        } catch (_: Exception) {}
    }

    /** Earlier messages that start with what is typed now, most used first. */
    fun complete(c: Context, typed: String, limit: Int = 3): List<String> {
        val q = typed.trim()
        if (q.length < 2) return emptyList()
        return try {
            val o = JSONObject(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_TYPED, "{}") ?: "{}")
            o.keys().asSequence().filter { it.startsWith(q, ignoreCase = true) && !it.equals(q, ignoreCase = true) }
                .sortedByDescending { o.getInt(it) }.take(limit).toList()
        } catch (_: Exception) { emptyList() }
    }

    /** Forget everything that was learned (habits, typed history, what was already offered). */
    fun clearAll(c: Context) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val e = p.edit().remove(K_DATA).remove(K_TYPED)
        p.all.keys.filter { it.startsWith(K_ASKED) }.forEach { e.remove(it) }
        e.apply()
    }

    data class Prediction(val command: String, val say: Say, val prompt: String)

    /** The best thing to offer right now, or null. Marks it as offered for today. */
    fun suggestNow(c: Context): Prediction? {
        try {
            val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val root = JSONObject(p.getString(K_DATA, "{}") ?: "{}")
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val askedKey = K_ASKED + day()
            val asked = p.getString(askedKey, "").orEmpty().split('|').toSet()
            var best: String? = null
            var bestDays = 0
            for (key in root.keys()) {
                if (key in asked) continue
                val byHour = root.getJSONObject(key)
                val days = HashSet<String>()
                for (h in listOf((hour + 23) % 24, hour, (hour + 1) % 24)) {
                    val d = byHour.optJSONObject(h.toString()) ?: continue
                    d.keys().forEach { if (it != day()) days.add(it) }      // today's own use does not count
                }
                if (days.size >= MIN_DAYS && days.size > bestDays) { best = key; bestDays = days.size }
            }
            val key = best ?: return null
            p.edit().putString(askedKey, (asked + key).filter { it.isNotBlank() }.joinToString("|")).apply()
            val label = titleOf(key)
            val verb = if (key.startsWith("OPEN_APP ")) "$label khuli" else label
            val say = Say(
                "এই সময়ে তুমি সাধারণত $label চালাও। চালিয়ে দেবো?",
                "Ei shomoy tumi shadharonoto $label chalao. Chaliye debo?",
                "You usually do this around now: $label. Want me to?"
            )
            val prompt = "[CHECK-IN] You noticed a habit: around this hour the user usually does \"$key\". " +
                "Do NOT run it yet. In one short, warm Bangla sentence (tumi) ask if you should do it ($verb). " +
                "If the user says yes, then call phone_action with exactly: $key"
            return Prediction(key, say, prompt)
        } catch (_: Exception) { return null }
    }
}
