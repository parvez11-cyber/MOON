package com.myra.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.SystemClock
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.prefs

/**
 * Voice wake-up: while the mic is OFF, the phone's own speech recogniser waits for Moon's name
 * ("Moon", "মুন", "মায়া", "মাইরা", "hey maya"...). When it hears it, [onWake] is called with what was said, so
 * "Moon torch jalao" can wake her AND run the command in one go.
 *
 * It only runs while the mic switch is off (the service stops it the moment the mic goes on), so it never fights
 * Gemini for the microphone. Extra names can be added in prefs "wake_extra" (comma separated).
 */
object WakeWord {
    private const val TAG = "WAKE"
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var rec: SpeechRecognizer? = null
    private var onWake: ((String) -> Unit)? = null
    @Volatile var active = false
        private set
    private var firedAt = 0L

    private val NAMES = setOf("moon", "mun", "moone", "মুন", "মূন", "মুণ", "मून", "maya", "maia", "myra", "mayra", "maira", "মায়া", "মাইরা", "মায়রা", "माया", "मायरा")
    private val GREETINGS = setOf("hey", "hay", "hi", "ok", "okay", "o", "oi", "ও", "হে", "এই", "ওগো", "হেই", "হাই", "ওকে")

    private fun norm(s: String) =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun names(c: Context): Set<String> {
        val extra = c.prefs().getString("wake_extra", "").orEmpty().split(',').map { norm(it) }.filter { it.isNotEmpty() }
        return NAMES + extra
    }

    private fun hasName(c: Context, text: String): Boolean {
        val n = names(c)
        return norm(text).split(' ').any { it in n }
    }

    /** What was said after the name, without greetings ("hey maya torch jalao" -> "torch jalao"). */
    fun restOf(text: String): String {
        val c = app ?: return ""
        val n = names(c)
        val words = norm(text).split(' ').filter { it.isNotEmpty() }
        val i = words.indexOfFirst { it in n }
        if (i < 0) return norm(text)
        return (words.take(i).filter { it !in GREETINGS } + words.drop(i + 1)).joinToString(" ")
    }

    fun start(context: Context, callback: (String) -> Unit) {
        app = context.applicationContext
        onWake = callback
        if (active) return
        active = true
        main.postDelayed({ listen() }, 600)       // let the mic switch settle first
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        main.post {
            try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
            rec = null
        }
    }

    private fun again(ms: Long) { if (active) main.postDelayed({ listen() }, ms) }

    private fun check(results: Bundle?): Boolean {
        val c = app ?: return false
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        for (t in list) {
            if (t.isNotBlank() && hasName(c, t)) {
                val now = SystemClock.elapsedRealtime()
                if (now - firedAt < 2500) return true
                firedAt = now
                Logger.d(TAG, "wake word heard")
                val cb = onWake
                stop()
                cb?.invoke(t)
                return true
            }
        }
        return false
    }

    private fun listen() {
        val c = app ?: return
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(c)) {
            Logger.e(TAG, "no speech recogniser on this phone")
            active = false
            return
        }
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        // not during a phone call, and not while Moon herself is speaking (she would wake herself up)
        if (am.mode != AudioManager.MODE_NORMAL) { again(3000); return }
        if (LocalSpeaker.busy || SystemClock.elapsedRealtime() - LocalSpeaker.lastEndAt < 1500 || VoiceStateManager.isAiSpeaking()) { again(800); return }
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(c).also { r ->
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onPartialResults(partialResults: Bundle?) { check(partialResults) }
                    override fun onResults(results: Bundle?) { if (!check(results)) again(150) }
                    override fun onError(error: Int) {
                        when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { active = false }
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> again(1500)
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(150)
                            else -> again(1500)
                        }
                    }
                })
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, c.prefs().getString("offline_lang", "bn-BD"))
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, c.packageName)
            }
            rec?.startListening(i)
        } catch (e: Exception) {
            Logger.e(TAG, "listen failed: ${e.message}")
            again(2500)
        }
    }
}
