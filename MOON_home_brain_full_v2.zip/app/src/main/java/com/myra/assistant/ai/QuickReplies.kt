package com.myra.assistant.ai

import android.content.Context
import com.myra.assistant.utils.Constants
import org.json.JSONArray
import org.json.JSONObject

/**
 * User-saved short phrases ("shorotkoth answer") that can be sent with one tap from the chat screen,
 * instead of typing the same thing again and again. Drawer / chat has no size limit beyond what is
 * reasonable to scroll; the newest template is shown first.
 *
 * A template can be made two ways:
 *  - typed by hand ("+ notun" in the chip row)
 *  - "Shortcut banao" long-press on any existing chat bubble (yours or Moon's), which copies that
 *    message's text straight into a new template
 *
 * Saved only on this phone (SharedPreferences), included in a Sync snapshot like tasks / routines.
 */
object QuickReplies {
    private const val K = "quick_replies_json"

    data class Reply(val id: Long, val label: String, val text: String)

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    /** A short chip label from the full text: first few words, trimmed, so chips stay compact. */
    private fun autoLabel(text: String): String {
        val words = text.trim().split(Regex("\\s+"))
        val short = words.take(4).joinToString(" ")
        return if (words.size > 4) "$short…" else short
    }

    @Synchronized
    fun all(c: Context): List<Reply> = try {
        val a = JSONArray(p(c).getString(K, "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Reply(o.getLong("id"), o.optString("label", ""), o.getString("text"))
        }.sortedByDescending { it.id }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    private fun save(c: Context, list: List<Reply>) {
        val a = JSONArray()
        list.forEach { r -> a.put(JSONObject().put("id", r.id).put("label", r.label).put("text", r.text)) }
        p(c).edit().putString(K, a.toString()).apply()
    }

    /** Adds a new template. [label] left blank auto-derives one from the text. Returns false if an identical
     * text is already saved (so long-pressing the same bubble twice does not create duplicates). */
    fun add(c: Context, text: String, label: String = ""): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        if (all(c).any { it.text == t }) return false
        val l = label.trim().ifEmpty { autoLabel(t) }.take(40)
        save(c, all(c) + Reply(System.currentTimeMillis(), l, t.take(1000)))
        return true
    }

    fun delete(c: Context, id: Long) = save(c, all(c).filter { it.id != id })

    fun rename(c: Context, id: Long, newLabel: String) =
        save(c, all(c).map { if (it.id == id) it.copy(label = newLabel.trim().take(40).ifEmpty { it.label }) else it })

    fun clearAll(c: Context) = save(c, emptyList())
}
