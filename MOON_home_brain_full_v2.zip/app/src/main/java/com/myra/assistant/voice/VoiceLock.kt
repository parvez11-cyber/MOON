package com.myra.assistant.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.myra.assistant.utils.Logger
import kotlin.math.*

/**
 * Voice Lock: Moon only answers the owner's voice.
 *
 * On-device voiceprint (no internet, no extra library): MFCC features -> mean + spread per ~1.2 s window,
 * compared with the profile saved during enrolment. Everything stays in SharedPreferences on the phone.
 *
 * Honest limits: this is a lightweight speaker check, good at "owner vs someone else in the room", not a
 * bank-grade biometric. A recording of the owner can pass, and a very noisy room lowers accuracy.
 */
object VoiceLock {
    private const val TAG = "VOICELOCK"
    private const val PREFS = "myra_prefs"
    private const val K_ENABLED = "voice_lock_enabled"
    private const val K_PROFILE = "voice_lock_profile"
    private const val K_SENS = "voice_lock_sens"        // 0 loose, 1 normal, 2 strict

    private const val SR = 16000
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    private const val NC = 19                            // c1..c19
    private const val MIN_VOICED_FRAMES = 40             // ~0.4 s of real speech
    const val WINDOW_BYTES = SR * 2 * 12 / 10            // 1.2 s

    private val melBank: Array<FloatArray> by lazy { buildMel() }
    private val hamming = FloatArray(FRAME) { (0.54 - 0.46 * cos(2 * PI * it / (FRAME - 1))).toFloat() }
    private val dct = Array(NC) { k -> FloatArray(NMEL) { m -> cos(PI * (k + 1) * (m + 0.5) / NMEL).toFloat() } }

    @Volatile private var mu: FloatArray? = null
    @Volatile private var sd: FloatArray? = null
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnrolled(c: Context): Boolean { load(c); return mu != null }
    fun isEnabled(c: Context) = prefs(c).getBoolean(K_ENABLED, false)
    /** True only when the lock is switched on AND a voice has been saved. */
    fun active(c: Context) = isEnabled(c) && isEnrolled(c)
    fun setEnabled(c: Context, on: Boolean) = prefs(c).edit().putBoolean(K_ENABLED, on).apply()
    fun sensitivity(c: Context) = prefs(c).getInt(K_SENS, 1)
    fun setSensitivity(c: Context, s: Int) = prefs(c).edit().putInt(K_SENS, s.coerceIn(0, 2)).apply()

    fun clear(c: Context) {
        prefs(c).edit().remove(K_PROFILE).putBoolean(K_ENABLED, false).apply()
        mu = null; sd = null; loaded = true
    }

    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        val s = prefs(c).getString(K_PROFILE, null) ?: return
        try {
            val parts = s.split("|")
            mu = parts[0].split(",").map { it.toFloat() }.toFloatArray()
            sd = parts[1].split(",").map { it.toFloat() }.toFloatArray()
        } catch (e: Exception) { mu = null; sd = null }
    }

    // ---------------------------------------------------------------- verify

    /** Called with the first ~1 s of an utterance. True = owner. */
    fun verify(c: Context, chunks: List<ByteArray>): Boolean {
        load(c)
        val m = mu ?: return true          // nothing saved yet: never lock the owner out
        val s = sd ?: return true
        val pcm = concat(chunks)
        val v = embed(pcm) ?: run { Logger.d(TAG, "too little speech -> reject"); return false }
        val d = distance(v, m, s)
        val limit = verifyLimit(c)
        Logger.d(TAG, "distance=$d limit=$limit")
        return d <= limit
    }

    /** The largest distance that still counts as the owner (depends on the Soja / Normal / Kora setting). */
    fun verifyLimit(c: Context): Float = when (sensitivity(c)) { 0 -> 2.6f; 2 -> 1.7f; else -> 2.15f }

    /** Distance of this speech from the owner's voiceprint (smaller = more alike). Null when no voice is saved. */
    fun score(c: Context, chunks: List<ByteArray>): Float? {
        load(c)
        val m = mu ?: return null
        val s = sd ?: return null
        val v = embed(concat(chunks)) ?: return Float.MAX_VALUE
        return distance(v, m, s)
    }

    /** Sensitive actions (message, call, settings, taps) need a closer match than normal talking. */
    fun sensitiveLimit(c: Context): Float = when (sensitivity(c)) { 0 -> 2.0f; 2 -> 1.55f; else -> 1.8f }

    private fun distance(v: FloatArray, m: FloatArray, s: FloatArray): Float {
        var acc = 0.0
        for (i in v.indices) { val z = (v[i] - m[i]) / s[i]; acc += z * z }
        return sqrt(acc / v.size).toFloat()
    }

    // ---------------------------------------------------------------- enrol

    /**
     * Records [seconds] of the owner talking and saves the profile. Run it off the main thread.
     * Returns null on success or a short message (Banglish) to show the user.
     */
    @SuppressLint("MissingPermission")
    fun enroll(c: Context, seconds: Int, onLevel: (Float) -> Unit = {}): String? {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 4096) * 2)
        } catch (e: Exception) { return "Mic khola gelo na" }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return "Mic khola gelo na (onno app mic dhore ace?)" }

        val total = SR * seconds
        val all = ShortArray(total)
        var got = 0
        rec.startRecording()
        val buf = ShortArray(1024)
        while (got < total) {
            val n = rec.read(buf, 0, min(buf.size, total - got))
            if (n <= 0) break
            System.arraycopy(buf, 0, all, got, n)
            got += n
            var e = 0.0; for (i in 0 until n) e += (buf[i] / 32768.0).pow(2)
            onLevel(sqrt(e / n).toFloat())
        }
        rec.stop(); rec.release()

        // overlapping 1.2 s windows, each becomes one sample of "how the owner sounds"
        val win = SR * 12 / 10
        val vecs = ArrayList<FloatArray>()
        var p = 0
        while (p + win <= got) {
            embed(all.copyOfRange(p, p + win))?.let { vecs.add(it) }
            p += win / 2
        }
        if (vecs.size < 6) return "Kom kotha bolecho, ektu jore, bhalo kore, aro kotha bolo"

        val dim = vecs[0].size
        val m = FloatArray(dim) { i -> vecs.map { it[i] }.average().toFloat() }
        val rawSd = FloatArray(dim) { i -> sqrt(vecs.map { (it[i] - m[i]).pow(2) }.average()).toFloat() }
        val floor = rawSd.average().toFloat() * 0.5f + 1e-3f      // stops one unusually steady dimension from dominating
        val s = FloatArray(dim) { max(rawSd[it], floor) * 1.0f }
        prefs(c).edit().putString(K_PROFILE, m.joinToString(",") + "|" + s.joinToString(",")).apply()
        mu = m; sd = s; loaded = true
        Logger.d(TAG, "enrolled from ${vecs.size} windows")
        return null
    }

    // ---------------------------------------------------------------- features

    private fun concat(chunks: List<ByteArray>): ShortArray {
        val total = chunks.sumOf { it.size } / 2
        val out = ShortArray(total)
        var o = 0
        for (ch in chunks) {
            var i = 0
            while (i + 1 < ch.size) {
                out[o++] = ((ch[i].toInt() and 0xFF) or (ch[i + 1].toInt() shl 8)).toShort()
                i += 2
            }
        }
        return out
    }

    /** mean + std of c1..c19 over voiced frames, or null when there is not enough speech. */
    private fun embed(pcm: ShortArray): FloatArray? {
        if (pcm.size < FRAME * 3) return null
        val nFrames = (pcm.size - FRAME) / HOP + 1
        val x = FloatArray(pcm.size)
        x[0] = pcm[0] / 32768f
        for (i in 1 until pcm.size) x[i] = pcm[i] / 32768f - 0.97f * pcm[i - 1] / 32768f

        val energies = FloatArray(nFrames)
        val feats = ArrayList<FloatArray>(nFrames)
        val re = FloatArray(NFFT); val im = FloatArray(NFFT)
        for (f in 0 until nFrames) {
            val st = f * HOP
            var e = 0f
            java.util.Arrays.fill(re, 0f); java.util.Arrays.fill(im, 0f)
            for (i in 0 until FRAME) { val v = x[st + i] * hamming[i]; re[i] = v; e += v * v }
            energies[f] = e
            fft(re, im)
            val mel = FloatArray(NMEL)
            for (m in 0 until NMEL) {
                var a = 0f
                val w = melBank[m]
                for (k in 0..NFFT / 2) if (w[k] != 0f) a += w[k] * (re[k] * re[k] + im[k] * im[k])
                mel[m] = ln(a + 1e-9f)
            }
            val c = FloatArray(NC)
            for (k in 0 until NC) { var a = 0f; for (m in 0 until NMEL) a += dct[k][m] * mel[m]; c[k] = a / NMEL * 4f }
            feats.add(c)
        }
        val thr = energies.average().toFloat() * 0.4f
        val voiced = feats.filterIndexed { i, _ -> energies[i] > thr }
        if (voiced.size < MIN_VOICED_FRAMES) return null

        val out = FloatArray(NC * 2)
        for (k in 0 until NC) {
            val mean = voiced.map { it[k] }.average().toFloat()
            out[k] = mean
            out[NC + k] = sqrt(voiced.map { (it[k] - mean).pow(2) }.average()).toFloat()
        }
        return out
    }

    private fun hz2mel(h: Double) = 2595.0 * log10(1 + h / 700.0)
    private fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1)

    private fun buildMel(): Array<FloatArray> {
        val lo = hz2mel(100.0); val hi = hz2mel(4000.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { floor((NFFT + 1) * pts[it] / SR).toInt().coerceIn(0, NFFT / 2) }
        return Array(NMEL) { m ->
            val w = FloatArray(NFFT / 2 + 1)
            for (k in bins[m] until bins[m + 1]) w[k] = (k - bins[m]).toFloat() / max(1, bins[m + 1] - bins[m])
            for (k in bins[m + 1] until bins[m + 2]) w[k] = (bins[m + 2] - k).toFloat() / max(1, bins[m + 2] - bins[m + 1])
            w
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f; var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
