-- MYRA live cloud sync: run this ONCE in Supabase -> SQL Editor -> New query -> Run.
-- The table has row-level security on and NO policy, so the public (anon) key cannot read or list it directly.
-- The phone only calls the two functions below, and only knows its own row id (a SHA-256 of your Sync code).
-- The stored data is already encrypted on the phone before it is sent.

create table if not exists public.myra_sync (
  id         text primary key,
  data       text not null,
  updated_at timestamptz not null default now()
);
alter table public.myra_sync enable row level security;

create or replace function public.myra_push(p_id text, p_data text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if length(p_id) <> 64 or p_id !~ '^[0-9a-f]+$' then raise exception 'bad id'; end if;
  if length(p_data) > 2000000 then raise exception 'too large'; end if;
  insert into public.myra_sync(id, data, updated_at) values (p_id, p_data, now())
  on conflict (id) do update set data = excluded.data, updated_at = now();
end $$;

create or replace function public.myra_pull(p_id text)
returns text language sql security definer stable set search_path = public as $$
  select data from public.myra_sync where id = p_id and length(p_id) = 64;
$$;

revoke all on function public.myra_push(text, text) from public;
revoke all on function public.myra_pull(text) from public;
grant execute on function public.myra_push(text, text) to anon, authenticated;
grant execute on function public.myra_pull(text) to anon, authenticated;
