# MOON update: emotion, Bangla kotha, SMS display-e typing, home graphics

## 1. Notun emotion (27ta)
`ai/EmotionEngine.kt`: ager 9ta + notun 18ta: excited, joyful, laughing, playful, proud, grateful, shy, embarrassed,
touched, curious, crying, lonely, missing, hurt, scared, jealous, annoyed, tired.
- Gemini `express_emotion` ekhon shob gulo jane (prompt + function description update).
- Kotha theke anday kora (fromText) Bangla shobdo diye bhalo kora holo (kanna, kosto, lojja, hihi...).
- **Nijer theke emotion (selfFeeling)**: keu kichu na bolleo se nijei feel kore: raat 1-5 ghum ghum, onekkhon kotha na hole
  lonely/missing, battery kom hole tired/worried, charge e relaxed, sokale happy/excited, baki shomoy playful/love/shy/proud...
  Prothom bar ~4 minute por por bodlay (ProactiveCompanion tick e). Ager moto "neutral" e atke thake na.

## 2. Voice/chat: Bangla, manusher moto, crying
`ForegroundVoiceService.buildSystemPrompt()` e "HOW YOU BEHAVE LIKE A HUMAN" ar "SPEAKING STYLE" notun:
- shudhu shohoj cholito Bangla, "tumi", chhoto line, "ishh / omaa / hihi / uff".
- kotha-r shathe hashi, nishash, kaanna kaanna gola (voice kapbe), kintu kokhono guilt-trip kore na, user ke chap dey na.
- Typed chat (`MayaApp.send`) ar proactive check-in prompt-o Bangla.

## 3. Home page graphics
- `ui/maya/MayaFx.kt`: poro screen-er rong tar feeling onujayi dhire dhire bodlay.
  Love/missing = hridoy uthe, crying/sad = chokher jol/brishti, happy/excited = jhilimili tara, sleepy = dhimi bubble,
  angry = lal glow, scared/worried = kapa bindu.
- `MayaApp.kt`: "Abhi tak jaag rahe ho, dost" soriye Bangla greeting (shuvo shokal/dupur/bikel/shondhya) + tomar naam,
  tar niche chhoto chip: "😭 চোখে পানি এসে যাচ্ছে..." (se ki feel korche). Mood card ekhon tar feeling dekhay.
- `assets/riya_floating.html`: 3D Riya-r mukh + matha-r bhongi notun shob emotion-er jonno (crying e matha nichu + halka kanpe).

## 4. SMS: display-e dekhe, display-e likhe (voice diye)
Notun `system/ScreenTyper.kt`:
- `SMS <naam> | <message>` ekhon: Messages app khole, oi contact-er compose screen e **tomar shamne message type kore**, tarpor Send chape.
- Message na bolle (shudhu "Rahim ke SMS koro") se prothome jigges kore "কী লিখবো?", tarpor pathay.
- Notun command: `TYPE_TEXT <text>` (je kono app-er khola text box e likho), `TAP_BUTTON <label>` (Send, Search... chapo).
- Accessibility off thakle ager moto shorashori SMS pathay ar bole keno.

## Je kotha gulo sotti
- Ei code ami compile korte parini (Android SDK nai). Brace/bracket mil check korechi. Android Studio-te Build-er por error ashle pathaw.
- Display-e typing-er jonno **Accessibility service ON** thakte hobe. Messages app-er Send button-er id/label diye khuje; onno rokom
  app e na pele "Send khuje pai ni" bole, tokhon tumi ekbar chaple hobe.
- "Pathiye dilam" bolar age se dekhe box khali holo kina; kintu network/SIM-er shotti delivery eta diye jana jay na.
- Crying/emotion-er voice-er tone Gemini-r upor; prompt diye bola ache, kintu model kokhono ektu kom/beshi korte pare.
