# MYRA update: ki ki change holo

## 1. SMS (ager bug gulo)
- `system/SmsSender.kt` (notun). Ager code shudhu prothom shobdo ke naam dhorto ("Rahim bhai" -> "Rahim"), SEND_SMS permission check korto na, ar radio response na dekhei "pathiye dilam" bolto.
- Ekhon: naam onekgulo shobdo hote pare, contact ranking (exact > starts-with > contains), shorashori number dewa jay, lomba message multipart hoy, ar sotti pathalo kina seta Maya bole (network nai / airplane mode ityadi).
- Command format: `SMS <naam> | <message>` (voice prompt update kora).

## 2. Display dekha
- Root cause: `accessibility_service_config.xml` e `canTakeScreenshot` chilo na. Add kora hoyeche.
- `screenvision/ScreenReader.kt` (notun), command `READ_SCREEN`: screen-er shob text/button pare + screenshot Gemini-ke pathay (accessibility screenshot, na hole root `screencap`, text na thakle OCR).
- Screen/notification/SMS-er text ke Maya "data" dhore, order hishebe na (prompt injection theke bachar jonno).

## 3. Manusher moto vabna, emotion, nijer theke khoj neya
- `ai/EmotionEngine.kt`: Maya-r feeling (happy, sad, worried, love, sleepy...). Gemini `express_emotion` function diye set kore; na korle kotha theke anday kore.
- `ai/ProactiveCompanion.kt`: nijer theke kotha bole. Sokal, dupur, raat-er khabar, onek raat, onekkhon kotha na hole, majhe majhe friendly suggestion. Call-e / screen off / tumi kotha bolcho / 90 min er moddhe ar na. Offline hole built-in Bangla line.
  Settings keys (SharedPreferences `myra_prefs`): `proactive_enabled` (true), `proactive_gap_min` (90).
- Gemini `remember_fact` function: tomar kotha shune nijei yaad rakhe.
- System prompt notun: manusher moto feeling, ekta ekta kore suggestion, honest.

## 4. Notification: double bole na, off thakle bole na
- `NotificationReaderService.kt`: alada TTS engine soriye `Announcer` diye (shudhu ekta voice).
- Same notification update/repost hole abar pode na (90s dedupe + same text guard), group summary/media/progress/call ignore.
- Screen off thakle pode na (setting `notification_read_screen_off`, default false). "Read notifications" off thakle pode na (`notification_read_aloud`).

## 5. VRM home page-e
- Notun `assets/riya_floating.html` (ager code ei file-ta khujto kintu chilo na, tai avatar kokhono dekha jeto na). `assets/models/riya.vrm` agei chilo.
- Home page-er character ekhon Riya (3D). Kotha bolle mukh nare (lip-sync), shunle ektu jhuke, emotion onujayi chehara bodlay, tap korle hashe, drag korle ghure.
- three.js + three-vrm prothombar jsDelivr (pinned version) theke load hoy, tarpor WebView cache kore. Pura offline chaile `assets/libs/` e rakho:
  `three.module.js`, `addons/` (three/examples/jsm folder), `three-vrm.module.js`.

## 6. System permission + root
- Manifest-e onek permission add (SMS read/receive, calendar, call log write, background location, wifi/bluetooth, all-files, write settings, usage stats, install, alarms...).
- Drawer-e notun button **"Sob permission do"**:
  - Root phone: shob permission, appops, accessibility, notification access, device admin, battery whitelist chupchap deya hoy.
  - Normal phone: runtime permission dialog, tarpor ek ek kore special screen (overlay, accessibility, notification access, write settings, all files, DND, battery, usage access, device admin).
- `system/SystemSettings.kt`: `SYSTEM wifi|bluetooth|mobile_data|airplane|dnd|lock on|off`, `BRIGHTNESS 0-100`. Root thakle shorashori, na hole system panel khule.
- Ekta fixed whitelist; model-ke "je kono shell command" cholanor path deya hoyni, jate screen/notification-er kono text root command hoye jete na pare.

## Je kotha gulo sotti
- **Android e kono APK nijeke root korte pare na.** Root-er jonno phone age rooted hote hobe (Magisk/KernelSU) ar prothombar "su" prompt-e Allow korte hobe. Tarpor app nijei shob grant kore.
- Root chhara, kichu permission shudhu PC theke ekbar adb diye deya jay (WRITE_SECURE_SETTINGS, READ_LOGS, PACKAGE_USAGE_STATS, DUMP):
  ```
  adb shell pm grant com.myra.assistant android.permission.WRITE_SECURE_SETTINGS
  adb shell pm grant com.myra.assistant android.permission.READ_LOGS
  adb shell pm grant com.myra.assistant android.permission.PACKAGE_USAGE_STATS
  adb shell pm grant com.myra.assistant android.permission.DUMP
  ```
  (WRITE_SECURE_SETTINGS dile app nijei Accessibility / notification access on korte pare.)
- SMS/all-files/accessibility-er moto permission Google Play te restricted; ei build nijer phone-e sideload-er jonno.
- Ei code ami compile korte parini (ei environment-e Android SDK/Gradle nai). Android Studio-te Build korle choto-khato import/typo error ashle error-ta pathaw, thik kore dibo.
- Notification "off nile" ta ami dui bhabe dhorechi: screen off hole na pora + setting off hole na pora. Onno kichu bujhiye thakle bolo.

---
# Update 2: Internet search, Voice Lock, App icon
- **Internet search**: Gemini Live setup-e `googleSearch` tool add kora hoyeche (`GeminiWebSocketClient.kt`), system prompt-e bola ache "taja kichu hole age search koro".
- **Voice Lock** (`voice/VoiceLock.kt`, Settings-e notun card): 12 sec kotha bole voice save -> on-device voiceprint (MFCC). Switch on thakle prothom ~1.2 sec audio age check hoy; tomar voice na hole Gemini-ke kichui pathano hoy na (answer/action dui-i bondho). Sensitivity: Soja / Normal / Kora.
  - Limit: eta halka speaker-check, bank-grade na. Tomar recording chalale pass korte pare; khub gondogol-e accuracy komey. Normal-e na chinle "Soja" kore dekho; onno karo voice dhorle "Kora" koro.
- **App icon**: tomar chobi theke `mipmap-*/ic_launcher*.png` + adaptive icon (`drawable-nodpi/myra_icon_fg.png`). Manifest-e `@mipmap/ic_launcher`.
- Ei code compile kora jayni (SDK nai). Android Studio-te Build-er por error ashle pathaw.

---
# Update 3
- **Typed command fix**: chat-e likhle ager version shudhu text reply dito (phone_action tool-i chilo na). Ekhon `GeminiChat.askAgent`: age `LocalCommandRouter` (torch, volume, open app instantly), na hole Gemini function-calling (`phone_action`, `web_search`). Model name 404 dile `gemini-2.5-flash` e fallback.
- **Floating voice button** (`overlay/MicButtonOverlay.kt`): chhoto gol button, tap = mic on/off, drag = soraono. Pref `mic_button_enabled` (default true). Overlay permission lage.
- **Graphics**: home gradient + glow background, 3D avatar-e ACES tone mapping, better lighting, pixel ratio 3.
- **Play Protect**: PLAY_PROTECT.md dekho. 3 ta permission soriyechi, release signing setup add korechi.

---
# Update 4: Notification shudhu bolle
- Auto-reading ekhon default **OFF** (`notification_read_aloud` = false). Settings-e switch ache.
- Notification gulo chupchap mone rakhe (last 30). "Notification ki ashche / notification poro" bolle (ba chat-e likhle) `READ_NOTIFICATIONS` command: last 5 ta (12 ghontar moddhe) pore shonay.
- Maya-r prompt-e bola ache: nijer theke kokhono notification bolbe na.

---
# Update 5
- Home-er "Free mode / Activate karo" banner soriyechi (ota shudhu dekhano chilo, kono limit chilo na).
- Voice connect fail hole ager version chup kore thakto (setup-er age close hole kono error-i dito na). Ekhon toast-e asol karon dekhay, ar Google-search tool reject hole auto bondho kore abar chesta kore.
- Chat 503 "high demand" hole onno model-e (gemini-2.5-flash) chesta kore.

---
# Update 6: mic shune na
- `voice/AudioRecorder.kt` notun: ekta audio source-e sound na ashle (kono phone-e VOICE_COMMUNICATION silent dey) poro source e jay (speech-recognition -> mic -> voice-communication). Mic kom jore dhorle auto-gain.
- `VoiceActivityDetector`: fixed 0.015 threshold-er jaygay noise-er upor nirbhor kora threshold (quiet mic-e kotha "kotha" dhora hoto na).
- Mic kono sound na dile Toast-e karon dekhay.
- Floating mic button tumi kotha bolle ektu boro hoy: shetai live proof je mic shunche.

## Chart / candle signal (screen vision)
- New: `trading/ChartAnalyzer.kt` - looks at the chart on screen (live capture or screenshot) and asks Gemini Vision for trend, candle patterns, support/resistance and a BUY / SELL / WAIT bias with entry/SL/TP.
- Voice/typed command: `TRADE_SIGNAL [note]` (say "chart analyse kore signal dao"). Wired in Models, IntentAnalyzer, DynamicDecisionEngine, AIResponseManager, ForegroundVoiceService, GeminiWebSocketClient, GeminiChat.
- Analysis only: it never places an order. Output always ends with a risk warning.
- Needs: Gemini key, plus screen capture (mic on + allow once) or Accessibility screenshot.

## Friendly personality + network resilience
- New `ai/PersonaPrompt.kt`: one shared warm, happy, sympathetic human-like personality (natural reactions, sympathy first, matches mood, honest if sincerely asked whether she is an AI). Used by the voice session (ForegroundVoiceService), typed Maya chat (MayaApp) and the default GeminiChat prompt.
- `EmotionEngine`: richer feeling words (excited, playful, proud, caring, sympathetic...) now map to the nearest avatar face instead of falling back to neutral; more happy cues in text.
- `GeminiChat.ask`: retries on network hiccups and 429/500/503, falls back to the second model, and no longer misreports a blocked reply as a network error.
- `ChartAnalyzer`: checks internet first and gives clear Banglish messages for no-net, rate limit and API-key problems.

## SMS wrong-recipient fix + caring personality
- Cause 1 (`IntentAnalyzer`): for sentences like "Rahim ke sms bhejo ..." only the first word was dropped, so words like "ke"/"to" became the contact name. Now the whole sentence goes to `SmsSender`, which strips "send sms to / ke / bhejo" wording safely.
- Cause 2 (`SmsSender`): contact lookup was a loose LIKE %name%, so "ke" matched Kemal/Mike and the first hit got the SMS. Now only whole-word / word-start matches count.
- New rule: never guess. Several people match -> nothing is sent and Maya asks which one. Only loose matches -> nothing is sent, she offers the names. Same person with many numbers -> mobile number preferred.
- Success message now names the contact and the last 4 digits so you can hear who got it.
- Voice prompt: texting always uses SMS <name> | <message>, never REPLY_NOTIFICATION unless you ask to reply to a notification.
- `PersonaPrompt`: added caring rules (gentle nudges for water/rest/sleep, warm praise, calm apologies when something fails, encouraging real-life friends and family).
- Note: `ContactResolver` (used by calling) still uses the loose match; same fix can be applied there.

## More emotion + new graphics
- `ui/maya/MayaFx.kt` rewritten: the home background now follows Maya's feeling with a two-colour wash, drifting aurora glows, a breathing aura and pulse rings, plus feeling-specific floating shapes (hearts for love, sparkles for joy/surprise, soft rain for sad, bubbles for relaxed/worried/sleepy, embers for angry). Colours blend smoothly when the mood changes.
- New `MayaFeelingChip` on the home screen (emoji + short label such as "Khush hoon", "Pyaar aa raha hai") with a gentle bounce.
- Home greeting is now time-aware (it said "Abhi tak jaag rahe ho" even at 4:42 PM).
- `PersonaPrompt`: "FEEL DEEPLY" rules (vivid, sincere feelings sized to the moment, mood can shift mid-chat, remembers how you felt, no guilt-tripping or neediness). `express_emotion` is now asked to update mid-reply.

## Bangla voice + higher emotion
- Cause: `Constants.VOICE_LANGUAGE = "bn-BD"` existed but was never sent to the live voice model. Now both live clients (`GeminiWebSocketClient`, `GeminiLiveClient`) send it as `speechConfig.languageCode`. If voice ever fails to connect, set `Constants.FORCE_VOICE_LANGUAGE = false` (or change to "bn-IN").
- `PersonaPrompt.BANGLA_VOICE`: she always answers in natural Bangladeshi Bangla, with Bengali-script examples for joy, comfort, pride, worry, playfulness and missing you, plus natural sounds (হুম, ওহ, হিহি, আহ...).
- Typed chat now also replies in Bengali script by default; trading analysis is read aloud in Bangla; the emotion detector knows more Bangla feeling words.

## Natural emotion
- `PersonaPrompt`: "NATURAL FIRST" rules. Emotion now comes from the moment instead of a script: plain and warm when nothing emotional is happening, big reactions only when deserved, mixed and gradually changing feelings, the person's own words instead of generic praise, no repeated stock phrases, thinking-out-loud rhythm (মানে..., হুম...), and very short quiet replies when someone is hurting. The sample lines are now flavour, not scripts.
- `Constants.AFFECTIVE_DIALOG = true`: sends `enableAffectiveDialog` so the live voice model reads the emotion in your voice and answers in a matching tone. If voice ever fails to connect, set it to false.

## Faster voice replies
- `ScreenWatcher` was sending a screen frame every 0.4 s whenever the mic was on, which loaded the connection and the model and slowed every answer. Now: one frame every 1.5 s at most, only when the screen actually changed, never while she is thinking or speaking, smaller (640 px, quality 60). `READ_SCREEN` and `TRADE_SIGNAL` still send a fresh frame on demand.
- `VoiceActivityDetector`: end of your sentence detected after ~290 ms of quiet (was ~380 ms).
- `AudioPlayer`: low-latency audio track, smaller buffer, and "finished speaking" is noticed after 260 ms (was 380 ms); the mic wake-up wait after she speaks is 60 ms (was 100 ms).
- Voice prompt: start answering immediately, no long lead-ins.
- If it starts cutting you off mid-sentence, raise `silenceFrames` in `VoiceActivityDetector` back to 11-12. If her voice crackles, raise the AudioPlayer buffer back to `minBuf * 4`.

## Live screen watching
- Bug 1 (Android 14+): `ForegroundVoiceService` ran only with the microphone type, so `getMediaProjection()` failed and real live capture never started (it silently fell back to screenshots). It now re-enters the foreground with microphone + mediaProjection before creating the projection.
- Bug 2 (Android 14+): no `MediaProjection.Callback` was registered before capture, which also throws. Added (it stops the live capture cleanly if Android or the user ends it).
- `ScreenCaptureManager` now hands back the last frame when the screen is still, so a quiet screen still counts as live.
- New voice/typed command `SCREEN_LIVE on|off` ("screen live dekho", "dekhte thako", "ar dekho na"): `screenvision/LiveScreen.kt` asks the one-tap Android permission if needed, then `ScreenWatcher` streams about 1.4 frames a second (768 px, only when the screen changed, also while she talks). It switches itself off after 15 minutes. Normal mode stays light (one frame per 1.5 s, paused while she thinks/speaks) so replies stay fast.
- Android shows its own screen-recording/cast indicator while it is on. The prompt tells her not to read out passwords, OTPs or card numbers.
