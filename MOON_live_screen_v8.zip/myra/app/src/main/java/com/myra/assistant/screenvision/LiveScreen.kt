package com.myra.assistant.screenvision

import android.content.Context
import com.myra.assistant.services.ForegroundVoiceService

/**
 * "Live screen" switch for the voice command SCREEN_LIVE on|off.
 * On: Maya watches the screen continuously (about 1.4 frames a second, only when the screen changes) and can
 * talk about what is happening as it happens. It switches itself off after 15 minutes, and Android shows its
 * own "screen is being recorded/cast" indicator the whole time.
 */
object LiveScreen {
    fun set(context: Context, on: Boolean): String {
        val svc = ForegroundVoiceService.instance
            ?: return "Voice service chalu nei, tai screen dekhte parchi na. Age mic on koro."
        if (!on) {
            ScreenWatcher.setLive(false)
            return "Thik ache, ar live dekhchi na."
        }
        if (!svc.isMicEnabled()) {
            return "Mic off, tai live dekhte parchi na. Mic on kore abar bolo."
        }
        ScreenWatcher.setLive(true)
        ScreenWatcher.start()
        return if (svc.hasLiveScreen()) {
            "Live screen dekha shuru korlam. Ami ekhon tomar screen dekhchi."
        } else {
            ScreenCapturePermissionActivity.launch(context.applicationContext)
            "Screen dekhar permission chaichhi. Phone-e ashle 'Start now' e tap koro, tarpor live dekha shuru hobe."
        }
    }
}
