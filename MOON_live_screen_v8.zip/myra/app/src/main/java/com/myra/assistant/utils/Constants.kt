package com.myra.assistant.utils

object Constants {
    // Gemini
    const val GEMINI_MODEL = "models/gemini-3.8-live"
    const val GEMINI_CHAT_MODEL = "gemini-3.8-flash"
    const val GEMINI_WS_BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    const val GEMINI_VOICE = "Aoede"
    const val VOICE_LANGUAGE = "bn-BD"
    // sends VOICE_LANGUAGE to the live voice model so she speaks Bangla. If voice ever fails to connect, set this to false (or try "bn-IN").
    const val FORCE_VOICE_LANGUAGE = true
    // lets the live voice model read the emotion in the user's voice and answer with a matching, natural tone.
    // If voice ever fails to connect after this update, set it to false.
    const val AFFECTIVE_DIALOG = true

    // Prefs
    const val PREFS_NAME = "myra_prefs"
    const val KEY_API_KEY = "api_key"
    const val KEY_USER_NAME = "user_name"
    const val KEY_PERSONALITY = "personality"
    const val KEY_VOICE_TYPE = "voice_type"
    const val KEY_LIVE_MODE = "live_mode"
    const val KEY_PRIME_NAME = "prime_name"
    const val KEY_PRIME_NUMBER = "prime_number"
    const val KEY_CALL_ANNOUNCE = "call_announce"
    const val KEY_WAKE_WORD = "wake_word"

    // Notifications
    const val NOTIF_CHANNEL_OVERLAY = "myra_overlay_channel"
    const val NOTIF_CHANNEL_VOICE = "myra_voice_channel"
    const val NOTIF_ID_OVERLAY = 1001
    const val NOTIF_ID_VOICE = 1002

    // Audio
    const val SAMPLE_RATE_IN = 16000
    const val SAMPLE_RATE_OUT = 24000

    // Actions
    const val ACTION_SHOW_OVERLAY = "SHOW_OVERLAY"
    const val ACTION_HIDE_OVERLAY = "HIDE_OVERLAY"
    const val ACTION_TOGGLE_OVERLAY = "TOGGLE_OVERLAY"
    const val ACTION_START_LISTENING = "START_LISTENING"
    const val ACTION_STOP_LISTENING = "STOP_LISTENING"

    // Fast voice: our VAD tells Gemini when the user starts/stops, so it answers without its own silence wait
    const val MANUAL_ACTIVITY = true
    const val KEY_ANNOUNCE_EVENTS = "announce_events"

    // Voice States
    const val STATE_IDLE = "IDLE"
    const val STATE_LISTENING = "LISTENING"
    const val STATE_THINKING = "THINKING"
    const val STATE_SPEAKING = "SPEAKING"
}
